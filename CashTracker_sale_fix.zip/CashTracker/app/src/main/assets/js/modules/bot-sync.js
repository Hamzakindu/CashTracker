// BOT SYNC: sends a summary of your data to your Cloudflare Telegram bot so it can answer commands
(function(){'use strict';
window.registerModule('BotSync',function(){
const URLK='SP_bot_url',KEYK='SP_bot_key',LASTK='SP_bot_last';
const store=()=>{try{return JSON.parse(localStorage.getItem('stockProfile')||'{}').storeName||'CashTracker'}catch(e){return 'CashTracker'}};
const num=v=>Number(v)||0;
function snapshot(){
  CashBanks.init();const t=Helpers.getToday();
  const sales=(State.sales||[]).filter(s=>String(s.date||'').slice(0,10)===t&&!s.voided&&s.status!=='void');
  const exps=(State.directExpenses||[]).filter(e=>String(e.date||'').slice(0,10)===t);
  const min=p=>(p.minStock!=null&&p.minStock!=='')?num(p.minStock):5;
  const byBal=(a,b)=>b.bal-a.bal;
  return{v:1,ts:new Date().toISOString(),store:store(),
    today:{sales:sales.reduce((a,s)=>a+num(s.total),0),count:sales.length,expenses:exps.reduce((a,e)=>a+num(e.amount),0)},
    accounts:CashBanks.accounts().map(a=>({name:a.name,bal:CashBanks.balance(a.id)})),
    owed:(State.customers||[]).filter(c=>num(c.balance)>0).map(c=>({name:c.name,bal:num(c.balance)})).sort(byBal),
    owe:(State.suppliers||[]).filter(s=>num(s.balance)>0).map(s=>({name:s.name,bal:num(s.balance)})).sort(byBal),
    low:(State.products||[]).filter(p=>num(p.stock)<=min(p)).map(p=>({name:p.name,stock:num(p.stock),min:min(p)})).slice(0,60),
    products:(State.products||[]).slice(0,2000).map(p=>({id:p.id,n:p.name,p:num(p.sell),s:num(p.stock),c:p.category||'',u:p.unit||''})),
    customers:(State.customers||[]).slice(0,2000).map(c=>({n:c.name,b:num(c.balance)}))};
}
async function push(manual,unl){
  let url=(localStorage.getItem(URLK)||'').trim(),key=localStorage.getItem(KEYK)||'';
  try{url=new URL(url).origin}catch(e){url=url.replace(/\/+$/,'')}
  if(!url||!key){if(manual)Toast.warning('Enter the Worker address and the key first');return false}
  try{
    const body=JSON.stringify(snapshot());
    const o={method:'POST',headers:{'Content-Type':'application/json','X-Push-Key':key},body};
    const r=await fetch(url+'/snapshot',unl&&body.length<60000?Object.assign({keepalive:true},o):o);
    if(r.ok){localStorage.setItem(LASTK,new Date().toISOString());if(manual)Toast.success('✅ Bot data updated');setTimeout(()=>pushPhotos(url,key),500);return true}
    if(manual)Toast.error(r.status===403?'The key does not match the one in your Worker':'The Worker answered '+r.status);
    return false;
  }catch(e){if(manual)Toast.error('Could not reach the Worker ('+((e&&e.message)||'network error')+'). Open '+url+'/snapshot in your browser. It should say: CashTracker sends data here.');return false}
}
// Product photos: sent one by one (a few per run) so the shop bot can show them. Only changed photos are re-sent.
const PHK='SP_bot_photos';
const hash=s=>{let h=5381;for(let i=0;i<s.length;i+=7)h=((h<<5)+h+s.charCodeAt(i))|0;return s.length+':'+h};
let photoBusy=false;
async function pushPhotos(url,key){
  if(photoBusy||!url||!key)return;photoBusy=true;
  try{
    let done={};try{done=JSON.parse(localStorage.getItem(PHK)||'{}')}catch(e){}
    let sent=0;
    for(const p of (State.products||[])){
      if(sent>=6)break;
      let u=(p.images||[]).find(x=>String(x).indexOf('data:image')===0);if(!u)continue;
      const hsh=hash(u);if(done[p.id]===hsh)continue;
      try{if(window.Catalog&&Catalog.shrink)u=await Catalog.shrink(u,640)}catch(e){}
      if(u.length>390000){done[p.id]=hsh;continue}
      const r=await fetch(url+'/photo/'+encodeURIComponent(p.id),{method:'PUT',headers:{'Content-Type':'text/plain','X-Push-Key':key},body:u});
      if(!r.ok)break;
      done[p.id]=hsh;sent++;
    }
    localStorage.setItem(PHK,JSON.stringify(done));
    if(sent>=6)setTimeout(()=>{photoBusy=false;pushPhotos(url,key)},3000);
  }catch(e){}finally{photoBusy=false}
}
const BotSync={
  snapshot,
  push,
  lastText(){const v=localStorage.getItem(LASTK);return v?new Date(v).toLocaleString():'never'},
  save(){
    let u=(document.getElementById('botUrl')?.value||'').trim();const k=(document.getElementById('botKey')?.value||'').trim();
    if(!/^https:\/\//.test(u))return Toast.warning('The address must start with https://');
    try{u=new URL(u).origin}catch(e){return Toast.warning('That address is not valid')}
    if(k.length<12)return Toast.warning('Use a longer key (at least 12 characters)');
    localStorage.setItem(URLK,u);localStorage.setItem(KEYK,k);Toast.success('Saved');push(true).then(()=>{if(window.Tools)Tools.render()});
  },
  now(){push(true).then(()=>{if(window.Tools)Tools.render()})},
  url(){return localStorage.getItem(URLK)||''},
  key(){return localStorage.getItem(KEYK)||''},
  clear(){localStorage.removeItem(URLK);localStorage.removeItem(KEYK);Toast.success('Bot connection removed');if(window.Tools)Tools.render()}
};
window.BotSync=BotSync;
// Send to the bot soon after any change that affects prices, stock or balances
const WATCH=['products','sales','returns','purchases','customers','suppliers','supplierAdvances','paymentLedger','directExpenses','cashAccounts','moneyTransactions'];
let dirty=false,timer=null,lastAt=0;
function later(){
  dirty=true;clearTimeout(timer);
  const wait=Math.max(4000,20000-(Date.now()-lastAt));
  timer=setTimeout(flush,wait);
}
async function flush(unl){
  if(!dirty)return;
  if(!(localStorage.getItem(URLK)||'').trim()||!localStorage.getItem(KEYK))return;
  dirty=false;lastAt=Date.now();
  const ok=await push(false,!!unl||document.hidden);
  if(!ok){dirty=true;clearTimeout(timer);timer=setTimeout(flush,60000)}
}
try{
  if(window.Storage&&!Storage.__botPatched){
    const orig=Storage.save.bind(Storage);
    Storage.save=function(name,data){const ok=orig(name,data);if(ok&&WATCH.indexOf(name)>=0)later();return ok};
    Storage.__botPatched=true;
  }
}catch(e){}
setTimeout(()=>push(false),8000);
setInterval(()=>{if(!document.hidden)push(false)},10*60*1000);
// Send when the app comes back, when it goes to the background, and when the internet returns
document.addEventListener('visibilitychange',()=>{if(document.hidden){if(dirty)flush(true)}else push(false)});
window.addEventListener('pagehide',()=>{if(dirty)flush(true)});
window.addEventListener('online',()=>push(false));
return BotSync;});
})();
