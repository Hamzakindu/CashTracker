# CashTracker V8.59 — IndexedDB primary business storage

## Root cause
The previous storage implementation wrote complete business stores (including sales) to Local Storage before mirroring them to IndexedDB. Large sales records could exceed the WebView Local Storage quota and stop startup or saving.

## Changes
- IndexedDB is now the primary store for business records.
- Existing `SMDB_<profile>_*` Local Storage values are read as migration input, copied in one IndexedDB transaction, read back and verified, and only then removed from Local Storage.
- If migration or verification fails, bootstrap throws and does not intentionally delete the legacy values.
- Synchronous `Storage.save` / `saveBatch` callers now enqueue IndexedDB writes rather than writing full business records to Local Storage. Durable transaction paths continue to await `StorageIDB.flush()`.
- Removed the obsolete 4 MB per-store Local Storage size ceiling.
- First-run detection checks both the IndexedDB cache and legacy Local Storage so migrated records are not mistaken for a new installation.

## Safety limitations
This change was validated by the automated Node test suite only. It has not yet been built as an Android APK or tested against the user's installed app data. Do not uninstall, clear app data, or reset the database. Confirm the app opens and records are present before relying on this build.
