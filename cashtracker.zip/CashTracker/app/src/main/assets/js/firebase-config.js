// ============================================
// FIREBASE CONFIGURATION - STOCKPRO
// ============================================
// This is the Firebase Web app configuration for the user's CashTracker project.
// It is safe for browser use; security is enforced by Firebase Authentication
// and Firestore Security Rules, not by hiding this configuration.

window.STOCKPRO_FIREBASE_CONFIG = {
    apiKey: "AIzaSyC0EpW82u9DLrj3-nMfge2tt7o1bQwamak",
    authDomain: "stockprome.firebaseapp.com",
    projectId: "stockprome",
    storageBucket: "stockprome.firebasestorage.app",
    messagingSenderId: "220451660474",
    appId: "1:220451660474:web:67f78a071d72cb38d81883",
    measurementId: "G-NTBXPQTRK2"
};
