// ============================================
// APP.JS - COMPLETE FIXED
// ============================================

// Ensure Storage exists
if (typeof Storage === 'undefined' || typeof Storage.getSetting !== 'function') {
    console.warn('⚠️ Storage incomplete, creating fallback...');
    window.Storage = {
        getProfileId: function() { 
            try { return localStorage.getItem('currentProfileId') || 'default'; } 
            catch(e) { return 'default'; } 
        },
        getKey: function(storeName) { 
            try { return 'SMDB_' + this.getProfileId() + '_' + storeName; } 
            catch(e) { return 'SMDB_default_' + storeName; } 
        },
        save: function(storeName, data) { 
            try { localStorage.setItem(this.getKey(storeName), JSON.stringify(data)); return true; } 
            catch(e) { return false; } 
        },
        load: function(storeName) { 
            try { const raw = localStorage.getItem(this.getKey(storeName)); return raw ? JSON.parse(raw) : []; } 
            catch(e) { return []; } 
        },
        getSetting: function(key, defaultValue) { 
            try { const value = localStorage.getItem(key); return value !== null ? value : defaultValue; } 
            catch(e) { return defaultValue; } 
        },
        setSetting: function(key, value) { 
            try { localStorage.setItem(key, value); return true; } 
            catch(e) { return false; } 
        },
        remove: function(storeName) { 
            try { localStorage.removeItem(this.getKey(storeName)); return true; } 
            catch(e) { return false; } 
        }
    };
    console.log('✅ Storage fallback created');
}

// Ensure Helpers exists
if (typeof Helpers === 'undefined' || typeof Helpers.uid !== 'function') {
    console.warn('⚠️ Helpers incomplete, creating fallback...');
    window.Helpers = {
        uid: function() { return Date.now().toString(36) + Math.random().toString(36).substr(2, 9); },
        esc: function(str) { return str || ''; },
        formatCurrency: function(amount) { return 'ETB ' + (amount || 0).toFixed(2); },
        getToday: function() { return new Date().toISOString().slice(0, 10); },
        getSorted: function(arr) { return arr || []; },
        formatDate: function(dateStr) { 
            if (!dateStr) return '';
            try {
                const date = new Date(dateStr + 'T00:00:00');
                return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
            } catch(e) { return dateStr; }
        },
        downloadFile: function(content, filename) { 
            try {
                const blob = new Blob([content], { type: 'text/csv' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = filename;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            } catch(e) { console.log('Download:', filename); }
        },
        debounce: function(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        },
        sortByName: function(array) {
            return array.slice().sort((a, b) => a.name.localeCompare(b.name));
        },
        sortByRecent: function(array) {
            return array.slice().sort((a, b) => 
                new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
            );
        },
        getSorted: function(array) {
            if (!array) return [];
            const mode = localStorage.getItem('stockSortMode') || 'alphabet';
            if (mode === 'alphabet') return this.sortByName(array);
            if (mode === 'recent') return this.sortByRecent(array);
            return array;
        },
        compressImage: async function(file) {
            return new Promise((resolve, reject) => {
                try {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        try {
                            const img = new Image();
                            img.onload = function() {
                                try {
                                    let maxDim = 400;
                                    try {
                                        if (typeof CONFIG !== 'undefined' && CONFIG.IMAGE_MAX_DIMENSION) {
                                            maxDim = CONFIG.IMAGE_MAX_DIMENSION;
                                        }
                                    } catch(e) {}
                                    
                                    let compression = 0.6;
                                    try {
                                        if (typeof CONFIG !== 'undefined' && CONFIG.IMAGE_COMPRESSION) {
                                            compression = CONFIG.IMAGE_COMPRESSION;
                                        }
                                    } catch(e) {}
                                    
                                    let w = img.width, h = img.height;
                                    if (w > h) {
                                        if (w > maxDim) { h *= maxDim / w; w = maxDim; }
                                    } else {
                                        if (h > maxDim) { w *= maxDim / h; h = maxDim; }
                                    }
                                    const canvas = document.createElement('canvas');
                                    canvas.width = w;
                                    canvas.height = h;
                                    const ctx = canvas.getContext('2d');
                                    ctx.drawImage(img, 0, 0, w, h);
                                    resolve(canvas.toDataURL('image/jpeg', compression));
                                } catch(err) {
                                    reject(err);
                                }
                            };
                            img.onerror = function() {
                                reject(new Error('Failed to load image'));
                            };
                            img.src = e.target.result;
                        } catch(err) {
                            reject(err);
                        }
                    };
                    reader.onerror = function() {
                        reject(new Error('Failed to read file'));
                    };
                    reader.readAsDataURL(file);
                } catch(err) {
                    reject(err);
                }
            });
        },
        convertToInternational: function(phone) {
            if (!phone) return '';
            try {
                let cleaned = phone.replace(/[^\d+]/g, '');
                if (/^0\d{9}$/.test(cleaned)) return '+251' + cleaned.substring(1);
                if (/^\+251\d{9}$/.test(cleaned)) return cleaned;
                return cleaned;
            } catch(e) {
                return phone;
            }
        }
    };
    console.log('✅ Helpers fallback created');
}

// SP Object
const SP = {
    data: { calculations: [], currentTab: 'dashboard' },
    uid: function() { return Helpers.uid ? Helpers.uid() : Date.now().toString(36) + Math.random().toString(36).substr(2, 9); },
    fc: function(amount) { return Helpers.formatCurrency ? Helpers.formatCurrency(amount) : 'ETB ' + (amount || 0).toFixed(2); },
    esc: function(str) { return Helpers.esc ? Helpers.esc(str) : str || ''; },
    toast: function(msg, type) { if (typeof Toast !== 'undefined' && Toast.show) { Toast.show(msg, type); } else { console.log(msg); } },
    td: function() { return Helpers.getToday ? Helpers.getToday() : new Date().toISOString().slice(0, 10); },
    dl: function(content, filename) { if (Helpers.downloadFile) { Helpers.downloadFile(content, filename); } else { console.log('Download:', filename); } }
};

// ============================================
// MAIN APPLICATION - COMPLETE FIXED
// ============================================
const App = {
    async init() {
        console.log('🚀 Initializing CashTracker...');

        try {
            // STEP 1: Make sure DOM is ready
            if (document.readyState === 'loading') {
                console.log('Waiting for DOM...');
                await new Promise(resolve => {
                    document.addEventListener('DOMContentLoaded', resolve);
                });
            }

            // STEP 2: Check Storage
            console.log('Checking Storage...');
            if (typeof Storage === 'undefined' || typeof Storage.getSetting !== 'function') {
                console.warn('⚠️ Storage not ready, waiting...');
                await new Promise(resolve => {
                    let attempts = 0;
                    const checkStorage = setInterval(function() {
                        attempts++;
                        if (typeof Storage !== 'undefined' && typeof Storage.getSetting === 'function') {
                            clearInterval(checkStorage);
                            resolve();
                        } else if (attempts > 20) {
                            clearInterval(checkStorage);
                            if (typeof Storage === 'undefined') {
                                window.Storage = {
                                    getSetting: function(key, defaultValue) { return localStorage.getItem(key) || defaultValue; },
                                    setSetting: function(key, value) { localStorage.setItem(key, value); return true; },
                                    getProfileId: function() { return localStorage.getItem('currentProfileId') || 'default'; },
                                    getKey: function(storeName) { return 'SMDB_' + this.getProfileId() + '_' + storeName; },
                                    save: function(storeName, data) { localStorage.setItem(this.getKey(storeName), JSON.stringify(data)); return true; },
                                    load: function(storeName) { const raw = localStorage.getItem(this.getKey(storeName)); return raw ? JSON.parse(raw) : []; },
                                    remove: function(storeName) { localStorage.removeItem(this.getKey(storeName)); }
                                };
                            }
                            resolve();
                        }
                    }, 200);
                });
            }
            console.log('✅ Storage ready');

            // STEP 3: Load State
            console.log('Loading State...');
            if (typeof State !== 'undefined' && typeof State.init === 'function') {
                await State.init();
                if (typeof AccountingLedger !== 'undefined' && AccountingLedger.init) AccountingLedger.init();
            } else {
                await new Promise(resolve => {
                    let attempts = 0;
                    const checkState = setInterval(function() {
                        attempts++;
                        if (typeof State !== 'undefined' && typeof State.init === 'function') {
                            clearInterval(checkState);
                            resolve();
                        } else if (attempts > 20) {
                            clearInterval(checkState);
                            if (typeof State === 'undefined') {
                                window.State = {
                                    products: [],
                                    sales: [],
                                    purchases: [],
                                    customers: [{ id: 'walkin', name: 'Walk-in Customer', contact: '', address: '', balance: 0 }],
                                    suppliers: [],
                                    expenseTypes: [],
                                    directExpenses: [],
                                    returns: [],
                                    calculations: [],
                                    currentProfileId: 'default',
                                    init: function() { return Promise.resolve(); },
                                    loadAllData: function() { return Promise.resolve(); },
                                    save: function() {},
                                    saveAll: function() {}
                                };
                            }
                            resolve();
                        }
                    }, 200);
                });
                if (typeof State !== 'undefined' && typeof State.init === 'function') {
                    await State.init();
                    if (typeof AccountingLedger !== 'undefined' && AccountingLedger.init) AccountingLedger.init();
                }
            }
            console.log('State loaded:', State.products ? State.products.length : 0, 'products');

            // STEP 4: Initialize UI components
            console.log('Initializing UI...');
            if (typeof Theme !== 'undefined' && typeof Theme.init === 'function') Theme.init();
            if (typeof Modals !== 'undefined' && typeof Modals.init === 'function') Modals.init();
            
            // STEP 5: Initialize tabs
            console.log('Initializing tabs...');
            if (typeof Tabs !== 'undefined' && typeof Tabs.init === 'function') {
                Tabs.init();
            }
            
            // STEP 6: Initialize dashboard
            console.log('Initializing dashboard...');
            if (typeof Dashboard !== 'undefined' && typeof Dashboard.init === 'function') {
                Dashboard.init();
            }
            
            // STEP 7: Initialize ALL modules
            console.log('Initializing all modules...');
            
            const modules = ['Products', 'Sales', 'Purchases', 'Customers', 'Suppliers', 'Expenses', 'Returns', 'Reports',
                'AccountingLedger', 'CashBanks', 'PeopleMoney', 'Payments', 'Cashier'];
            modules.forEach(name => {
                try {
                    if (typeof window[name] !== 'undefined' && typeof window[name].init === 'function') {
                        window[name].init();
                        console.log('✅ Module initialized:', name);
                    } else {
                        console.warn('⚠️ Module not found or no init:', name);
                    }
                } catch(e) {
                    console.warn('⚠️ Error initializing', name, ':', e.message);
                }
            });
            
            // STEP 8: Initialize calculator tab content
            this.initCalculatorTab();
            
            // STEP 9: Load profile
            console.log('Loading profile...');
            if (typeof Profiles !== 'undefined' && typeof Profiles.load === 'function') {
                Profiles.load();
            }
            
            // STEP 10: Populate dropdowns
            console.log('Populating dropdowns...');
            this.populateDropdowns();
            
            // STEP 11: Render all data
            console.log('Rendering data...');
            
            if (typeof Dashboard !== 'undefined' && typeof Dashboard.update === 'function') {
                Dashboard.update();
            }
            
            if (typeof Products !== 'undefined' && typeof Products.render === 'function') {
                Products.render();
            }
            
            if (typeof Sales !== 'undefined' && typeof Sales.render === 'function') {
                Sales.render();
            }
            
            if (typeof Purchases !== 'undefined' && typeof Purchases.render === 'function') {
                Purchases.render();
            }
            
            if (typeof Customers !== 'undefined' && typeof Customers.render === 'function') {
                Customers.render();
            }
            
            if (typeof Suppliers !== 'undefined' && typeof Suppliers.render === 'function') {
                Suppliers.render();
            }
            
            if (typeof Expenses !== 'undefined') {
                if (typeof Expenses.renderTypes === 'function') Expenses.renderTypes();
                if (typeof Expenses.renderDirect === 'function') Expenses.renderDirect();
            }
            
            if (typeof Returns !== 'undefined' && typeof Returns.render === 'function') {
                Returns.render();
            }
            
            // STEP 12: Start services
            console.log('Starting services...');
            this.startDateTimeUpdates();
            this.loadBackupSettings();
            this.startDailyReportCheck();
            
            // STEP 13: Update displays
            if (typeof TelegramModule !== 'undefined' && typeof TelegramModule.updateStatus === 'function') {
                TelegramModule.updateStatus();
            }
            if (typeof EthiopianDate !== 'undefined' && typeof EthiopianDate.updateDisplay === 'function') {
                EthiopianDate.updateDisplay();
            }
            
            // STEP 14: Setup hamburger menu
            console.log('Setting up hamburger menu...');
            this.setupHamburgerMenu();
            
            // STEP 15: Ensure first tab is active
            this.ensureFirstTabActive();
            
            console.log('✅ CashTracker initialized successfully');
            if (typeof Toast !== 'undefined' && typeof Toast.info === 'function') {
                Toast.info('📂 ' + State.currentProfileId + ' loaded', 1500);
            }
            
        } catch (error) {
            console.error('❌ Init error:', error);
            console.error('Stack:', error.stack);
            if (typeof Toast !== 'undefined' && typeof Toast.error === 'function') {
                Toast.error('Init error: ' + error.message);
            }
        }
    },

    ensureFirstTabActive() {
        try {
            const activeTab = document.querySelector('.tab-btn.active');
            if (!activeTab) {
                const defaultTab = document.querySelector('.tab-btn[data-tab="dashboard"]');
                if (defaultTab) {
                    defaultTab.classList.add('active');
                    const pane = document.getElementById('tab-dashboard');
                    if (pane) {
                        pane.classList.add('active');
                        if (typeof Tabs !== 'undefined') {
                            Tabs.currentTab = 'dashboard';
                        }
                    }
                }
            }
        } catch(e) {
            console.warn('ensureFirstTabActive error:', e);
        }
    },

    // ============================================
    // TAB CONTENT INITIALIZATION
    // ============================================
    
    initCalculatorTab() {
        try {
            const container = document.getElementById('tab-calculator');
            if (!container) return;
            
            if (container.innerHTML.trim() === '') {
                if (typeof initCalcTab === 'function') {
                    initCalcTab();
                } else {
                    container.innerHTML = `
                        <div class="card">
                            <div class="card-title">🔢 Calculator</div>
                            <p style="margin:10px 0;">Calculator module loading...</p>
                            <button class="btn btn-primary" onclick="window.open('calculator-home.html', '_blank')">
                                🖥️ Open Standalone Calculator
                            </button>
                        </div>
                    `;
                }
            }
        } catch(e) {
            console.warn('initCalculatorTab error:', e);
        }
    },

    initExpensesTab() {
        try {
            const container = document.getElementById('tab-expenses');
            if (!container) return;
            
            if (container.innerHTML.trim() === '') {
                container.innerHTML = `
                    <div class="card">
                        <div class="flex-between">
                            <div class="card-title">💸 Expense Types</div>
                            <button class="btn btn-success btn-sm" onclick="Expenses.openTypeModal()">➕ Add</button>
                        </div>
                        <div id="expenseList"></div>
                    </div>
                    <div class="card">
                        <div class="flex-between">
                            <span class="card-title">📋 Recorded Expenses</span>
                            <button class="btn btn-success btn-sm" onclick="Expenses.openDirectModal()">➕ New</button>
                        </div>
                        <div id="directExpenseList"></div>
                    </div>
                `;
            }
        } catch(e) {
            console.warn('initExpensesTab error:', e);
        }
    },

    initReturnsTab() {
        try {
            const container = document.getElementById('tab-returns');
            if (!container) return;
            
            if (container.innerHTML.trim() === '') {
                container.innerHTML = `
                    <div class="card">
                        <div class="flex-between">
                            <div class="card-title">↩️ Returns</div>
                            <button class="btn btn-warning btn-sm" onclick="Returns.openModal()">➕ New Return</button>
                        </div>
                        <div id="returnList"></div>
                    </div>
                `;
            }
        } catch(e) {
            console.warn('initReturnsTab error:', e);
        }
    },

    initReportsTab() {
        try {
            const container = document.getElementById('tab-reports');
            if (!container) return;
            
            if (container.innerHTML.trim() === '') {
                container.innerHTML = `
                    <div class="card">
                        <div class="card-title">📈 Generate Report</div>
                        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;">
                            <div class="form-group">
                                <label>From</label>
                                <input class="form-control" type="date" id="reportFromDate">
                            </div>
                            <div class="form-group">
                                <label>To</label>
                                <input class="form-control" type="date" id="reportToDate">
                            </div>
                        </div>
                        <div id="ethiopianDateDisplay" class="eth-date-display"></div>
                        <div style="display:flex;flex-wrap:wrap;gap:10px;margin:10px 0;font-size:0.85rem;">
                            <label><input type="checkbox" id="repSales" checked> Sales</label>
                            <label><input type="checkbox" id="repSalesByPrice"> Sales by Product &amp; Price</label>
                            <label><input type="checkbox" id="repPurchases" checked> Purchases</label>
                            <label><input type="checkbox" id="repReturns" checked> Returns</label>
                            <label><input type="checkbox" id="repExpenses" checked> Expenses</label>
                            <label><input type="checkbox" id="repCustomers"> Customers</label>
                            <label><input type="checkbox" id="repSuppliers"> Suppliers</label>
                            <label><input type="checkbox" id="repProducts"> Products</label>
                        </div>
                        <button class="btn btn-primary" onclick="Reports.generate()">🔍 Generate</button>
                        <button class="btn btn-outline" onclick="Reports.exportCSV()" style="margin-left:8px;">📤 CSV</button>
                        <div id="reportOutput" style="margin-top:16px;"></div>
                    </div>
                `;
            }
        } catch(e) {
            console.warn('initReportsTab error:', e);
        }
    },

    // ============================================
    // DROPDOWNS
    // ============================================
    
    populateDropdowns() {
        try {
            if (typeof Helpers === 'undefined' || typeof State === 'undefined') {
                console.warn('⚠️ Helpers or State not available for dropdowns');
                return;
            }
            
            const getSorted = function(arr) {
                if (!arr) return [];
                if (typeof Helpers.getSorted === 'function') {
                    return Helpers.getSorted(arr);
                }
                return arr;
            };
            
            const sortedProducts = getSorted(State.products || []);
            const sortedCustomers = getSorted(State.customers || []);
            const sortedSuppliers = getSorted(State.suppliers || []);

            // Customer dropdown
            const sellCustomer = document.getElementById('sellCustomerId');
            if (sellCustomer) {
                sellCustomer.innerHTML = '<option value="">-- Select --</option>';
                sortedCustomers.forEach(c => { const option=document.createElement('option'); option.value=c.id; option.textContent=c.name; sellCustomer.appendChild(option); });
                const dl=document.getElementById('sellCustomerOptions'); if(dl){dl.innerHTML=''; sortedCustomers.forEach(c=>{const o=document.createElement('option');o.value=c.name;o.label=c.contact||'';dl.appendChild(o);});}
            }

            // Supplier dropdown
            const purchaseSupplier = document.getElementById('purchaseSupplier');
            if (purchaseSupplier) {
                purchaseSupplier.innerHTML = '<option value="">-- Select --</option>';
                sortedSuppliers.forEach(s => { const option=document.createElement('option'); option.value=s.id; option.textContent=s.name; purchaseSupplier.appendChild(option); });
                const sdl=document.getElementById('purchaseSupplierOptions'); if(sdl){sdl.innerHTML=''; sortedSuppliers.forEach(x=>{const o=document.createElement('option');o.value=x.name;o.label=x.contact||'';sdl.appendChild(o);});}
            }

            // Expense type dropdowns
            const expenseSelects = ['sellExpenseId', 'directExpenseTypeId'];
            expenseSelects.forEach(selectId => {
                const select = document.getElementById(selectId);
                if (select) {
                    select.innerHTML = '<option value="">-- None --</option>';
                    (State.expenseTypes || []).forEach(e => {
                        const option = document.createElement('option');
                        option.value = e.id;
                        option.textContent = e.name;
                        select.appendChild(option);
                    });
                }
            });

            // Return product dropdown
            const returnProduct = document.getElementById('returnProductId');
            if (returnProduct) {
                returnProduct.innerHTML = '<option value="">-- Select --</option>';
                sortedProducts.forEach(p => {
                    const option = document.createElement('option');
                    option.value = p.id;
                    option.textContent = p.name + ' (' + (p.stock || 0) + ')';
                    returnProduct.appendChild(option);
                });
            }

            if (typeof Profiles !== 'undefined' && typeof Profiles.updateProfileSelector === 'function') {
                Profiles.updateProfileSelector();
            }
        } catch (error) {
            console.warn('populateDropdowns error:', error);
        }
    },

    // ============================================
    // HAMBURGER MENU
    // ============================================
    
    setupHamburgerMenu() {
        console.log('🍔 Setting up hamburger menu (WebView hardened)...');

        try {
            const hamburger = document.getElementById('hamburgerBtn');
            const dropdown = document.getElementById('optionsDropdown');

            if (!hamburger || !dropdown) {
                console.warn('⚠️ Hamburger/dropdown not found');
                return;
            }

            // Android WebView can clip descendants of the header because
            // .header uses overflow:hidden. Move the menu to <body>.
            if (dropdown.parentElement !== document.body) {
                document.body.appendChild(dropdown);
            }
            document.body.classList.add('stockpro-menu-portal-ready');

            // Remove prior App-managed handlers without cloning the DOM.
            if (hamburger._stockProMenuHandler) {
                hamburger.removeEventListener('click', hamburger._stockProMenuHandler);
            }
            if (document._stockProMenuOutsideHandler) {
                document.removeEventListener('click', document._stockProMenuOutsideHandler);
            }
            if (document._stockProMenuKeyHandler) {
                document.removeEventListener('keydown', document._stockProMenuKeyHandler);
            }

            const toggle = function(e) {
                if (e) e.stopPropagation();
                if (e) e.preventDefault();

                const open = !dropdown.classList.contains('show');
                dropdown.classList.toggle('show', open);
                hamburger.classList.toggle('active', open);
                document.body.classList.toggle('stockpro-menu-portal-open', open);

                if (open) {
                    // Re-assert visibility after WebView layout.
                    requestAnimationFrame(() => {
                        dropdown.style.visibility = 'visible';
                        dropdown.style.opacity = '1';
                    });
                } else {
                    dropdown.style.removeProperty('visibility');
                    dropdown.style.removeProperty('opacity');
                }
            };

            hamburger._stockProMenuHandler = toggle;
            hamburger.addEventListener('click', toggle, { passive: false });

            const outside = function(e) {
                if (!hamburger.contains(e.target) && !dropdown.contains(e.target)) {
                    dropdown.classList.remove('show');
                    hamburger.classList.remove('active');
                    document.body.classList.remove('stockpro-menu-portal-open');
                }
            };
            document._stockProMenuOutsideHandler = outside;
            document.addEventListener('click', outside, false);

            const keyHandler = function(e) {
                if (e.key === 'Escape') {
                    dropdown.classList.remove('show');
                    hamburger.classList.remove('active');
                    document.body.classList.remove('stockpro-menu-portal-open');
                }
            };
            document._stockProMenuKeyHandler = keyHandler;
            document.addEventListener('keydown', keyHandler, false);

            this.setupDropdownControls();
            console.log('✅ WebView-hardened hamburger menu ready');
        } catch (e) {
            console.warn('setupHamburgerMenu error:', e);
        }
    },

    setupDropdownControls() {
        try {
            const fontSizeSelect = document.getElementById('fontSizeSelect');
            if (fontSizeSelect) {
                fontSizeSelect.addEventListener('change', function() {
                    if (typeof Theme !== 'undefined' && typeof Theme.changeFontSize === 'function') {
                        Theme.changeFontSize(this.value);
                    }
                });
            }

            const fontStyleSelect = document.getElementById('fontStyleSelect');
            if (fontStyleSelect) {
                fontStyleSelect.addEventListener('change', function() {
                    if (typeof Theme !== 'undefined' && typeof Theme.changeFontStyle === 'function') {
                        Theme.changeFontStyle(this.value);
                    }
                });
            }

            const sortModeSelect = document.getElementById('globalSortMode');
            if (sortModeSelect) {
                sortModeSelect.addEventListener('change', function() {
                    App.changeSortMode(this.value);
                });
            }

            const profileSwitcher = document.getElementById('profileSwitcher');
            if (profileSwitcher) {
                profileSwitcher.addEventListener('change', function() {
                    if (typeof Profiles !== 'undefined' && typeof Profiles.switchProfile === 'function') {
                        Profiles.switchProfile(this.value);
                    }
                });
            }
        } catch(e) {
            console.warn('setupDropdownControls error:', e);
        }
    },

    // ============================================
    // SERVICES
    // ============================================
    
    changeSortMode(mode) {
        try {
            if (typeof State === 'undefined') return;
            State.sortMode = mode;
            if (typeof Storage !== 'undefined' && typeof Storage.setSetting === 'function') {
                Storage.setSetting('stockSortMode', mode);
            }
            this.populateDropdowns();
            if (typeof Tabs !== 'undefined' && Tabs.currentTab) {
                if (Tabs.currentTab === 'products' && typeof Products !== 'undefined' && typeof Products.render === 'function') {
                    Products.render();
                }
                if (Tabs.currentTab === 'customers' && typeof Customers !== 'undefined' && typeof Customers.render === 'function') {
                    Customers.render();
                }
                if (Tabs.currentTab === 'suppliers' && typeof Suppliers !== 'undefined' && typeof Suppliers.render === 'function') {
                    Suppliers.render();
                }
            }
            if (typeof Toast !== 'undefined' && typeof Toast.info === 'function') {
                Toast.info('Sort: ' + mode, 1000);
            }
        } catch(e) {
            console.warn('changeSortMode error:', e);
        }
    },

    refreshAll() {
        try {
            if(typeof Dashboard!=='undefined'&&Dashboard.update) Dashboard.update();
            if(typeof Sales!=='undefined'&&Sales.render) Sales.render();
            if(typeof Purchases!=='undefined'&&Purchases.render) Purchases.render();
            if(typeof CashBanks!=='undefined'&&CashBanks.render) CashBanks.render();
            if(typeof Cashier!=='undefined'&&Cashier.render) Cashier.render();
            if(typeof FinanceControl!=='undefined'&&FinanceControl.render) FinanceControl.render();
            if(typeof Reports!=='undefined'&&Reports.render) Reports.render();
            if(typeof I18n!=='undefined') setTimeout(()=>I18n.translatePage(),50);
        } catch(e){ console.warn('refreshAll error:',e); }
    },

    toggleDailyAutoReport() {
        try {
            if (typeof State === 'undefined') return;
            State.dailyAutoReport = !State.dailyAutoReport;
            if (typeof Storage !== 'undefined' && typeof Storage.setSetting === 'function') {
                Storage.setSetting('dailyAutoReport', State.dailyAutoReport.toString());
            }
            const statusEl = document.getElementById('dailyReportStatus');
            if (statusEl) statusEl.textContent = State.dailyAutoReport ? '✅ ON' : '❌ OFF';
            if (typeof Toast !== 'undefined' && typeof Toast.info === 'function') {
                Toast.info(State.dailyAutoReport ? '✅ Daily auto-report ON' : '⏸️ Daily auto-report OFF');
            }
        } catch(e) {
            console.warn('toggleDailyAutoReport error:', e);
        }
    },

    undo() {
        try {
            if (typeof State === 'undefined' || typeof State.undo !== 'function') return;
            if (State.undo()) {
                this.populateDropdowns();
                if (typeof Dashboard !== 'undefined' && typeof Dashboard.update === 'function') Dashboard.update();
                if (typeof Products !== 'undefined' && typeof Products.render === 'function') Products.render();
                if (typeof Sales !== 'undefined' && typeof Sales.render === 'function') Sales.render();
                if (typeof Purchases !== 'undefined' && typeof Purchases.render === 'function') Purchases.render();
                if (typeof Customers !== 'undefined' && typeof Customers.render === 'function') Customers.render();
                if (typeof Suppliers !== 'undefined' && typeof Suppliers.render === 'function') Suppliers.render();
                if (typeof Expenses !== 'undefined') {
                    if (typeof Expenses.renderTypes === 'function') Expenses.renderTypes();
                    if (typeof Expenses.renderDirect === 'function') Expenses.renderDirect();
                }
                if (typeof Returns !== 'undefined' && typeof Returns.render === 'function') Returns.render();
            }
        } catch(e) {
            console.warn('undo error:', e);
        }
    },

    startDateTimeUpdates() {
        const updateDateTime = () => {
            try {
                const now = new Date();
                const time = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                const date = now.toLocaleDateString('en-US', { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' });
                let ethDateStr = '';
                if (typeof EthiopianDate !== 'undefined' && typeof EthiopianDate.getCurrent === 'function') {
                    const ethDate = EthiopianDate.getCurrent();
                    ethDateStr = ethDate.formattedShort + ' ዓ.ም';
                }
                const html = `<span style="color:var(--text2);">${date}</span><span style="color:var(--text);">${time}</span><span class="ethiopian-date">${ethDateStr}</span>`;
                const dt1 = document.getElementById('headerDateTime');
                const dt2 = document.getElementById('headerDateTime2');
                if (dt1) dt1.innerHTML = html;
                if (dt2) dt2.innerHTML = html;
            } catch(e) {
                console.warn('updateDateTime error:', e);
            }
        };
        updateDateTime();
        setInterval(updateDateTime, 1000);
    },

    loadBackupSettings() {
        try {
            if (typeof Storage === 'undefined' || typeof Storage.getSetting !== 'function') return;
            
            const enabled = Storage.getSetting('autoBackupEnabled', 'enabled');
            const freq = Storage.getSetting('autoBackupFrequency', '24');
            const enabledEl = document.getElementById('autoBackupEnabled');
            const freqEl = document.getElementById('autoBackupFrequency');
            const statusEl = document.getElementById('dailyReportStatus');
            
            if (enabledEl) enabledEl.value = enabled;
            if (freqEl) freqEl.value = freq;
            if (statusEl) {
                statusEl.textContent = (typeof State !== 'undefined' && State.dailyAutoReport) ? '✅ ON' : '❌ OFF';
            }
            
            if (enabled === 'enabled' && typeof Backup !== 'undefined' && typeof Backup.startAuto === 'function') {
                Backup.startAuto();
            }
            
            const lastBackup = Storage.getSetting('labt');
            if (lastBackup) {
                const el = document.getElementById('lastAutoBackup');
                if (el) el.textContent = new Date(lastBackup).toLocaleString();
            }
        } catch(e) {
            console.warn('loadBackupSettings error:', e);
        }
    },

    startDailyReportCheck() {
        try {
            const checkReport = () => {
                try {
                    if (typeof State === 'undefined' || !State.dailyAutoReport) return;
                    if (typeof Storage === 'undefined' || typeof Storage.getSetting !== 'function') return;
                    if (typeof EthiopianDate === 'undefined') return;
                    
                    const now = new Date();
                    const hour = now.getHours();
                    let date = hour < 18 ? new Date(now.setDate(now.getDate() - 1)).toISOString().slice(0, 10) : now.toISOString().slice(0, 10);
                    const lastReport = Storage.getSetting('ldr');
                    
                    if (lastReport !== date) {
                        const ethDate = EthiopianDate.gregorianToEthiopian(date);
                        const dailySales = State.activeSales().filter(s => s.date === date);
                        const total = dailySales.reduce((sum, s) => sum + (s.total || 0), 0);
                        const profit = dailySales.reduce((sum, s) => sum + (s.profit || 0), 0);
                        const expenses = (State.directExpenses || []).filter(e => e.date === date).reduce((sum, e) => sum + (e.amount || 0), 0);
                        const report = { id: 'dr_' + date, date, ethDate: ethDate.formattedShort, totalSales: total, totalProfit: profit, totalExpenses: expenses, netIncome: profit - expenses };
                        Storage.setSetting('dr_' + date, JSON.stringify(report));
                        Storage.setSetting('ldr', date);
                        if (typeof Toast !== 'undefined' && typeof Toast.info === 'function') {
                            Toast.info(`📊 Daily Auto-Report\n${ethDate.formattedShort}\nSales: ETB ${total.toFixed(2)}\nProfit: ETB ${profit.toFixed(2)}`, 5000);
                        }
                    }
                } catch(e) {
                    console.warn('checkReport error:', e);
                }
            };
            setInterval(checkReport, 3600000);
            setTimeout(checkReport, 5000);
        } catch(e) {
            console.warn('startDailyReportCheck error:', e);
        }
    },

    async reload() {
        try {
            if (typeof State !== 'undefined' && typeof State.loadAllData === 'function') {
                await State.loadAllData();
            }
            this.populateDropdowns();
            if (typeof Dashboard !== 'undefined' && typeof Dashboard.update === 'function') Dashboard.update();
            if (typeof Products !== 'undefined' && typeof Products.render === 'function') Products.render();
            if (typeof Sales !== 'undefined' && typeof Sales.render === 'function') Sales.render();
            if (typeof Purchases !== 'undefined' && typeof Purchases.render === 'function') Purchases.render();
            if (typeof Customers !== 'undefined' && typeof Customers.render === 'function') Customers.render();
            if (typeof Suppliers !== 'undefined' && typeof Suppliers.render === 'function') Suppliers.render();
            if (typeof Expenses !== 'undefined') {
                if (typeof Expenses.renderTypes === 'function') Expenses.renderTypes();
                if (typeof Expenses.renderDirect === 'function') Expenses.renderDirect();
            }
            if (typeof Returns !== 'undefined' && typeof Returns.render === 'function') Returns.render();
            if (typeof renderCalcHistory === 'function') renderCalcHistory();
        } catch(error) {
            console.error('Reload error:', error);
        }
    }
};

// ============================================
// EXPOSE GLOBALLY
// ============================================
window.Tabs = Tabs;
window.Modals = Modals;
window.Theme = Theme;
window.Toast = Toast;
window.Products = Products;
window.Sales = Sales;
window.Purchases = Purchases;
window.Customers = Customers;
window.Suppliers = Suppliers;
window.Payments = Payments;
window.Backup = Backup;
window.Profiles = Profiles;
window.TelegramModule = TelegramModule;
window.Expenses = Expenses;
window.Returns = Returns;
window.Reports = Reports;
window.App = App;
window.EthiopianDate = EthiopianDate;
window.Helpers = Helpers;
window.State = State;
window.Storage = Storage;

// ============================================
// START APPLICATION
// ============================================
if (document.readyState === 'complete' || document.readyState === 'interactive') {
    setTimeout(function() { App.init(); }, 200);
} else {
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(function() { App.init(); }, 200);
    });
}