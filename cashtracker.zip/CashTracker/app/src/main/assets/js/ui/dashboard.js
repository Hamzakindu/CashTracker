// ============================================
// DASHBOARD UI - COMPLETE FIXED WITH NULL CHECKS
// ============================================

const Dashboard = {
    init() {
        console.log('📊 Dashboard init...');
        const container = document.getElementById('tab-dashboard');
        if (!container) {
            console.error('❌ Dashboard container not found!');
            return;
        }

        container.innerHTML = `
            <div class="stats-grid" id="statsGrid">
                <div class="stat-card" onclick="Tabs.switchTo('products')">
                    <div class="stat-value" id="totalProducts">0</div>
                    <div class="stat-label">Products</div>
                </div>
                <div class="stat-card" onclick="Tabs.switchTo('products')">
                    <div class="stat-value" id="totalStock">0</div>
                    <div class="stat-label">Total Stock</div>
                </div>
                <div class="stat-card" onclick="Tabs.switchTo('sales')">
                    <div class="stat-value" id="totalProfit">0</div>
                    <div class="stat-label">Total Profit</div>
                </div>
                <div class="stat-card" onclick="Tabs.switchTo('sales')">
                    <div class="stat-value" id="todayRevenue">0</div>
                    <div class="stat-label">Today Revenue</div>
                </div>
                <div class="stat-card" onclick="Tabs.switchTo('purchases')">
                    <div class="stat-value" id="totalPurchases">0</div>
                    <div class="stat-label">Purchases</div>
                </div>
                <div class="stat-card" onclick="Tabs.switchTo('customers')">
                    <div class="stat-value" id="customerDebit">0</div>
                    <div class="stat-label">Customer Debit</div>
                </div>
                <div class="stat-card" onclick="Tabs.switchTo('suppliers')">
                    <div class="stat-value" id="supplierDebit">0</div>
                    <div class="stat-label">Supplier Debit</div>
                </div>
                <div class="stat-card" onclick="Tabs.switchTo('cashbanks')">
                    <div class="stat-value" id="cashAvailable">0</div>
                    <div class="stat-label">Cash Available</div>
                </div>
                <div class="stat-card" onclick="Tabs.switchTo('cashbanks')">
                    <div class="stat-value" id="bankAvailable">0</div>
                    <div class="stat-label">Bank Available</div>
                </div>
                <div class="stat-card" onclick="Tabs.switchTo('cashbanks')">
                    <div class="stat-value" id="moneyAvailable">0</div>
                    <div class="stat-label">Total Money</div>
                </div>
            </div>
            
            <div class="calculator-home-card" onclick="Tabs.switchTo('calculator')">
                <div class="calculator-home-content">
                    <div class="calculator-home-icon">🧮</div>
                    <div class="calculator-home-info">
                        <div class="calculator-home-title">Quick Calculator</div>
                        <div class="calculator-home-subtitle">Calculate prices, discounts & more</div>
                    </div>
                    <div class="calculator-home-arrow">➜</div>
                </div>
                <div class="calculator-home-preview" id="homeCalcPreview">
                    <span class="preview-query">0</span>
                    <span class="preview-result">= 0</span>
                </div>
            </div>
            
            <div class="card">
                <div class="card-title">🛒 Quick Actions</div>
                <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                    <button class="btn btn-success btn-sm" onclick="Sales.openSellModal()">💰 Quick Sell</button>
                    <button class="btn btn-danger btn-sm" onclick="Expenses.recordExclusive()">💸 Expense</button>
                    <button class="btn btn-info btn-sm" onclick="Reports.generateDailyFull()">📊 Daily Report</button>
                    <button class="btn btn-sm" onclick="Tabs.switchTo('calculator')" style="background:#6f42c1;color:#fff;">🔢 Calculator</button>
                    <button class="btn btn-primary btn-sm" onclick="Backup.exportBackup()" style="background:#0d6efd;color:#fff;">📤 Export All</button>
                </div>
            </div>
            
            <div class="card">
                <div class="card-title">📋 Recent Sales</div>
                <div id="recentSalesList"></div>
            </div>
            
            <div class="card">
                <div class="card-title">⚠️ Low Stock</div>
                <div id="lowStockList"></div>
            </div>
            <div class="card" id="negativeStockAlert" style="display:none;border:2px solid var(--danger);">
                <div class="card-title">🚨 Negative Stock Alert</div><div id="negativeStockList"></div>
            </div>
        `;
        
        console.log('✅ Dashboard HTML rendered');
        setTimeout(() => this.update(), 100);
    },

    update() {
        console.log('📊 Updating Dashboard stats...');
        
        // Helper to safely update element
        const updateElement = (id, value) => {
            const el = document.getElementById(id);
            if (el) {
                el.textContent = value;
                return true;
            }
            return false;
        };
        
        try {
            if (typeof State === 'undefined' || !State.products) {
                console.warn('⚠️ State not available yet');
                setTimeout(() => this.update(), 500);
                return;
            }
            
            const products = State.products || [];
            const sales = State.sales || [];
            const purchases = State.purchases || [];
            const customers = State.customers || [];
            const suppliers = State.suppliers || [];
            const directExpenses = State.directExpenses || [];
            
            updateElement('totalProducts', products.length);
            
            const totalStock = products.reduce((s, p) => s + (p.stock || 0), 0);
            updateElement('totalStock', totalStock);
            
            const salesProfit = sales.reduce((s, sl) => s + (sl.profit || 0), 0);
            const expenses = directExpenses.reduce((s, d) => s + (d.amount || 0), 0);
            const totalProfit = salesProfit - expenses;
            updateElement('totalProfit', 'ETB ' + totalProfit.toFixed(2));
            
            const today = new Date().toISOString().slice(0, 10);
            const todayRevenue = sales.filter(s => s.date === today).reduce((s, sl) => s + (sl.total || 0), 0);
            updateElement('todayRevenue', 'ETB ' + todayRevenue.toFixed(2));
            
            const totalPurchases = purchases.reduce((s, p) => s + (p.total || 0), 0);
            updateElement('totalPurchases', 'ETB ' + totalPurchases.toFixed(2));
            
            const customerDebit = customers.reduce((s, c) => s + ((c.balance || 0) > 0 ? c.balance : 0), 0);
            updateElement('customerDebit', 'ETB ' + customerDebit.toFixed(2));
            
            const supplierDebit = suppliers.reduce((s, sp) => s + ((sp.balance || 0) > 0 ? sp.balance : 0), 0);
            updateElement('supplierDebit', 'ETB ' + supplierDebit.toFixed(2));

            if (typeof CashBanks !== 'undefined') {
                CashBanks.init();
                const money = CashBanks.totals();
                updateElement('cashAvailable', 'ETB ' + money.cash.toFixed(2));
                updateElement('bankAvailable', 'ETB ' + money.bank.toFixed(2));
                updateElement('moneyAvailable', 'ETB ' + money.total.toFixed(2));
            }

            this.updateRecentSales();
            this.updateLowStock();
            this.updateNegativeStock();
            
            console.log('✅ Dashboard stats updated');
            
        } catch (error) {
            console.error('❌ Error updating dashboard:', error);
        }
    },

    updateRecentSales() {
        const recentSalesEl = document.getElementById('recentSalesList');
        if (!recentSalesEl) return;
        
        try {
            const sales = State.sales || [];
            const recent = sales
                .slice()
                .sort((a, b) => {
                    const dateA = a.createdAt || a.date || '1970-01-01';
                    const dateB = b.createdAt || b.date || '1970-01-01';
                    return new Date(dateB).getTime() - new Date(dateA).getTime();
                })
                .slice(0, 5);
            
            if (recent.length === 0) {
                recentSalesEl.innerHTML = '<div class="empty-state">No sales recorded yet</div>';
                return;
            }
            
            recentSalesEl.innerHTML = recent.map(s => {
                const items = (s.items || []).map(i => (i.productName || 'Unknown') + ' x' + i.quantity).join(', ');
                const total = s.total || 0;
                return `
                    <div class="list-item" onclick="showDetail('sale', '${s.id}')" style="cursor:pointer;">
                        <div>${items}</div>
                        <div style="font-weight:600;">ETB ${total.toFixed(2)}</div>
                    </div>
                `;
            }).join('');
            
        } catch (e) {
            console.warn('Error updating recent sales:', e);
            recentSalesEl.innerHTML = '<div class="empty-state">Error loading sales</div>';
        }
    },

    updateNegativeStock() {
        const box=document.getElementById('negativeStockAlert'), list=document.getElementById('negativeStockList'); if(!box||!list)return;
        const bad=(State.products||[]).filter(p=>!p.archived&&(Number(p.stock)||0)<0);
        box.style.display=bad.length?'block':'none';
        list.innerHTML=bad.map(p=>`<div class="list-item" onclick="showDetail('product','${p.id}')"><div>${Helpers.esc(p.name)}</div><strong style="color:var(--danger)">${p.stock}</strong></div>`).join('');
    },

    updateLowStock() {
        const lowStockEl = document.getElementById('lowStockList');
        if (!lowStockEl) return;
        
        try {
            const products = State.products || [];
            // V5.7: respect per-product minStock (default 5)
            const lowStock = products.filter(p => {
                const min = (p.minStock != null && p.minStock !== '') ? Number(p.minStock) : 5;
                return (p.stock || 0) <= min;
            }).sort((a, b) => (a.stock || 0) - (b.stock || 0));
            
            if (lowStock.length === 0) {
                lowStockEl.innerHTML = '<div class="empty-state">All products have good stock ✅</div>';
                return;
            }
            
            lowStockEl.innerHTML = lowStock.map(p => {
                const stock = p.stock || 0;
                const min = (p.minStock != null && p.minStock !== '') ? Number(p.minStock) : 5;
                let badgeClass = 'stock-low';
                let label = '⚠️ Low';
                if (stock <= 0) {
                    badgeClass = 'stock-out';
                    label = '❌ Out';
                }
                return `
                    <div class="list-item" onclick="showDetail('product', '${p.id}')" style="cursor:pointer;">
                        <div>${Helpers.esc(p.name)}${p.barcode ? ' <small style="opacity:.6">('+Helpers.esc(p.barcode)+')</small>' : ''}</div>
                        <div class="stock-badge ${badgeClass}">${label} (${stock}/${min})</div>
                    </div>
                `;
            }).join('');
            
        } catch (e) {
            console.warn('Error updating low stock:', e);
            lowStockEl.innerHTML = '<div class="empty-state">No products available</div>';
        }
    }
};