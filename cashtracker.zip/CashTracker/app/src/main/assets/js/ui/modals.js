// ============================================
// MODAL MANAGEMENT + 30-MINUTE ENTRY DRAFTS
// ============================================
// Entry forms remember the last values entered for up to 30 minutes.
// This is profile-specific and only applies to new-entry forms; edit/detail
// forms are intentionally excluded so existing records are never overwritten.
const EntryDrafts = {
    TTL: 30 * 60 * 1000,
    keyPrefix: 'CashTracker_entryDraft_',
    modalIds: new Set([
        'sellModal','purchaseModal','directExpenseModal','returnModal',
        'paymentModal','customerModal','supplierModal','expenseModal','pmPersonModal','pmTxModal','cashAccountModal',
        'cashMovementModal','adjustBalanceModal','reorderModal'
    ]),

    profileKey() {
        try { return (typeof Storage !== 'undefined' && Storage.getProfileId) ? Storage.getProfileId() : (localStorage.getItem('currentProfileId') || 'default'); }
        catch(e) { return 'default'; }
    },

    storageKey(id) {
        return this.keyPrefix + this.profileKey() + '_' + id;
    },

    shouldRemember(id) {
        return this.modalIds.has(id);
    },

    controls(root) {
        if (!root) return [];
        return Array.from(root.querySelectorAll('input:not([type="file"]):not([type="hidden"]), select, textarea'))
            .filter(el => !el.disabled && !el.readOnly && !el.closest('[data-no-entry-draft]'));
    },

    serialize(root) {
        const fields = {};
        this.controls(root).forEach((el, index) => {
            const key = el.id || ('__index_' + index);
            if (el.type === 'checkbox' || el.type === 'radio') fields[key] = { type: el.type, checked: !!el.checked };
            else fields[key] = { type: el.type || el.tagName.toLowerCase(), value: el.value };
        });

        // Preserve repeated sale/purchase item rows as well.
        const rows = {};
        ['.sell-item-row', '.purchase-item-row'].forEach(selector => {
            const found = Array.from(root.querySelectorAll(selector));
            if (found.length) {
                rows[selector] = found.map(row => Array.from(row.querySelectorAll('input,select,textarea')).map(el => ({
                    className: el.className || '',
                    type: el.type || el.tagName.toLowerCase(),
                    value: el.value,
                    checked: !!el.checked
                })));
            }
        });

        return { savedAt: Date.now(), fields, rows };
    },

    save(id) {
        if (!this.shouldRemember(id)) return;
        const modal = document.getElementById(id);
        if (!modal) return;
        // Do not save an edit record as a reusable new-entry draft.
        if (modal.querySelector('input[type="hidden"][id^="edit"]')?.value) return;
        try { localStorage.setItem(this.storageKey(id), JSON.stringify(this.serialize(modal))); } catch(e) {}
    },

    load(id) {
        try {
            const raw = localStorage.getItem(this.storageKey(id));
            if (!raw) return null;
            const draft = JSON.parse(raw);
            if (!draft || !draft.savedAt || Date.now() - Number(draft.savedAt) > this.TTL) {
                localStorage.removeItem(this.storageKey(id));
                return null;
            }
            return draft;
        } catch(e) { return null; }
    },

    clear(id) { try { localStorage.removeItem(this.storageKey(id)); } catch(e) {} },
    markSaved(id) { this.clear(id); try { const modal=document.getElementById(id); if(modal) modal.dataset.entrySaved='1'; } catch(e) {} },

    restore(id) {
        if (!this.shouldRemember(id)) return;
        const modal = document.getElementById(id);
        if (!modal) return;
        if (modal.dataset.skipEntryDraft === '1') return;
        // Never restore into an existing-record edit form.
        const editHidden = modal.querySelector('input[type="hidden"][id^="edit"]');
        if (editHidden && editHidden.value) return;

        const draft = this.load(id);
        if (!draft) return;
        if (!confirm('Restore the values from your previous unfinished entry?\n\nChoose Cancel to start with a fresh empty form.')) { this.clear(id); return; }

        const apply = () => {
            const current = this.controls(modal);
            Object.entries(draft.fields || {}).forEach(([key, data]) => {
                const el = key.startsWith('__index_') ? current[Number(key.slice(8))] : document.getElementById(key);
                if (!el || el.disabled || el.readOnly) return;
                if (data.type === 'checkbox' || data.type === 'radio') el.checked = !!data.checked;
                else el.value = data.value ?? '';
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
            });
            this.restoreRows(id, modal, draft.rows || {});
        };
        // Modules finish their normal/default setup before calling Modals.open().
        // A micro-delay makes the restore the final step without racing dynamic UI.
        setTimeout(apply, 0);
    },

    restoreRows(id, modal, rows) {
        const saleRows = rows['.sell-item-row'] || [];
        const purchaseRows = rows['.purchase-item-row'] || [];
        if (id === 'sellModal' && saleRows.length && typeof Sales !== 'undefined') {
            const body = document.getElementById('sellItemsBody');
            if (body) {
                while (body.querySelectorAll('.sell-item-row').length < saleRows.length && Sales.addSellItem) Sales.addSellItem();
                this.applyRows(body.querySelectorAll('.sell-item-row'), saleRows);
            }
        }
        if (id === 'purchaseModal' && purchaseRows.length && typeof Purchases !== 'undefined') {
            const body = document.getElementById('purchaseItemsBody');
            if (body) {
                while (body.querySelectorAll('.purchase-item-row').length < purchaseRows.length && Purchases.addItem) Purchases.addItem();
                this.applyRows(body.querySelectorAll('.purchase-item-row'), purchaseRows);
            }
        }
    },

    applyRows(domRows, savedRows) {
        Array.from(domRows).slice(0, savedRows.length).forEach((row, ri) => {
            const els = Array.from(row.querySelectorAll('input,select,textarea'));
            (savedRows[ri] || []).forEach((saved, i) => {
                const el = els[i];
                if (!el || el.disabled || el.readOnly) return;
                if (saved.type === 'checkbox' || saved.type === 'radio') el.checked = !!saved.checked;
                else el.value = saved.value ?? '';
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
            });
        });
    },

    bindModal(modal) {
        if (!modal || modal.dataset.entryDraftBound === '1') return;
        modal.dataset.entryDraftBound = '1';
        const save = () => this.save(modal.id);
        modal.addEventListener('input', save);
        modal.addEventListener('change', save);
    },

    bindStaticEntryForms() {
        // Add Product is a permanent form rather than a modal.
        const ids = ['name','category','barcode','buy','sell','stock','minStock','productNotes'];
        const existing = ids.map(id => document.getElementById(id)).filter(Boolean);
        if (existing.length) {
            const pane = existing[0].closest('#tab-add') || existing[0].parentElement;
            if (pane && pane.dataset.entryDraftBound !== '1') {
                pane.dataset.entryDraftBound = '1';
                const key = 'staticAddProduct';
                const save = () => {
                    try { localStorage.setItem(this.storageKey(key), JSON.stringify({ savedAt: Date.now(), fields: this.serialize(pane).fields })); } catch(e) {}
                };
                existing.forEach(el => { el.addEventListener('input', save); el.addEventListener('change', save); });
                try {
                    const d = JSON.parse(localStorage.getItem(this.storageKey(key)) || 'null');
                    if (d && Date.now() - Number(d.savedAt) <= this.TTL) {
                        Object.entries(d.fields || {}).forEach(([id, v]) => { const el = document.getElementById(id); if (el && v) el.value = v.value ?? ''; });
                    } else if (d) localStorage.removeItem(this.storageKey(key));
                } catch(e) {}
            }
        }
    },

    observe() {
        if (this._observer) return;
        this._observer = new MutationObserver(() => {
            document.querySelectorAll('.modal-overlay').forEach(m => this.bindModal(m));
            this.bindStaticEntryForms();
        });
        this._observer.observe(document.body, { childList: true, subtree: true });
        document.querySelectorAll('.modal-overlay').forEach(m => this.bindModal(m));
        this.bindStaticEntryForms();
    }
};

const Modals = {
    open(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('show');
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
            EntryDrafts.bindModal(modal);
            EntryDrafts.restore(modalId);
        }
    },

    close(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            if (modal.dataset.entrySaved === '1') { EntryDrafts.clear(modalId); delete modal.dataset.entrySaved; } else { EntryDrafts.save(modalId); }
            modal.classList.remove('show');
            modal.style.display = 'none';
            document.body.style.overflow = '';
        }
    },

    init() {
        EntryDrafts.observe();

        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            EntryDrafts.bindModal(overlay);
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    EntryDrafts.save(overlay.id);
                    overlay.classList.remove('show');
                    overlay.style.display = 'none';
                    document.body.style.overflow = '';
                }
            });
        });

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const openModals = document.querySelectorAll('.modal-overlay.show');
                if (openModals.length > 0) {
                    const modal = openModals[openModals.length - 1];
                    EntryDrafts.save(modal.id);
                    modal.classList.remove('show');
                    modal.style.display = 'none';
                    document.body.style.overflow = '';
                }
                const dropdown = document.getElementById('optionsDropdown');
                const btn = document.getElementById('hamburgerBtn');
                if (dropdown) dropdown.classList.remove('show');
                if (btn) btn.classList.remove('active');
            }
        });
    }
};

window.EntryDrafts = EntryDrafts;
