// ============================================
// SUPPLIERS MODULE - COMPLETE WITH SHARE & REPORT
// ============================================

(function() {
    'use strict';
    
    const MODULE_NAME = 'Suppliers';
    
    console.log('📦 Registering ' + MODULE_NAME + '...');
    
    window.registerModule(MODULE_NAME, function() {
        console.log('✅ ' + MODULE_NAME + ' initializing...');
        
        const Suppliers = {
            init() {
                const container = document.getElementById('tab-suppliers');
                if (!container) return;

                container.innerHTML = `
                    <div class="card">
                        <div class="flex-between">
                            <div class="card-title">🏢 Suppliers</div>
                            <button class="btn btn-success btn-sm" onclick="Suppliers.openModal()">➕ Add</button>
                        </div>
                        <input class="form-control" id="supplierSearch" placeholder="🔍 Search..." oninput="Suppliers.renderDebounced()" style="margin-bottom:10px;">
                        <div style="display:flex;gap:8px;align-items:center;margin-bottom:10px;flex-wrap:wrap;"><label style="font-size:.85rem;">Sort</label><select class="form-control" id="supplierSortMode" style="max-width:210px;" onchange="Suppliers.changeSort(this.value)"><option value="lastInteraction">Last interaction</option><option value="name">Name A–Z</option><option value="saved">Saved date</option></select></div>
                        <div id="supplierList"></div>
                    </div>
                `;
            },

            openModal(id) {
                let modal = document.getElementById('supplierModal');
                if (!modal) {
                    modal = document.createElement('div');
                    modal.className = 'modal-overlay';
                    modal.id = 'supplierModal';
                    modal.innerHTML = `
                        <div class="modal" style="max-width:400px;">
                            <button class="close-btn" onclick="Modals.close('supplierModal')">✕</button>
                            <h3>🏢 Supplier</h3>
                            <input type="hidden" id="editSupplierId">
                            <div class="form-group"><label>Name</label><input class="form-control" id="supplierName"></div>
                            <div class="form-group"><label>Phone</label><input class="form-control" id="supplierContact"></div>
                            <div class="form-group"><label>Address</label><input class="form-control" id="supplierAddress"></div>
                            <button class="btn btn-success" onclick="Suppliers.save()">💾 Save</button>
                        </div>
                    `;
                    document.body.appendChild(modal);
                }

                document.getElementById('editSupplierId').value = '';
                document.getElementById('supplierName').value = '';
                document.getElementById('supplierContact').value = '';
                document.getElementById('supplierAddress').value = '';

                if (id) {
                    const supplier = State.suppliers.find(s => s.id === id);
                    if (supplier) {
                        document.getElementById('editSupplierId').value = id;
                        document.getElementById('supplierName').value = supplier.name;
                        document.getElementById('supplierContact').value = supplier.contact || '';
                        document.getElementById('supplierAddress').value = supplier.address || '';
                    }
                }

                Modals.open('supplierModal');
            },

            save() {
                const id = document.getElementById('editSupplierId').value;
                const name = document.getElementById('supplierName').value.trim();
                
                if (!name) return Toast.warning('Name required');

                if (id) {
                    const supplier = State.suppliers.find(s => s.id === id);
                    if (supplier) {
                        supplier.name = name;
                        supplier.contact = document.getElementById('supplierContact').value.trim();
                        supplier.address = document.getElementById('supplierAddress').value.trim();
                    }
                } else {
                    State.suppliers.push({
                        id: Helpers.uid(),
                        name,
                        contact: document.getElementById('supplierContact').value.trim(),
                        address: document.getElementById('supplierAddress').value.trim(),
                        balance: 0,
                        createdAt: new Date().toISOString()
                    });
                }

                Storage.save('suppliers', State.suppliers);
                Toast.success('Supplier saved');
                Modals.close('supplierModal');
                this.render();
                App.populateDropdowns();
            },

            delete(id) {
                if (!confirm('Delete this supplier?')) return;
                State.suppliers = State.suppliers.filter(s => s.id !== id);
                Storage.save('suppliers', State.suppliers);
                Toast.success('Supplier deleted');
                this.render();
                App.populateDropdowns();
            },

            render() {
                const search = (document.getElementById('supplierSearch')?.value || '').toLowerCase();
                const filtered = State.suppliers.filter(s => 
                    s.name.toLowerCase().includes(search) || 
                    (s.contact || '').toLowerCase().includes(search)
                );

                const sortedFiltered = Helpers.getPartySort(filtered, 'supplier', document.getElementById('supplierSortMode')?.value);
                const sortEl = document.getElementById('supplierSortMode');
                if (sortEl) sortEl.value = localStorage.getItem('supplierSortMode') || 'lastInteraction';

                const container = document.getElementById('supplierList');
                if (!container) return;

                if (!filtered.length) {
                    container.innerHTML = '<div class="empty-state">No suppliers found</div>';
                    return;
                }

                container.innerHTML = sortedFiltered.map(s => {
                    const balance = s.balance || 0;
                    let cls, label;
                    if (balance > 0) { cls = 'balance-positive'; label = 'We Owe'; }
                    else if (balance < 0) { cls = 'balance-negative'; label = 'Credit'; }
                    else { cls = 'balance-zero'; label = 'Settled'; }

                    return `
                        <div class="list-item" onclick="TransactionDetail.show('supplier', '${s.id}')">
                            <div class="info">
                                <span class="title">${Helpers.esc(s.name)}</span>
                                <span class="meta">📞 ${Helpers.esc(s.contact || '')}</span>
                            </div>
                            <div>
                                <span class="balance-badge ${cls}">${label} ${Helpers.formatCurrency(Math.abs(balance))}</span>
                            </div>
                            <div class="actions" onclick="event.stopPropagation();">
                                <button class="btn btn-info btn-sm" onclick="Payments.openModal('supplier','${s.id}')">💳</button>
                                <button class="btn btn-outline btn-sm" onclick="Payments.openAdjustBalance('supplier','${s.id}')">⚖️</button>
                                <button class="btn btn-success btn-sm" onclick="Customers.openShareModal('supplier','${s.id}')">📤</button>
                                <button class="btn btn-warning btn-sm" onclick="Suppliers.openModal('${s.id}')">✏️</button>
                                <button class="btn btn-danger btn-sm" onclick="Suppliers.delete('${s.id}')">🗑️</button>
                            </div>
                        </div>
                    `;
                }).join('');
            },

            changeSort(mode) { localStorage.setItem('supplierSortMode', mode); this.render(); },

            renderDebounced: Helpers.debounce(function() {
                Suppliers.render();
            }, 300),

            // ============================================
            // VIEW DETAIL
            // ============================================
            
            viewDetail(id) {
                const supplier = State.suppliers.find(s => s.id === id);
                if (!supplier) {
                    Toast.error('Supplier not found');
                    return;
                }

                const balance = supplier.balance || 0;
                let cls, label;
                if (balance > 0) { cls = 'balance-positive'; label = 'We Owe'; }
                else if (balance < 0) { cls = 'balance-negative'; label = 'Credit'; }
                else { cls = 'balance-zero'; label = 'Settled'; }

                const transactions = this.getAllSupplierTransactions(id);
                
                const totalPurchases = transactions.purchases.reduce((sum, p) => sum + p.amount, 0);
                const totalPaid = transactions.purchases.reduce((sum, p) => sum + p.paid, 0);
                const totalDebit = transactions.purchases.reduce((sum, p) => sum + p.debit, 0);

                const html = `
                    <div class="detail-section">
                        <h4>🏢 Supplier Information</h4>
                        <div class="detail-row"><span class="detail-label">Name:</span><span class="detail-value">${Helpers.esc(supplier.name)}</span></div>
                        <div class="detail-row"><span class="detail-label">Phone:</span><span class="detail-value">${Helpers.esc(supplier.contact || '')}</span></div>
                        <div class="detail-row"><span class="detail-label">Address:</span><span class="detail-value">${Helpers.esc(supplier.address || '')}</span></div>
                        <div class="detail-row">
                            <span class="detail-label">Balance:</span>
                            <span class="detail-value"><span class="balance-badge ${cls}">${label} ${Helpers.formatCurrency(Math.abs(balance))}</span></span>
                        </div>
                    </div>

                    <div class="detail-section">
                        <h4>📊 Summary</h4>
                        <div class="stock-summary-grid">
                            <div class="stock-summary-item">
                                <span class="summary-label">Total Purchases</span>
                                <span class="summary-value text-primary">${Helpers.formatCurrency(totalPurchases)}</span>
                            </div>
                            <div class="stock-summary-item">
                                <span class="summary-label">Total Paid</span>
                                <span class="summary-value text-success">${Helpers.formatCurrency(totalPaid)}</span>
                            </div>
                            <div class="stock-summary-item">
                                <span class="summary-label">Outstanding</span>
                                <span class="summary-value text-danger">${Helpers.formatCurrency(totalDebit)}</span>
                            </div>
                            <div class="stock-summary-item">
                                <span class="summary-label">Orders</span>
                                <span class="summary-value">${transactions.purchases.length}</span>
                            </div>
                        </div>
                    </div>

                    ${this.renderSupplierPurchasesTable(transactions.purchases)}
                    ${this.renderSupplierProductsTable(transactions.products)}

                    <div class="detail-section">
                        <h4>⚡ Quick Actions</h4>
                        <div style="display:flex;gap:8px;flex-wrap:wrap;">
                            <button class="btn btn-primary btn-sm" onclick="Purchases.openModal()">📥 New Purchase</button>
                            <button class="btn btn-info btn-sm" onclick="Payments.openModal('supplier','${supplier.id}')">💳 Record Payment</button>
                            <button class="btn btn-outline btn-sm" onclick="AccountingLedger.showEntityStatement('supplier','${supplier.id}')">📒 Statement</button>
                            <button class="btn btn-success btn-sm" onclick="Customers.openShareModal('supplier','${supplier.id}')">📤 Share Balance</button>
                        </div>
                    </div>
                `;

                document.getElementById('detailModalContent').innerHTML = html;
                document.getElementById('detailModalTitle').textContent = '🏢 ' + Helpers.esc(supplier.name);
                Modals.open('detailModal');
            },

            getAllSupplierTransactions(supplierId) {
                const purchases = [];
                const productMap = {};

                (State.purchases || []).forEach(purchase => {
                    if (purchase.supplierId === supplierId) {
                        const items = (purchase.items || []).map(i => i.productName + ' x' + i.quantity);
                        
                        purchases.push({
                            date: purchase.date,
                            items: items,
                            amount: purchase.total || 0,
                            paid: purchase.paid || 0,
                            debit: purchase.debit || 0
                        });

                        (purchase.items || []).forEach(item => {
                            if (!productMap[item.productId]) {
                                productMap[item.productId] = {
                                    productId: item.productId,
                                    name: item.productName,
                                    totalQty: 0,
                                    totalCost: 0
                                };
                            }
                            productMap[item.productId].totalQty += item.quantity;
                            productMap[item.productId].totalCost += item.amount;
                        });
                    }
                });

                purchases.sort((a, b) => new Date(b.date) - new Date(a.date));
                const products = Object.values(productMap);
                products.sort((a, b) => b.totalCost - a.totalCost);

                return { purchases, products };
            },

            renderSupplierPurchasesTable(purchases) {
                if (!purchases || !purchases.length) return '<div class="detail-section"><div class="empty-state">No purchases</div></div>';
                
                return `
                    <div class="detail-section">
                        <h4>📥 Purchase Orders (${purchases.length})</h4>
                        <table class="transaction-table">
                            <thead><tr><th>Date</th><th>Items</th><th>Total</th><th>Paid</th><th>Balance</th></tr></thead>
                            <tbody>
                                ${purchases.map(p => `
                                    <tr>
                                        <td>${Helpers.formatDate(p.date)}</td>
                                        <td>${p.items.join(', ')}</td>
                                        <td>${Helpers.formatCurrency(p.amount)}</td>
                                        <td>${Helpers.formatCurrency(p.paid)}</td>
                                        <td>${Helpers.formatCurrency(p.debit)}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            },

            renderSupplierProductsTable(products) {
                if (!products || !products.length) return '<div class="detail-section"><div class="empty-state">No products</div></div>';
                
                return `
                    <div class="detail-section">
                        <h4>📦 Products Supplied</h4>
                        <table class="transaction-table">
                            <thead><tr><th>Product</th><th>Total Qty</th><th>Total Cost</th></tr></thead>
                            <tbody>
                                ${products.map(p => `
                                    <tr onclick="TransactionDetail.show('product', '${p.productId}')" style="cursor:pointer;">
                                        <td style="color:var(--primary);">${Helpers.esc(p.name)}</td>
                                        <td>${p.totalQty}</td>
                                        <td>${Helpers.formatCurrency(p.totalCost)}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            }
        };
        
        // ✅ Expose Suppliers globally
        window.Suppliers = Suppliers;
        console.log('✅ ' + MODULE_NAME + ' loaded successfully');
        return Suppliers;
    });
    
})();