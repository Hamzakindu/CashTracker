// ============================================
// CUSTOMERS MODULE - COMPLETE FIXED
// SMS opens app, fallback to clipboard
// ============================================

(function() {
    'use strict';
    
    var MODULE_NAME = 'Customers';
    
    console.log('📦 Registering ' + MODULE_NAME + '...');
    
    window.registerModule(MODULE_NAME, function() {
        console.log('✅ ' + MODULE_NAME + ' initializing...');
        
        var Customers = {
            init: function() {
                var container = document.getElementById('tab-customers');
                if (!container) return;

                container.innerHTML = `
                    <div class="card">
                        <div class="flex-between">
                            <div class="card-title">👤 Customers</div>
                            <button class="btn btn-success btn-sm" onclick="Customers.openModal()">➕ Add</button>
                        </div>
                        <input class="form-control" id="customerSearch" placeholder="🔍 Search..." oninput="Customers.renderDebounced()" style="margin-bottom:10px;">
                        <div id="customerList"></div>
                    </div>
                `;
            },

            openModal: function(id) {
                var modal = document.getElementById('customerModal');
                if (!modal) {
                    modal = document.createElement('div');
                    modal.className = 'modal-overlay';
                    modal.id = 'customerModal';
                    modal.innerHTML = `
                        <div class="modal" style="max-width:400px;">
                            <button class="close-btn" onclick="Modals.close('customerModal')">✕</button>
                            <h3>👤 Customer</h3>
                            <input type="hidden" id="editCustomerId">
                            <div class="form-group"><label>Name</label><input class="form-control" id="customerName"></div>
                            <div class="form-group"><label>Phone</label><input class="form-control" id="customerContact"></div>
                            <div class="form-group"><label>Address</label><input class="form-control" id="customerAddress"></div>
                            <button class="btn btn-success" onclick="Customers.save()">💾 Save</button>
                        </div>
                    `;
                    document.body.appendChild(modal);
                }

                document.getElementById('editCustomerId').value = '';
                document.getElementById('customerName').value = '';
                document.getElementById('customerContact').value = '';
                document.getElementById('customerAddress').value = '';

                if (id) {
                    var customer = State.customers.find(function(c) { return c.id === id; });
                    if (customer) {
                        document.getElementById('editCustomerId').value = id;
                        document.getElementById('customerName').value = customer.name;
                        document.getElementById('customerContact').value = customer.contact || '';
                        document.getElementById('customerAddress').value = customer.address || '';
                    }
                }

                Modals.open('customerModal');
            },

            save: function() {
                var id = document.getElementById('editCustomerId').value;
                var name = document.getElementById('customerName').value.trim();
                
                if (!name) { Toast.warning('Name required'); return; }

                if (id) {
                    var customer = State.customers.find(function(c) { return c.id === id; });
                    if (customer) {
                        customer.name = name;
                        customer.contact = document.getElementById('customerContact').value.trim();
                        customer.address = document.getElementById('customerAddress').value.trim();
                    }
                } else {
                    State.customers.push({
                        id: Helpers.uid(),
                        name: name,
                        contact: document.getElementById('customerContact').value.trim(),
                        address: document.getElementById('customerAddress').value.trim(),
                        balance: 0,
                        createdAt: new Date().toISOString()
                    });
                }

                Storage.save('customers', State.customers);
                Toast.success('Customer saved');
                Modals.close('customerModal');
                this.render();
                App.populateDropdowns();
            },

            delete: function(id) {
                if (!confirm('Delete this customer?')) { return; }
                State.customers = State.customers.filter(function(c) { return c.id !== id; });
                Storage.save('customers', State.customers);
                Toast.success('Customer deleted');
                this.render();
                App.populateDropdowns();
            },

            render: function() {
                var search = (document.getElementById('customerSearch')?.value || '').toLowerCase();
                var filtered = State.customers.filter(function(c) {
                    return c.name.toLowerCase().includes(search) || (c.contact || '').toLowerCase().includes(search);
                });

                var container = document.getElementById('customerList');
                if (!container) { return; }

                if (!filtered.length) {
                    container.innerHTML = '<div class="empty-state">No customers found</div>';
                    return;
                }

                container.innerHTML = filtered.map(function(c) {
                    var balance = c.balance || 0;
                    var cls, label;
                    if (balance > 0) { cls = 'balance-positive'; label = 'Owes'; }
                    else if (balance < 0) { cls = 'balance-negative'; label = 'Credit'; }
                    else { cls = 'balance-zero'; label = 'Settled'; }

                    return `
                       <div class="list-item" onclick="TransactionDetail.show('customer', '${c.id}')">
                            <div class="info">
                                <span class="title">${Helpers.esc(c.name)}</span>
                                <span class="meta">📞 ${Helpers.esc(c.contact || '')}</span>
                            </div>
                            <div>
                                <span class="balance-badge ${cls}">${label} ${Helpers.formatCurrency(Math.abs(balance))}</span>
                            </div>
                            <div class="actions" onclick="event.stopPropagation();">
                                <button class="btn btn-info btn-sm" onclick="Payments.openModal('customer','${c.id}')">💳</button>
                                <button class="btn btn-outline btn-sm" onclick="Payments.openAdjustBalance('customer','${c.id}')">⚖️</button>
                                <button class="btn btn-success btn-sm" onclick="Customers.openShareModal('customer','${c.id}')">📤</button>
                                <button class="btn btn-warning btn-sm" onclick="Customers.openModal('${c.id}')">✏️</button>
                                <button class="btn btn-danger btn-sm" onclick="Customers.delete('${c.id}')">🗑️</button>
                            </div>
                        </div>
                    `;
                }).join('');
            },

            renderDebounced: Helpers.debounce(function() {
                Customers.render();
            }, 300),

            viewDetail: function(id) {
                var customer = State.customers.find(function(c) { return c.id === id; });
                if (!customer) {
                    Toast.error('Customer not found');
                    return;
                }

                var balance = customer.balance || 0;
                var cls, label;
                if (balance > 0) { cls = 'balance-positive'; label = 'Owes'; }
                else if (balance < 0) { cls = 'balance-negative'; label = 'Credit'; }
                else { cls = 'balance-zero'; label = 'Settled'; }

                var transactions = this.getAllCustomerTransactions(id);
                
                var totalSales = transactions.sales.reduce(function(sum, s) { return sum + s.amount; }, 0);
                var totalPaid = transactions.sales.reduce(function(sum, s) { return sum + s.paid; }, 0);
                var totalDebit = transactions.sales.reduce(function(sum, s) { return sum + s.debit; }, 0);
                var totalProfit = transactions.sales.reduce(function(sum, s) { return sum + s.profit; }, 0);

                var html = `
                    <div class="detail-section">
                        <h4>👤 Customer Information</h4>
                        <div class="detail-row"><span class="detail-label">Name:</span><span class="detail-value">${Helpers.esc(customer.name)}</span></div>
                        <div class="detail-row"><span class="detail-label">Phone:</span><span class="detail-value">${Helpers.esc(customer.contact || '')}</span></div>
                        <div class="detail-row"><span class="detail-label">Address:</span><span class="detail-value">${Helpers.esc(customer.address || '')}</span></div>
                        <div class="detail-row">
                            <span class="detail-label">Balance:</span>
                            <span class="detail-value"><span class="balance-badge ${cls}">${label} ${Helpers.formatCurrency(Math.abs(balance))}</span></span>
                        </div>
                    </div>

                    <div class="detail-section">
                        <h4>📊 Summary</h4>
                        <div class="stock-summary-grid">
                            <div class="stock-summary-item">
                                <span class="summary-label">Total Purchases</span>
                                <span class="summary-value text-primary">${Helpers.formatCurrency(totalSales)}</span>
                            </div>
                            <div class="stock-summary-item">
                                <span class="summary-label">Total Paid</span>
                                <span class="summary-value text-success">${Helpers.formatCurrency(totalPaid)}</span>
                            </div>
                            <div class="stock-summary-item">
                                <span class="summary-label">Outstanding</span>
                                <span class="summary-value text-danger">${Helpers.formatCurrency(totalDebit)}</span>
                            </div>
                            <div class="stock-summary-item">
                                <span class="summary-label">Total Profit</span>
                                <span class="summary-value text-success">${Helpers.formatCurrency(totalProfit)}</span>
                            </div>
                        </div>
                    </div>

                    ${this.renderCustomerSalesTable(transactions.sales)}
                    ${this.renderCustomerProductsTable(transactions.products)}

                    <div class="detail-section">
                        <h4>⚡ Quick Actions</h4>
                        <div style="display:flex;gap:8px;flex-wrap:wrap;">
                            <button class="btn btn-primary btn-sm" onclick="Sales.openSellModal()">💰 New Sale</button>
                            <button class="btn btn-info btn-sm" onclick="Payments.openModal('customer','${customer.id}')">💳 Record Payment</button>
                            <button class="btn btn-outline btn-sm" onclick="AccountingLedger.showEntityStatement('customer','${customer.id}')">📒 Statement</button>
                            <button class="btn btn-success btn-sm" onclick="Customers.openShareModal('customer','${customer.id}')">📤 Share Balance</button>
                        </div>
                    </div>
                `;

                document.getElementById('detailModalContent').innerHTML = html;
                document.getElementById('detailModalTitle').textContent = '👤 ' + Helpers.esc(customer.name);
                Modals.open('detailModal');
            },

            getAllCustomerTransactions: function(customerId) {
                var sales = [];
                var productMap = {};

                State.activeSales().forEach(function(sale) {
                    if (sale.customerId === customerId) {
                        var items = (sale.items || []).map(function(i) { return i.productName + ' x' + i.quantity; });
                        var profit = sale.profit || 0;
                        
                        sales.push({
                            saleId: sale.id,
                            date: sale.date,
                            items: items,
                            amount: sale.total || 0,
                            paid: sale.paymentReceived || 0,
                            debit: sale.debitRemaining || 0,
                            profit: profit
                        });

                        (sale.items || []).forEach(function(item) {
                            if (!productMap[item.productId]) {
                                productMap[item.productId] = {
                                    productId: item.productId,
                                    name: item.productName,
                                    totalQty: 0,
                                    totalSpent: 0
                                };
                            }
                            productMap[item.productId].totalQty += item.quantity;
                            productMap[item.productId].totalSpent += item.amount;
                        });
                    }
                });

                sales.sort(function(a, b) { return new Date(b.date) - new Date(a.date); });
                var products = Object.values(productMap);
                products.sort(function(a, b) { return b.totalSpent - a.totalSpent; });

                return { sales: sales, products: products };
            },

            renderCustomerSalesTable: function(sales) {
                if (!sales || !sales.length) { return '<div class="detail-section"><div class="empty-state">No sales</div></div>'; }
                
                return `
                    <div class="detail-section">
                        <h4>💰 Sales (${sales.length})</h4>
                        <table class="transaction-table">
                            <thead><tr><th>Date</th><th>Items</th><th>Total</th><th>Paid</th><th>Balance</th><th>Profit</th></tr></thead>
                            <tbody>
                                ${sales.map(function(s) {
                                    return `
                                        <tr onclick="TransactionDetail.show('sale', '${s.saleId}')" style="cursor:pointer;">
                                            <td>${Helpers.formatDate(s.date)}</td>
                                            <td>${s.items.join(', ')}</td>
                                            <td>${Helpers.formatCurrency(s.amount)}</td>
                                            <td>${Helpers.formatCurrency(s.paid)}</td>
                                            <td>${Helpers.formatCurrency(s.debit)}</td>
                                            <td style="color:${s.profit >= 0 ? 'var(--success)' : 'var(--danger)'}">${Helpers.formatCurrency(s.profit)}</td>
                                        </tr>
                                    `;
                                }).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            },

            renderCustomerProductsTable: function(products) {
                if (!products || !products.length) { return '<div class="detail-section"><div class="empty-state">No products</div></div>'; }
                
                return `
                    <div class="detail-section">
                        <h4>📦 Products Bought</h4>
                        <table class="transaction-table">
                            <thead><tr><th>Product</th><th>Total Qty</th><th>Total Spent</th></tr></thead>
                            <tbody>
                                ${products.map(function(p) {
                                    return `
                                        <tr onclick="TransactionDetail.show('product', '${p.productId}')" style="cursor:pointer;">
                                            <td style="color:var(--primary);">${Helpers.esc(p.name)}</td>
                                            <td>${p.totalQty}</td>
                                            <td>${Helpers.formatCurrency(p.totalSpent)}</td>
                                        </tr>
                                    `;
                                }).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            },

            // ============================================
            // SHARE BALANCE - COMPLETE
            // ============================================
            
            openShareModal: function(type, entityId) {
                var entity = null;
                if (type === 'customer') {
                    entity = State.customers.find(function(c) { return c.id === entityId; });
                } else {
                    entity = State.suppliers.find(function(s) { return s.id === entityId; });
                }
                
                if (!entity) { return; }

                var modal = document.getElementById('shareModal');
                if (!modal) {
                    modal = document.createElement('div');
                    modal.className = 'modal-overlay';
                    modal.id = 'shareModal';
                    modal.innerHTML = `
                        <div class="modal" style="max-width:600px; max-height:90vh; overflow-y:auto;">
                            <button class="close-btn" onclick="Modals.close('shareModal')">✕</button>
                            <h3>📤 Share Balance</h3>
                            <input type="hidden" id="shareEntityType">
                            <input type="hidden" id="shareEntityId">
                            
                            <div class="detail-section">
                                <h4>📋 Info</h4>
                                <div id="shareBalanceInfo"></div>
                            </div>
                            
                            <div class="form-group">
                                <label>📱 Phone Number</label>
                                <input class="form-control" id="sharePhoneNumber" type="tel" placeholder="0912345678" oninput="Customers.updateSharePhoneConverter()">
                                <small id="phoneConvertedDisplay" style="color:var(--text2);font-size:0.75rem;display:none;margin-top:4px;"></small>
                            </div>
                            
                            <div class="form-group">
                                <label>📝 Custom Message (Optional)</label>
                                <textarea class="form-control note-area" id="shareCustomMessage" placeholder="Type custom message..." oninput="Customers.updateShareMessagePreview()" style="min-height:60px;"></textarea>
                            </div>
                            
                            <div class="share-message-preview" id="shareMessagePreview"></div>
                            
                            <div style="margin-top:12px;">
                                <label style="font-weight:600;font-size:0.85rem;display:block;margin-bottom:6px;">📤 Share via:</label>
                                <div class="share-buttons">
                                    <button class="btn btn-sms btn-sm" onclick="Customers.shareViaSMS()" title="SMS">📱 SMS</button>
                                    <button class="btn btn-whatsapp btn-sm" onclick="Customers.shareViaWhatsApp()" title="WhatsApp">💬 WhatsApp</button>
                                    <button class="btn btn-telegram btn-sm" onclick="Customers.shareViaTelegram()" title="Telegram (Phone)">✈️ Telegram</button>
                                    <button class="btn btn-telegram btn-sm" onclick="Customers.shareViaTelegramUsername()" title="Telegram (Username)">✈️ TG User</button>
                                    <button class="btn btn-telegram btn-sm" onclick="Customers.shareViaTelegramChannel()" title="Telegram Channel" style="background:#0088cc;color:#fff;">📢 TG Channel</button>
                                    <button class="btn btn-primary btn-sm" onclick="Customers.shareViaNative()" title="Native Share" style="background:#0d6efd;color:#fff;">📤 Share</button>
                                    <button class="btn btn-outline btn-sm" onclick="Customers.copyShareMessage()" title="Copy">📋 Copy</button>
                                    <button class="btn btn-email btn-sm" onclick="Customers.shareViaEmail()" title="Email">📧 Email</button>
                                    <button class="btn btn-outline btn-sm" onclick="Customers.shareBalanceReport()" title="Date Range Report">📊 Report</button>
                                </div>
                            </div>
                            
                            <div style="margin-top:8px;font-size:0.7rem;color:var(--text2);text-align:center;">
                                💡 Tip: For Telegram, enter phone number or use username option
                            </div>
                        </div>
                    `;
                    document.body.appendChild(modal);
                }

                document.getElementById('shareEntityType').value = type;
                document.getElementById('shareEntityId').value = entityId;
                document.getElementById('shareBalanceInfo').innerHTML = 
                    '<strong>' + Helpers.esc(entity.name) + '</strong><br>Balance: ' + Helpers.formatCurrency(entity.balance || 0);
                document.getElementById('sharePhoneNumber').value = entity.contact || '';
                document.getElementById('shareCustomMessage').value = '';
                
                this.updateShareMessagePreview();
                this.updateSharePhoneConverter();
                Modals.open('shareModal');
            },

            updateSharePhoneConverter: function() {
                var phone = document.getElementById('sharePhoneNumber').value;
                var converted = Helpers.convertToInternational(phone);
                var display = document.getElementById('phoneConvertedDisplay');
                
                if (converted !== phone && converted !== '') {
                    display.style.display = 'block';
                    display.textContent = '➡️ International: ' + converted;
                } else {
                    display.style.display = 'none';
                }
                
                this.updateShareMessagePreview();
            },

            updateShareMessagePreview: function() {
                var type = document.getElementById('shareEntityType').value;
                var id = document.getElementById('shareEntityId').value;
                var entity = null;
                if (type === 'customer') {
                    entity = State.customers.find(function(c) { return c.id === id; });
                } else {
                    entity = State.suppliers.find(function(s) { return s.id === id; });
                }
                
                if (!entity) { return; }

                var balance = entity.balance || 0;
                var profile = JSON.parse(localStorage.getItem('stockProfile') || '{}');
                var store = profile.storeName || 'CashTracker';
                var typeLabel = (type === 'customer') ? 'Customer' : 'Supplier';
                
                var message = '📊 *' + typeLabel + ' Balance Update*\n\n';
                message += '👤 *' + entity.name + '*\n';
                message += '🏪 Store: ' + store + '\n\n';
                message += '💰 *Balance: ' + Helpers.formatCurrency(Math.abs(balance)) + '*\n';
                if (balance > 0) { message += '📌 *Status:* Owes\n'; }
                else if (balance < 0) { message += '📌 *Status:* Credit\n'; }
                else { message += '📌 *Status:* Settled ✅\n'; }
                message += '\n📅 ' + new Date().toLocaleDateString();

                var custom = document.getElementById('shareCustomMessage').value.trim();
                if (custom) { message = custom; }
                
                document.getElementById('shareMessagePreview').textContent = message;
            },

            getEffectivePhone: function() {
                var phone = document.getElementById('sharePhoneNumber').value.trim();
                return Helpers.convertToInternational(phone) || phone;
            },

            getEntityFromModal: function() {
                var type = document.getElementById('shareEntityType').value;
                var id = document.getElementById('shareEntityId').value;
                if (type === 'customer') {
                    return State.customers.find(function(c) { return c.id === id; });
                } else {
                    return State.suppliers.find(function(s) { return s.id === id; });
                }
            },

            // ============================================
            // SMS - NOW OPENS MESSAGING APP
            // ============================================
            
            shareViaSMS: function() {
                var phone = this.getEffectivePhone();
                var message = document.getElementById('shareMessagePreview').textContent;
                if (!phone) { 
                    Toast.warning('📱 Enter a phone number');
                    return; 
                }
                
                var encodedMessage = encodeURIComponent(message);
                var encodedPhone = encodeURIComponent(phone);
                
                // Try all possible SMS URL schemes
                var urls = [
                    'sms:' + phone + '?body=' + encodedMessage,
                    'sms://' + phone + '?body=' + encodedMessage,
                    'intent://sms/' + phone + '?body=' + encodedMessage + '#Intent;scheme=sms;action=android.intent.action.SENDTO;end'
                ];
                
                var success = false;
                for (var i = 0; i < urls.length; i++) {
                    try {
                        window.location.href = urls[i];
                        Toast.success('📱 Opening SMS...');
                        success = true;
                        break;
                    } catch(e) {
                        // Continue to next URL
                    }
                }
                
                // If all failed, fallback to copy
                if (!success) {
                    this.fallbackSMS(phone, message);
                }
            },

            fallbackSMS: function(phone, message) {
                var copyMessage = function() {
                    alert('📱 Please send SMS to ' + phone + '\n\nMessage copied to clipboard:\n\n' + message);
                    Toast.success('📋 Message copied!');
                };
                
                if (navigator.clipboard) {
                    navigator.clipboard.writeText(message).then(copyMessage).catch(function() {
                        Customers.fallbackCopyWithPrompt(phone, message);
                    });
                } else {
                    Customers.fallbackCopyWithPrompt(phone, message);
                }
            },

            fallbackCopyWithPrompt: function(phone, message) {
                var textarea = document.createElement('textarea');
                textarea.value = message;
                document.body.appendChild(textarea);
                textarea.select();
                try {
                    document.execCommand('copy');
                    alert('📱 Please send SMS to ' + phone + '\n\nMessage copied to clipboard:\n\n' + message);
                    Toast.success('📋 Message copied!');
                } catch (err) {
                    prompt('📱 Send SMS to ' + phone + '\n\nCopy this message:', message);
                }
                document.body.removeChild(textarea);
            },

            // ============================================
            // WHATSAPP - uses web.whatsapp.com
            // ============================================
            
            shareViaWhatsApp: function() {
                var phone = this.getEffectivePhone();
                var message = document.getElementById('shareMessagePreview').textContent;
                if (!phone) { 
                    Toast.warning('📱 Enter a phone number');
                    return; 
                }
                
                var cleanPhone = phone.replace(/\+/g, '');
                var webUrl = 'https://wa.me/' + cleanPhone + '?text=' + encodeURIComponent(message);
                window.open(webUrl, '_blank');
                Toast.success('💬 Opening WhatsApp Web...');
            },

            // ============================================
            // TELEGRAM - uses web.telegram.org
            // ============================================
            
            shareViaTelegram: function() {
                var phone = this.getEffectivePhone();
                var message = document.getElementById('shareMessagePreview').textContent;
                if (!phone) { 
                    Toast.warning('📱 Enter a phone number');
                    return; 
                }
                
                var cleanPhone = phone.replace(/\+/g, '');
                var webUrl = 'https://t.me/' + cleanPhone + '?text=' + encodeURIComponent(message);
                window.open(webUrl, '_blank');
                Toast.success('✈️ Opening Telegram Web...');
            },

            shareViaTelegramUsername: function() {
                var username = prompt('📡 Enter Telegram username (without @):', '');
                if (!username) { return; }
                var message = document.getElementById('shareMessagePreview').textContent;
                var webUrl = 'https://t.me/' + encodeURIComponent(username) + '?text=' + encodeURIComponent(message);
                window.open(webUrl, '_blank');
                Toast.success('✈️ Opening Telegram Web...');
            },

            shareViaTelegramChannel: function() {
                var message = document.getElementById('shareMessagePreview').textContent;
                var entity = this.getEntityFromModal();
                if (!entity) { return; }
                
                var caption = '📊 *Balance Share*\n\n' + message;
                
                Toast.info('📡 Sending to Telegram Channel...');
                
                fetch('https://api.telegram.org/bot' + CONFIG.TELEGRAM.TOKEN + '/sendMessage', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        chat_id: CONFIG.TELEGRAM.BACKUP_CHANNEL,
                        text: caption,
                        parse_mode: 'Markdown'
                    })
                })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.ok) {
                        Toast.success('✅ Sent to Telegram Channel!');
                    } else {
                        Toast.error('❌ Failed: ' + (data.description || 'Unknown error'));
                        navigator.clipboard.writeText(caption).then(function() {
                            alert('📋 Message copied to clipboard. Please send to Telegram manually.');
                        });
                    }
                })
                .catch(function(err) {
                    Toast.error('❌ Network error: ' + err.message);
                    navigator.clipboard.writeText(caption).then(function() {
                        alert('📋 Message copied to clipboard. Please send to Telegram manually.');
                    });
                });
            },

            shareViaNative: function() {
                var message = document.getElementById('shareMessagePreview').textContent;
                var entity = this.getEntityFromModal();
                
                if (navigator.share) {
                    navigator.share({
                        title: 'Balance Update - ' + (entity ? entity.name : ''),
                        text: message,
                    })
                    .then(function() { Toast.success('📤 Shared!'); })
                    .catch(function(err) {
                        if (err.name !== 'AbortError') {
                            Toast.error('❌ Share failed');
                            Customers.copyShareMessage();
                        }
                    });
                } else {
                    this.copyShareMessage();
                    Toast.info('📋 Message copied to clipboard');
                }
            },

            copyShareMessage: function() {
                var message = document.getElementById('shareMessagePreview').textContent;
                if (!message) {
                    Toast.warning('No message to copy');
                    return;
                }
                
                if (navigator.clipboard) {
                    navigator.clipboard.writeText(message)
                        .then(function() { Toast.success('📋 Copied!'); })
                        .catch(function() {
                            Customers.fallbackCopy(message);
                        });
                } else {
                    Customers.fallbackCopy(message);
                }
            },

            fallbackCopy: function(text) {
                var textarea = document.createElement('textarea');
                textarea.value = text;
                document.body.appendChild(textarea);
                textarea.select();
                try {
                    document.execCommand('copy');
                    Toast.success('📋 Copied!');
                } catch (err) {
                    prompt('📋 Copy this message:', text);
                }
                document.body.removeChild(textarea);
            },

            shareViaEmail: function() {
                var message = document.getElementById('shareMessagePreview').textContent;
                var entity = this.getEntityFromModal();
                var subject = 'Balance Update - ' + (entity ? entity.name : 'Customer');
                
                try {
                    var url = 'mailto:?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(message);
                    window.location.href = url;
                    Toast.success('📧 Opening Email...');
                } catch(e) {
                    navigator.clipboard.writeText(message).then(function() {
                        alert('📧 Email subject: ' + subject + '\n\nMessage copied to clipboard:\n\n' + message);
                    }).catch(function() {
                        prompt('📧 Email subject: ' + subject + '\n\nCopy this message:', message);
                    });
                }
            },

            shareBalanceReport: function() {
                var entity = this.getEntityFromModal();
                if (!entity) { return; }

                var today = Helpers.getToday();
                var fromDate = prompt('📅 From Date (YYYY-MM-DD):', today);
                if (!fromDate) { return; }
                if (!/^\d{4}-\d{2}-\d{2}$/.test(fromDate)) {
                    Toast.warning('Invalid date format. Use YYYY-MM-DD');
                    return;
                }

                var toDate = prompt('📅 To Date (YYYY-MM-DD):', today);
                if (!toDate) { return; }
                if (!/^\d{4}-\d{2}-\d{2}$/.test(toDate)) {
                    Toast.warning('Invalid date format. Use YYYY-MM-DD');
                    return;
                }

                var type = document.getElementById('shareEntityType').value;
                var report = this.generateBalanceReport(entity, type, fromDate, toDate);
                
                document.getElementById('shareMessagePreview').textContent = report;
                
                navigator.clipboard.writeText(report).then(function() {
                    Toast.success('📊 Report generated and copied!');
                }).catch(function() {
                    Toast.success('📊 Report generated! Use copy button to copy.');
                });
            },

            generateBalanceReport: function(entity, type, fromDate, toDate) {
                var typeLabel = (type === 'customer') ? 'Customer' : 'Supplier';
                var balance = entity.balance || 0;
                var profile = JSON.parse(localStorage.getItem('stockProfile') || '{}');
                var store = profile.storeName || 'CashTracker';
                
                var transactions = [];
                if (type === 'customer') {
                    transactions = State.activeSales().filter(function(s) {
                        return s.customerId === entity.id && s.date >= fromDate && s.date <= toDate;
                    });
                } else {
                    transactions = (State.purchases || []).filter(function(p) {
                        return p.supplierId === entity.id && p.date >= fromDate && p.date <= toDate;
                    });
                }

                var totalAmount = transactions.reduce(function(sum, t) { return sum + (t.total || 0); }, 0);
                var totalPaid = transactions.reduce(function(sum, t) { return sum + (t.paid || t.paymentReceived || 0); }, 0);
                var totalBalance = transactions.reduce(function(sum, t) { return sum + (t.debitRemaining || t.debit || 0); }, 0);

                var report = '📊 *' + typeLabel + ' Balance Report*\n\n';
                report += '👤 *' + entity.name + '*\n';
                report += '🏪 Store: ' + store + '\n';
                report += '📅 Period: ' + fromDate + ' to ' + toDate + '\n\n';
                report += '📋 *Summary*\n';
                report += '━━━━━━━━━━━━━━━━━━\n';
                report += '💰 Current Balance: ' + Helpers.formatCurrency(Math.abs(balance)) + '\n';
                if (balance > 0) { report += '📌 Status: Owes\n'; }
                else if (balance < 0) { report += '📌 Status: Credit\n'; }
                else { report += '📌 Status: Settled ✅\n'; }
                report += '━━━━━━━━━━━━━━━━━━\n';
                report += '📥 Total Transactions: ' + transactions.length + '\n';
                report += '💵 Total Amount: ' + Helpers.formatCurrency(totalAmount) + '\n';
                report += '💳 Total Paid: ' + Helpers.formatCurrency(totalPaid) + '\n';
                report += '📊 Outstanding: ' + Helpers.formatCurrency(totalBalance) + '\n';
                report += '━━━━━━━━━━━━━━━━━━\n';
                report += '📅 Generated: ' + new Date().toLocaleString() + '\n';

                if (transactions.length > 0 && transactions.length <= 20) {
                    report += '\n📋 *Transaction Details*\n';
                    report += '━━━━━━━━━━━━━━━━━━\n';
                    transactions.forEach(function(t, i) {
                        var date = t.date || 'N/A';
                        var amount = t.total || 0;
                        var paid = t.paid || t.paymentReceived || 0;
                        var debit = t.debitRemaining || t.debit || 0;
                        report += (i+1) + '. ' + date + ' | ' + Helpers.formatCurrency(amount) + ' | Paid: ' + Helpers.formatCurrency(paid) + ' | Bal: ' + Helpers.formatCurrency(debit) + '\n';
                    });
                } else if (transactions.length > 20) {
                    report += '\n📋 Showing ' + transactions.length + ' transactions (export for full list)';
                }

                return report;
            }
        };
        
        window.Customers = Customers;
        console.log('✅ ' + MODULE_NAME + ' loaded successfully');
        return Customers;
    });
    
})();