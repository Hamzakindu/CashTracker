// LOW STOCK: products at or below their minimum, with a shareable reorder list
(function(){'use strict';
window.registerModule('StockAlerts',function(){
const esc=s=>Helpers.esc(String(s==null?'':s));
const store=()=>{try{return JSON.parse(localStorage.getItem('stockProfile')||'{}').storeName||'CashTracker'}catch(e){return 'CashTracker'}};
const CH=[['whatsapp','💬 WhatsApp'],['telegram','✈️ Telegram'],['imo','🟣 imo'],['sms','📱 SMS'],['more','📤 More…']];
function low(){
  return (State.products||[]).map(p=>{const s=Number(p.stock)||0,m=(p.minStock!=null&&p.minStock!=='')?Number(p.minStock):5;return{p,s,m,need:Math.max(1,m*2-s)}})
    .filter(x=>x.s<=x.m).sort((a,b)=>a.s-b.s||a.p.name.localeCompare(b.p.name));
}
function badge(){const n=low().length,b=document.querySelector('.tab-btn[data-tab="lowstock"]');if(b)b.textContent='📉 Low Stock'+(n?' ('+n+')':'')}
const isActive=()=>document.getElementById('tab-lowstock')?.classList.contains('active');
function render(){
  const p=document.getElementById('tab-lowstock');if(!p)return;const l=low();
  p.innerHTML=`<div class="card"><div class="card-title">📉 Low Stock</div><p>${l.length?'<b>'+l.length+'</b> product(s) at or below their minimum.':'All products are above their minimum 🎉'}</p>
  <div style="display:flex;gap:8px;flex-wrap:wrap">${l.length?'<button class="btn btn-success btn-sm" onclick="StockAlerts.openReorder()">📤 Share reorder list</button>':''}<button class="btn btn-outline btn-sm" onclick="Purchases.openModal()">🛒 New purchase</button></div>
  <small style="display:block;margin-top:6px;opacity:.75">Suggested order = enough to reach twice the minimum. Set each product's minimum when you edit it.</small></div>
  ${l.map(x=>`<div class="card" style="margin:8px 0;padding:10px"><div class="flex-between"><b>${esc(x.p.name)}</b><b style="color:${x.s<=0?'#dc3545':'#fd7e14'}">${x.s<=0?'Out of stock':x.s+' left'}</b></div><small>Minimum ${x.m} · suggested order ${x.need}${x.p.category?' · '+esc(x.p.category):''}</small></div>`).join('')}`;
  badge();
}
function msg(){
  const rows=[...document.querySelectorAll('#reorderModal input[data-pid]')].filter(i=>i.parentElement.querySelector('.ro-chk').checked).map(i=>({n:i.dataset.n,q:Number(i.value)||0})).filter(r=>r.q>0);
  return '🛒 Order request from '+store()+'\n\n'+rows.map(r=>'• '+r.n+' — '+r.q).join('\n')+'\n\nPlease confirm availability and price. Thank you.';
}
const StockAlerts={
  render,
  openReorder(){
    const l=low();if(!l.length)return;
    let m=document.getElementById('reorderModal');if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='reorderModal';document.body.appendChild(m)}
    const sup=(State.suppliers||[]).filter(s=>s.contact||s.phone);
    m.innerHTML=`<div class="modal" style="max-width:520px;max-height:90vh;overflow-y:auto"><button class="close-btn" onclick="Modals.close('reorderModal')">✕</button><h3>📤 Reorder list</h3>
    <div class="form-group"><label>Tick what to order and edit the quantities</label><div style="margin:4px 0"><button class="btn btn-outline btn-sm" onclick="StockAlerts.tick(true)">☑ All</button> <button class="btn btn-outline btn-sm" onclick="StockAlerts.tick(false)">☐ None</button></div>${l.map(x=>`<div style="display:flex;gap:8px;align-items:center;margin:4px 0"><input type="checkbox" checked class="ro-chk" style="width:20px;height:20px"><span style="flex:1">${esc(x.p.name)} <small>(${x.s} left)</small></span><input type="number" min="0" class="form-control" style="width:80px" data-pid="${esc(x.p.id)}" data-n="${esc(x.p.name)}" value="${x.need}"></div>`).join('')}</div>
    <div class="form-group"><label>👤 Supplier (optional)</label><select class="form-control" onchange="document.getElementById('roPhone').value=this.value"><option value="">Choose in the app after tapping</option>${sup.map(s=>`<option value="${esc(s.contact||s.phone)}">${esc(s.name)}</option>`).join('')}</select></div>
    <div class="form-group"><label>📱 Phone (optional)</label><input class="form-control" id="roPhone" type="tel"></div>
    <div style="display:flex;gap:6px;flex-wrap:wrap">${CH.map(c=>`<button class="btn btn-primary btn-sm" onclick="StockAlerts.go('${c[0]}')">${c[1]}</button>`).join('')}</div></div>`;
    Modals.open('reorderModal');
  },
  tick(v){document.querySelectorAll('#reorderModal .ro-chk').forEach(c=>c.checked=v)},
  go(ch){if(!window.ShareHub)return;ShareHub.send(ch,msg(),document.getElementById('roPhone').value)}
};
window.StockAlerts=StockAlerts;
setTimeout(()=>{badge();const n=low().length;if(n&&window.Toast)Toast.warning('📉 '+n+' product(s) low on stock. See the Low Stock tab.')},2500);
document.addEventListener('visibilitychange',()=>{if(!document.hidden){badge();if(isActive())render()}});
return StockAlerts;});
})();
