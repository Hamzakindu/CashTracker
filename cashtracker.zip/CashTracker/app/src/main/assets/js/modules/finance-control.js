// STOCKPRO V5.3 - FINANCE CONTROL CENTER
(function(){'use strict';
window.registerModule('FinanceControl', function(){
const F={
  moneyAsOf(date){
    const rows=(State.cashAccounts||[]).filter(a=>a.active!==false).map(a=>{
      let b=Number(a.openingBalance||0);
      (State.moneyTransactions||[]).forEach(t=>{
        if(t.status==='void'||t.accountId!==a.id||String(t.date||'')>date)return;
        const n=Number(t.amount||0);
        // openingBalance is the snapshot; opening ledger rows are not additive.
        if(t.type==='opening')return;
        if(['in','income','transfer_in','adjustment_in'].includes(t.type))b+=n;
        if(['out','expense','transfer_out','adjustment_out'].includes(t.type))b-=n;
      });
      return {a,b};
    });
    return rows;
  },
  period(from,to){
    const sales=(State.sales||[]).filter(x=>x.date>=from&&x.date<=to);
    const purchases=(State.purchases||[]).filter(x=>x.date>=from&&x.date<=to);
    const returns=(State.returns||[]).filter(x=>x.date>=from&&x.date<=to);
    const expenses=(State.directExpenses||[]).filter(x=>x.date>=from&&x.date<=to);
    const grossSales=sales.reduce((n,x)=>n+Number(x.total||0),0);
    const salesReturns=returns.filter(x=>x.type==='sale'||x.returnType==='sale'||x.sourceType==='sale').reduce((n,x)=>n+Number(x.total||x.amount||0),0);
    const purchaseTotal=purchases.reduce((n,x)=>n+Number(x.total||0),0);
    const purchaseReturns=returns.filter(x=>x.type==='purchase'||x.returnType==='purchase'||x.sourceType==='purchase').reduce((n,x)=>n+Number(x.total||x.amount||0),0);
    const profit=sales.reduce((n,x)=>n+Number(x.profit||0),0);
    const expenseTotal=expenses.reduce((n,x)=>n+Number(x.amount||0),0);
    const customerPayments=(State.moneyTransactions||[]).filter(t=>t.status!=='void'&&t.date>=from&&t.date<=to&&t.sourceType==='payment'&&t.entityType==='customer').reduce((n,t)=>n+Number(t.amount||0),0);
    const supplierPayments=(State.moneyTransactions||[]).filter(t=>t.status!=='void'&&t.date>=from&&t.date<=to&&t.sourceType==='payment'&&t.entityType==='supplier').reduce((n,t)=>n+Number(t.amount||0),0);
    return {sales,purchases,returns,expenses,grossSales,salesReturns,netSales:grossSales-salesReturns,purchaseTotal,purchaseReturns,netPurchases:purchaseTotal-purchaseReturns,profit,expenseTotal,netProfit:profit-expenseTotal,customerPayments,supplierPayments};
  },
  priceBreakdown(sales){
    const m={};
    sales.forEach(s=>(s.items||[]).forEach(i=>{
      const price=Number(i.price??i.sellingPrice??0), key=(i.productId||i.productName||'')+'|'+price;
      if(!m[key])m[key]={productName:i.productName||'Unknown',price,quantity:0,amount:0,profit:0,transactions:0};
      const q=Number(i.quantity||0);m[key].quantity+=q;m[key].amount+=q*price;
      m[key].profit+=Number(i.profit||0);m[key].transactions++;
    }));
    return Object.values(m).sort((a,b)=>String(a.productName).localeCompare(String(b.productName))||a.price-b.price);
  },
  render(){
    const pane=document.getElementById('tab-finance');if(!pane)return;
    const today=Helpers.getToday();
    pane.innerHTML=`<div class="card"><div class="flex-between"><div><div class="card-title">💰 Finance Control Center</div><small>Money position, reconciliation and complete financial reports.</small></div><button class="btn btn-primary btn-sm" onclick="FinanceControl.generate()">📊 Generate</button></div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-top:12px">
      <div class="form-group"><label>From</label><input class="form-control" type="date" id="finFrom" value="${today}"></div>
      <div class="form-group"><label>To</label><input class="form-control" type="date" id="finTo" value="${today}"></div></div>
      <div id="financeOutput" style="margin-top:14px"></div><div class="card" style="margin-top:12px"><div class="card-title">📚 Double-entry accounting</div><small>Read-only trial balance, profit and loss, and journal preview based on recorded transactions.</small><button class="btn btn-outline btn-sm" style="margin-top:8px" onclick="FinanceControl.showAccounting()">📒 View accounting statements</button><div id="accountingStatementsOutput" style="margin-top:12px"></div></div>
      <div class="card" style="margin-top:12px"><div class="card-title">📊 Statements</div><small>Live reports from your balances.</small>
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px"><button class="btn btn-outline btn-sm" onclick="Statements.show('balance')">⚖️ Balance sheet</button><button class="btn btn-outline btn-sm" onclick="Statements.show('ar')">🧾 Who owes me</button><button class="btn btn-outline btn-sm" onclick="Statements.show('ap')">📤 Who I owe</button><button class="btn btn-outline btn-sm" onclick="Statements.show('inventory')">📦 Stock value</button><button class="btn btn-outline btn-sm" onclick="Statements.show('cashflow')">💸 Cash flow</button></div>
      <div id="statementsOutput" style="margin-top:10px"></div></div>
      <div class="card" style="margin-top:12px"><div class="card-title">🔒 Close the books</div><small>Stops changes to sales, purchases, expenses and returns dated on or before the closing date.</small><div style="margin-top:8px"><b>${window.PeriodLock?PeriodLock.label():''}</b> <button class="btn btn-primary btn-sm" onclick="PeriodLock.dialog()">Set closing date</button></div></div><div id="branchAccessOutput"></div></div>`;
    this.generate();
    if(typeof BranchAccess!=='undefined') BranchAccess.render();
  },
  generate(){
    const from=document.getElementById('finFrom')?.value||Helpers.getToday(),to=document.getElementById('finTo')?.value||from;
    const p=this.period(from,to), money=this.moneyAsOf(to), cash=money.filter(x=>x.a.type==='cash').reduce((n,x)=>n+x.b,0), bank=money.filter(x=>x.a.type==='bank').reduce((n,x)=>n+x.b,0), wallet=money.filter(x=>x.a.type==='wallet').reduce((n,x)=>n+x.b,0), total=money.reduce((n,x)=>n+x.b,0);
    const rec=typeof AccountingLedger!=='undefined'?AccountingLedger.reconcile():{ok:true,issues:[]};
    const price=this.priceBreakdown(p.sales);
    const o=document.getElementById('financeOutput');if(!o)return;
    o.innerHTML=`<div class="stock-summary-grid">
      ${[['💵 Cash',cash],['🏦 Banks',bank],['📱 Wallets',wallet],['💰 Total Money',total],['🛒 Net Sales',p.netSales],['📈 Gross Profit',p.profit],['💸 Expenses',p.expenseTotal],['✅ Net Profit',p.netProfit]].map(x=>`<div class="stock-summary-item"><span class="summary-label">${x[0]}</span><span class="summary-value">${Helpers.formatCurrency(x[1])}</span></div>`).join('')}
    </div>
    <div class="card" style="margin-top:12px"><div class="card-title">🏦 Money by account — as of ${Helpers.formatDate(to)}</div>
      <div style="overflow-x:auto"><table class="transaction-table"><thead><tr><th>Account</th><th>Type</th><th>Bank</th><th>Available</th></tr></thead><tbody>${money.map(x=>`<tr><td>${Helpers.esc(x.a.name)}</td><td>${x.a.type}</td><td>${Helpers.esc(x.a.bankName||'')}</td><td><b>${Helpers.formatCurrency(x.b)}</b></td></tr>`).join('')||'<tr><td colspan="4">No accounts</td></tr>'}</tbody></table></div></div>
    <div class="card" style="margin-top:12px"><div class="card-title">📊 Financial statement</div>
      <div style="overflow-x:auto"><table class="transaction-table"><tbody>
      <tr><td>Gross sales</td><td>${Helpers.formatCurrency(p.grossSales)}</td></tr><tr><td>Sales returns</td><td>- ${Helpers.formatCurrency(p.salesReturns)}</td></tr><tr><td><b>Net sales</b></td><td><b>${Helpers.formatCurrency(p.netSales)}</b></td></tr>
      <tr><td>Gross profit</td><td>${Helpers.formatCurrency(p.profit)}</td></tr><tr><td>Expenses</td><td>- ${Helpers.formatCurrency(p.expenseTotal)}</td></tr><tr><td><b>Net profit</b></td><td><b>${Helpers.formatCurrency(p.netProfit)}</b></td></tr>
      <tr><td>Customer payments received</td><td>${Helpers.formatCurrency(p.customerPayments)}</td></tr><tr><td>Supplier payments paid</td><td>- ${Helpers.formatCurrency(p.supplierPayments)}</td></tr></tbody></table></div></div>
    <div class="card" style="margin-top:12px"><div class="flex-between"><div class="card-title">💲 Sales by Product & Price</div><button class="btn btn-outline btn-sm" onclick="FinanceControl.exportCSV()">📤 CSV</button></div>
      <div style="overflow-x:auto"><table class="transaction-table"><thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Revenue</th><th>Profit</th><th>Transactions</th></tr></thead><tbody>${price.map(g=>`<tr><td>${Helpers.esc(g.productName)}</td><td>${Helpers.formatCurrency(g.price)}</td><td>${g.quantity}</td><td>${Helpers.formatCurrency(g.amount)}</td><td>${Helpers.formatCurrency(g.profit)}</td><td>${g.transactions}</td></tr>`).join('')||'<tr><td colspan="6">No sales</td></tr>'}</tbody></table></div></div>
    <div class="card" style="margin-top:12px"><div class="flex-between"><div class="card-title">📒 Accounting reconciliation</div><span>${rec.ok?'✅ Balanced':'⚠️ '+rec.issues.length+' issue(s)'}</span></div>
      ${rec.ok?'<p>Customer and supplier balances reconcile with the accounting records.</p>':`<div style="overflow-x:auto"><table class="transaction-table"><thead><tr><th>Type</th><th>Name</th><th>Expected</th><th>Actual</th><th>Difference</th></tr></thead><tbody>${rec.issues.map(i=>`<tr><td>${i.type}</td><td>${Helpers.esc(i.name)}</td><td>${Helpers.formatCurrency(i.expected)}</td><td>${Helpers.formatCurrency(i.actual)}</td><td>${Helpers.formatCurrency(i.difference)}</td></tr>`).join('')}</tbody></table></div>`}</div>`;
    this._last={from,to,p,price,money};
  },
  showAccounting(){const from=document.getElementById('finFrom')?.value||'';const to=document.getElementById('finTo')?.value||Helpers.getToday();if(typeof AccountingDoubleEntry==='undefined'){Toast.error('Accounting module is not loaded');return;}AccountingDoubleEntry.render(from,to);},
  exportCSV(){
    const d=this._last;if(!d)return;
    let c='CashTracker Financial Report\\nFrom,'+d.from+'\\nTo,'+d.to+'\\n\\n';
    c+='Summary,Amount\\nGross Sales,'+d.p.grossSales+'\\nSales Returns,'+d.p.salesReturns+'\\nNet Sales,'+d.p.netSales+'\\nGross Profit,'+d.p.profit+'\\nExpenses,'+d.p.expenseTotal+'\\nNet Profit,'+d.p.netProfit+'\\nCustomer Payments,'+d.p.customerPayments+'\\nSupplier Payments,'+d.p.supplierPayments+'\\n\\n';
    c+='Account,Type,Bank,Available\\n';d.money.forEach(x=>c+=`"${x.a.name}",${x.a.type},"${x.a.bankName||''}",${x.b}\\n`);
    c+='\\nProduct,Unit Price,Quantity,Revenue,Profit,Transactions\\n';d.price.forEach(x=>c+=`"${String(x.productName).replace(/"/g,'""')}",${x.price},${x.quantity},${x.amount},${x.profit},${x.transactions}\\n`);
    Helpers.downloadFile(c,'stockpro-financial-report.csv');Toast.success('Financial report exported');
  }
};
window.FinanceControl=F;return F;});
})();