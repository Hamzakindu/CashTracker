// SUMMARY: share today's sales, expenses, account balances and what people owe
(function(){'use strict';
window.registerModule('Summary',function(){
const esc=s=>Helpers.esc(String(s==null?'':s));
const fmt=n=>Helpers.formatCurrency(Number(n)||0);
const store=()=>{try{return JSON.parse(localStorage.getItem('stockProfile')||'{}').storeName||'CashTracker'}catch(e){return 'CashTracker'}};
const CH=[['whatsapp','💬 WhatsApp'],['telegram','✈️ Telegram'],['imo','🟣 imo'],['sms','📱 SMS'],['more','📤 More…']];
function data(){
  const t=Helpers.getToday();CashBanks.init();
  const sales=(State.sales||[]).filter(s=>String(s.date||'').slice(0,10)===t&&!s.voided&&s.status!=='void');
  const exps=(State.directExpenses||[]).filter(e=>String(e.date||'').slice(0,10)===t&&!e.voided&&e.status!=='void');
  return{sales:sales.reduce((a,s)=>a+(Number(s.total)||0),0),ns:sales.length,exp:exps.reduce((a,e)=>a+(Number(e.amount)||0),0),
    accs:CashBanks.accounts().map(a=>({id:a.id,name:a.name,bal:CashBanks.balance(a.id)})),
    owed:(State.customers||[]).filter(c=>Number(c.balance)>0),owe:(State.suppliers||[]).filter(s=>Number(s.balance)>0),
    low:(State.products||[]).filter(p=>{const s=Number(p.stock)||0,m=(p.minStock!=null&&p.minStock!=='')?Number(p.minStock):5;return s<=m}).length};
}
function build(){
  const d=data(),on=id=>document.getElementById(id)?.checked,L=['📊 *'+store()+'* summary · '+Helpers.getToday(),''];
  if(on('sumSales'))L.push('💰 Sales today: '+fmt(d.sales)+' ('+d.ns+')');
  if(on('sumExp'))L.push('💸 Expenses today: '+fmt(d.exp));
  const ids=[...document.querySelectorAll('.sum-acc:checked')].map(c=>c.dataset.id),ac=d.accs.filter(a=>ids.includes(a.id));
  if(ac.length){L.push('','🏦 Balances:');ac.forEach(a=>L.push('• '+a.name+': '+fmt(a.bal)));L.push('Total: '+fmt(ac.reduce((n,a)=>n+a.bal,0)))}
  if(on('sumOwed'))L.push('','📥 Customers owe you: '+fmt(d.owed.reduce((n,c)=>n+c.balance,0))+' ('+d.owed.length+')');
  if(on('sumOwe'))L.push('📤 You owe suppliers: '+fmt(d.owe.reduce((n,s)=>n+s.balance,0))+' ('+d.owe.length+')');
  if(on('sumLow'))L.push('📉 Low stock items: '+d.low);
  document.getElementById('sumText').value=L.join('\n').trim();
}
const Summary={
  build,
  open(){
    const d=data();
    let m=document.getElementById('summaryModal');
    if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='summaryModal';document.body.appendChild(m)}
    const cb=(id,l)=>`<label style="display:flex;gap:8px;align-items:center;margin:4px 0"><input type="checkbox" id="${id}" checked onchange="Summary.build()"> ${l}</label>`;
    const people=[...(State.customers||[]),...(State.suppliers||[])].filter(x=>x.contact);
    m.innerHTML=`<div class="modal" style="max-width:520px;max-height:90vh;overflow-y:auto"><button class="close-btn" onclick="Modals.close('summaryModal')">✕</button><h3>📊 Share summary</h3>
    <div class="form-group"><label>Include</label>${cb('sumSales','💰 Sales today')}${cb('sumExp','💸 Expenses today')}${cb('sumOwed','📥 Customers owe you')}${cb('sumOwe','📤 You owe suppliers')}${cb('sumLow','📉 Low stock count')}</div>
    <div class="form-group"><label>🏦 Account balances</label>${d.accs.map(a=>`<label style="display:flex;gap:8px;align-items:center;margin:4px 0"><input type="checkbox" class="sum-acc" data-id="${esc(a.id)}" checked onchange="Summary.build()"> ${esc(a.name)}</label>`).join('')||'<small>No accounts yet</small>'}</div>
    <div class="form-group"><label>👤 Send to (optional)</label><select class="form-control" onchange="document.getElementById('sumPhone').value=this.value"><option value="">Choose in the app after tapping</option>${people.map(x=>`<option value="${esc(x.contact)}">${esc(x.name)}</option>`).join('')}</select></div>
    <div class="form-group"><label>📱 Phone (optional)</label><input class="form-control" id="sumPhone" type="tel"></div>
    <div class="form-group"><label>📝 Message</label><textarea class="form-control note-area" id="sumText" rows="9"></textarea></div>
    <div style="display:flex;gap:6px;flex-wrap:wrap">${CH.map(c=>`<button class="btn btn-primary btn-sm" onclick="Summary.go('${c[0]}')">${c[1]}</button>`).join('')}</div></div>`;
    Modals.open('summaryModal');build();
  },
  go(ch){if(window.ShareHub)ShareHub.send(ch,document.getElementById('sumText').value,document.getElementById('sumPhone').value)}
};
window.Summary=Summary;return Summary;});
})();
