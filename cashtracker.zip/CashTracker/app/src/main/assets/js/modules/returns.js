// ============================================
// RETURNS MODULE
// ============================================

(function() {
    'use strict';
    
    const MODULE_NAME = 'Returns';
    
    console.log('📦 Registering ' + MODULE_NAME + '...');
    
    window.registerModule(MODULE_NAME, function() {
        console.log('✅ ' + MODULE_NAME + ' initializing...');
        
        const Returns = {
            openModal() {
                let modal = document.getElementById('returnModal');
                if (!modal) {
                    modal = document.createElement('div');
                    modal.className = 'modal-overlay';
                    modal.id = 'returnModal';
                    modal.innerHTML = `
                        <div class="modal" style="max-width:450px;">
                            <button class="close-btn" onclick="Modals.close('returnModal')">✕</button>
                            <h3>↩️ Process Return</h3>
                            <div class="form-group"><label>Date</label><input class="form-control" type="date" id="returnDate"></div>
                            <div class="form-group"><label>Product</label><select class="form-control" id="returnProductId"><option value="">-- Select --</option></select></div>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                                <div class="form-group"><label>Quantity</label><input class="form-control" id="returnQty" type="number" min="1" value="1"></div>
                                <div class="form-group"><label>Refund/unit</label><input class="form-control" id="returnRefund" type="number" step="0.01" placeholder="0"></div>
                            </div>
                            <div class="form-group"><label>Refund given as</label>
                                <select class="form-control" id="returnMethod" onchange="Returns.toggleMethod()">
                                    <option value="cash">💵 Money paid back (cash / bank)</option>
                                    <option value="credit">🧾 Credit to customer account</option>
                                    <option value="none">🔁 No money (exchange / stock correction)</option>
                                </select></div>
                            <div class="form-group" id="returnAccountWrap"><label>Paid from account</label><select class="form-control" id="returnAccount"></select></div>
                            <div class="form-group" id="returnCustomerWrap" style="display:none"><label>Customer</label><select class="form-control" id="returnCustomer"></select></div>
                            <button class="btn btn-warning" onclick="Returns.submit()">↩️ Process Return</button>
                        </div>
                    `;
                    document.body.appendChild(modal);
                }

                document.getElementById('returnDate').value = Helpers.getToday();
                document.getElementById('returnQty').value = '1';
                document.getElementById('returnRefund').value = '';
                
                App.populateDropdowns();
                const acc = document.getElementById('returnAccount');
                if (acc && window.CashBanks) acc.innerHTML = CashBanks.selectOptions('');
                const cus = document.getElementById('returnCustomer');
                if (cus) cus.innerHTML = '<option value="">-- Select customer --</option>' + (State.customers || []).map(c => `<option value="${Helpers.esc(c.id)}">${Helpers.esc(c.name)}</option>`).join('');
                document.getElementById('returnMethod').value = 'cash';
                this.toggleMethod();
                Modals.open('returnModal');
            },

            toggleMethod() {
                const m = document.getElementById('returnMethod')?.value;
                const a = document.getElementById('returnAccountWrap'), c = document.getElementById('returnCustomerWrap');
                if (a) a.style.display = m === 'cash' ? 'block' : 'none';
                if (c) c.style.display = m === 'credit' ? 'block' : 'none';
            },

            submit() {
                const productId = document.getElementById('returnProductId').value;
                const qty = Number(document.getElementById('returnQty').value);
                if (!productId || !Number.isFinite(qty) || qty <= 0) return Toast.warning('Select product and valid quantity');
                const refund = Number(document.getElementById('returnRefund').value) || 0;
                if (refund < 0) return Toast.warning('Refund cannot be negative');
                const product = State.products.find(p => p.id === productId);
                if (!product) return Toast.warning('Product not found');
                const date = document.getElementById('returnDate').value || Helpers.getToday();
                if (window.PeriodLock && PeriodLock.blocked(date)) return;
                const method = document.getElementById('returnMethod')?.value || 'none';
                const accountId = document.getElementById('returnAccount')?.value || '';
                const customerId = document.getElementById('returnCustomer')?.value || '';
                const totalRefund = refund * qty;
                if (totalRefund > 0 && method === 'cash' && !accountId) return Toast.warning('Select the account the refund was paid from');
                if (totalRefund > 0 && method === 'credit' && !customerId) return Toast.warning('Select the customer to credit');
                if (totalRefund > 0 && method === 'cash' && window.CashBanks && CashBanks.balance(accountId) < totalRefund) return Toast.warning('Insufficient available balance in that account');
                try {
                    State.saveUndoState(`Return: ${product.name} x${qty}`);
                    State.runAtomic('Process return', () => {
                        product.stock += qty;
                        if (window.StockHistory) StockHistory.recordChange(product.id, product.name, qty, 'Stock return', 'return');
                        const returnId = Helpers.uid();
                        const unitCost = Number(product.buy) || 0;
                        const refundMethod = totalRefund > 0 ? method : 'none';
                        State.returns.push({ id: returnId, transactionId: returnId, sourceType: 'return', productId, productName: product.name, quantity: qty, refundPerUnit: refund, totalRefund, refundMethod, accountId: refundMethod === 'cash' ? accountId : '', customerId: refundMethod === 'credit' ? customerId : '', costAmount: unitCost * qty, date, createdAt: new Date().toISOString() });
                        if (refundMethod === 'cash') {
                            CashBanks.link(accountId, totalRefund, 'out', { date, note: 'Return refund: ' + product.name + ' x' + qty, sourceType: 'return', sourceId: returnId });
                        } else if (refundMethod === 'credit') {
                            const cust = State.customers.find(c => c.id === customerId);
                            if (!cust) throw new Error('Customer not found');
                            // Reduce what the customer owes first; any remainder becomes advance (credit) they can use later.
                            const owed = Math.max(0, Number(cust.balance) || 0);
                            const off = Math.min(owed, totalRefund);
                            cust.balance = (Number(cust.balance) || 0) - off;
                            cust.customerAdvance = Number(cust.customerAdvance || 0) + (totalRefund - off);
                            const rr = State.returns[State.returns.length - 1]; rr.arOffset = off; rr.advanceAdded = totalRefund - off;
                        }
                        if (window.Security && Security.audit) Security.audit('return_posted', 'return', returnId, { product: product.name, qty, totalRefund, method: refundMethod });
                    });
                    Toast.success(`Return processed: ${product.name} x${qty}`); Modals.close('returnModal'); this.render(); Products.render(); Dashboard.update();
                } catch (error) { Toast.error('Return failed: ' + (error.message || error)); }
            },

            render() {
                const container = document.getElementById('returnList');
                if (!container) return;

                if (!State.returns.length) {
                    container.innerHTML = '<div class="empty-state">No returns recorded</div>';
                    return;
                }

                const sorted = State.returns
                    .slice()
                    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

                container.innerHTML = sorted.map(r => `
                   <div class="list-item" onclick=" showDetail('return', '${r.id}')" style="cursor:pointer;">
                        <div class="info">
                            <span class="title">${Helpers.esc(r.productName)} x${r.quantity}</span>
                            <span class="meta">${Helpers.formatDate(r.date)}</span>
                        </div>
                        <div>Refund: ${Helpers.formatCurrency(r.totalRefund || 0)}${r.refundMethod ? ' · ' + ({cash:'paid back',credit:'credited',none:'no money'}[r.refundMethod] || '') : ''}</div>
                    </div>
                `).join('');
            }
        };
        
        window.Returns = Returns;
        console.log('✅ ' + MODULE_NAME + ' loaded successfully');
        return Returns;
    });
    
})();