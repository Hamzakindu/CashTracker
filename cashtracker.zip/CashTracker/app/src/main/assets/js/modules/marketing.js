// MARKETING: choose customers, products and platforms, then send the offer one by one
(function(){'use strict';
window.registerModule('Marketing',function(){
const TPL='SP_promo_tpl',LOGK='SP_promo_log';
const DEF='Hello {name}, we have new offers at {store}! Visit us or reply to order. 🛍️';
const esc=s=>Helpers.esc(String(s==null?'':s));
const fmt=n=>Helpers.formatCurrency(Number(n)||0);
const store=()=>{try{return JSON.parse(localStorage.getItem('stockProfile')||'{}').storeName||'CashTracker'}catch(e){return 'CashTracker'}};
const SEG=[['','Quick select…'],['all','All customers'],['top','Top 10 buyers'],['recent','Bought in last 30 days'],['inactive','Not bought in 30+ days'],['debtors','Owe money']];
const CH=[['whatsapp','💬 WhatsApp'],['telegram','✈️ Telegram'],['imo','🟣 imo'],['sms','📱 SMS']];
const TPLS=[['🛍️ New offer','Hello {name}, special offer at {store} this week! Visit us or reply to order. 🛍️'],['🆕 New arrivals','Hello {name}, new items just arrived at {store}. Reply to see the details. 🆕'],['📦 Back in stock','Hello {name}, good news! Items you asked about are back in stock at {store}. 📦'],['🙏 Thank you','Dear {name}, thank you for shopping at {store}. We appreciate you! 🙏'],['🌼 Ethiopian New Year','Happy Ethiopian New Year, {name}! Wishing you a year of peace, health and prosperity. 🌼 {store}'],['✝️ Meskel','Happy Meskel, {name}! Wishing you and your family a blessed holiday. {store}'],['🎄 Genna (Christmas)','Merry Genna, {name}! Wishing you joy and peace this Christmas. 🎄 {store}'],['🌊 Timket','Happy Timket, {name}! Blessings to you and your family. {store}'],['🐣 Easter (Fasika)','Happy Easter, {name}! Wishing you a joyful Fasika. 🐣 {store}'],['🌙 Eid Mubarak','Eid Mubarak, {name}! Wishing you and your family joy and blessings. 🌙 {store}'],['🌙 Ramadan Kareem','Ramadan Kareem, {name}! Wishing you a blessed month. {store}']];
const CHL=Object.fromEntries(CH);
let rec=[],prodIds=[],chs=['whatsapp'],photo=true,cat=true,per=true,pics=true,text=localStorage.getItem(TPL)||DEF;
const days=d=>{const t=new Date(String(d||'').slice(0,10)+'T00:00:00');return isNaN(t)?9999:Math.floor((Date.now()-t)/864e5)};
const readLog=()=>{try{return JSON.parse(localStorage.getItem(LOGK)||'{}')}catch(e){return{}}};
const key=()=>(per?(pics?'B':'P'):'C')+'|'+prodIds.slice().sort().join(',')+'|'+text.slice(0,60);
const hasImg=p=>(p.images||[]).find(u=>String(u).indexOf('data:image')===0)||'';
function all(){
  const st={};(State.sales||[]).forEach(s=>{if(!s.customerId||s.customerId==='walkin')return;const o=st[s.customerId]||(st[s.customerId]={total:0,last:''});o.total+=Number(s.total)||0;if(String(s.date)>o.last)o.last=String(s.date)});
  return (State.customers||[]).filter(c=>c.contact&&!c.noMarketing).map(c=>Object.assign({c},st[c.id]||{total:0,last:''}));
}
function segIds(v){
  let l=all();
  if(v==='top')l=l.filter(x=>x.total>0).sort((a,b)=>b.total-a.total).slice(0,10);
  else if(v==='recent')l=l.filter(x=>x.last&&days(x.last)<=30);
  else if(v==='inactive')l=l.filter(x=>!x.last||days(x.last)>30);
  else if(v==='debtors')l=l.filter(x=>Number(x.c.balance)>0);
  return l.map(x=>x.c.id);
}
const recipients=()=>{const a=all();return rec.map(id=>a.find(x=>x.c.id===id)).filter(Boolean)};
const prods=()=>prodIds.map(id=>(State.products||[]).find(p=>p.id===id)).filter(Boolean);
function prodText(){
  const l=prods();if(!l.length)return '';
  if(l.length===1&&window.ShareHub)return ShareHub.productText(l[0]);
  return '🛍️ Our products:\n'+l.map(p=>'• '+p.name+' — '+fmt(p.sell)+((Number(p.stock)||0)>0?'':' (out of stock)')).join('\n');
}
function msg(x){const t=text.split('{name}').join(x.c.name).split('{store}').join(store()),pt=prodText();return pt?t+'\n\n'+pt:t}
function steps(){
  const s=[],P=prods();
  recipients().forEach(x=>{
    if(per&&!pics&&P.length>1)P.forEach((p,i)=>chs.forEach(ch=>s.push({x,ch,p,first:i===0})));
    else chs.forEach(ch=>s.push({x,ch}));
  });
  return s;
}
const skey=s=>s.x.c.id+'|'+(s.p?s.p.id:'')+'|'+s.ch;
const greet=x=>text.split('{name}').join(x.c.name).split('{store}').join(store());
function ticks(x,sent){const mine=steps().filter(s=>s.x.c.id===x.c.id),d=mine.filter(s=>sent[skey(s)]).length;return d?'✅ '+d+'/'+mine.length:''}
const catOpts=()=>'<option value="">➕ Add a whole category…</option>'+MultiPick.catGroups().map(g=>`<option value="${esc(g.label)}">${esc(g.label)} (${g.ids.length})</option>`).join('');
async function deliver(s){
  let img='';const l=prods();let batchDone=false;
  if(!s.p&&per&&pics&&l.length>1&&window.Android&&Android.shareMulti){
    const imgs=[];for(const p of l.slice(0,12))imgs.push((await Catalog.card(p)).split(',')[1]);
    Android.shareMulti(s.ch==='sms'?'more':s.ch,'',Helpers.convertToInternational(s.x.c.contact||'')||'',JSON.stringify(imgs),localStorage.getItem('SP_share_mode')||'sheet');
    batchDone=true;
  }
  if(s.p){if(photo){const u=hasImg(s.p);img=u&&window.Catalog&&Catalog.shrink?await Catalog.shrink(u):u}}
  else{img=photo&&l.length===1?hasImg(l[0]):'';if(cat&&l.length>1&&window.Catalog){try{img=await Catalog.make(l)}catch(e){}}}
  if(!batchDone)ShareHub.send(s.ch,s.p?(s.first?greet(s.x)+'\n\n':'')+ShareHub.productText(s.p):msg(s.x),s.x.c.contact,img);
  const lg=readLog(),k=key(),sent=lg[k]||{};sent[skey(s)]=1;lg[k]=sent;localStorage.setItem(LOGK,JSON.stringify(lg));logCampaign();
  try{const sd=JSON.parse(localStorage.getItem('SP_promo_start')||'{}');if(!sd[k]){sd[k]=new Date().toISOString().slice(0,10);localStorage.setItem('SP_promo_start',JSON.stringify(sd))}}catch(e){}
  render();
}
function results(){
  let sd={};try{sd=JSON.parse(localStorage.getItem('SP_promo_start')||'{}')}catch(e){}
  const st=sd[key()];if(!st||!rec.length)return '';
  const ids=new Set(rec),buyers=new Set();let tot=0,n=0;
  (State.sales||[]).forEach(s=>{if(ids.has(s.customerId)&&String(s.date).slice(0,10)>=st&&!s.voided&&s.status!=='void'){buyers.add(s.customerId);tot+=Number(s.total)||0;n++}});
  return `<div class="card"><div class="card-title">📈 Results since ${esc(st)}</div><b>${buyers.size}</b> of ${rec.length} customers bought · ${n} sale(s) · <b>${fmt(tot)}</b><br><small>Counts all purchases by these customers since the first message was sent.</small></div>`;
}
function render(){
  const p=document.getElementById('tab-marketing');if(!p)return;
  const st=steps(),sent=readLog()[key()]||{},todo=st.filter(s=>!sent[skey(s)]),nx=todo[0],pl=prods();
  p.innerHTML=`<div class="card"><div class="card-title">📣 Marketing</div><small>Choose who gets the offer, what to promote and which apps to use. Messages go out one at a time; you tap Send for each.</small>
  <div class="form-group" style="margin-top:10px"><label>👥 Customers (only those with a phone number)</label>
  <div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn btn-primary btn-sm" onclick="Marketing.pickCust()">☑ Choose customers (${rec.length})</button><button class="btn btn-outline btn-sm" onclick="Marketing.pickOptOut()">🚫 Opted out (${(State.customers||[]).filter(c=>c.noMarketing).length})</button>
  <select class="form-control" style="width:auto" onchange="Marketing.quick(this.value);this.value=''">${SEG.map(s=>`<option value="${s[0]}">${s[1]}</option>`).join('')}</select></div></div>
  <div class="form-group"><label>🛍️ Products (optional)</label><button class="btn btn-primary btn-sm" onclick="Marketing.pickProd()">☑ Choose products (${prodIds.length})</button>
  ${pl.length?'<div><small>'+pl.map(v=>esc(v.name)).join(', ')+'</small></div>':''}<div style="margin-top:6px"><select class="form-control" onchange="Marketing.addCat(this.value);this.value=''">${catOpts()}</select></div>${pl.length>1?`<label style="display:flex;gap:8px;align-items:center;margin:6px 0"><input type="checkbox" ${per?'checked':''} onchange="Marketing.setPer(this.checked)"> 📦 Send each product as its own message</label>${per?`<label style="display:flex;gap:8px;align-items:center;margin:6px 0"><input type="checkbox" ${pics?'checked':''} onchange="Marketing.setPics(this.checked)"> 📸 Send all as separate pictures in one tap (recommended)</label>`:''}`:''}</div>
  ${pl.length===1&&hasImg(pl[0])?`<label style="display:flex;gap:8px;align-items:center;margin:6px 0"><input type="checkbox" ${photo?'checked':''} onchange="Marketing.setPhoto(this.checked)"> 📸 Include photo</label>`:(pl.length>1&&per&&!pics?`<label style="display:flex;gap:8px;align-items:center;margin:6px 0"><input type="checkbox" ${photo?'checked':''} onchange="Marketing.setPhoto(this.checked)"> 📸 Include each product's photo</label>`:pl.length>1?`<label style="display:flex;gap:8px;align-items:center;margin:6px 0"><input type="checkbox" ${cat?'checked':''} onchange="Marketing.setCat(this.checked)"> 🖼️ Include catalog picture (first 8 products)</label>`:'')}
  <div class="form-group"><label>📲 Platforms (tick one or more)</label><div style="display:flex;gap:12px;flex-wrap:wrap">${CH.map(c=>`<label style="display:flex;gap:6px;align-items:center"><input type="checkbox" ${chs.includes(c[0])?'checked':''} onchange="Marketing.toggleCh('${c[0]}',this.checked)"> ${c[1]}</label>`).join('')}</div></div>
  <div class="form-group"><label>📝 Message ({name} and {store} are filled in)</label><select class="form-control" style="margin-bottom:6px" onchange="Marketing.useTpl(this.value);this.value=''"><option value="">Use a template…</option>${TPLS.map((t,i)=>`<option value="${i}">${t[0]}</option>`).join('')}</select><textarea class="form-control note-area" rows="4" oninput="Marketing.setText(this.value)">${esc(text)}</textarea></div></div>
  <div class="card"><b>${rec.length}</b> customer(s) × <b>${chs.length}</b> platform(s) · <b>${todo.length}</b> message(s) left
  <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px"><button class="btn btn-success btn-sm" onclick="Marketing.next()">▶ Send next${nx?': '+esc(nx.x.c.name)+' via '+CHL[nx.ch]:''}</button><button class="btn btn-outline btn-sm" onclick="Marketing.reset()">↺ Start over</button><button class="btn btn-outline btn-sm" onclick="Marketing.results()">📈 Results</button></div>
  <small style="opacity:.7;display:block;margin-top:6px">Tap Send next to open the app for the next message. Or tap an app icon next to a customer to send to just that customer, even if already sent.</small></div>
  ${results()}
  ${recipients().map(x=>`<div class="list-item"><div class="info"><span class="title">${esc(x.c.name)} ${ticks(x,sent)}</span><span class="meta">${esc(x.c.contact)}${x.last?' · last bought '+esc(x.last.slice(0,10)):' · never bought'}</span></div><div style="display:flex;gap:4px;flex-wrap:wrap">${chs.map(ch=>`<button class="btn btn-outline btn-sm" onclick="Marketing.sendOne('${esc(x.c.id)}','${ch}')">${CHL[ch].slice(0,2)}</button>`).join('')}</div></div>`).join('')||'<div class="empty-state">No customers chosen yet. Tap Choose customers or use Quick select.</div>'}`;
}
function logCampaign(){try{
  let cs=JSON.parse(localStorage.getItem('SP_campaigns')||'[]');const k=key();let c=cs.find(x=>x.k===k);
  if(!c){c={k,date:new Date().toISOString().slice(0,10),text:text.slice(0,80),prods:prodIds.length,rec:[],sent:0};cs.unshift(c)}
  c.rec=[...new Set([...c.rec,...rec])];c.sent=Object.keys(readLog()[k]||{}).length;
  localStorage.setItem('SP_campaigns',JSON.stringify(cs.slice(0,30)));
}catch(e){}}
const Marketing={
  render,
  pickCust(){MultiPick.open({title:'Choose customers',items:all().map(x=>({id:x.c.id,label:x.c.name,sub:x.c.contact+(x.last?' · last bought '+x.last.slice(0,10):' · never bought')})),selected:rec,onDone:ids=>{rec=ids;render()}})},
  pickProd(){MultiPick.open({title:'Choose products',items:(State.products||[]).map(v=>({id:v.id,label:v.name,sub:fmt(v.sell)+' · stock '+(Number(v.stock)||0)})),selected:prodIds,groups:MultiPick.catGroups(),onDone:ids=>{prodIds=ids;render()}})},
  pickOptOut(){MultiPick.open({title:'Customers who do NOT want offers',items:(State.customers||[]).map(c=>({id:c.id,label:c.name,sub:c.contact||'no phone'})),selected:(State.customers||[]).filter(c=>c.noMarketing).map(c=>c.id),onDone:ids=>{const s=new Set(ids);(State.customers||[]).forEach(c=>{if(s.has(c.id))c.noMarketing=true;else delete c.noMarketing});if(State.saveAll)State.saveAll();rec=rec.filter(id=>!s.has(id));render()}})},
  quick(v){if(!v)return;rec=segIds(v);render()},
  preload(ids){prodIds=(ids||[]).slice();render()},
  toggleCh(c,on){const s=new Set(chs);on?s.add(c):s.delete(c);if(!s.size){Toast.warning('Keep at least one platform');return render()}chs=CH.map(x=>x[0]).filter(x=>s.has(x));render()},
  setPhoto(v){photo=v},
  setPer(v){per=v;render()},
  setPics(v){pics=v;render()},
  addCat(c){if(!c)return;const g=MultiPick.catGroups().find(x=>x.label===c);if(!g)return;prodIds=[...new Set([...prodIds,...g.ids])];render()},
  setCat(v){cat=v},
  setText(v){text=v;localStorage.setItem(TPL,v)},
  async next(){
    if(!window.ShareHub)return Toast.error('Share module not loaded');
    const st=steps();if(!st.length)return Toast.warning('Choose customers first');
    const lg=readLog(),k=key(),sent=lg[k]||{},s=st.find(z=>!sent[skey(z)]);
    if(!s){if(confirm('Every message in this campaign was already sent.\n\nSend them again from the start?')){Marketing.reset();return Marketing.next()}return}
    await deliver(s);
  },
  async sendOne(id,ch){
    if(!window.ShareHub)return Toast.error('Share module not loaded');
    const x=recipients().find(r=>r.c.id===id);if(!x)return;
    const mine=steps().filter(z=>z.x.c.id===id&&z.ch===ch),sent=readLog()[key()]||{};
    let s=mine.find(z=>!sent[skey(z)]);
    if(!s){
      if(!confirm('Everything was already sent to '+x.c.name+' on this app.\n\nSend again from the start?'))return;
      const l2=readLog(),k2=key(),sm=l2[k2]||{};mine.forEach(z=>delete sm[skey(z)]);l2[k2]=sm;localStorage.setItem(LOGK,JSON.stringify(l2));s=mine[0];
    }
    if(s)await deliver(s);
  },
  useTpl(i){if(i==='')return;text=TPLS[+i][1];localStorage.setItem(TPL,text);render()},
  results(){
    let cs=[];try{cs=JSON.parse(localStorage.getItem('SP_campaigns')||'[]')}catch(e){}
    let m=document.getElementById('campResultsModal');if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='campResultsModal';document.body.appendChild(m)}
    const rowsH=cs.slice(0,10).map(c=>{const by={};let amt=0;(State.sales||[]).forEach(s=>{if(!c.rec.includes(s.customerId)||s.voided||s.status==='void')return;const d=(new Date(String(s.date).slice(0,10))-new Date(c.date))/864e5;if(d>=0&&d<=7){by[s.customerId]=1;amt+=Number(s.total)||0}});const n=Object.keys(by).length;
      return `<div class="card" style="margin:8px 0;padding:10px"><b>${esc(c.date)}</b> · ${c.sent} sent · ${c.prods} product(s)<br><small>${esc(c.text)}</small><div style="margin-top:4px"><b>${n}</b> of ${c.rec.length} customers bought within 7 days · <b>${fmt(amt)}</b></div></div>`}).join('');
    m.innerHTML=`<div class="modal" style="max-width:520px;max-height:90vh;overflow-y:auto"><button class="close-btn" onclick="Modals.close('campResultsModal')">✕</button><h3>📈 Campaign results</h3><small>Counts customers who bought within 7 days after you messaged them. It shows a link, not proof the message caused the sale.</small>${rowsH||'<p>No campaigns yet. Send a message first.</p>'}</div>`;
    Modals.open('campResultsModal');
  },
  reset(){const lg=readLog();delete lg[key()];localStorage.setItem(LOGK,JSON.stringify(lg));render()}
};
window.Marketing=Marketing;return Marketing;});
})();
