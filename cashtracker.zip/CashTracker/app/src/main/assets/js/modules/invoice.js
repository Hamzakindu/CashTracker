// INVOICE: draws a clean invoice image for a sale and shares it
(function(){'use strict';
window.registerModule('Invoice',function(){
const esc=s=>Helpers.esc(String(s==null?'':s));
const fmt=n=>Helpers.formatCurrency(Number(n)||0);
const store=()=>{try{return JSON.parse(localStorage.getItem('stockProfile')||'{}').storeName||'CashTracker'}catch(e){return 'CashTracker'}};
const no=s=>'INV-'+String(s.id).slice(-6).toUpperCase();
const CH=[['whatsapp','💬 WhatsApp'],['telegram','✈️ Telegram'],['imo','🟣 imo'],['sms','📱 SMS'],['more','📤 More…']];
let cur=null;
function fit(x,t,w){t=String(t||'');if(x.measureText(t).width<=w)return t;while(t.length>1&&x.measureText(t+'…').width>w)t=t.slice(0,-1);return t+'…'}
function draw(s){
  const it=s.items||[],W=800,rh=54,H=330+it.length*rh+250,c=document.createElement('canvas');c.width=W;c.height=H;
  const x=c.getContext('2d');x.textBaseline='middle';x.fillStyle='#fff';x.fillRect(0,0,W,H);
  x.fillStyle='#0d6efd';x.fillRect(0,0,W,120);x.fillStyle='#fff';x.font='bold 40px sans-serif';x.fillText(fit(x,store(),480),40,60);
  x.textAlign='right';x.font='bold 32px sans-serif';x.fillText('INVOICE',W-40,60);x.textAlign='left';
  x.fillStyle='#222';x.font='24px sans-serif';x.fillText('No: '+no(s),40,165);x.fillText('Date: '+String(s.date||'').slice(0,10),40,200);x.fillText('Customer: '+fit(x,s.customer||'Walk-in',560),40,235);
  let y=275;x.fillStyle='#eef2f7';x.fillRect(30,y,W-60,48);x.fillStyle='#222';x.font='bold 22px sans-serif';
  x.fillText('Item',45,y+24);x.textAlign='right';x.fillText('Qty',480,y+24);x.fillText('Price',630,y+24);x.fillText('Amount',W-45,y+24);x.textAlign='left';
  y+=48;x.font='22px sans-serif';
  it.forEach((i,k)=>{const cy=y+k*rh+rh/2;x.fillStyle='#222';x.textAlign='left';x.fillText(fit(x,i.productName,330),45,cy);
    x.textAlign='right';x.fillText(String(i.quantity),480,cy);x.fillText(fmt(i.price),630,cy);x.fillText(fmt(i.amount),W-45,cy);
    x.fillStyle='#e5e9f0';x.fillRect(30,y+(k+1)*rh-1,W-60,1)});
  y+=it.length*rh+30;x.textAlign='right';
  const paid=(Number(s.paymentReceived)||0)+(Number(s.advanceUsed)||0),due=Number(s.debitRemaining)||0;
  x.font='bold 28px sans-serif';x.fillStyle='#222';x.fillText('Total: '+fmt(s.total),W-45,y+20);
  x.font='24px sans-serif';x.fillText('Paid: '+fmt(paid),W-45,y+66);
  x.font='bold 30px sans-serif';x.fillStyle=due>0?'#dc3545':'#198754';x.fillText(due>0?'Balance due: '+fmt(due):'PAID IN FULL ✓',W-45,y+120);
  x.textAlign='center';x.font='22px sans-serif';x.fillStyle='#777';x.fillText('Thank you for your business',W/2,H-40);
  return c;
}
const Invoice={
  open(id){
    const s=(State.sales||[]).find(v=>v.id===id);if(!s)return;
    const cust=(State.customers||[]).find(c=>c.id===s.customerId),due=Number(s.debitRemaining)||0;
    cur={url:draw(s).toDataURL('image/jpeg',0.9)};
    const cap='🧾 Invoice '+no(s)+' from '+store()+'\nTotal: '+fmt(s.total)+(due>0?'\n⚠️ Balance due: '+fmt(due):'\n✅ Paid in full');
    let m=document.getElementById('invoiceModal');
    if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='invoiceModal';document.body.appendChild(m)}
    m.innerHTML=`<div class="modal" style="max-width:520px;max-height:90vh;overflow-y:auto"><button class="close-btn" onclick="Modals.close('invoiceModal')">✕</button><h3>🧾 Share Invoice</h3>
    <img src="${cur.url}" style="width:100%;border:1px solid #ccc;border-radius:8px;margin:6px 0">
    <div class="form-group"><label>📱 Phone (optional)</label><input class="form-control" id="invPhone" type="tel" value="${esc(cust?cust.contact||'':'')}"></div>
    <div class="form-group"><label>📝 Message</label><textarea class="form-control note-area" id="invText" rows="4">${esc(cap)}</textarea></div>
    <div style="display:flex;gap:6px;flex-wrap:wrap">${CH.map(c=>`<button class="btn btn-primary btn-sm" onclick="Invoice.go('${c[0]}')">${c[1]}</button>`).join('')}</div></div>`;
    Modals.open('invoiceModal');
  },
  go(ch){if(!cur||!window.ShareHub)return;ShareHub.send(ch,document.getElementById('invText').value,document.getElementById('invPhone').value,cur.url)}
};
window.Invoice=Invoice;return Invoice;});
})();
