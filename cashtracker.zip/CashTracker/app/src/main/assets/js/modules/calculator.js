// ============================================
// CALCULATOR MODULE - V5.10.9 WEBVIEW FIX + COMPACT IMPORT FORM
// Features: Copy/Paste style recall, independent query/result
// ============================================

(function() {
    'use strict';
    
    const MODULE_NAME = 'Calculator';
    
    console.log('📦 Registering ' + MODULE_NAME + '...');
    
    window.registerModule(MODULE_NAME, function() {
        console.log('✅ ' + MODULE_NAME + ' initializing...');
        
        // ============================================
        // CALCULATOR STATE
        // ============================================
        
        const CalculatorState = {
            query: '',
            displayValue: '0',
            liveResult: null,
            memory: 0,
            lastResult: null,
            isNewCalculation: true,
            invoiceItems: [],
            invoiceTotal: 0,
            invoiceDiscount: 0,
            invoiceTax: 0,
            invoiceNote: '',
            history: [],
            historyLimit: Infinity, // Keep history until the user explicitly deletes it; never auto-delete entries.
            calculationHistory: [],
            decimalPlaces: 2,
            useThousandsSeparator: true,
            autoSave: true,
            showingResult: false,
            isError: false,
            expressionHistory: [],
            currentHistoryIndex: -1,
            showKeyboard: false,
            internalClipboard: '',
            cursorStart: 0,
            cursorEnd: 0
        };

        // ============================================
        // CORE CALCULATOR ENGINE
        // ============================================
        
        const CalculatorEngine = {
            evaluate(expr) {
                if (!expr || String(expr).trim() === '') return null;
                try {
                    const source = String(expr).replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-').replace(/\s+/g,'');
                    const tokens = [];
                    let i = 0;
                    while (i < source.length) {
                        const c = source[i];
                        if (/[0-9.]/.test(c)) {
                            let j = i, dots = 0;
                            while (j < source.length && /[0-9.]/.test(source[j])) { if (source[j] === '.') dots++; j++; }
                            if (dots > 1) return null;
                            const raw = source.slice(i,j);
                            if (raw === '.') return null;
                            tokens.push({t:'num',v:Number(raw)}); i = j; continue;
                        }
                        if ('+-*/%()'.includes(c)) { tokens.push({t:c,v:c}); i++; continue; }
                        return null;
                    }
                    let p = 0;
                    const peek = () => tokens[p];
                    const take = op => { if (peek() && peek().t === op) { p++; return true; } return false; };
                    const primary = () => {
                        if (take('+')) return primary();
                        if (take('-')) return -primary();
                        if (take('(')) { const v = add(); if (!take(')')) throw new Error('Missing )'); return v; }
                        if (!peek() || peek().t !== 'num') throw new Error('Number expected');
                        const v = peek().v; p++; return v;
                    };
                    const postfix = () => { let v = primary(); while (take('%')) v /= 100; return v; };
                    const mul = () => { let v = postfix(); while (peek() && (peek().t === '*' || peek().t === '/')) { const op=peek().t; p++; const r=postfix(); v=op==='*'?v*r:v/r; } return v; };
                    const add = () => { let v = mul(); while (peek() && (peek().t === '+' || peek().t === '-')) { const op=peek().t; p++; const r=mul(); v=op==='+'?v+r:v-r; } return v; };
                    if (!tokens.length) return null;
                    const result = add();
                    if (p !== tokens.length || Number.isNaN(result)) return null;
                    if (Number.isFinite(result)) return Math.round(result * 1000000) / 1000000;
                    return result;
                } catch (error) { return null; }
            },
            formatNumber(num, decimals = CalculatorState.decimalPlaces) {
                if (num === null || num === undefined || isNaN(num)) return '0';
                if (!isFinite(num)) {
                    if (num > 0) return '∞';
                    if (num < 0) return '-∞';
                    return '0';
                }
                
                const rounded = Number(num.toFixed(decimals));
                
                if (CalculatorState.useThousandsSeparator) {
                    return rounded.toLocaleString('en-US', {
                        minimumFractionDigits: 0,
                        maximumFractionDigits: decimals
                    });
                }
                
                return rounded.toString();
            },
            
            parseNumber(str) {
                if (!str) return 0;
                return parseFloat(str.replace(/,/g, '')) || 0;
            },
            
            memoryAdd(value) {
                CalculatorState.memory += value;
                return CalculatorState.memory;
            },
            
            memorySubtract(value) {
                CalculatorState.memory -= value;
                return CalculatorState.memory;
            },
            
            memoryClear() {
                CalculatorState.memory = 0;
                return 0;
            },
            
            memoryRecall() {
                return CalculatorState.memory;
            }
        };

        // ============================================
        // HISTORY MANAGEMENT
        // ============================================
        
        const HistoryManager = {
            saveCalculation(expression, result, type = 'calculation', items = null) {
                let fullQuery = expression;
                let displayResult = result;
                
                if (typeof result === 'number' && !isFinite(result)) {
                    displayResult = result > 0 ? 'Infinity' : '-Infinity';
                }
                
                let displayExpression = expression;
                displayExpression = displayExpression.replace(/\*/g, '×');
                displayExpression = displayExpression.replace(/\//g, '÷');
                displayExpression = displayExpression.replace(/-/g, '−');
                
                let formattedResult = CalculatorEngine.formatNumber(result);
                const fullDisplay = displayExpression + ' = ' + formattedResult;
                
                if (type === 'invoice' && items && items.length) {
                    const itemDetails = items.map(item => 
                        `${item.qty}×${item.price}=${CalculatorEngine.formatNumber(item.total)}`
                    ).join(' + ');
                    fullDisplay = `${itemDetails} = ${CalculatorEngine.formatNumber(result)}`;
                }
                
                if (type === 'sale') {
                    fullDisplay = `💰 SALE: ${fullDisplay}`;
                } else if (type === 'purchase') {
                    fullDisplay = `📥 PURCHASE: ${fullDisplay}`;
                }
                
                const entry = {
                    id: 'calc_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
                    expression: fullDisplay,
                    originalExpression: expression,
                    displayExpression: displayExpression,
                    result: result,
                    displayResult: displayResult,
                    formattedResult: formattedResult,
                    fullDisplay: fullDisplay,
                    type: type,
                    timestamp: new Date().toISOString(),
                    date: new Date().toLocaleString(),
                    items: items ? JSON.parse(JSON.stringify(items)) : null,
                    imported: false,
                    importedAs: null
                };
                
                CalculatorState.calculationHistory.unshift(entry);
                CalculatorState.expressionHistory.unshift({
                    query: expression,
                    displayQuery: displayExpression,
                    result: result,
                    displayResult: displayResult,
                    formattedResult: formattedResult,
                    fullDisplay: fullDisplay
                });
                
                CalculatorState.history.unshift({
                    id: entry.id,
                    expression: fullDisplay,
                    displayExpression: displayExpression,
                    query: expression,
                    result: result,
                    displayResult: displayResult,
                    formattedResult: formattedResult,
                    fullDisplay: fullDisplay,
                    timestamp: entry.timestamp,
                    type: type
                });
                
                this.saveToStorage(entry);
                return entry;
            },
            
            saveToStorage(entry) {
                try {
                    const saved = JSON.parse(localStorage.getItem('SP_calculations_history') || '[]');
                    saved.unshift(entry);
                    localStorage.setItem('SP_calculations_history', JSON.stringify(saved));
                    
                    const today = new Date().toISOString().slice(0, 10);
                    const dailyKey = 'SP_calc_daily_' + today;
                    const daily = JSON.parse(localStorage.getItem(dailyKey) || '[]');
                    daily.unshift(entry);
                    localStorage.setItem(dailyKey, JSON.stringify(daily));
                    
                } catch (e) {
                    console.warn('Failed to save calculation history:', e);
                }
            },
            
            loadFromStorage() {
                try {
                    const saved = JSON.parse(localStorage.getItem('SP_calculations_history') || '[]');
                    if (saved.length) {
                        CalculatorState.calculationHistory = saved;
                        CalculatorState.history = saved.map(entry => ({
                            id: entry.id,
                            expression: entry.expression || 'Calculation',
                            displayExpression: entry.displayExpression || entry.originalExpression || entry.expression,
                            query: entry.originalExpression || entry.expression,
                            result: entry.result || 0,
                            displayResult: entry.displayResult || entry.formattedResult || '0',
                            formattedResult: entry.formattedResult || CalculatorEngine.formatNumber(entry.result),
                            fullDisplay: entry.fullDisplay || entry.expression,
                            timestamp: entry.timestamp || new Date().toISOString(),
                            type: entry.type || 'calculation'
                        }));
                        CalculatorState.expressionHistory = saved.map(e => ({
                            id: e.id,
                            query: e.originalExpression || e.expression,
                            displayQuery: e.displayExpression || e.originalExpression || e.expression,
                            result: e.result,
                            displayResult: e.displayResult || e.formattedResult,
                            formattedResult: e.formattedResult || CalculatorEngine.formatNumber(e.result),
                            fullDisplay: e.fullDisplay || e.expression
                        }));
                    }
                    return saved;
                } catch (e) {
                    console.warn('Failed to load calculation history:', e);
                    return [];
                }
            },
            
            getAll() {
                return CalculatorState.calculationHistory;
            },
            
            recallPrevious() {
                if (CalculatorState.expressionHistory.length === 0) return null;
                const idx = Math.min(CalculatorState.currentHistoryIndex + 1, CalculatorState.expressionHistory.length - 1);
                CalculatorState.currentHistoryIndex = idx;
                const entry = CalculatorState.expressionHistory[idx];
                return {
                    query: entry.query || entry.expression,
                    displayQuery: entry.displayQuery || entry.query,
                    result: entry.result,
                    displayResult: entry.displayResult || entry.formattedResult,
                    formattedResult: entry.formattedResult || CalculatorEngine.formatNumber(entry.result),
                    fullDisplay: entry.fullDisplay,
                    fullEntry: CalculatorState.calculationHistory[idx] || null
                };
            },
            
            recallNext() {
                if (CalculatorState.expressionHistory.length === 0) return null;
                const idx = Math.max(CalculatorState.currentHistoryIndex - 1, 0);
                CalculatorState.currentHistoryIndex = idx;
                const entry = CalculatorState.expressionHistory[idx];
                return {
                    query: entry.query || entry.expression,
                    displayQuery: entry.displayQuery || entry.query,
                    result: entry.result,
                    displayResult: entry.displayResult || entry.formattedResult,
                    formattedResult: entry.formattedResult || CalculatorEngine.formatNumber(entry.result),
                    fullDisplay: entry.fullDisplay,
                    fullEntry: CalculatorState.calculationHistory[idx] || null
                };
            },
            
            resetRecall() {
                CalculatorState.currentHistoryIndex = -1;
            },
            
            delete(id) {
                const targetId = String(id);
                const removed = CalculatorState.calculationHistory.find(e => String(e.id) === targetId);
                if (!removed) return false;

                CalculatorState.calculationHistory = CalculatorState.calculationHistory.filter(e => String(e.id) !== targetId);
                CalculatorState.history = CalculatorState.history.filter(h => String(h.id || '') !== targetId);
                CalculatorState.expressionHistory = CalculatorState.calculationHistory.map(e => ({
                    id: e.id,
                    query: e.originalExpression || e.expression,
                    displayQuery: e.displayExpression || e.originalExpression || e.expression,
                    result: e.result,
                    displayResult: e.displayResult || e.formattedResult,
                    formattedResult: e.formattedResult || CalculatorEngine.formatNumber(e.result),
                    fullDisplay: e.fullDisplay || e.expression
                }));

                localStorage.setItem('SP_calculations_history', JSON.stringify(CalculatorState.calculationHistory));

                // Remove only this entry from its daily mirror; history is never auto-deleted.
                Object.keys(localStorage).forEach(key => {
                    if (!key.startsWith('SP_calc_daily_')) return;
                    try {
                        const daily = JSON.parse(localStorage.getItem(key) || '[]');
                        const filtered = daily.filter(e => String(e.id) !== targetId);
                        if (filtered.length !== daily.length) {
                            if (filtered.length) localStorage.setItem(key, JSON.stringify(filtered));
                            else localStorage.removeItem(key);
                        }
                    } catch (_) {}
                });
                CalculatorState.currentHistoryIndex = -1;
                return true;
            },
            
            clearAll() {
                if (!confirm('⚠️ Delete ALL calculation history?')) return false;
                CalculatorState.calculationHistory = [];
                CalculatorState.history = [];
                CalculatorState.expressionHistory = [];
                CalculatorState.currentHistoryIndex = -1;
                localStorage.removeItem('SP_calculations_history');
                const keys = Object.keys(localStorage);
                keys.forEach(key => {
                    if (key.startsWith('SP_calc_daily_')) {
                        localStorage.removeItem(key);
                    }
                });
                return true;
            },
            
            exportCSV() {
                const data = CalculatorState.calculationHistory;
                if (!data.length) {
                    Toast.warning('No history to export');
                    return;
                }
                
                let csv = 'Date,Query,Result,Type,Items\n';
                data.forEach(entry => {
                    const itemsStr = entry.items ? entry.items.map(i => `${i.qty}×${i.price}`).join('; ') : '';
                    const resultStr = entry.displayResult || entry.formattedResult || entry.result;
                    const queryStr = entry.displayExpression || entry.originalExpression || entry.expression;
                    csv += `"${entry.date || entry.timestamp}","${queryStr}","${resultStr}",${entry.type || 'calculation'},"${itemsStr}"\n`;
                });
                
                Helpers.downloadFile(csv, 'calculation-history.csv');
                Toast.success('History exported!');
            }
        };

        // ============================================
        // CALCULATOR OBJECT
        // ============================================
        
        const Calculator = {
            setExpression(value) {
                CalculatorState.query = value;
                CalculatorState.showingResult = false;
                CalculatorState.isNewCalculation = false;
                this.updateDisplay();
                this.updateLiveResult();
            },
            
            insertAtCursor(text) {
                const exprInput = document.getElementById('calcExpressionInput');
                if (!exprInput) {
                    this.digit(String(text || ''));
                    return;
                }

                const wasFocused = document.activeElement === exprInput;
                let start = wasFocused && Number.isFinite(exprInput.selectionStart)
                    ? exprInput.selectionStart : Number(CalculatorState.cursorStart) || 0;
                let end = wasFocused && Number.isFinite(exprInput.selectionEnd)
                    ? exprInput.selectionEnd : Number(CalculatorState.cursorEnd) || start;
                const current = CalculatorState.query || '';
                start = Math.max(0, Math.min(start, current.length));
                end = Math.max(start, Math.min(end, current.length));
                const value = String(text ?? '');
                const newQuery = current.substring(0, start) + value + current.substring(end);
                const newPos = start + value.length;

                CalculatorState.query = newQuery;
                CalculatorState.cursorStart = newPos;
                CalculatorState.cursorEnd = newPos;
                CalculatorState.showingResult = false;
                CalculatorState.isNewCalculation = false;
                this.updateDisplay();
                this.updateLiveResult();

                // Critical AppMint/WebView rule: calculator keypad presses must NOT
                // focus the text input, otherwise Android immediately opens the keyboard.
                if (wasFocused) {
                    try {
                        exprInput.focus({ preventScroll: true });
                        exprInput.setSelectionRange(newPos, newPos);
                    } catch (e) {}
                }
            },
            
            digit(value) {
                if (CalculatorState.showingResult) {
                    CalculatorState.query = '';
                    CalculatorState.showingResult = false;
                }
                
                if (CalculatorState.isNewCalculation) {
                    CalculatorState.query = '';
                    CalculatorState.isNewCalculation = false;
                }
                
                this.insertAtCursor(value);
            },
            
            decimal() {
                if (CalculatorState.showingResult) {
                    CalculatorState.query = '0.';
                    CalculatorState.showingResult = false;
                    CalculatorState.isNewCalculation = false;
                    this.updateDisplay();
                    this.updateLiveResult();
                    return;
                }
                
                if (CalculatorState.isNewCalculation) {
                    CalculatorState.query = '0.';
                    CalculatorState.isNewCalculation = false;
                    this.updateDisplay();
                    this.updateLiveResult();
                    return;
                }
                
                const parts = CalculatorState.query.split(/[\+\−\×\÷]/);
                const lastPart = parts[parts.length - 1];
                
                if (!lastPart.includes('.')) {
                    this.insertAtCursor('.');
                }
            },
            
            operator(op) {
                if (CalculatorState.showingResult) {
                    CalculatorState.query = CalculatorState.displayValue + ' ' + op + ' ';
                    CalculatorState.showingResult = false;
                    this.updateDisplay();
                    this.updateLiveResult();
                    return;
                }
                
                if (!CalculatorState.query && CalculatorState.displayValue === '0') {
                    return;
                }
                
                const lastChar = CalculatorState.query.trim().slice(-1);
                if (['+', '−', '×', '÷'].includes(lastChar)) {
                    CalculatorState.query = CalculatorState.query.slice(0, -2) + ' ' + op + ' ';
                    this.updateDisplay();
                    this.updateLiveResult();
                    return;
                }
                
                this.insertAtCursor(' ' + op + ' ');
            },
            
            backspace() {
                if (CalculatorState.showingResult) {
                    CalculatorState.query = '';
                    CalculatorState.showingResult = false;
                    this.updateDisplay();
                    this.updateLiveResult();
                    return;
                }
                
                const exprInput = document.getElementById('calcExpressionInput');
                if (exprInput && exprInput.selectionStart === exprInput.selectionEnd) {
                    const pos = exprInput.selectionStart;
                    if (pos > 0) {
                        const current = CalculatorState.query;
                        const newQuery = current.substring(0, pos - 1) + current.substring(pos);
                        CalculatorState.query = newQuery;
                        this.updateDisplay();
                        this.updateLiveResult();
                        setTimeout(() => {
                            exprInput.focus();
                            exprInput.selectionStart = pos - 1;
                            exprInput.selectionEnd = pos - 1;
                        }, 10);
                        return;
                    }
                }
                
                if (CalculatorState.query.endsWith(' ')) {
                    CalculatorState.query = CalculatorState.query.slice(0, -3);
                } else {
                    CalculatorState.query = CalculatorState.query.slice(0, -1);
                }
                
                if (!CalculatorState.query) {
                    CalculatorState.query = '';
                    CalculatorState.displayValue = '0';
                    CalculatorState.liveResult = null;
                }
                
                this.updateDisplay();
                this.updateLiveResult();
            },
            
            clear() {
                CalculatorState.query = '';
                CalculatorState.displayValue = '0';
                CalculatorState.liveResult = null;
                CalculatorState.isNewCalculation = true;
                CalculatorState.showingResult = false;
                CalculatorState.isError = false;
                this.updateDisplay();
                HistoryManager.resetRecall();
                this.renderHistory();
            },
            
            clearAll() {
                this.clear();
                CalculatorState.memory = 0;
                CalculatorState.lastResult = null;
                this.updateDisplay();
                Toast.info('Cleared all');
            },
            
            percent() {
                if (!CalculatorState.query) return;
                
                const result = CalculatorEngine.evaluate(
                    CalculatorState.query.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-')
                );
                
                if (result === null) return;
                
                const percentResult = result / 100;
                CalculatorState.query = percentResult.toString();
                CalculatorState.displayValue = CalculatorEngine.formatNumber(percentResult);
                CalculatorState.showingResult = true;
                CalculatorState.liveResult = percentResult;
                this.updateDisplay();
            },
            
            updateLiveResult() {
                const resultEl = document.getElementById('calcResult');
                if (!resultEl) return;
                
                if (!CalculatorState.query || CalculatorState.query.trim() === '') {
                    resultEl.textContent = '0';
                    resultEl.style.color = 'var(--text)';
                    CalculatorState.liveResult = null;
                    return;
                }
                
                const trimmed = CalculatorState.query.trim();
                if (/[\+\−\×\÷]$/.test(trimmed)) {
                    resultEl.textContent = '...';
                    resultEl.style.color = 'var(--text2)';
                    CalculatorState.liveResult = null;
                    return;
                }
                
                const result = CalculatorEngine.evaluate(
                    CalculatorState.query
                        .replace(/×/g, '*')
                        .replace(/÷/g, '/')
                        .replace(/−/g, '-')
                );
                
                if (result === null) {
                    resultEl.textContent = '';
                    resultEl.style.color = 'var(--text2)';
                    CalculatorState.liveResult = null;
                    CalculatorState.isError = false;
                    return;
                }
                
                CalculatorState.liveResult = result;
                CalculatorState.isError = false;
                
                if (typeof result === 'number' && !isFinite(result)) {
                    resultEl.textContent = result > 0 ? '∞' : '-∞';
                    resultEl.style.color = 'var(--warning)';
                    return;
                }
                
                resultEl.textContent = CalculatorEngine.formatNumber(result);
                resultEl.style.color = 'var(--primary)';
            },
            
            equals() {
                if (!CalculatorState.query) return;
                
                let result = CalculatorState.liveResult;
                
                if (result === null) {
                    result = CalculatorEngine.evaluate(
                        CalculatorState.query
                            .replace(/×/g, '*')
                            .replace(/÷/g, '/')
                            .replace(/−/g, '-')
                    );
                }
                
                if (result === null) {
                    Toast.warning('Invalid expression');
                    return;
                }
                
                const displayQuery = CalculatorState.query;
                
                HistoryManager.saveCalculation(displayQuery, result, 'calculation');
                
                if (typeof result === 'number' && !isFinite(result)) {
                    CalculatorState.displayValue = result > 0 ? '∞' : '-∞';
                } else {
                    CalculatorState.displayValue = CalculatorEngine.formatNumber(result);
                }
                
                CalculatorState.showingResult = true;
                CalculatorState.lastResult = result;
                CalculatorState.isNewCalculation = true;
                CalculatorState.liveResult = result;
                
                this.updateDisplay();
                this.renderHistory();
                renderAllHistory();
                updateHistoryCount();
                
                const displayMsg = typeof result === 'number' && !isFinite(result) ? 
                    (result > 0 ? '∞' : '-∞') : 
                    CalculatorEngine.formatNumber(result);
                const displayExpr = displayQuery.replace(/\*/g, '×').replace(/\//g, '÷').replace(/-/g, '−');
                Toast.success('✅ ' + displayExpr + ' = ' + displayMsg);
            },
            
            // ============================================
            // HISTORY RECALL / COPY / PASTE
            // ============================================


            // AppMint/Android WebView compatibility: inline onclick handlers can be
            // ignored by some WebView CSP/bridge configurations. Install real DOM
            // listeners after rendering so calculator controls remain functional.
            installWebViewEventBridge() {
                const root = document.getElementById('tab-calculator');
                if (!root) return;

                const parseArgs = (raw) => {
                    raw = String(raw || '').trim();
                    if (!raw) return [];
                    const out = [];
                    const re = /'(?:\\'|[^'])*'|"(?:\\"|[^"])*"|[^,]+/g;
                    let m;
                    while ((m = re.exec(raw))) {
                        let a = m[0].trim();
                        if ((a[0] === "'" && a[a.length - 1] === "'") ||
                            (a[0] === '"' && a[a.length - 1] === '"')) {
                            a = a.slice(1, -1).replace(/\\(['"])/g, '$1');
                        }
                        if (a === 'true') a = true;
                        else if (a === 'false') a = false;
                        else if (a === 'null') a = null;
                        out.push(a);
                    }
                    return out;
                };

                root.querySelectorAll('[onclick]').forEach((el) => {
                    if (el.dataset.spCalcBound === '1') return;
                    const source = el.getAttribute('onclick') || '';
                    const match = source.match(/Calculator\.([A-Za-z_$][\w$]*)\s*\(([^)]*)\)/);
                    if (!match || typeof Calculator[match[1]] !== 'function') return;

                    const method = match[1];
                    const args = parseArgs(match[2]);
                    el.dataset.spCalcBound = '1';
                    el.addEventListener('click', function(ev) {
                        // Reproduce the common inline event.stopPropagation() behavior.
                        if (/event\.stopPropagation\(\)/.test(source)) ev.stopPropagation();
                        try {
                            const fn = Calculator[method];
                            if (typeof fn === 'function') fn.apply(Calculator, args);
                        } catch (err) {
                            console.error('Calculator WebView action failed:', method, err);
                            if (typeof Toast !== 'undefined' && Toast.error) {
                                Toast.error('Calculator action failed: ' + method);
                            }
                        }
                    }, false);
                    // Remove the inline handler so WebView CSP cannot create a second
                    // path or interfere with the direct listener.
                    el.removeAttribute('onclick');
                });
            },

            ensureCalculatorGlobal() {
                if (window.Calculator !== Calculator) window.Calculator = Calculator;
                return true;
            },

            getHistoryEntry(indexOrId) {
                if (typeof indexOrId === 'number') return CalculatorState.calculationHistory[indexOrId] || null;
                return CalculatorState.calculationHistory.find(e => e.id === String(indexOrId)) || null;
            },

            getHistoryIndex(indexOrId) {
                if (typeof indexOrId === 'number') return indexOrId;
                return CalculatorState.calculationHistory.findIndex(e => e.id === String(indexOrId));
            },

            // WebView-safe internal clipboard. This never depends on Android's
            // context-menu clipboard implementation. Native clipboard is used
            // when available, but the internal clipboard is always maintained
            // as a reliable fallback.
            setInternalClipboard(text) {
                text = String(text ?? '');
                CalculatorState.internalClipboard = text;
                try {
                    localStorage.setItem('stockpro_calculator_clipboard', text);
                } catch (e) {}
                return text;
            },

            getInternalClipboard() {
                if (CalculatorState.internalClipboard) return CalculatorState.internalClipboard;
                try {
                    return localStorage.getItem('stockpro_calculator_clipboard') || '';
                } catch (e) {
                    return '';
                }
            },

            async copyToClipboard(text, label = 'Value') {
                text = String(text ?? '');
                this.setInternalClipboard(text);

                // Try the native clipboard as an optional enhancement.
                // Failure here must never make Copy unavailable.
                try {
                    if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
                        await navigator.clipboard.writeText(text);
                    } else {
                        const ta = document.createElement('textarea');
                        ta.value = text;
                        ta.setAttribute('readonly', '');
                        ta.style.position = 'fixed';
                        ta.style.left = '-9999px';
                        ta.style.top = '0';
                        document.body.appendChild(ta);
                        ta.focus();
                        ta.select();
                        try { document.execCommand('copy'); } catch (e) {}
                        ta.remove();
                    }
                } catch (e) {}

                Toast.success('📋 ' + label + ' copied');
                return true;
            },

            async pasteFromClipboard() {
                let text = '';

                // First try native clipboard so text copied outside CashTracker
                // can still be pasted when the Android WebView permits it.
                try {
                    if (navigator.clipboard && typeof navigator.clipboard.readText === 'function') {
                        text = await navigator.clipboard.readText();
                    }
                } catch (e) {}

                // The guaranteed WebView-safe fallback.
                if (!text) text = this.getInternalClipboard();

                if (!text) {
                    Toast.warning('Clipboard is empty');
                    return false;
                }

                this.insertAtCursor(text);
                Toast.success('📥 Pasted');
                return true;
            },

            selectAllExpression() {
                const input = document.getElementById('calcExpressionInput');
                if (!input) return false;
                input.focus();
                try { input.select(); } catch (e) {
                    input.setSelectionRange(0, input.value.length);
                }
                return true;
            },

            copySelectionOrExpression() {
                const input = document.getElementById('calcExpressionInput');
                if (!input) return false;
                const start = Number.isFinite(input.selectionStart) ? input.selectionStart : 0;
                const end = Number.isFinite(input.selectionEnd) ? input.selectionEnd : 0;
                const text = start !== end ? input.value.slice(start, end) : input.value;
                return this.copyToClipboard(text, start !== end ? 'Selection' : 'Expression');
            },

            cutSelectionOrExpression() {
                const input = document.getElementById('calcExpressionInput');
                if (!input) return false;
                const start = Number.isFinite(input.selectionStart) ? input.selectionStart : 0;
                const end = Number.isFinite(input.selectionEnd) ? input.selectionEnd : 0;
                if (start !== end) {
                    const selected = input.value.slice(start, end);
                    this.copyToClipboard(selected, 'Selection');
                    input.setRangeText('', start, end, 'start');
                    input.dispatchEvent(new Event('input', { bubbles: true }));
                    return true;
                }
                return this.copyToClipboard(input.value, 'Expression');
            },

            clearInternalClipboard() {
                CalculatorState.internalClipboard = '';
                try { localStorage.removeItem('stockpro_calculator_clipboard'); } catch (e) {}
            },

            recallQuery(indexOrId) {
                const entry = this.getHistoryEntry(indexOrId);
                if (!entry) return;
                const query = entry.originalExpression || entry.query || entry.expression || '';
                this.insertAtCursor(query);
                this.copyToClipboard(query, 'Query');
            },

            recallResult(indexOrId) {
                const entry = this.getHistoryEntry(indexOrId);
                if (!entry) return;
                const result = entry.result;
                const value = (typeof result === 'number' && isFinite(result))
                    ? String(result)
                    : String(entry.formattedResult || entry.displayResult || (result ?? ''));
                this.insertAtCursor(value.replace(/,/g, ''));
                this.copyToClipboard(value.replace(/,/g, ''), 'Result');
            },

            recallBoth(indexOrId) {
                const entry = this.getHistoryEntry(indexOrId);
                if (!entry) return;
                const query = entry.originalExpression || entry.query || entry.expression || '';
                const result = entry.result;
                CalculatorState.query = query;
                CalculatorState.displayValue = (typeof result === 'number' && !isFinite(result))
                    ? (result > 0 ? '∞' : '-∞')
                    : (entry.formattedResult || CalculatorEngine.formatNumber(result));
                CalculatorState.liveResult = result;
                CalculatorState.showingResult = true;
                CalculatorState.isNewCalculation = false;
                CalculatorState.isError = false;
                CalculatorState.currentHistoryIndex = this.getHistoryIndex(entry.id);
                this.updateDisplay();
                this.updateLiveResult();
                const input = document.getElementById('calcExpressionInput');
                if (input) {
                    CalculatorState.cursorStart = input.value.length;
                    CalculatorState.cursorEnd = input.value.length;
                    // Do not focus: recalling history must not open the Android keyboard.
                    try { input.blur(); } catch (e) {}
                }
                Toast.info('📥 Loaded calculation');
            },

            recallPrevious() {
                const entry = HistoryManager.recallPrevious();
                if (!entry) return Toast.warning('No more history');
                this.loadHistoryEntry(entry);
            },

            recallNext() {
                const entry = HistoryManager.recallNext();
                if (!entry) return Toast.warning('No more history');
                this.loadHistoryEntry(entry);
            },

            loadHistoryEntry(entry) {
                if (!entry) return;
                CalculatorState.query = entry.query || '';
                const result = entry.result;
                CalculatorState.displayValue = (typeof result === 'number' && !isFinite(result))
                    ? (result > 0 ? '∞' : '-∞')
                    : (entry.formattedResult || entry.displayResult || CalculatorEngine.formatNumber(result));
                CalculatorState.liveResult = result;
                CalculatorState.showingResult = true;
                CalculatorState.isNewCalculation = false;
                this.updateDisplay();
                this.updateLiveResult();
                const input = document.getElementById('calcExpressionInput');
                if (input) {
                    CalculatorState.cursorStart = input.value.length;
                    CalculatorState.cursorEnd = input.value.length;
                    try { input.blur(); } catch (e) {}
                }
            },

            // Legacy compatibility
            recallHistory(index) { this.recallBoth(index); },

            memoryClear() {
                CalculatorEngine.memoryClear();
                this.updateDisplay();
                Toast.info('Memory cleared');
            },
            
            memoryRecall() {
                const value = CalculatorEngine.memoryRecall();
                CalculatorState.query = value.toString();
                CalculatorState.displayValue = CalculatorEngine.formatNumber(value);
                CalculatorState.showingResult = true;
                CalculatorState.liveResult = value;
                this.updateDisplay();
                this.updateLiveResult();
            },
            
            memoryAdd() {
                const current = CalculatorEngine.parseNumber(CalculatorState.displayValue);
                CalculatorEngine.memoryAdd(current);
                this.updateDisplay();
                Toast.info('Added to memory');
            },
            
            memorySubtract() {
                const current = CalculatorEngine.parseNumber(CalculatorState.displayValue);
                CalculatorEngine.memorySubtract(current);
                this.updateDisplay();
                Toast.info('Subtracted from memory');
            },
            
            updateDisplay() {
                const resultEl = document.getElementById('calcResult');
                const inputEl = document.getElementById('calcExpressionInput');
                const memoryEl = document.getElementById('calcMemory');
                const queryDisplay = document.getElementById('calcQueryDisplay');
                
                if (inputEl) {
                    inputEl.value = CalculatorState.query;
                    inputEl.removeAttribute('readonly');
                    inputEl.removeAttribute('disabled');
                }
                
                if (queryDisplay) {
                    queryDisplay.textContent = CalculatorState.query || '\u00A0';
                }
                
                if (resultEl) {
                    if (CalculatorState.showingResult && CalculatorState.displayValue !== '0') {
                        resultEl.textContent = CalculatorState.displayValue;
                        resultEl.style.fontSize = '2.2rem';
                        resultEl.style.color = 'var(--success)';
                    } else if (CalculatorState.liveResult !== null && !CalculatorState.isError) {
                        if (!resultEl.textContent || resultEl.textContent === '0' || resultEl.textContent === '...' || resultEl.textContent === '') {
                            if (typeof CalculatorState.liveResult === 'number' && !isFinite(CalculatorState.liveResult)) {
                                resultEl.textContent = CalculatorState.liveResult > 0 ? '∞' : '-∞';
                            } else {
                                resultEl.textContent = CalculatorEngine.formatNumber(CalculatorState.liveResult);
                            }
                            resultEl.style.color = 'var(--primary)';
                        }
                    } else if (CalculatorState.isError) {
                        resultEl.textContent = '';
                        resultEl.style.color = 'var(--text2)';
                    } else {
                        resultEl.textContent = CalculatorState.displayValue || '0';
                        resultEl.style.color = 'var(--text)';
                    }
                }
                
                if (memoryEl) {
                    memoryEl.textContent = CalculatorState.memory !== 0 ? 
                        'M: ' + CalculatorEngine.formatNumber(CalculatorState.memory) : '';
                }
            },
            
            renderHistory() {
                const container = document.getElementById('calcHistoryList');
                if (!container) return;
                
                const history = CalculatorState.history;
                
                if (!history || history.length === 0) {
                    container.innerHTML = '<div class="history-empty">📋 No calculations yet</div>';
                    return;
                }
                
                container.innerHTML = history.map((entry, i) => {
                    const typeIcon = entry.type === 'sale' ? '💰' : 
                                   entry.type === 'purchase' ? '📥' : 
                                   entry.type === 'invoice' ? '🧾' : '';
                    const displayResult = entry.displayResult || entry.formattedResult || CalculatorEngine.formatNumber(entry.result);
                    const displayQuery = entry.displayExpression || entry.query || entry.expression;
                    
                    let dateStr = '';
                    try {
                        const date = new Date(entry.timestamp);
                        dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
                    } catch(e) {}
                    
                    return `
                        <div class="history-item" onclick="Calculator.recallBoth('${entry.id}')" title="Tap the query to recall it, or tap the result to recall the result">
                            <div class="history-item-content">
                                <div class="history-query" onclick="event.stopPropagation(); Calculator.recallQuery('${entry.id}')" style="cursor:pointer;">${typeIcon} ${displayQuery}</div>
                                <div class="history-result-display" onclick="event.stopPropagation(); Calculator.recallResult('${entry.id}')" style="cursor:pointer;">= ${displayResult}</div>
                                ${dateStr ? `<div class="history-date">${dateStr}</div>` : ''}
                            </div>
                            <div class="history-actions">
                                <button class="history-btn query-btn" onclick="event.stopPropagation(); Calculator.recallQuery('${entry.id}')" title="Recall and copy query">📋</button>
                                <button class="history-btn result-btn" onclick="event.stopPropagation(); Calculator.recallResult('${entry.id}')" title="Recall and copy result">🔢</button>
                                <button class="history-btn both-btn" onclick="event.stopPropagation(); Calculator.recallBoth('${entry.id}')" title="Load Both">📥</button>
                                <button class="history-btn" onclick="event.stopPropagation(); Calculator.createTransactionFromHistory('${entry.id}')" title="Create Sale, Purchase or Return">⚡</button>
                                <button class="history-delete-btn" onclick="event.stopPropagation(); Calculator.deleteHistoryItem('${entry.id || i}')">✕</button>
                            </div>
                        </div>
                    `;
                }).join('');
                
                if (container.scrollTop > 0) {
                    container.scrollTop = 0;
                }
            },
            
            deleteHistoryItem(id) {
                if (!confirm('Delete this calculation?')) return;
                HistoryManager.delete(id);
                this.renderHistory();
                renderAllHistory();
                updateHistoryCount();
                Toast.info('Deleted');
            },
            
            clearHistory() {
                if (!confirm('⚠️ Delete ALL calculation history?')) return;
                HistoryManager.clearAll();
                this.renderHistory();
                renderAllHistory();
                updateHistoryCount();
                Toast.info('History cleared');
            },
            
            toggleHistory() {
                const panel = document.getElementById('calcHistoryPanel');
                if (panel) {
                    panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
                    if (panel.style.display === 'block') this.renderHistory();
                }
            },
            
            toggleAllHistory() {
                const panel = document.getElementById('calcAllHistoryPanel');
                if (panel) {
                    panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
                    if (panel.style.display === 'block') renderAllHistory();
                }
            },
            
            toggleSettings() {
                const decimal = prompt('Decimal places (0-6):', CalculatorState.decimalPlaces);
                if (decimal !== null && !isNaN(decimal)) {
                    CalculatorState.decimalPlaces = Math.min(6, Math.max(0, parseInt(decimal)));
                    this.updateDisplay();
                    this.updateLiveResult();
                    Toast.info('Decimal places: ' + CalculatorState.decimalPlaces);
                }
            },
            
            searchHistory() {
                renderAllHistory();
            },
            
            filterHistory() {
                renderAllHistory();
            },

            // ============================================
            // INVOICE BUILDER
            // ============================================
            
            addToInvoice() {
                const value = CalculatorState.liveResult || CalculatorEngine.parseNumber(CalculatorState.displayValue);
                
                if (value === 0) {
                    Toast.warning('No value to add');
                    return;
                }
                
                let qty = 1;
                let price = value;
                let desc = '';
                
                const match = CalculatorState.query.match(/^(\d+)\s*[×x]\s*([\d.]+)/);
                if (match) {
                    qty = parseFloat(match[1]);
                    price = parseFloat(match[2]);
                    desc = qty + ' × ' + CalculatorEngine.formatNumber(price);
                } else {
                    desc = '1 × ' + CalculatorEngine.formatNumber(value);
                }
                
                const item = {
                    id: Date.now().toString(36) + Math.random().toString(36).substr(2, 4),
                    qty: qty,
                    price: price,
                    total: qty * price,
                    desc: desc,
                    expression: CalculatorState.query || desc,
                    timestamp: new Date().toISOString()
                };
                
                CalculatorState.invoiceItems.push(item);
                this.updateInvoice();
                
                Toast.success('Added: ' + desc + ' = ' + CalculatorEngine.formatNumber(item.total));
                this.clear();
            },
            
            removeInvoiceItem(id) {
                CalculatorState.invoiceItems = CalculatorState.invoiceItems.filter(item => item.id !== id);
                this.updateInvoice();
            },
            
            clearInvoice() {
                if (!CalculatorState.invoiceItems.length) return;
                if (!confirm('Clear all invoice items?')) return;
                CalculatorState.invoiceItems = [];
                CalculatorState.invoiceDiscount = 0;
                CalculatorState.invoiceTax = 0;
                this.updateInvoice();
                Toast.info('Invoice cleared');
            },
            
            applyDiscount() {
                if (!CalculatorState.invoiceItems.length) {
                    Toast.warning('No items to discount');
                    return;
                }
                
                const percent = prompt('Discount percentage (%):', '10');
                if (percent === null) return;
                if (isNaN(percent) || parseFloat(percent) < 0) {
                    Toast.warning('Invalid percentage');
                    return;
                }
                
                CalculatorState.invoiceDiscount = parseFloat(percent);
                this.updateInvoice();
                Toast.success('Discount: ' + CalculatorState.invoiceDiscount + '%');
            },
            
            applyTax() {
                if (!CalculatorState.invoiceItems.length) {
                    Toast.warning('No items to tax');
                    return;
                }
                
                const percent = prompt('Tax percentage (%):', '15');
                if (percent === null) return;
                if (isNaN(percent) || parseFloat(percent) < 0) {
                    Toast.warning('Invalid percentage');
                    return;
                }
                
                CalculatorState.invoiceTax = parseFloat(percent);
                this.updateInvoice();
                Toast.success('Tax: ' + CalculatorState.invoiceTax + '%');
            },
            
            updateInvoice() {
                const subtotal = CalculatorState.invoiceItems.reduce((sum, item) => sum + item.total, 0);
                const discountAmount = (subtotal * CalculatorState.invoiceDiscount) / 100;
                const taxAmount = ((subtotal - discountAmount) * CalculatorState.invoiceTax) / 100;
                const total = subtotal - discountAmount + taxAmount;
                
                CalculatorState.invoiceTotal = total;
                
                const container = document.getElementById('invoiceItems');
                const countEl = document.getElementById('invoiceCount');
                
                if (!container) return;
                
                if (countEl) {
                    countEl.textContent = CalculatorState.invoiceItems.length + ' items';
                }
                
                if (!CalculatorState.invoiceItems.length) {
                    container.innerHTML = '<div class="empty-state">No items added</div>';
                } else {
                    container.innerHTML = CalculatorState.invoiceItems.map(item => `
                        <div class="invoice-item">
                            <div class="invoice-item-info">
                                <span class="invoice-item-desc">${item.desc}</span>
                                <span class="invoice-item-total">${CalculatorEngine.formatNumber(item.total)}</span>
                            </div>
                            <button class="btn btn-sm btn-danger" onclick="Calculator.removeInvoiceItem('${item.id}')">✕</button>
                        </div>
                    `).join('');
                }
                
                document.getElementById('invoiceSubtotal').textContent = 'ETB ' + CalculatorEngine.formatNumber(subtotal);
                document.getElementById('invoiceDiscountPercent').textContent = CalculatorState.invoiceDiscount;
                document.getElementById('invoiceDiscountAmount').textContent = 'ETB ' + CalculatorEngine.formatNumber(discountAmount);
                document.getElementById('invoiceTaxPercent').textContent = CalculatorState.invoiceTax;
                document.getElementById('invoiceTaxAmount').textContent = 'ETB ' + CalculatorEngine.formatNumber(taxAmount);
                document.getElementById('invoiceGrandTotal').textContent = 'ETB ' + CalculatorEngine.formatNumber(total);
            },
            
            saveInvoice() {
                if (!CalculatorState.invoiceItems.length) {
                    Toast.warning('No items to save');
                    return;
                }
                
                const note = document.getElementById('invoiceNote')?.value || '';
                
                const invoice = {
                    id: 'inv_' + Date.now(),
                    items: JSON.parse(JSON.stringify(CalculatorState.invoiceItems)),
                    subtotal: CalculatorState.invoiceItems.reduce((sum, item) => sum + item.total, 0),
                    discount: CalculatorState.invoiceDiscount,
                    tax: CalculatorState.invoiceTax,
                    total: CalculatorState.invoiceTotal,
                    note: note,
                    date: new Date().toISOString(),
                    type: 'invoice'
                };
                
                const itemDetails = CalculatorState.invoiceItems.map(item => 
                    `${item.qty}×${item.price}=${CalculatorEngine.formatNumber(item.total)}`
                ).join(' + ');
                
                const fullQuery = `🧾 INVOICE: ${itemDetails} = ${CalculatorEngine.formatNumber(CalculatorState.invoiceTotal)}${note ? ' | Note: ' + note : ''}`;
                
                HistoryManager.saveCalculation(
                    fullQuery,
                    CalculatorState.invoiceTotal,
                    'invoice',
                    CalculatorState.invoiceItems
                );
                
                const saved = this.getSavedInvoices();
                saved.unshift(invoice);
                localStorage.setItem('SP_invoices', JSON.stringify(saved));
                
                Toast.success('Invoice saved! Total: ' + CalculatorEngine.formatNumber(CalculatorState.invoiceTotal));
                
                if (confirm('Invoice saved! Clear items?')) {
                    this.clearInvoice();
                    document.getElementById('invoiceNote').value = '';
                }
            },
            
            getSavedInvoices() {
                try {
                    return JSON.parse(localStorage.getItem('SP_invoices') || '[]');
                } catch {
                    return [];
                }
            },
            
            // ============================================
            // DIRECT TRANSACTION FROM CALCULATOR HISTORY
            // Format: 12*125+24*200-1000
            // Multiplication terms become item lines; negative standalone numbers become payment.
            // ============================================
            async createTransactionFromHistory(indexOrId) {
                const entry = this.getHistoryEntry(indexOrId);
                if (!entry) return Toast.warning('Calculation history entry not found');
                const raw = String(entry.originalExpression || entry.query || entry.expression || '').trim();
                const parsed = this.parseTransactionExpression(raw);
                if (!parsed.items.length) {
                    return Toast.warning('Use lines such as 12*100+500+15*500. First number = Qty, second number = Price; a term without * means Qty 1. A negative standalone number is payment/refund.');
                }

                // IMPORTANT: do not ask for products one-by-one before showing the form.
                // The formal Sell/Purchase/Return form must open immediately with the
                // parsed Qty and Price already filled. Product buttons are then used to
                // select the products exactly like the normal transaction form.
                const type = await this.askHistoryTransactionType();
                if (!type || !['sale','purchase','customer_return','supplier_return'].includes(type)) {
                    return Toast.warning('Invalid transaction type selected');
                }

                const items = parsed.items.map(line => ({
                    productId: '',
                    productName: '',
                    qty: Number(line.qty) || 1,
                    price: Number(line.price) || 0,
                    lineTotal: (Number(line.qty) || 1) * (Number(line.price) || 0)
                }));
                const total = items.reduce((sum, item) => sum + item.lineTotal, 0);
                const defaultDate = entry.timestamp ? new Date(entry.timestamp).toISOString().slice(0, 10) : Helpers.getToday();
                const payment = Math.max(0, Number(parsed.payment) || 0);

                if ((type === 'sale' || type === 'purchase') && payment > total) {
                    return Toast.warning('Payment ' + Helpers.formatCurrency(payment) + ' exceeds total ' + Helpers.formatCurrency(total));
                }

                if (type === 'sale' || type === 'purchase') {
                    return this.openQuickTransactionWindow({
                        type, entry, raw, items, total, payment,
                        party: null, date: defaultDate, accountId: ''
                    });
                }

                // Returns use the same formal line-item selector. Sale/Customer Return
                // uses Customer; Purchase/Supplier Return uses Supplier.
                return this.openQuickReturnWindow({
                    type, entry, raw, items, total, refund: payment,
                    party: null, date: defaultDate
                });
            },

            parseTransactionExpression(raw) {
                const normalized = String(raw || '')
                    .replace(/,/g, '')
                    .replace(/×/g, '*')
                    .replace(/−/g, '-')
                    .replace(/\s+/g, '');
                if (!normalized) return { items: [], payment: 0, total: 0 };

                // Every positive term is an item line.  qty*price => qty/price;
                // a standalone positive number => qty 1 / that number as price.
                // A negative standalone number => payment/refund.
                const items = [];
                let payment = 0;
                const parts = normalized.match(/[+-]?\d+(?:\.\d+)?(?:\*\d+(?:\.\d+)?)?/g) || [];
                let consumed = '';
                for (const token of parts) {
                    consumed += token;
                    const sign = token[0] === '-' ? -1 : 1;
                    const body = token[0] === '+' || token[0] === '-' ? token.slice(1) : token;
                    if (!body) return { items: [], payment: 0, total: 0 };
                    const pieces = body.split('*');
                    const a = Number(pieces[0]);
                    const b = pieces.length === 2 ? Number(pieces[1]) : null;
                    if (!Number.isFinite(a) || a <= 0) return { items: [], payment: 0, total: 0 };
                    if (sign < 0 && b === null) {
                        payment += a;
                    } else if (sign > 0) {
                        const qty = b === null ? 1 : a;
                        const price = b === null ? a : b;
                        if (!Number.isFinite(qty) || !Number.isFinite(price) || qty <= 0 || price < 0) return { items: [], payment: 0, total: 0 };
                        items.push({ qty, price });
                    } else {
                        return { items: [], payment: 0, total: 0 };
                    }
                }
                // Reject expressions containing unsupported syntax, e.g. division or parentheses.
                if (consumed !== normalized) return { items: [], payment: 0, total: 0 };
                return { items, payment, total: items.reduce((sum, x) => sum + x.qty * x.price, 0) };
            },

            async askHistoryTransactionType() {
                const choice = await this._historyChoiceModal({
                    title: 'Create from calculator history',
                    subtitle: 'Choose the transaction type.',
                    items: [
                        { id: 'sale', name: '💰 Sale' },
                        { id: 'purchase', name: '📥 Purchase' },
                        { id: 'customer_return', name: '↩️ Return from customer' },
                        { id: 'supplier_return', name: '↪️ Return to supplier' }
                    ],
                    label: x => x.name
                });
                // _historyChoiceModal returns the selected object. The transaction
                // workflow must receive the stable type ID, not the display object.
                return choice ? String(choice.id) : null;
            },

            async openQuickTransactionWindow({ type, entry, raw, items, total, payment, party, date, accountId }) {
                // V5.10.6: WebView-safe quick transaction form.
                // It mirrors the normal Sell/Purchase form: Product | Qty | Price | Amt,
                // plus Add Item, Date, correct Party, Payment and account selection.
                const isSale = type === 'sale';
                const title = isSale ? '💰 Sell' : '📥 Purchase';
                const modal = this._buildQuickTransactionForm({
                    title, items, total, payment, party, date, type, accountId
                });
                const action = await modal.promise;
                if (!action) return;

                const selectedItems = action.items || [];
                if (!selectedItems.length) return Toast.warning('Add at least one item');

                // Populate the authoritative existing transaction form and let its
                // normal validation/accounting engine complete the transaction.
                try {
                    if (isSale) {
                        if (typeof Sales === 'undefined' || !Sales.openSellModal) throw new Error('Sales module not loaded');
                        Sales.openSellModal();
                        setTimeout(() => {
                            try {
                                const tbody = document.getElementById('sellItemsBody');
                                if (!tbody) throw new Error('Sale form did not open');
                                tbody.innerHTML = '';
                                selectedItems.forEach(item => {
                                    Sales.addSellItem(item.productId);
                                    const rows = document.querySelectorAll('.sell-item-row');
                                    const row = rows[rows.length - 1];
                                    if (!row) throw new Error('Could not create sale item row');
                                    const productSelect = row.querySelector('.sell-product-select');
                                    if (productSelect) productSelect.value = item.productId;
                                    row.querySelector('.sell-qty').value = item.qty;
                                    row.querySelector('.sell-price').value = item.price;
                                    Sales.updateSellRow(row.querySelector('.sell-price'));
                                });
                                const d = document.getElementById('sellDate');
                                const c = document.getElementById('sellCustomerId');
                                const cs = document.getElementById('sellCustomerSearch');
                                const pay = document.getElementById('sellPayment');
                                const method = document.getElementById('sellPaymentMethod');
                                const acct = document.getElementById('sellMoneyAccount');
                                const notes = document.getElementById('sellNotes');
                                if (d) d.value = date;
                                if (c) { c.value = party.id; c.dispatchEvent(new Event('change', {bubbles:true})); }
                                if (cs) cs.value = party.name || '';
                                if (pay) pay.value = payment;
                                if (method) method.value = 'Cash';
                                if (acct && accountId) acct.value = accountId;
                                if (notes) notes.value = 'Created from calculator history: ' + raw;
                                Toast.success('Quick sale prepared. Review and complete it.');
                                const panel = document.getElementById('sellModal');
                                if (panel) panel.scrollTop = 0;
                            } catch (e) { Toast.error('Could not prepare sale: ' + e.message); }
                        }, 180);
                    } else {
                        if (typeof Purchases === 'undefined' || !Purchases.openModal) throw new Error('Purchases module not loaded');
                        Purchases.openModal();
                        setTimeout(() => {
                            try {
                                const tbody = document.getElementById('purchaseItemsBody');
                                if (!tbody) throw new Error('Purchase form did not open');
                                tbody.innerHTML = '';
                                selectedItems.forEach(item => {
                                    Purchases.addItem();
                                    const rows = document.querySelectorAll('.purchase-item-row');
                                    const row = rows[rows.length - 1];
                                    if (!row) throw new Error('Could not create purchase item row');
                                    const productSelect = row.querySelector('.purchase-product-select');
                                    if (productSelect) productSelect.value = item.productId;
                                    row.querySelector('.purchase-qty').value = item.qty;
                                    row.querySelector('.purchase-cost').value = item.price;
                                    Purchases.updateRow(row.querySelector('.purchase-cost'));
                                });
                                const d = document.getElementById('purchaseDate');
                                const s = document.getElementById('purchaseSupplier');
                                const ss = document.getElementById('purchaseSupplierSearch');
                                const paid = document.getElementById('purchasePaid');
                                const acct = document.getElementById('purchaseMoneyAccount');
                                if (d) d.value = date;
                                if (s) { s.value = party.id; s.dispatchEvent(new Event('change', {bubbles:true})); }
                                if (ss) ss.value = party.name || '';
                                if (paid) paid.value = payment;
                                if (acct && accountId) acct.value = accountId;
                                Toast.success('Quick purchase prepared. Review and complete it.');
                                const panel = document.getElementById('purchaseModal');
                                if (panel) panel.scrollTop = 0;
                            } catch (e) { Toast.error('Could not prepare purchase: ' + e.message); }
                        }, 180);
                    }
                } catch (e) {
                    Toast.error('Could not open transaction: ' + (e.message || e));
                }
            },

            _buildQuickTransactionForm({ title, items, total, payment = 0, party, date, type, accountId }) {
                const old = document.getElementById('calculatorQuickTransactionForm');
                if (old) old.remove();

                let resolvePromise;
                const promise = new Promise(resolve => { resolvePromise = resolve; });
                const modal = document.createElement('div');
                modal.id = 'calculatorQuickTransactionForm';
                modal.style.cssText = [
                    'position:fixed!important','inset:0!important','z-index:2147483647!important',
                    'background:rgba(0,0,0,.72)!important','display:flex!important',
                    'align-items:flex-start!important','justify-content:center!important',
                    'padding:12px 10px!important','overflow-y:auto!important',
                    '-webkit-overflow-scrolling:touch!important','touch-action:manipulation!important'
                ].join(';');

                const box = document.createElement('div');
                box.style.cssText = [
                    'width:min(720px,100%)','max-height:calc(100vh - 24px)',
                    'display:flex','flex-direction:column','background:var(--surface,#111827)',
                    'color:var(--text,#f8fafc)','border-radius:20px','overflow:hidden',
                    'box-shadow:0 20px 80px rgba(0,0,0,.55)','margin-top:4px'
                ].join(';');

                const header = document.createElement('div');
                header.style.cssText='padding:14px 18px;border-bottom:1px solid var(--border,#334155);display:flex;align-items:center;justify-content:space-between;flex:0 0 auto;';
                const hTitle=document.createElement('div');
                hTitle.style.cssText='font-size:18px;font-weight:800;';
                hTitle.textContent=title;
                const closeBtn=document.createElement('button');
                closeBtn.type='button'; closeBtn.textContent='✕'; closeBtn.setAttribute('aria-label','Close');
                closeBtn.style.cssText='border:0;background:transparent;color:inherit;font-size:32px;line-height:1;padding:2px 8px;cursor:pointer;touch-action:manipulation;';
                header.append(hTitle,closeBtn); box.appendChild(header);

                const scroll=document.createElement('div');
                scroll.style.cssText='overflow-y:auto;flex:1;min-height:0;padding:12px 14px 18px;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;';
                box.appendChild(scroll);

                const addBtn=document.createElement('button');
                addBtn.type='button'; addBtn.className='btn'; addBtn.textContent='＋ Item';
                addBtn.style.cssText='font-size:14px;font-weight:700;margin-bottom:10px;touch-action:manipulation;';
                scroll.appendChild(addBtn);

                const tableWrap=document.createElement('div');
                tableWrap.style.cssText='width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch;';
                const table=document.createElement('div');
                table.style.cssText='min-width:600px;';
                const head=document.createElement('div');
                head.style.cssText='display:grid;grid-template-columns:1.55fr .75fr .9fr .9fr 42px;gap:8px;background:#1673ea;color:#fff;padding:8px 10px;font-weight:800;font-size:13px;';
                ['Product','Qty','Price','Amt',''].forEach(t=>{const c=document.createElement('div');c.textContent=t;head.appendChild(c);});
                table.appendChild(head);
                const rowsBox=document.createElement('div'); table.appendChild(rowsBox); tableWrap.appendChild(table); scroll.appendChild(tableWrap);

                const footerInfo=document.createElement('div');
                footerInfo.style.cssText='margin-top:14px;border-top:1px solid var(--border,#334155);padding-top:12px;';
                scroll.appendChild(footerInfo);

                const totalLine=document.createElement('div');
                totalLine.style.cssText='display:flex;justify-content:space-between;align-items:center;font-size:20px;font-weight:800;padding:8px 0 14px;';
                const totalLabel=document.createElement('span'); totalLabel.textContent='Total:';
                const totalValue=document.createElement('span'); totalValue.id='quickTxTotal'; totalValue.textContent=Helpers.formatCurrency(total);
                totalLine.append(totalLabel,totalValue); footerInfo.appendChild(totalLine);

                const makeField=(labelText, initialValue, typeAttr='text')=>{
                    const wrap=document.createElement('label'); wrap.style.cssText='display:block;margin:10px 0;';
                    const lab=document.createElement('div'); lab.textContent=labelText; lab.style.cssText='font-weight:700;opacity:.8;margin-bottom:6px;';
                    const input=document.createElement('input'); input.type=typeAttr; input.value=initialValue||''; input.autocomplete='off';
                    input.style.cssText='width:100%;box-sizing:border-box;padding:13px 14px;border:1px solid var(--border,#334155);border-radius:12px;background:var(--surface2,#0b1220);color:inherit;font-size:17px;';
                    wrap.append(lab,input); return {wrap,input};
                };

                const dateField=makeField('Date',date,'date');
                footerInfo.appendChild(dateField.wrap);

                const partyWrap=document.createElement('div'); partyWrap.style.cssText='margin:10px 0;';
                const partyLabel=document.createElement('div'); partyLabel.textContent=(type==='sale'||type==='customer_return')?'Customer':'Supplier'; partyLabel.style.cssText='font-weight:700;opacity:.8;margin-bottom:6px;';
                const partyBtn=document.createElement('button'); partyBtn.type='button'; partyBtn.className='btn'; partyBtn.style.cssText='width:100%;text-align:left;padding:13px 14px;border:1px solid var(--border,#334155);border-radius:12px;background:var(--surface2,#0b1220);color:inherit;font-size:17px;touch-action:manipulation;';
                partyBtn.textContent=party?.name || ((type==='sale'||type==='customer_return')?'-- Select Customer --':'-- Select Supplier --');
                partyWrap.append(partyLabel,partyBtn); footerInfo.appendChild(partyWrap);

                const paymentField=makeField(type==='sale'||type==='purchase'?'Payment':'Refund',String(payment||0),'number');
                footerInfo.appendChild(paymentField.wrap);

                let selectedParty=party;
                let selectedAccountId=accountId || '';
                const accountWrap=document.createElement('div'); accountWrap.style.cssText='margin:10px 0;';
                const accountLabel=document.createElement('div'); accountLabel.textContent='Payment Account'; accountLabel.style.cssText='font-weight:700;opacity:.8;margin-bottom:6px;';
                const accountBtn=document.createElement('button'); accountBtn.type='button'; accountBtn.className='btn'; accountBtn.style.cssText='width:100%;text-align:left;padding:13px 14px;border:1px solid var(--border,#334155);border-radius:12px;background:var(--surface2,#0b1220);color:inherit;font-size:17px;touch-action:manipulation;';
                const accountObj=(State.cashAccounts||[]).find(a=>a.id===selectedAccountId);
                accountBtn.textContent=accountObj?.name || '-- Select Payment Account --';
                accountWrap.append(accountLabel,accountBtn);
                footerInfo.appendChild(accountWrap);
                accountWrap.style.display = (Number(paymentField.input.value)||0)>0 ? 'block' : 'none';
                paymentField.input.addEventListener('input',()=>{
                    accountWrap.style.display = (Number(paymentField.input.value)||0)>0 ? 'block' : 'none';
                });

                const rowData = items.map(x=>({productId:x.productId||'',productName:x.productName||'',qty:Number(x.qty)||1,price:Number(x.price)||0}));
                const productRows=[];

                const recalc=()=>{
                    let sum=0;
                    productRows.forEach(r=>{
                        const amt=Math.max(0,Number(r.qtyInput.value)||0)*Math.max(0,Number(r.priceInput.value)||0);
                        r.amount.textContent=Helpers.formatCurrency(amt);
                        sum+=amt;
                    });
                    totalValue.textContent=Helpers.formatCurrency(sum);
                    return sum;
                };

                const makeProductRow=(data={qty:1,price:0})=>{
                    const row=document.createElement('div');
                    row.style.cssText='display:grid;grid-template-columns:1.55fr .75fr .9fr .9fr 42px;gap:8px;align-items:center;padding:9px 10px;border-bottom:1px solid var(--border,#334155);';
                    const productBtn=document.createElement('button');
                    productBtn.type='button'; productBtn.className='btn'; productBtn.style.cssText='min-height:42px;width:100%;text-align:left;padding:7px 9px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;touch-action:manipulation;font-size:14px;';
                    productBtn.textContent=data.productName || '-- Select --';
                    const qty=document.createElement('input'); qty.type='number'; qty.min='0.001'; qty.step='any'; qty.value=data.qty||1; qty.inputMode='decimal'; qty.autocomplete='off';
                    const price=document.createElement('input'); price.type='number'; price.min='0'; price.step='any'; price.value=data.price||0; price.inputMode='decimal'; price.autocomplete='off';
                    [qty,price].forEach(inp=>{inp.style.cssText='width:100%;box-sizing:border-box;min-height:42px;padding:7px 8px;border:1px solid var(--border,#334155);border-radius:10px;background:var(--surface2,#0b1220);color:inherit;font-size:14px;';});
                    const amount=document.createElement('div'); amount.style.cssText='font-weight:700;text-align:right;white-space:nowrap;font-size:14px;'; amount.textContent=Helpers.formatCurrency((Number(qty.value)||0)*(Number(price.value)||0));
                    const del=document.createElement('button'); del.type='button'; del.textContent='✕'; del.title='Remove item'; del.style.cssText='min-height:42px;border:0;background:transparent;color:inherit;font-size:24px;cursor:pointer;touch-action:manipulation;';
                    row.append(productBtn,qty,price,amount,del); rowsBox.appendChild(row);
                    const rec={row,productBtn,qtyInput:qty,priceInput:price,amount,data};
                    productRows.push(rec);

                    productBtn.addEventListener('click',async()=>{
                        const product=await this.askHistoryProduct({qty:Number(qty.value)||1,price:Number(price.value)||0},productRows.indexOf(rec),productRows.length);
                        if(!product)return;
                        rec.data.productId=product.id; rec.data.productName=product.name;
                        productBtn.textContent=product.name;
                    });
                    [qty,price].forEach(inp=>{
                        inp.addEventListener('input',()=>recalc());
                        inp.addEventListener('focus',()=>setTimeout(()=>inp.scrollIntoView({behavior:'smooth',block:'center'}),80));
                    });
                    del.addEventListener('click',()=>{const i=productRows.indexOf(rec); if(i>=0)productRows.splice(i,1); row.remove(); recalc();});
                    return rec;
                };

                rowData.forEach(d=>makeProductRow(d));
                addBtn.addEventListener('click',()=>{makeProductRow({qty:1,price:0}); setTimeout(()=>rowsBox.lastElementChild?.scrollIntoView({behavior:'smooth',block:'nearest'}),50);});

                partyBtn.addEventListener('click',async()=>{
                    const isCustomerParty=(type==='sale'||type==='customer_return');
                    const list=isCustomerParty?(State.customers||[]):(State.suppliers||[]);
                    const chosen=await this.askHistoryParty(isCustomerParty?'customer':'supplier',list);
                    if(chosen){selectedParty=chosen;partyBtn.textContent=chosen.name;}
                });
                accountBtn.addEventListener('click',async()=>{
                    const accounts=Array.isArray(State.cashAccounts)?State.cashAccounts:[];
                    if(!accounts.length){Toast.warning('Create a cash/bank account first');return;}
                    const chosen=await this.askHistoryAccount(accounts,Number(paymentField.input.value)||0);
                    if(chosen){selectedAccountId=chosen.id;accountBtn.textContent=chosen.name;}
                });

                const actions=document.createElement('div');
                actions.style.cssText='display:flex;gap:8px;justify-content:flex-end;padding-top:12px;position:sticky;bottom:0;background:var(--surface,#111827);';
                const cancel=document.createElement('button'); cancel.type='button'; cancel.className='btn'; cancel.textContent='Cancel';
                const confirm=document.createElement('button'); confirm.type='button'; confirm.className='btn btn-primary'; confirm.textContent=type==='sale'?'Complete Sale':type==='purchase'?'Complete Purchase':(type==='customer_return'?'Process Customer Return':'Process Supplier Return');
                actions.append(cancel,confirm); footerInfo.appendChild(actions);

                const close=()=>{modal.remove();resolvePromise(null);};
                const finish=()=>{
                    const selected=productRows.filter(r=>r.data.productId).map(r=>({
                        productId:r.data.productId,productName:r.data.productName,
                        qty:Number(r.qtyInput.value)||0,price:Number(r.priceInput.value)||0
                    })).filter(x=>x.qty>0 && x.price>=0);
                    if(!selected.length)return Toast.warning('Select at least one product');
                    const sum=selected.reduce((s,x)=>s+x.qty*x.price,0);
                    const pay=Math.max(0,Number(paymentField.input.value)||0);
                    if(pay>sum && (type==='sale'||type==='purchase'))return Toast.warning('Payment cannot exceed total');
                    if(!selectedParty)return Toast.warning((type==='sale'||type==='customer_return')?'Select a customer':'Select a supplier');
                    if(pay>0 && !selectedAccountId)return Toast.warning('Select a payment account');
                    const chosenDate=dateField.input.value || Helpers.getToday();
                    resolvePromise({items:selected,total:sum,payment:pay,party:selectedParty,date:chosenDate,accountId:selectedAccountId});
                    modal.remove();
                };
                cancel.addEventListener('click',close); closeBtn.addEventListener('click',close);
                modal.addEventListener('click',e=>{if(e.target===modal)close();});
                confirm.addEventListener('click',finish);
                modal.appendChild(box); document.body.appendChild(modal);

                // Never autofocus the form. When a WebView keyboard opens, keep the
                // active control visible instead of leaving it hidden behind the keyboard.
                const scrollActiveIntoView=()=>{
                    const a=document.activeElement;
                    if(a && modal.contains(a) && (a.tagName==='INPUT'||a.tagName==='BUTTON')){
                        setTimeout(()=>a.scrollIntoView({behavior:'smooth',block:'center'}),120);
                    }
                };
                modal.addEventListener('focusin',scrollActiveIntoView);
                if(window.visualViewport){
                    const vvHandler=()=>scrollActiveIntoView();
                    window.visualViewport.addEventListener('resize',vvHandler,{passive:true});
                    modal._vvHandler=vvHandler;
                }
                return { promise, close };
            },

            openQuickReturnWindow({ type, items, total, refund, party, date, raw }) {
                const title = type === 'customer_return' ? '↩️ Return from customer' : '↪️ Return to supplier';
                const modal = this._buildQuickTransactionForm({
                    title, items, total, payment: refund, party, date, type, accountId: '',
                    confirmText: type === 'customer_return' ? 'Process Customer Return' : 'Process Supplier Return'
                });
                modal.promise.then(action => {
                    if (!action) return;
                    try {
                        const selectedItems = action.items || [];
                        if (!selectedItems.length) return Toast.warning('Select at least one product');
                        State.saveUndoState((type === 'customer_return' ? 'Customer return' : 'Supplier return') + ' from calculator');
                        State.runAtomic('Calculator return', () => {
                            selectedItems.forEach(item => {
                                const product = (State.products || []).find(p => p.id === item.productId);
                                if (!product) throw new Error('Product not found: ' + (item.productName || item.productId));
                                const qty = Number(item.qty) || 0;
                                const price = Number(item.price) || 0;
                                if (type === 'customer_return') {
                                    product.stock = Number(product.stock || 0) + qty;
                                    if (window.StockHistory) StockHistory.recordChange(product.id, product.name, qty, 'Customer return from calculator', 'customer-return');
                                } else {
                                    product.stock = Number(product.stock || 0) - qty;
                                    if (window.StockHistory) StockHistory.recordChange(product.id, product.name, -qty, 'Supplier return from calculator', 'supplier-return');
                                }
                                State.returns.push({
                                    id: Helpers.uid(), productId: product.id, productName: product.name,
                                    quantity: qty, refundPerUnit: price, totalRefund: qty * price,
                                    date: action.date, partyId: action.party.id, partyName: action.party.name,
                                    returnType: type, source: 'calculator-history', rawExpression: raw,
                                    createdAt: new Date().toISOString()
                                });
                            });
                        });
                        if (window.Products) Products.render();
                        if (window.Returns) Returns.render();
                        if (window.Dashboard) Dashboard.update();
                        Toast.success(type === 'customer_return' ? 'Customer return recorded' : 'Supplier return recorded');
                    } catch (e) { Toast.error('Return failed: ' + (e.message || e)); }
                });
            },

            _buildQuickLineModal({ title, items, total, payment = 0, party, date, type, confirmText = 'Continue to transaction' }) {
                const old = document.getElementById('calculatorQuickLineModal');
                if (old) old.remove();
                let resolvePromise;
                const promise = new Promise(resolve => { resolvePromise = resolve; });
                const modal = document.createElement('div');
                modal.id = 'calculatorQuickLineModal';
                modal.style.cssText = 'position:fixed!important;inset:0!important;z-index:2147483647!important;background:rgba(0,0,0,.68)!important;display:flex!important;align-items:center!important;justify-content:center!important;padding:12px!important;';
                const box = document.createElement('div');
                box.style.cssText = 'width:min(620px,100%);max-height:92vh;display:flex;flex-direction:column;background:var(--surface,#fff);color:var(--text,#111);border-radius:16px;overflow:hidden;box-shadow:0 20px 70px rgba(0,0,0,.4);';
                box.innerHTML = `<div style="padding:15px 16px;border-bottom:1px solid var(--border,#ddd);font-weight:700;font-size:18px;display:flex;justify-content:space-between;align-items:center;"><span>${title}</span><button type="button" id="quickTxClose" style="border:0;background:transparent;font-size:24px;padding:2px 8px;">✕</button></div>`;
                const info = document.createElement('div');
                info.style.cssText = 'padding:10px 14px;display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:14px;';
                info.innerHTML = `<div><b>Party:</b> ${Helpers.esc(party?.name || '')}</div><div><b>Date:</b> ${Helpers.esc(date)}</div><div><b>Lines:</b> ${items.length}</div><div><b>Total:</b> ${Helpers.formatCurrency(total)}</div>`;
                box.appendChild(info);
                const list = document.createElement('div');
                list.style.cssText = 'overflow-y:auto;flex:1;min-height:120px;padding:8px 12px;-webkit-overflow-scrolling:touch;';
                items.forEach((item, idx) => {
                    const row = document.createElement('div');
                    row.style.cssText = 'display:flex;justify-content:space-between;gap:10px;align-items:center;padding:12px;border:1px solid var(--border,#ddd);border-radius:12px;margin:6px 0;';
                    row.innerHTML = `<div style="min-width:0;"><b>${idx + 1}. ${Helpers.esc(item.productName || '')}</b><div style="opacity:.75;font-size:13px;">${item.qty} × ${Helpers.formatCurrency(item.price)}</div></div><strong>${Helpers.formatCurrency(item.lineTotal)}</strong>`;
                    list.appendChild(row);
                });
                box.appendChild(list);
                const footer = document.createElement('div');
                footer.style.cssText = 'padding:12px;border-top:1px solid var(--border,#ddd);display:flex;gap:8px;flex-wrap:wrap;';
                const cancel = document.createElement('button'); cancel.type='button'; cancel.className='btn'; cancel.textContent='Cancel';
                const confirm = document.createElement('button'); confirm.type='button'; confirm.className='btn btn-primary'; confirm.textContent=confirmText;
                if (payment > 0) {
                    const pay = document.createElement('div'); pay.style.cssText='width:100%;font-size:14px;'; pay.innerHTML='<b>' + (type === 'sale' || type === 'purchase' ? 'Payment' : 'Refund') + ':</b> ' + Helpers.formatCurrency(payment); footer.appendChild(pay);
                }
                footer.appendChild(cancel); footer.appendChild(confirm); box.appendChild(footer); modal.appendChild(box); document.body.appendChild(modal);
                const close = () => { modal.remove(); resolvePromise(null); };
                cancel.addEventListener('click', close); document.getElementById('quickTxClose').addEventListener('click', close);
                modal.addEventListener('click', e => { if (e.target === modal) close(); });
                confirm.addEventListener('click', () => { modal.remove(); resolvePromise(true); });
                return { promise, close };
            },

            _historyChoiceModal(options = {}) {
                return new Promise(resolve => {
                    const old = document.getElementById('calculatorHistoryChoiceModal');
                    if (old) old.remove();
                    const modal = document.createElement('div');
                    modal.id = 'calculatorHistoryChoiceModal';
                    modal.className = '';
                    modal.style.cssText = 'position:fixed!important;inset:0!important;z-index:2147483647!important;background:rgba(0,0,0,.68)!important;display:flex!important;align-items:center!important;justify-content:center!important;padding:12px!important;pointer-events:auto!important;touch-action:manipulation!important;';
                    const box = document.createElement('div');
                    box.style.cssText = 'width:min(560px,100%);max-height:90vh;display:flex;flex-direction:column;background:var(--surface,#fff);color:var(--text,#111);border-radius:16px;box-shadow:0 20px 60px rgba(0,0,0,.35);overflow:hidden;';
                    const title = document.createElement('div');
                    title.style.cssText='padding:16px 18px;border-bottom:1px solid var(--border,#ddd);font-weight:700;font-size:18px;display:flex;justify-content:space-between;align-items:center;';
                    title.innerHTML='<span></span><button type="button" style="border:0;background:transparent;font-size:24px;cursor:pointer;padding:2px 8px;">✕</button>';
                    title.firstElementChild.textContent=options.title||'Select';
                    const close=()=>{modal.remove();resolve(null);};
                    title.lastElementChild.addEventListener('click',close);
                    box.appendChild(title);
                    if(options.subtitle){const sub=document.createElement('div');sub.style.cssText='padding:10px 18px 4px;opacity:.75;font-size:14px;';sub.textContent=options.subtitle;box.appendChild(sub);}
                    if(options.search){const search=document.createElement('input');search.type='search';search.placeholder=options.searchPlaceholder||'Search...';search.autocomplete='off';search.style.cssText='margin:12px 14px 8px;padding:12px;border:1px solid var(--border,#ccc);border-radius:10px;background:var(--surface2,#f7f7f7);color:inherit;font-size:16px;';box.appendChild(search);options._search=search;}
                    const list=document.createElement('div');
                    list.style.cssText='overflow-y:auto;flex:1;min-height:0;padding:8px 12px 14px;-webkit-overflow-scrolling:touch;';
                    box.appendChild(list);
                    modal.appendChild(box);document.body.appendChild(modal);
                    const render=()=>{
                        list.innerHTML='';
                        const term=(options._search?.value||'').trim().toLowerCase();
                        const vals=(options.items||[]).filter(x=>!term || String(options.label(x)).toLowerCase().includes(term));
                        if(!vals.length){const e=document.createElement('div');e.style.cssText='padding:24px;text-align:center;opacity:.7;';e.textContent='No matching items';list.appendChild(e);return;}
                        vals.forEach((item,i)=>{
                            const b=document.createElement('button');
                            b.type='button';
                            b.style.cssText='display:block!important;width:100%!important;text-align:left;padding:12px 14px;margin:5px 0;border:1px solid var(--border,#334155);border-radius:10px;background:var(--surface2,#0b1220);color:inherit;font-size:14px;line-height:1.25;cursor:pointer;touch-action:manipulation;pointer-events:auto!important;';
                            b.textContent=options.label(item,i);
                            let chosen=false;
                            const choose=(ev)=>{ if(chosen)return; chosen=true; if(ev)ev.preventDefault(); if(ev)ev.stopPropagation(); modal.remove(); resolve(item); };
                            b.addEventListener('pointerup',choose,{passive:false});
                            b.addEventListener('click',choose,false);
                            list.appendChild(b);
                        });
                    };
                    if(options._search) options._search.addEventListener('input',render);
                    modal.addEventListener('click',e=>{if(e.target===modal)close();});
                    render();
                    // AppMint/Android WebView: never autofocus the search box. The keyboard
                    // should open only when the user explicitly taps the search field.
                });
            },

            async askHistoryProduct(line, index, count) {
                const products = State.products || [];
                if (!products.length) { Toast.warning('No products found'); return null; }
                const preview = Helpers.getSorted ? Helpers.getSorted(products) : products.slice();
                return this._historyChoiceModal({
                    title:`Select product ${index + 1} of ${count}`,
                    subtitle:`${line.qty} × ${Helpers.formatCurrency(line.price)}`,
                    search:true,
                    searchPlaceholder:'Search product...',
                    items:preview,
                    label:p=>`${p.name}  •  Stock: ${p.stock || 0}`
                });
            },

            async askHistoryParty(type, partyList) {
                const title = type === 'sale' || type === 'customer' || type === 'customer_return' ? 'customer' : 'supplier';
                return this._historyChoiceModal({
                    title:`Select ${title}`,
                    search:true,
                    searchPlaceholder:`Search ${title}...`,
                    items:partyList,
                    label:p=>p.name
                });
            },

            async askHistoryAccount(accounts, payment) {
                return this._historyChoiceModal({
                    title:'Select payment account',
                    subtitle:`Payment: ${Helpers.formatCurrency(payment)}`,
                    search:true,
                    searchPlaceholder:'Search account...',
                    items:accounts,
                    label:a=>`${a.name}  •  ${a.type || 'account'}`
                });
            },

            importHistoryEntryAsSale(index) {
                const entry=CalculatorState.calculationHistory[index];
                if(!entry || !entry.items || !entry.items.length) return Toast.warning('This history entry has no item lines');
                if(typeof Sales==='undefined') return Toast.error('Sales module not loaded');
                Sales.openSellModal();
                setTimeout(()=>{ const tbody=document.getElementById('sellItemsBody'); if(!tbody)return; tbody.innerHTML=''; entry.items.forEach(item=>{Sales.addSellItem(item.productId||null); const rows=document.querySelectorAll('.sell-item-row'); const row=rows[rows.length-1]; if(row){ if(item.productId) row.querySelector('.sell-product-select').value=item.productId; row.querySelector('.sell-qty').value=item.qty||item.quantity||1; row.querySelector('.sell-price').value=item.price||item.sell||0; Sales.updateSellRow(row.querySelector('.sell-price')); }}); entry.imported=true;entry.importedAs='sale'; this.persistHistoryEntry(entry); Toast.success('History imported into Sale'); },250);
            },
            importHistoryEntryAsPurchase(index) {
                const entry=CalculatorState.calculationHistory[index];
                if(!entry || !entry.items || !entry.items.length) return Toast.warning('This history entry has no item lines');
                if(typeof Purchases==='undefined') return Toast.error('Purchases module not loaded');
                Purchases.openModal();
                setTimeout(()=>{ const tbody=document.getElementById('purchaseItemsBody'); if(!tbody)return; tbody.innerHTML=''; entry.items.forEach(item=>{Purchases.addItem(); const rows=document.querySelectorAll('.purchase-item-row'); const row=rows[rows.length-1]; if(row){ if(item.productId) row.querySelector('.purchase-product-select').value=item.productId; row.querySelector('.purchase-qty').value=item.qty||item.quantity||1; row.querySelector('.purchase-cost').value=item.price||item.cost||0; Purchases.updateRow(row.querySelector('.purchase-cost')); }}); entry.imported=true;entry.importedAs='purchase'; this.persistHistoryEntry(entry); Toast.success('History imported into Purchase'); },250);
            },
            persistHistoryEntry(entry){ try{ const all=JSON.parse(localStorage.getItem('SP_calculations_history')||'[]'); const i=all.findIndex(x=>x.id===entry.id); if(i>=0){all[i]=entry;localStorage.setItem('SP_calculations_history',JSON.stringify(all));} }catch(e){} },

            importAsSale() {
                if (!CalculatorState.invoiceItems.length) {
                    Toast.warning('No items to import');
                    return;
                }
                
                if (!confirm('Import ' + CalculatorState.invoiceItems.length + ' item(s) as a SALE?\n\nTotal: ' + 
                    CalculatorEngine.formatNumber(CalculatorState.invoiceTotal))) {
                    return;
                }
                
                if (typeof Sales === 'undefined' || !Sales.openSellModal) {
                    Toast.error('Sales module not loaded');
                    return;
                }
                
                const itemDetails = CalculatorState.invoiceItems.map(item => 
                    `${item.qty}×${item.price}=${CalculatorEngine.formatNumber(item.total)}`
                ).join(' + ');
                
                const fullQuery = `💰 SALE: ${itemDetails} = ${CalculatorEngine.formatNumber(CalculatorState.invoiceTotal)}`;
                
                HistoryManager.saveCalculation(
                    fullQuery,
                    CalculatorState.invoiceTotal,
                    'sale',
                    CalculatorState.invoiceItems
                );
                
                Sales.openSellModal();
                
                setTimeout(() => {
                    const tbody = document.getElementById('sellItemsBody');
                    if (!tbody) {
                        Toast.warning('Please open the sale modal first');
                        return;
                    }
                    
                    tbody.innerHTML = '';
                    
                    CalculatorState.invoiceItems.forEach(item => {
                        Sales.addSellItem();
                        const rows = document.querySelectorAll('.sell-item-row');
                        const row = rows[rows.length - 1];
                        
                        if (row) {
                            row.querySelector('.sell-qty').value = item.qty;
                            row.querySelector('.sell-price').value = item.price;
                            Sales.updateSellRow(row.querySelector('.sell-price'));
                        }
                    });
                    
                    Toast.success('✅ Sale form prepared with ' + CalculatorState.invoiceItems.length + ' item(s)!');
                }, 300);
            },
            
            importAsPurchase() {
                if (!CalculatorState.invoiceItems.length) {
                    Toast.warning('No items to import');
                    return;
                }
                
                if (!confirm('Import ' + CalculatorState.invoiceItems.length + ' item(s) as a PURCHASE?\n\nTotal: ' + 
                    CalculatorEngine.formatNumber(CalculatorState.invoiceTotal))) {
                    return;
                }
                
                if (typeof Purchases === 'undefined' || !Purchases.openModal) {
                    Toast.error('Purchases module not loaded');
                    return;
                }
                
                const itemDetails = CalculatorState.invoiceItems.map(item => 
                    `${item.qty}×${item.price}=${CalculatorEngine.formatNumber(item.total)}`
                ).join(' + ');
                
                const fullQuery = `📥 PURCHASE: ${itemDetails} = ${CalculatorEngine.formatNumber(CalculatorState.invoiceTotal)}`;
                
                HistoryManager.saveCalculation(
                    fullQuery,
                    CalculatorState.invoiceTotal,
                    'purchase',
                    CalculatorState.invoiceItems
                );
                
                Purchases.openModal();
                
                setTimeout(() => {
                    const tbody = document.getElementById('purchaseItemsBody');
                    if (!tbody) {
                        Toast.warning('Please open the purchase modal first');
                        return;
                    }
                    
                    tbody.innerHTML = '';
                    
                    CalculatorState.invoiceItems.forEach(item => {
                        Purchases.addItem();
                        const rows = document.querySelectorAll('.purchase-item-row');
                        const row = rows[rows.length - 1];
                        
                        if (row) {
                            row.querySelector('.purchase-qty').value = item.qty;
                            row.querySelector('.purchase-cost').value = item.price;
                            Purchases.updateRow(row.querySelector('.purchase-cost'));
                        }
                    });
                    
                    Toast.success('✅ Purchase form prepared with ' + CalculatorState.invoiceItems.length + ' item(s)!');
                }, 300);
            },
            
            quickSell() {
                const value = CalculatorState.liveResult || CalculatorEngine.parseNumber(CalculatorState.displayValue);
                if (value === 0) {
                    Toast.warning('Enter a valid amount');
                    return;
                }
                
                HistoryManager.saveCalculation(
                    `💰 QUICK SELL: ${CalculatorState.query || CalculatorState.displayValue}`,
                    value,
                    'sale'
                );
                
                if (typeof Sales === 'undefined' || !Sales.openSellModal) {
                    Toast.error('Sales module not loaded');
                    return;
                }
                
                Sales.openSellModal();
                
                setTimeout(() => {
                    const tbody = document.getElementById('sellItemsBody');
                    if (!tbody) return;
                    
                    tbody.innerHTML = '';
                    Sales.addSellItem();
                    const rows = document.querySelectorAll('.sell-item-row');
                    const row = rows[rows.length - 1];
                    
                    if (row) {
                        row.querySelector('.sell-qty').value = 1;
                        row.querySelector('.sell-price').value = value;
                        Sales.updateSellRow(row.querySelector('.sell-price'));
                    }
                    
                    Toast.success('Quick sell prepared: ' + CalculatorEngine.formatNumber(value));
                }, 300);
            },
            
            quickPurchase() {
                const value = CalculatorState.liveResult || CalculatorEngine.parseNumber(CalculatorState.displayValue);
                if (value === 0) {
                    Toast.warning('Enter a valid amount');
                    return;
                }
                
                HistoryManager.saveCalculation(
                    `📥 QUICK PURCHASE: ${CalculatorState.query || CalculatorState.displayValue}`,
                    value,
                    'purchase'
                );
                
                if (typeof Purchases === 'undefined' || !Purchases.openModal) {
                    Toast.error('Purchases module not loaded');
                    return;
                }
                
                Purchases.openModal();
                
                setTimeout(() => {
                    const tbody = document.getElementById('purchaseItemsBody');
                    if (!tbody) return;
                    
                    tbody.innerHTML = '';
                    Purchases.addItem();
                    const rows = document.querySelectorAll('.purchase-item-row');
                    const row = rows[rows.length - 1];
                    
                    if (row) {
                        row.querySelector('.purchase-qty').value = 1;
                        row.querySelector('.purchase-cost').value = value;
                        Purchases.updateRow(row.querySelector('.purchase-cost'));
                    }
                    
                    Toast.success('Quick purchase prepared: ' + CalculatorEngine.formatNumber(value));
                }, 300);
            },
            
            exportInvoiceCSV() {
                if (!CalculatorState.invoiceItems.length) {
                    Toast.warning('No items to export');
                    return;
                }
                
                let csv = 'Item,Quantity,Price,Total\n';
                CalculatorState.invoiceItems.forEach((item, i) => {
                    csv += `${i+1},${item.qty},${item.price},${item.total}\n`;
                });
                
                csv += '\nSubtotal,' + CalculatorState.invoiceItems.reduce((sum, item) => sum + item.total, 0);
                csv += '\nDiscount,' + CalculatorState.invoiceDiscount + '%';
                csv += '\nTax,' + CalculatorState.invoiceTax + '%';
                csv += '\nGrand Total,' + CalculatorState.invoiceTotal;
                
                Helpers.downloadFile(csv, 'invoice-export.csv');
                Toast.success('Invoice exported!');
            },
            
            exportHistory() {
                HistoryManager.exportCSV();
            },
            
            importHistory() {
                HistoryManager.importCSV();
            },
            
            exportAllHistory() {
                const data = HistoryManager.getAll();
                if (!data.length) {
                    Toast.warning('No history to export');
                    return;
                }
                
                let csv = 'ID,Date,Query,Result,Type,Items\n';
                data.forEach(entry => {
                    const itemsStr = entry.items ? entry.items.map(i => `${i.qty}×${i.price}`).join('; ') : '';
                    const resultStr = entry.displayResult || entry.formattedResult || entry.result;
                    const queryStr = entry.displayExpression || entry.originalExpression || entry.expression;
                    csv += `"${entry.id}","${entry.date || entry.timestamp}","${queryStr}","${resultStr}",${entry.type || 'calculation'},"${itemsStr}"\n`;
                });
                
                Helpers.downloadFile(csv, 'all-calculations-history.csv');
                Toast.success('All history exported! (' + data.length + ' entries)');
            },
            
            loadHistory(index) {
                this.recallBoth(index);
            },
            
            deleteHistory(index) {
                CalculatorState.history.splice(index, 1);
                this.renderHistory();
            },
            
            loadHistoryFromAll(id) {
                this.recallBoth(id);
            },
            
            deleteHistoryEntry(id) {
                if (!confirm('Delete this calculation?')) return;
                HistoryManager.delete(id);
                this.renderHistory();
                renderAllHistory();
                updateHistoryCount();
                Toast.info('Deleted');
            },
            
            preventInitialKeyboard() {
                const input = document.getElementById('calcExpressionInput');
                // AppMint/Android WebView can restore focus when a calculator tab is
                // opened, which immediately raises the soft keyboard. The calculator
                // must open with no focused editable control.
                try {
                    if (input) {
                        input.setAttribute('data-calc-initial-blur', 'true');
                        input.blur();
                    }
                    if (document.activeElement && typeof document.activeElement.blur === 'function') {
                        document.activeElement.blur();
                    }
                    if (document.body) document.body.setAttribute('data-calc-keyboard-closed', 'true');
                } catch (e) {}
                // WebViews may restore focus a frame later; repeat after layout.
                [0, 50, 180, 350].forEach(delay => setTimeout(() => {
                    try {
                        const el = document.getElementById('calcExpressionInput');
                        if (el && el.getAttribute('data-calc-initial-blur') === 'true') el.blur();
                        if (document.activeElement && document.activeElement !== document.body &&
                            typeof document.activeElement.blur === 'function') {
                            document.activeElement.blur();
                        }
                    } catch (e) {}
                }, delay));
            },

            setupInputEditing() {
                const input = document.getElementById('calcExpressionInput');
                if (!input || input._stockProCalcInputBound) return;
                input._stockProCalcInputBound = true;
                input.removeAttribute('readonly');
                input.removeAttribute('disabled');
                input.setAttribute('data-calc-initial-blur', 'true');
                const rememberCursor = () => {
                    if (Number.isFinite(input.selectionStart)) CalculatorState.cursorStart = input.selectionStart;
                    if (Number.isFinite(input.selectionEnd)) CalculatorState.cursorEnd = input.selectionEnd;
                };
                input.addEventListener('select', rememberCursor);
                input.addEventListener('click', rememberCursor);
                input.addEventListener('keyup', rememberCursor);
                input.addEventListener('input', () => {
                    rememberCursor();
                    CalculatorState.query = input.value;
                    CalculatorState.showingResult = false;
                    CalculatorState.isNewCalculation = false;
                    CalculatorState.isError = false;
                    HistoryManager.resetRecall();
                    this.updateLiveResult();
                });
                input.addEventListener('focus', () => {
                    rememberCursor();
                    input.removeAttribute('data-calc-initial-blur');
                    if (document.body) document.body.removeAttribute('data-calc-keyboard-closed');
                    CalculatorState.showingResult = false;
                });
            },

            setupKeyboard() {
                document.addEventListener('keydown', (e) => {
                    const input = document.getElementById('calcExpressionInput');
                    
                    if (e.altKey && e.key === 'ArrowUp' && e.target === input) {
                        e.preventDefault();
                        this.recallPrevious();
                        return;
                    }
                    
                    if (e.altKey && e.key === 'ArrowDown' && e.target === input) {
                        e.preventDefault();
                        this.recallNext();
                        return;
                    }
                    
                    if (e.target === input) {
                        const key = e.key;
                        if (/^[0-9]$/.test(key)) {
                            e.preventDefault();
                            this.digit(key);
                        } else if (key === '.') {
                            e.preventDefault();
                            this.decimal();
                        } else if (key === '+') {
                            e.preventDefault();
                            this.operator('+');
                        } else if (key === '-') {
                            e.preventDefault();
                            this.operator('−');
                        } else if (key === '*') {
                            e.preventDefault();
                            this.operator('×');
                        } else if (key === '/') {
                            e.preventDefault();
                            this.operator('÷');
                        } else if (key === '%') {
                            e.preventDefault();
                            this.percent();
                        } else if (key === 'Enter' || key === '=') {
                            e.preventDefault();
                            this.equals();
                        } else if (key === 'Backspace') {
                            e.preventDefault();
                            this.backspace();
                        } else if (key === 'Escape') {
                            e.preventDefault();
                            this.clear();
                        }
                        return;
                    }
                    
                    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
                    
                    const key = e.key;
                    
                    if (/^[0-9]$/.test(key)) {
                        e.preventDefault();
                        this.digit(key);
                    } else if (key === '.') {
                        e.preventDefault();
                        this.decimal();
                    } else if (key === '+') {
                        e.preventDefault();
                        this.operator('+');
                    } else if (key === '-') {
                        e.preventDefault();
                        this.operator('−');
                    } else if (key === '*') {
                        e.preventDefault();
                        this.operator('×');
                    } else if (key === '/') {
                        e.preventDefault();
                        this.operator('÷');
                    } else if (key === '%') {
                        e.preventDefault();
                        this.percent();
                    } else if (key === 'Enter' || key === '=') {
                        e.preventDefault();
                        this.equals();
                    } else if (key === 'Backspace') {
                        if (e.target !== input) {
                            e.preventDefault();
                            this.backspace();
                        }
                    } else if (key === 'Escape') {
                        e.preventDefault();
                        this.clear();
                    }
                });
            }
        };

        // ============================================
        // RENDER FUNCTIONS
        // ============================================
        
        function renderCalculator() {
            const container = document.getElementById('tab-calculator');
            if (!container) return;
            
            container.innerHTML = `
                <!-- HISTORY SECTION - ABOVE CALCULATOR -->
                <div class="card history-card">
                    <div class="flex-between history-header">
                        <div class="card-title">📜 History <span id="historyCount" class="history-count">0</span></div>
                        <div style="display:flex;gap:4px;">
                            <button class="btn btn-sm btn-outline" onclick="Calculator.exportHistory()" title="Export">📤</button>
                            <button class="btn btn-sm btn-danger" onclick="Calculator.clearHistory()" title="Clear All">🗑️</button>
                        </div>
                    </div>
                    <div class="history-scroll" id="calcHistoryList">
                        <div class="history-empty">📋 No calculations yet</div>
                    </div>
                </div>
                
                <div class="calculator-layout">
                    <div class="calculator-main">
                        <div class="card">
                            <div class="flex-between">
                                <div class="card-title">🧮 Calculator</div>
                                <div class="calculator-tools">
                                    <button class="btn btn-sm btn-outline calculator-fullscreen-exit" onclick="Tabs.exitCalculatorFullscreen()" title="Back to CashTracker">↩️</button>
                                    <button class="btn btn-sm btn-outline" onclick="Calculator.toggleAllHistory()" title="All History">
                                        📚
                                    </button>
                                    <button class="btn btn-sm btn-outline" onclick="Calculator.toggleSettings()" title="Settings">
                                        ⚙️
                                    </button>
                                    <button class="btn btn-sm btn-danger" onclick="Calculator.clearAll()" title="Clear All">
                                        🗑️
                                    </button>
                                </div>
                            </div>
                            
                            <div class="calc-display">
                                <div class="calc-memory" id="calcMemory">
                                    ${CalculatorState.memory !== 0 ? 'M: ' + CalculatorEngine.formatNumber(CalculatorState.memory) : ''}
                                </div>
                                <div class="calc-query-display" id="calcQueryDisplay">${CalculatorState.query || '\u00A0'}</div>
                                <input type="text" class="calc-expression-input" id="calcExpressionInput" 
                                       value="${CalculatorState.query || ''}" 
                                       placeholder="Type expression..."
                                       spellcheck="false"
                                       autocomplete="off"
                                       autocapitalize="off"
                                       autocorrect="off"
                                       onfocus="this.setSelectionRange(this.value.length,this.value.length)">
                                <div class="calc-result" id="calcResult">
                                    ${CalculatorState.liveResult !== null ? 
                                        (typeof CalculatorState.liveResult === 'number' && !isFinite(CalculatorState.liveResult) ? 
                                            (CalculatorState.liveResult > 0 ? '∞' : '-∞') : 
                                            CalculatorEngine.formatNumber(CalculatorState.liveResult)) : 
                                        (CalculatorState.displayValue || '0')}
                                </div>
                                <div class="calc-hint">✏️ Edit anywhere | 📋 Query | 🔢 Result | Alt+↑/↓ History</div>
                                <div style="display:flex;gap:6px;justify-content:center;flex-wrap:wrap;margin-top:6px;">
                                    <button class="btn btn-sm btn-outline" onclick="Calculator.selectAllExpression()" title="Select all">☑️ All</button>
                                    <button class="btn btn-sm btn-outline" onclick="Calculator.copySelectionOrExpression()" title="Copy selected text or expression">📋 Copy</button>
                                    <button class="btn btn-sm btn-outline" onclick="Calculator.cutSelectionOrExpression()" title="Cut selected text or expression">✂️ Cut</button>
                                    <button class="btn btn-sm btn-outline" onclick="Calculator.pasteFromClipboard()" title="Paste (WebView-safe)">📥 Paste</button>
                                </div>
                            </div>
                            
                            <div class="calc-memory-bar">
                                <button class="btn btn-sm btn-outline" onclick="Calculator.memoryClear()">MC</button>
                                <button class="btn btn-sm btn-outline" onclick="Calculator.memoryRecall()">MR</button>
                                <button class="btn btn-sm btn-outline" onclick="Calculator.memoryAdd()">M+</button>
                                <button class="btn btn-sm btn-outline" onclick="Calculator.memorySubtract()">M-</button>
                            </div>
                            
                            <div class="calc-grid">
                                <button class="calc-btn calc-btn-clear" onclick="Calculator.clear()">AC</button>
                                <button class="calc-btn calc-btn-operator" onclick="Calculator.backspace()">⌫</button>
                                <button class="calc-btn calc-btn-operator" onclick="Calculator.percent()">%</button>
                                <button class="calc-btn calc-btn-operator" onclick="Calculator.operator('÷')">÷</button>
                                
                                <button class="calc-btn" onclick="Calculator.digit('7')">7</button>
                                <button class="calc-btn" onclick="Calculator.digit('8')">8</button>
                                <button class="calc-btn" onclick="Calculator.digit('9')">9</button>
                                <button class="calc-btn calc-btn-operator" onclick="Calculator.operator('×')">×</button>
                                
                                <button class="calc-btn" onclick="Calculator.digit('4')">4</button>
                                <button class="calc-btn" onclick="Calculator.digit('5')">5</button>
                                <button class="calc-btn" onclick="Calculator.digit('6')">6</button>
                                <button class="calc-btn calc-btn-operator" onclick="Calculator.operator('−')">−</button>
                                
                                <button class="calc-btn" onclick="Calculator.digit('1')">1</button>
                                <button class="calc-btn" onclick="Calculator.digit('2')">2</button>
                                <button class="calc-btn" onclick="Calculator.digit('3')">3</button>
                                <button class="calc-btn calc-btn-operator" onclick="Calculator.operator('+')">+</button>
                                
                                <button class="calc-btn" onclick="Calculator.digit('00')">00</button>
                                <button class="calc-btn" onclick="Calculator.digit('0')">0</button>
                                <button class="calc-btn" onclick="Calculator.decimal()">.</button>
                                <button class="calc-btn calc-btn-equals" onclick="Calculator.equals()">=</button>
                            </div>
                            
                            <div class="calc-quick-actions">
                                <button class="btn btn-sm btn-success" onclick="Calculator.addToInvoice()">➕ Add to Invoice</button>
                                <button class="btn btn-sm btn-warning" onclick="Calculator.applyDiscount()">🏷️ Discount</button>
                                <button class="btn btn-sm btn-info" onclick="Calculator.applyTax()">🧾 Tax</button>
                                <button class="btn btn-sm btn-primary" onclick="Calculator.quickSell()">💰 Quick Sell</button>
                                <button class="btn btn-sm btn-purple" onclick="Calculator.quickPurchase()">📥 Quick Purchase</button>
                            </div>
                            
                            <div class="calc-shortcuts">
                                📋 Paste Query | 🔢 Paste Result | 📥 Load Both | ⬆⬇ History
                            </div>
                        </div>
                    </div>
                    
                    <div class="calculator-invoice">
                        <div class="card">
                            <div class="flex-between">
                                <div class="card-title">🧾 Invoice Builder</div>
                                <span id="invoiceCount" class="invoice-count">0 items</span>
                            </div>
                            
                            <div class="invoice-items" id="invoiceItems">
                                <div class="empty-state">No items added</div>
                            </div>
                            
                            <div class="invoice-summary">
                                <div class="invoice-row">
                                    <span>Subtotal</span>
                                    <span id="invoiceSubtotal">ETB 0.00</span>
                                </div>
                                <div class="invoice-row">
                                    <span>Discount (<span id="invoiceDiscountPercent">0</span>%)</span>
                                    <span id="invoiceDiscountAmount">ETB 0.00</span>
                                </div>
                                <div class="invoice-row">
                                    <span>Tax (<span id="invoiceTaxPercent">0</span>%)</span>
                                    <span id="invoiceTaxAmount">ETB 0.00</span>
                                </div>
                                <div class="invoice-row invoice-total">
                                    <span>Total</span>
                                    <span id="invoiceGrandTotal">ETB 0.00</span>
                                </div>
                            </div>
                            
                            <div class="invoice-actions">
                                <input class="form-control" id="invoiceNote" placeholder="📝 Invoice note..." style="margin-bottom:8px;">
                                <div style="display:flex;gap:6px;flex-wrap:wrap;">
                                    <button class="btn btn-sm btn-success" onclick="Calculator.saveInvoice()">💾 Save</button>
                                    <button class="btn btn-sm btn-primary" onclick="Calculator.importAsSale()">💰 Import as Sale</button>
                                    <button class="btn btn-sm btn-info" onclick="Calculator.importAsPurchase()">📥 Import as Purchase</button>
                                    <button class="btn btn-sm btn-warning" onclick="Calculator.exportInvoiceCSV()">📤 Export CSV</button>
                                    <button class="btn btn-sm btn-danger" onclick="Calculator.clearInvoice()">🗑️ Clear</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- ALL HISTORY PANEL (hidden by default) -->
                <div class="card calc-all-history-panel" id="calcAllHistoryPanel" style="display:none;">
                    <div class="flex-between">
                        <div class="card-title">📚 All Calculations (<span id="allHistoryCount">0</span>)</div>
                        <div style="display:flex;gap:6px;flex-wrap:wrap;">
                            <input class="form-control" id="historySearch" placeholder="🔍 Search..." style="width:150px;padding:4px 8px;font-size:0.8rem;" oninput="Calculator.searchHistory()">
                            <select class="form-control" id="historyTypeFilter" style="width:120px;padding:4px 8px;font-size:0.8rem;" onchange="Calculator.filterHistory()">
                                <option value="all">All Types</option>
                                <option value="calculation">Calculations</option>
                                <option value="invoice">Invoices</option>
                                <option value="sale">Sales</option>
                                <option value="purchase">Purchases</option>
                            </select>
                            <button class="btn btn-sm btn-primary" onclick="Calculator.exportAllHistory()">📤 Export All</button>
                        </div>
                    </div>
                    <div id="calcAllHistoryList" style="max-height:400px;overflow-y:auto;"></div>
                </div>
            `;
            
            Calculator.renderHistory();
            Calculator.updateLiveResult();
            Calculator.updateInvoice();
            renderAllHistory();
            updateHistoryCount();
        }
        
        function renderAllHistory() {
            const container = document.getElementById('calcAllHistoryList');
            if (!container) return;
            
            const search = document.getElementById('historySearch')?.value?.toLowerCase() || '';
            const typeFilter = document.getElementById('historyTypeFilter')?.value || 'all';
            
            let data = CalculatorState.calculationHistory;
            
            if (search) {
                data = data.filter(entry => 
                    (entry.displayExpression || entry.originalExpression || entry.expression).toLowerCase().includes(search) ||
                    (entry.formattedResult || '').includes(search)
                );
            }
            
            if (typeFilter !== 'all') {
                data = data.filter(entry => entry.type === typeFilter);
            }
            
            const countEl = document.getElementById('allHistoryCount');
            if (countEl) countEl.textContent = data.length;
            
            if (!data.length) {
                container.innerHTML = '<div class="empty-state">No calculations found</div>';
                return;
            }
            
            container.innerHTML = data.map(entry => {
                const typeIcon = entry.type === 'sale' ? '💰' : 
                               entry.type === 'purchase' ? '📥' : 
                               entry.type === 'invoice' ? '🧾' : '📊';
                const importedBadge = entry.imported ? ' <span class="badge badge-info">Imported</span>' : '';
                const itemCount = entry.items && entry.items.length ? ` (${entry.items.length} items)` : '';
                const resultDisplay = entry.displayResult || entry.formattedResult || CalculatorEngine.formatNumber(entry.result);
                const queryDisplay = entry.displayExpression || entry.originalExpression || entry.expression;
                
                return `
                    <div class="history-item" onclick="Calculator.recallBoth('${entry.id}')" style="cursor:pointer;">
                        <div class="history-expression" onclick="event.stopPropagation(); Calculator.recallQuery('${entry.id}')" style="cursor:pointer;">
                            ${typeIcon} ${queryDisplay}${itemCount}
                            ${importedBadge}
                            <div class="history-date">${entry.date || entry.timestamp}</div>
                        </div>
                        <div class="history-result" onclick="event.stopPropagation(); Calculator.recallResult('${entry.id}')" style="cursor:pointer;">= ${resultDisplay}</div>
                        <div class="history-actions" onclick="event.stopPropagation();">
                            <button class="btn btn-sm btn-success" onclick="event.stopPropagation(); Calculator.recallQuery('${entry.id}')" title="Paste Query">📋</button>
                            <button class="btn btn-sm btn-info" onclick="event.stopPropagation(); Calculator.recallResult('${entry.id}')" title="Paste Result">🔢</button>
                            <button class="btn btn-sm btn-primary" onclick="Calculator.recallBoth('${entry.id}')" title="Load Both">📥</button>
                            <button class="btn btn-sm btn-warning" onclick="event.stopPropagation(); Calculator.createTransactionFromHistory('${entry.id}')" title="Create Sale, Purchase or Return">⚡</button>
                            ${entry.items && entry.items.length ? `<button class="btn btn-sm btn-success" onclick="event.stopPropagation(); Calculator.importHistoryEntryAsSale('${entry.id}')" title="Import as Sale">💰</button><button class="btn btn-sm btn-info" onclick="event.stopPropagation(); Calculator.importHistoryEntryAsPurchase('${entry.id}')" title="Import as Purchase">📥</button>` : ''}
                            <button class="btn btn-sm btn-danger" onclick="Calculator.deleteHistoryEntry('${entry.id}')">✕</button>
                        </div>
                    </div>
                `;
            }).join('');
            Calculator.installWebViewEventBridge();
        }
        
        function updateHistoryCount() {
            const count = document.getElementById('historyCount');
            if (count) {
                count.textContent = CalculatorState.calculationHistory.length;
            }
        }

        // ============================================
        // INITIALIZATION
        // ============================================
        
        function initCalcTab() {
            HistoryManager.loadFromStorage();
            renderCalculator();
            Calculator.ensureCalculatorGlobal();
            Calculator.installWebViewEventBridge();
            Calculator.setupInputEditing();
            Calculator.preventInitialKeyboard();
            Calculator.setupKeyboard();
            Calculator.updateDisplay();
            Calculator.updateLiveResult();
            
            try {
                const savedInvoice = JSON.parse(localStorage.getItem('SP_current_invoice') || 'null');
                if (savedInvoice) {
                    CalculatorState.invoiceItems = savedInvoice.items || [];
                    CalculatorState.invoiceDiscount = savedInvoice.discount || 0;
                    CalculatorState.invoiceTax = savedInvoice.tax || 0;
                    Calculator.updateInvoice();
                }
            } catch (e) {}
            
            const container = document.getElementById('tab-calculator');
            if (container) {
                container.style.display = 'block';
            }
            
            updateHistoryCount();
        }

        // ============================================
        // EXPOSE PUBLIC API
        // ============================================
        
        window.Calculator = Calculator;
        window.initCalcTab = initCalcTab;
        window.renderCalcHistory = renderHistory;
        window.HistoryManager = HistoryManager;
        
        console.log('✅ ' + MODULE_NAME + ' loaded successfully');
        return Calculator;
    });
    
})();