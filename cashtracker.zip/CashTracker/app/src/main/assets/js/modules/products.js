// ============================================
// PRODUCTS MODULE - WITH MULTI-IMAGE UPLOAD
// ============================================

(function() {
    'use strict';
    
    const MODULE_NAME = 'Products';
    
    console.log('📦 Registering ' + MODULE_NAME + '...');
    
    window.registerModule(MODULE_NAME, function() {
        console.log('✅ ' + MODULE_NAME + ' initializing...');
        
        const Products = {
            init() {
                const container = document.getElementById('tab-products');
                if (!container) return;

                container.innerHTML = `
                    <div style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap;">
                        <input class="form-control" id="search" placeholder="🔍 Search name, category or barcode..." oninput="Products.renderDebounced()" style="flex:1;min-width:180px;">
                        <button class="btn btn-outline btn-sm" type="button" onclick="Scan.into('search')" title="Scan barcode">📷</button>
                        <select class="form-control" id="sortSelect" onchange="Products.render()" style="max-width:130px;">
                            <option value="name">Name</option>
                            <option value="stock">Stock</option>
                            <option value="sell">Price</option>
                            <option value="low">Low Stock</option>
                        </select>
                        <button class="btn btn-outline btn-sm" onclick="Products.exportCSV()" title="Export CSV">📤</button>
                        <button class="btn btn-outline btn-sm" onclick="Products.importCSV()" title="Import CSV">📥</button>
                    </div>
                    <div id="productList"></div>
                `;

                const addPane = document.getElementById('tab-add');
                if (addPane) {
                    addPane.innerHTML = `
                        <div class="card" style="max-width:500px;">
                            <div class="card-title">➕ Add New Product</div>
                            <div class="form-group"><label>Name</label><input class="form-control" id="name"></div>
                            <div class="form-group"><label>Category</label><input class="form-control" id="category"></div>
                            <div class="form-group"><label>Barcode / SKU</label><div style="display:flex;gap:6px"><input class="form-control" id="barcode" placeholder="Optional barcode or SKU" style="flex:1"><button class="btn btn-outline btn-sm" type="button" onclick="Scan.into('barcode')" title="Scan barcode">📷</button></div></div>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                                <div class="form-group"><label>Buy Price</label><input class="form-control" id="buy" type="number" step="0.01"></div>
                                <div class="form-group"><label>Sell Price</label><input class="form-control" id="sell" type="number" step="0.01"></div>
                            </div>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                                <div class="form-group"><label>Stock</label><input class="form-control" id="stock" type="number"></div>
                                <div class="form-group"><label>Min Stock (alert)</label><input class="form-control" id="minStock" type="number" value="5" min="0"></div>
                            </div>
                            <div class="form-group"><label>Notes</label><textarea class="form-control note-area" id="productNotes"></textarea></div>
                            <button class="btn btn-success btn-block" onclick="Products.add()">➕ Add Product</button>
                        </div>
                    `;
                }
            },

            add() {
                const name = document.getElementById('name').value.trim();
                const category = document.getElementById('category').value.trim();
                const barcode = (document.getElementById('barcode')?.value || '').trim();
                const buy = +document.getElementById('buy').value || 0;
                const sell = +document.getElementById('sell').value || 0;
                const stock = +document.getElementById('stock').value || 0;
                const minStock = Math.max(0, +document.getElementById('minStock')?.value || 5);
                const notes = document.getElementById('productNotes').value.trim();

                if (!name) return Toast.warning('Name required');
                if (sell <= 0) return Toast.warning('Sell price must be greater than 0');
                if (barcode && State.products.some(p => (p.barcode || '').toLowerCase() === barcode.toLowerCase())) {
                    return Toast.warning('Barcode already used by another product');
                }

                State.saveUndoState('Add product: ' + name);

                State.products.push({
                    id: Helpers.uid(),
                    name,
                    category: category || 'Uncategorized',
                    barcode: barcode || '',
                    buy,
                    sell,
                    stock,
                    minStock,
                    notes,
                    initialStock: stock,
                    images: [],
                    createdAt: new Date().toISOString()
                });

                Storage.save('products', State.products);
                Toast.success(`"${name}" added!`);

                ['name', 'category', 'barcode', 'buy', 'sell', 'stock', 'minStock', 'productNotes'].forEach(id => {
                    const el = document.getElementById(id);
                    if (el) el.value = id === 'minStock' ? '5' : '';
                });

                this.render();
                Dashboard.update();
                App.populateDropdowns();
            },

            render() {
                const search = (document.getElementById('search')?.value || '').toLowerCase();
                const sort = document.getElementById('sortSelect')?.value || 'name';
                
                let filtered = State.products.filter(p => {
                    if (!search) return true;
                    return p.name.toLowerCase().includes(search) ||
                        (p.category || '').toLowerCase().includes(search) ||
                        (p.barcode || '').toLowerCase().includes(search);
                });

                if (sort === 'name') filtered.sort((a, b) => a.name.localeCompare(b.name));
                else if (sort === 'stock') filtered.sort((a, b) => (b.stock || 0) - (a.stock || 0));
                else if (sort === 'sell') filtered.sort((a, b) => (b.sell || 0) - (a.sell || 0));
                else if (sort === 'low') {
                    filtered = filtered.filter(p => {
                        const min = (p.minStock != null && p.minStock !== '') ? Number(p.minStock) : 5;
                        return (p.stock || 0) <= min;
                    });
                    filtered.sort((a, b) => (a.stock || 0) - (b.stock || 0));
                }

                const container = document.getElementById('productList');
                if (!container) return;

                if (!filtered.length) {
                    container.innerHTML = '<div class="empty-state">No products found</div>';
                    return;
                }

                container.innerHTML = '<div class="product-grid">' + filtered.map(p => {
                    const stock = p.stock || 0;
                    const minStock = (p.minStock != null && p.minStock !== '') ? Number(p.minStock) : 5;
                    let badgeClass = 'stock-high', label = '✅ In Stock';
                    
                    if (stock < 0) { badgeClass = 'stock-low'; label = '❌ Negative'; }
                    else if (stock <= 0) { badgeClass = 'stock-low'; label = '❌ Out of Stock'; }
                    else if (stock <= minStock) { badgeClass = 'stock-low'; label = '⚠️ Low Stock'; }
                    else if (stock <= minStock * 3) { badgeClass = 'stock-medium'; label = '⚡ Medium'; }

                    const margin = p.sell && p.buy ? ((p.sell - p.buy) / p.sell * 100).toFixed(1) : '?';
                    const imageCount = (p.images || []).length;
                    const barcodeHtml = p.barcode ? `<div class="meta">🏷 ${Helpers.esc(p.barcode)}</div>` : '';

                    return `
                       <div class="product-card" onclick="Products.showDetail('${p.id}')">
                            <div class="title">${Helpers.esc(p.name)}</div>
                            <div class="meta">${Helpers.esc(p.category || '')}</div>
                            ${barcodeHtml}
                            <div class="meta">Buy: ${Helpers.formatCurrency(p.buy)} | Sell: ${Helpers.formatCurrency(p.sell)} (${margin}%)</div>
                            <span class="stock-badge ${badgeClass}">${label} (${stock})</span>
                            ${imageCount > 0 ? `<span class="image-badge">📸 ${imageCount}</span>` : ''}
                            <div class="actions" onclick="event.stopPropagation();">
                                <button class="btn btn-primary btn-sm" onclick="Sales.openSellModal('${p.id}')">💰 Sell</button>
                                <button class="btn btn-info btn-sm" onclick="Products.openAdjust('${p.id}')" title="Adjust stock">±</button>
                                <button class="btn btn-success btn-sm" onclick="ShareHub.openProduct('${p.id}')" title="Share">📤</button>
                                <button class="btn btn-warning btn-sm" onclick="Products.edit('${p.id}')">✏️</button>
                                <button class="btn btn-danger btn-sm" onclick="Products.delete('${p.id}')">🗑️</button>
                            </div>
                        </div>
                    `;
                }).join('') + '</div>';
            },

            renderDebounced: Helpers.debounce(function() {
                Products.render();
            }, 300),

            // ============================================
            // EDIT PRODUCT - WITH MULTI-IMAGE UPLOAD
            // ============================================
            
            edit(id) {
                const product = State.products.find(p => p.id === id);
                if (!product) return;

                let editModal = document.getElementById('editProductModal');
                if (!editModal) {
                    editModal = document.createElement('div');
                    editModal.className = 'modal-overlay';
                    editModal.id = 'editProductModal';
                    editModal.innerHTML = `
                        <div class="modal" style="max-width:600px; max-height:90vh; overflow-y:auto;">
                            <button class="close-btn" onclick="Modals.close('editProductModal')">✕</button>
                            <h3>✏️ Edit Product</h3>
                            <input type="hidden" id="editProductId">
                            <div class="form-group"><label>Name</label><input class="form-control" id="editName"></div>
                            <div class="form-group"><label>Category</label><input class="form-control" id="editCategory"></div>
                            <div class="form-group"><label>Barcode / SKU</label><input class="form-control" id="editBarcode" placeholder="Optional barcode or SKU"></div>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                                <div class="form-group"><label>Buy Price</label><input class="form-control" id="editBuy" type="number" step="0.01"></div>
                                <div class="form-group"><label>Sell Price</label><input class="form-control" id="editSell" type="number" step="0.01"></div>
                            </div>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                                <div class="form-group"><label>Stock</label><input class="form-control" id="editStock" type="number"></div>
                                <div class="form-group"><label>Min Stock (alert)</label><input class="form-control" id="editMinStock" type="number" min="0"></div>
                            </div>
                            <div class="form-group"><label>Notes</label><textarea class="form-control note-area" id="editNotes"></textarea></div>
                            
                            <!-- IMAGE UPLOAD SECTION -->
                            <div class="form-group">
                                <label>📸 Product Images (max 5)</label>
                                <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px;">
                                    <button class="btn btn-sm btn-primary" onclick="Products.uploadImage('camera')">📷 Camera</button>
                                    <button class="btn btn-sm btn-success" onclick="Products.uploadImage('gallery')">🖼️ Gallery (Select Multiple)</button>
                                    <span style="font-size:0.8rem;color:var(--text2);display:flex;align-items:center;" id="editImageStatus">0 / 5 images</span>
                                </div>
                                <div id="editImagePreview" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;"></div>
                            </div>
                            
                            <!-- TELEGRAM SECTION -->
                            <div class="form-group">
                                <label>📡 Telegram</label>
                                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                                    <button class="btn btn-sm btn-telegram" onclick="Products.sendToTelegramForReview()">✈️ Send to Telegram</button>
                                    <span id="telegramStatus" style="font-size:0.75rem;color:var(--text2);display:flex;align-items:center;"></span>
                                </div>
                                <div id="telegramReviewStatus" style="font-size:0.8rem;color:var(--text2);margin-top:4px;"></div>
                            </div>
                            
                            <button class="btn btn-success btn-block" onclick="Products.saveEdit()">💾 Save Changes</button>
                        </div>
                    `;
                    document.body.appendChild(editModal);
                }

                // Fill product data
                document.getElementById('editProductId').value = product.id;
                document.getElementById('editName').value = product.name;
                document.getElementById('editCategory').value = product.category || '';
                document.getElementById('editBarcode').value = product.barcode || '';
                document.getElementById('editBuy').value = product.buy || 0;
                document.getElementById('editSell').value = product.sell || 0;
                document.getElementById('editMinStock').value = (product.minStock != null) ? product.minStock : 5;
                document.getElementById('editStock').value = product.stock || 0;
                document.getElementById('editNotes').value = product.notes || '';

                // Store images for editing
                this._editImages = (product.images || []).slice();
                this._productId = product.id;
                this._productName = product.name;
                this._telegramSent = false;
                
                this.renderEditImages();
                this.updateTelegramStatus();

                Modals.open('editProductModal');
            },

            // ============================================
            // ✅ MULTI-IMAGE UPLOAD
            // ============================================
            
            uploadImage(source) {
                const currentImages = this._editImages || [];
                const remaining = 5 - currentImages.length;
                
                if (remaining <= 0) {
                    Toast.warning('Maximum 5 images already added');
                    return;
                }

                const input = document.createElement('input');
                input.type = 'file';
                input.accept = 'image/*';
                input.multiple = true; // ✅ ALLOW MULTIPLE IMAGES
                
                if (source === 'camera') {
                    input.capture = 'environment';
                    input.multiple = false; // Camera can't do multiple
                }

                input.onchange = async (e) => {
                    const files = e.target.files;
                    if (!files || files.length === 0) return;

                    // ✅ Check if too many selected
                    if (files.length > remaining) {
                        Toast.warning(`You can only add ${remaining} more image(s)`);
                        // Only take the first 'remaining' files
                        const limitedFiles = Array.from(files).slice(0, remaining);
                        await this.processImages(limitedFiles);
                    } else {
                        await this.processImages(Array.from(files));
                    }
                };

                input.click();
            },

            // ✅ Process multiple images
            async processImages(files) {
                const currentImages = this._editImages || [];
                let added = 0;
                let failed = 0;

                Toast.info(`Processing ${files.length} image(s)...`);

                for (const file of files) {
                    try {
                        if (currentImages.length >= 5) {
                            Toast.warning('Maximum 5 images reached');
                            break;
                        }
                        
                        const compressed = await Helpers.compressImage(file);
                        currentImages.push(compressed);
                        added++;
                    } catch (error) {
                        console.error('Image processing error:', error);
                        failed++;
                    }
                }

                this._editImages = currentImages;
                this.renderEditImages();
                
                if (added > 0) {
                    Toast.success(`✅ ${added} image(s) added! (${currentImages.length}/5)`);
                }
                if (failed > 0) {
                    Toast.warning(`⚠️ ${failed} image(s) failed to process`);
                }
            },

            renderEditImages() {
                const container = document.getElementById('editImagePreview');
                const status = document.getElementById('editImageStatus');
                const images = this._editImages || [];
                
                if (!container) return;
                
                if (images.length === 0) {
                    container.innerHTML = '<div style="color:var(--text2);font-size:0.8rem;">No images uploaded</div>';
                    if (status) status.textContent = '0 / 5 images';
                    return;
                }

                container.innerHTML = images.map((img, i) => `
                    <div style="position:relative;display:inline-block;">
                        <img src="${img}" style="width:80px;height:80px;object-fit:cover;border-radius:8px;border:1px solid var(--border);">
                        <button onclick="Products.removeImage(${i})" style="position:absolute;top:-6px;right:-6px;background:var(--danger);color:#fff;border:none;border-radius:50%;width:20px;height:20px;cursor:pointer;font-size:12px;display:flex;align-items:center;justify-content:center;">✕</button>
                    </div>
                `).join('');
                
                if (status) status.textContent = images.length + ' / 5 images';
            },

            removeImage(index) {
                const images = this._editImages || [];
                if (index >= 0 && index < images.length) {
                    images.splice(index, 1);
                    this._editImages = images;
                    this.renderEditImages();
                    Toast.info('Image removed');
                }
            },

            // ============================================
            // TELEGRAM INTEGRATION
            // ============================================
            
            async sendToTelegramForReview() {
                const productId = document.getElementById('editProductId').value;
                const product = State.products.find(p => p.id === productId);
                if (!product) {
                    Toast.error('Product not found');
                    return;
                }

                const images = this._editImages || [];
                if (images.length === 0) {
                    Toast.warning('Please add at least one image');
                    return;
                }

                const name = document.getElementById('editName').value.trim() || product.name;
                const category = document.getElementById('editCategory').value.trim() || product.category || 'Uncategorized';
                const buy = +document.getElementById('editBuy').value || product.buy || 0;
                const sell = +document.getElementById('editSell').value || product.sell || 0;
                const stock = +document.getElementById('editStock').value || product.stock || 0;
                const notes = document.getElementById('editNotes').value.trim() || product.notes || '';

                const statusEl = document.getElementById('telegramReviewStatus');
                if (statusEl) statusEl.textContent = '⏳ Sending to Telegram...';

                try {
                    const caption = `🛍️ *Product Review*\n\n📦 *${name}*\n📂 Category: ${category}\n💰 Buy: ${Helpers.formatCurrency(buy)}\n💵 Sell: ${Helpers.formatCurrency(sell)}\n📊 Stock: ${stock}\n📝 Notes: ${notes}\n\n⏳ Auto-posting in 1 minute...`;

                    let successCount = 0;
                    for (let i = 0; i < images.length; i++) {
                        try {
                            const response = await fetch(images[i]);
                            const blob = await response.blob();
                            const formData = new FormData();
                            formData.append('chat_id', CONFIG.TELEGRAM.PHOTO_CHANNEL);
                            formData.append('photo', blob, 'product_' + i + '.jpg');
                            
                            if (i === 0) {
                                formData.append('caption', caption);
                            }

                            const result = await fetch(`https://api.telegram.org/bot${CONFIG.TELEGRAM.TOKEN}/sendPhoto`, {
                                method: 'POST',
                                body: formData
                            });
                            
                            if (result.ok) successCount++;
                        } catch (err) {
                            console.error('Photo send error:', err);
                        }
                    }

                    if (successCount > 0) {
                        this._telegramSent = true;
                        this._telegramData = { name, category, buy, sell, stock, notes, images };
                        
                        if (statusEl) {
                            statusEl.textContent = `✅ Sent ${successCount}/${images.length} images! Auto-posting in 60s...`;
                            statusEl.style.color = 'var(--success)';
                        }
                        
                        Toast.success(`✅ ${successCount} images sent for review! Auto-posting in 60s...`);
                        
                        this.startTelegramCountdown();
                    } else {
                        if (statusEl) {
                            statusEl.textContent = '❌ Failed to send to Telegram';
                            statusEl.style.color = 'var(--danger)';
                        }
                        Toast.error('Failed to send to Telegram');
                    }

                } catch (error) {
                    console.error('Telegram error:', error);
                    if (statusEl) {
                        statusEl.textContent = '❌ Error: ' + error.message;
                        statusEl.style.color = 'var(--danger)';
                    }
                    Toast.error('Telegram error: ' + error.message);
                }
            },

            startTelegramCountdown() {
                const statusEl = document.getElementById('telegramReviewStatus');
                let countdown = 60;
                
                if (this._countdownInterval) {
                    clearInterval(this._countdownInterval);
                }
                
                this._countdownInterval = setInterval(() => {
                    countdown--;
                    if (statusEl) {
                        statusEl.textContent = `⏳ Auto-posting in ${countdown}s... (${this._telegramData?.name || 'Product'})`;
                    }
                    
                    if (countdown <= 0) {
                        clearInterval(this._countdownInterval);
                        this._countdownInterval = null;
                        this.autoPostProduct();
                    }
                }, 1000);
            },

            async autoPostProduct() {
                const statusEl = document.getElementById('telegramReviewStatus');
                
                if (!this._telegramData) {
                    if (statusEl) {
                        statusEl.textContent = '❌ No data to post';
                        statusEl.style.color = 'var(--danger)';
                    }
                    return;
                }

                const data = this._telegramData;
                const productId = document.getElementById('editProductId')?.value;
                const product = State.products.find(p => p.id === productId);
                
                if (!product) {
                    if (statusEl) {
                        statusEl.textContent = '❌ Product not found';
                        statusEl.style.color = 'var(--danger)';
                    }
                    return;
                }

                try {
                    product.name = data.name;
                    product.category = data.category;
                    product.buy = data.buy;
                    product.sell = data.sell;
                    product.stock = data.stock;
                    product.notes = data.notes;
                    product.images = this._editImages || [];
                    
                    Storage.save('products', State.products);
                    
                    if (statusEl) {
                        statusEl.textContent = '✅ Product updated & posted to Telegram!';
                        statusEl.style.color = 'var(--success)';
                    }
                    
                    Toast.success('✅ Product updated and posted to Telegram!');
                    
                    const caption = `✅ *PRODUCT POSTED*\n\n📦 *${data.name}*\n📂 Category: ${data.category}\n💰 Buy: ${Helpers.formatCurrency(data.buy)}\n💵 Sell: ${Helpers.formatCurrency(data.sell)}\n📊 Stock: ${data.stock}\n📝 Notes: ${data.notes}\n\n✅ Successfully updated!`;
                    
                    await fetch(`https://api.telegram.org/bot${CONFIG.TELEGRAM.TOKEN}/sendMessage`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            chat_id: CONFIG.TELEGRAM.PHOTO_CHANNEL,
                            text: caption,
                            parse_mode: 'Markdown'
                        })
                    });
                    
                    this.render();
                    Dashboard.update();
                    App.populateDropdowns();
                    
                    setTimeout(() => {
                        Modals.close('editProductModal');
                    }, 2000);
                    
                } catch (error) {
                    console.error('Auto-post error:', error);
                    if (statusEl) {
                        statusEl.textContent = '❌ Auto-post failed: ' + error.message;
                        statusEl.style.color = 'var(--danger)';
                    }
                    Toast.error('Auto-post failed');
                }
            },

            updateTelegramStatus() {
                const statusEl = document.getElementById('telegramReviewStatus');
                if (statusEl) {
                    statusEl.textContent = this._telegramSent ? '✅ Sent for review' : '📡 Ready to send';
                    statusEl.style.color = this._telegramSent ? 'var(--success)' : 'var(--text2)';
                }
            },

            // ============================================
            // SAVE EDIT
            // ============================================
            
            saveEdit() {
                const id = document.getElementById('editProductId').value;
                const product = State.products.find(p => p.id === id);
                if (!product) return;

                const name = document.getElementById('editName').value.trim();
                if (!name) return Toast.warning('Name required');

                if (this._telegramSent && this._telegramData) {
                    Toast.success('✅ Product updated via Telegram');
                    Modals.close('editProductModal');
                    this.render();
                    Dashboard.update();
                    return;
                }

                const newBarcode = (document.getElementById('editBarcode')?.value || '').trim();
                if (newBarcode && State.products.some(p => p.id !== id && (p.barcode || '').toLowerCase() === newBarcode.toLowerCase())) {
                    return Toast.warning('Barcode already used by another product');
                }

                State.saveUndoState('Edit product: ' + name);

                const requestedStock = +document.getElementById('editStock').value || 0;
                const oldStock = Number(product.stock) || 0;
                State.runAtomic('Edit product', () => {
                    product.name = name;
                    product.category = document.getElementById('editCategory').value.trim();
                    product.barcode = newBarcode;
                    product.buy = +document.getElementById('editBuy').value || 0;
                    product.sell = +document.getElementById('editSell').value || 0;
                    product.stock = requestedStock;
                    product.minStock = Math.max(0, +document.getElementById('editMinStock')?.value || 5);
                    product.notes = document.getElementById('editNotes').value.trim();
                    product.images = this._editImages || [];
                    const delta = requestedStock - oldStock;
                    if (delta && window.StockHistory) StockHistory.recordChange(product.id, product.name, delta, 'Manual stock edit', 'adjustment');
                });
                Toast.success('✅ Product updated');
                Modals.close('editProductModal');
                
                this._editImages = [];
                this._telegramData = null;
                this._telegramSent = false;
                if (this._countdownInterval) {
                    clearInterval(this._countdownInterval);
                    this._countdownInterval = null;
                }
                
                this.render();
                Dashboard.update();
            },

            // ============================================
            // PRODUCT DETAIL
            // ============================================
            
            showDetail(id) {
                const product = State.products.find(p => p.id === id);
                if (!product) {
                    Toast.error('Product not found');
                    return;
                }

                const transactions = this.getAllProductTransactions(id);
                const stock = product.stock || 0;
                let status = '✅ In Stock';
                let statusClass = 'status-good';
                if (stock < 0) { 
                    status = '❌ Negative'; 
                    statusClass = 'status-negative';
                } else if (stock <= 0) { 
                    status = '❌ Out of Stock'; 
                    statusClass = 'status-out';
                } else if (stock <= 5) { 
                    status = '⚠️ Low Stock'; 
                    statusClass = 'status-low';
                } else if (stock <= 15) { 
                    status = '⚡ Medium'; 
                    statusClass = 'status-medium';
                }

                const margin = product.sell && product.buy ? 
                    ((product.sell - product.buy) / product.sell * 100).toFixed(1) : '?';

                const totalSold = transactions.sales.reduce((sum, s) => sum + s.qty, 0);
                const totalRevenue = transactions.sales.reduce((sum, s) => sum + s.amount, 0);
                const totalProfit = transactions.sales.reduce((sum, s) => sum + s.profit, 0);
                const totalPurchased = transactions.purchases.reduce((sum, p) => sum + p.qty, 0);
                const totalCost = transactions.purchases.reduce((sum, p) => sum + p.cost, 0);
                const totalReturned = transactions.returns.reduce((sum, r) => sum + r.qty, 0);
                const totalRefund = transactions.returns.reduce((sum, r) => sum + r.amount, 0);

                const imagesHtml = (product.images || []).length > 0 ? `
                    <div class="detail-section">
                        <h4>📸 Product Images</h4>
                        <div style="display:flex;gap:8px;flex-wrap:wrap;">
                            ${(product.images || []).map(img => `
                                <img src="${img}" style="width:100px;height:100px;object-fit:cover;border-radius:8px;border:1px solid var(--border);cursor:pointer;" onclick="window.open('${img}','_blank')">
                            `).join('')}
                        </div>
                    </div>
                ` : '';

                const html = `
                    <div class="detail-section">
                        <h4>📦 ${Helpers.esc(product.name)}</h4>
                        <div class="detail-row"><span class="detail-label">Category:</span><span class="detail-value">${Helpers.esc(product.category || 'Uncategorized')}</span></div>
                        <div class="detail-row"><span class="detail-label">Buy/Sell:</span><span class="detail-value">${Helpers.formatCurrency(product.buy)} / ${Helpers.formatCurrency(product.sell)} (${margin}%)</span></div>
                        <div class="detail-row"><span class="detail-label">Stock:</span><span class="detail-value"><span class="stock-status ${statusClass}">${status} (${stock})</span></span></div>
                        <div class="detail-row"><span class="detail-label">Stock Value:</span><span class="detail-value">${Helpers.formatCurrency((product.buy || 0) * stock)}</span></div>
                        ${product.notes ? '<div class="detail-row"><span class="detail-label">Notes:</span><span class="detail-value">' + Helpers.esc(product.notes) + '</span></div>' : ''}
                    </div>

                    ${imagesHtml}

                    <div class="detail-section">
                        <h4>📊 Summary</h4>
                        <div class="stock-summary-grid">
                            <div class="stock-summary-item"><span class="summary-label">Purchased</span><span class="summary-value text-success">+${totalPurchased}</span></div>
                            <div class="stock-summary-item"><span class="summary-label">Sold</span><span class="summary-value text-danger">-${totalSold}</span></div>
                            <div class="stock-summary-item"><span class="summary-label">Returned</span><span class="summary-value text-warning">+${totalReturned}</span></div>
                            <div class="stock-summary-item"><span class="summary-label">Current</span><span class="summary-value text-primary">${stock}</span></div>
                        </div>
                        <div class="stock-summary-total">
                            <span>💰 Revenue: ${Helpers.formatCurrency(totalRevenue)}</span>
                            <span>📥 Cost: ${Helpers.formatCurrency(totalCost)}</span>
                            <span>📈 Profit: ${Helpers.formatCurrency(totalProfit)}</span>
                            <span>↩️ Refund: ${Helpers.formatCurrency(totalRefund)}</span>
                        </div>
                    </div>

                    ${this.renderSalesTable(transactions.sales)}
                    ${this.renderPurchasesTable(transactions.purchases)}
                    ${this.renderReturnsTable(transactions.returns)}

                    <div class="detail-section">
                        <h4>⚡ Quick Actions</h4>
                        <div style="display:flex;gap:8px;flex-wrap:wrap;">
                            <button class="btn btn-primary btn-sm" onclick="Sales.openSellModal('${product.id}')">💰 Sell</button>
                            <button class="btn btn-success btn-sm" onclick="Products.adjustStock('${product.id}')">➕ Add Stock</button>
                            <button class="btn btn-danger btn-sm" onclick="Products.reduceStock('${product.id}')">➖ Reduce</button>
                            <button class="btn btn-warning btn-sm" onclick="Products.edit('${product.id}')">✏️ Edit</button>
                        </div>
                    </div>
                `;

                document.getElementById('detailModalContent').innerHTML = html;
                document.getElementById('detailModalTitle').textContent = '📦 ' + Helpers.esc(product.name);
                Modals.open('detailModal');
            },

            // ============================================
            // HELPER FUNCTIONS
            // ============================================
            
            getAllProductTransactions(productId) {
                const sales = [];
                const purchases = [];
                const returns = [];

                if (State.sales) {
                    State.activeSales().forEach(sale => {
                        if (sale.items) {
                            sale.items.forEach(item => {
                                if (item.productId === productId) {
                                    const cost = sale.items.find(i => i.productId === productId)?.cost || 0;
                                    sales.push({
                                        saleId: sale.id,
                                        date: sale.date,
                                        customer: sale.customer || 'Walk-in',
                                        customerId: sale.customerId,
                                        qty: item.quantity,
                                        price: item.price,
                                        amount: item.amount,
                                        profit: (item.price - cost) * item.quantity || 0,
                                        status: (sale.debitRemaining || 0) > 0 ? 'Debit' : 'Paid'
                                    });
                                }
                            });
                        }
                    });
                }

                if (State.purchases) {
                    State.purchases.forEach(purchase => {
                        if (purchase.items) {
                            purchase.items.forEach(item => {
                                if (item.productId === productId) {
                                    purchases.push({
                                        date: purchase.date,
                                        supplier: purchase.supplier || 'Unknown',
                                        supplierId: purchase.supplierId,
                                        qty: item.quantity,
                                        cost: item.cost,
                                        amount: item.amount,
                                        status: (purchase.debit || 0) > 0 ? 'Debit' : 'Paid'
                                    });
                                }
                            });
                        }
                    });
                }

                if (State.returns) {
                    State.returns.forEach(returnItem => {
                        if (returnItem.productId === productId) {
                            returns.push({
                                date: returnItem.date,
                                qty: returnItem.quantity || 0,
                                refundPerUnit: returnItem.refundPerUnit || 0,
                                amount: returnItem.totalRefund || 0
                            });
                        }
                    });
                }

                sales.sort((a, b) => new Date(b.date) - new Date(a.date));
                purchases.sort((a, b) => new Date(b.date) - new Date(a.date));
                returns.sort((a, b) => new Date(b.date) - new Date(a.date));

                return { sales, purchases, returns };
            },

            renderSalesTable(sales) {
                if (!sales || !sales.length) return '<div class="detail-section"><div class="empty-state">No sales</div></div>';
                
                return `
                    <div class="detail-section">
                        <h4>💰 Sales (${sales.length})</h4>
                        <table class="transaction-table">
                            <thead><tr><th>Date</th><th>Customer</th><th>Qty</th><th>Amount</th><th>Profit</th><th>Status</th></tr></thead>
                            <tbody>
                                ${sales.map(s => `
                                    <tr onclick="TransactionDetail.show('sale', '${s.saleId || ''}')" style="cursor:pointer;">
                                        <td>${Helpers.formatDate(s.date)}</td>
                                        <td onclick="event.stopPropagation();TransactionDetail.show('customer', '${s.customerId || ''}')" style="cursor:pointer;color:var(--primary);">${Helpers.esc(s.customer)}</td>
                                        <td>${s.qty}</td>
                                        <td>${Helpers.formatCurrency(s.amount)}</td>
                                        <td style="color:${s.profit >= 0 ? 'var(--success)' : 'var(--danger)'}">${Helpers.formatCurrency(s.profit)}</td>
                                        <td><span class="status-badge ${s.status === 'Paid' ? 'status-paid' : 'status-debit'}">${s.status}</span></td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            },

            renderPurchasesTable(purchases) {
                if (!purchases || !purchases.length) return '<div class="detail-section"><div class="empty-state">No purchases</div></div>';
                
                return `
                    <div class="detail-section">
                        <h4>📥 Purchases (${purchases.length})</h4>
                        <table class="transaction-table">
                            <thead><tr><th>Date</th><th>Supplier</th><th>Qty</th><th>Cost</th><th>Total</th><th>Status</th></tr></thead>
                            <tbody>
                                ${purchases.map(p => `
                                    <tr>
                                        <td>${Helpers.formatDate(p.date)}</td>
                                        <td onclick="event.stopPropagation();TransactionDetail.show('supplier', '${p.supplierId || ''}')" style="cursor:pointer;color:var(--primary);">${Helpers.esc(p.supplier)}</td>
                                        <td>${p.qty}</td>
                                        <td>${Helpers.formatCurrency(p.cost)}</td>
                                        <td>${Helpers.formatCurrency(p.amount)}</td>
                                        <td><span class="status-badge ${p.status === 'Paid' ? 'status-paid' : 'status-debit'}">${p.status}</span></td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            },

            renderReturnsTable(returns) {
                if (!returns || !returns.length) return '<div class="detail-section"><div class="empty-state">No returns</div></div>';
                
                return `
                    <div class="detail-section">
                        <h4>↩️ Returns (${returns.length})</h4>
                        <table class="transaction-table">
                            <thead><tr><th>Date</th><th>Qty</th><th>Refund/Unit</th><th>Total Refund</th></tr></thead>
                            <tbody>
                                ${returns.map(r => `
                                    <tr>
                                        <td>${Helpers.formatDate(r.date)}</td>
                                        <td>${r.qty}</td>
                                        <td>${Helpers.formatCurrency(r.refundPerUnit)}</td>
                                        <td>${Helpers.formatCurrency(r.amount)}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            },

            adjustStock(id) {
                const product = State.products.find(p => p.id === id);
                if (!product) return;

                const amount = prompt(`Add stock for "${product.name}"\nCurrent stock: ${product.stock || 0}\nQuantity to add:`, '1');
                if (!amount) return;

                const qty = parseInt(amount);
                if (isNaN(qty) || qty <= 0) {
                    Toast.warning('Invalid quantity');
                    return;
                }

                State.saveUndoState(`Add stock: ${product.name} (+${qty})`);

                const oldStock = product.stock || 0;
                State.runAtomic('Add stock', () => {
                    product.stock += qty;
                    if (window.StockHistory) StockHistory.recordChange(product.id, product.name, qty, 'Manual stock increase', 'adjustment');
                });

                Toast.success(`✅ +${qty} (${oldStock} → ${product.stock})`);
                this.render();
                Dashboard.update();
                this.showDetail(id);
            },

            reduceStock(id) {
                const product = State.products.find(p => p.id === id);
                if (!product) return;

                const currentStock = product.stock || 0;
                if (currentStock <= 0) return Toast.warning('❌ Out of stock!');

                const amount = prompt(`Reduce "${product.name}"\nCurrent stock: ${currentStock}\nQuantity to remove:`, '1');
                if (!amount) return;

                const qty = parseInt(amount);
                if (isNaN(qty) || qty <= 0) return Toast.warning('Invalid quantity');
                if (qty > currentStock) return Toast.warning(`Only ${currentStock} in stock`);

                State.saveUndoState(`Reduce stock: ${product.name}`);

                State.runAtomic('Reduce stock', () => {
                    product.stock -= qty;
                    if (window.StockHistory) StockHistory.recordChange(product.id, product.name, -qty, 'Manual stock reduction', 'adjustment');
                });
                
                Toast.success(`✅ -${qty} (${currentStock} → ${product.stock})`);
                this.render();
                Dashboard.update();
                this.showDetail(id);
            },

            delete(id) {
                const product = State.products.find(p => p.id === id);
                if (!product) return;
                if (!confirm(`Delete "${product.name}"?`)) return;

                State.saveUndoState('Delete product: ' + product.name);
                State.products = State.products.filter(p => p.id !== id);
                Storage.save('products', State.products);

                Toast.success('Product deleted');
                this.render();
                Dashboard.update();
                App.populateDropdowns();
            },

            // ============================================
            // STOCK ADJUSTMENT
            // ============================================
            openAdjust(id) {
                const product = State.products.find(p => p.id === id);
                if (!product) return Toast.error('Product not found');

                let modal = document.getElementById('adjustStockModal');
                if (!modal) {
                    modal = document.createElement('div');
                    modal.className = 'modal-overlay';
                    modal.id = 'adjustStockModal';
                    modal.innerHTML = `
                        <div class="modal" style="max-width:420px;">
                            <button class="close-btn" onclick="Modals.close('adjustStockModal')">✕</button>
                            <h3>± Adjust Stock</h3>
                            <input type="hidden" id="adjustProductId">
                            <p id="adjustProductName" style="font-weight:600;margin-bottom:12px;"></p>
                            <p style="opacity:.75;margin-bottom:12px;">Current stock: <strong id="adjustCurrentStock">0</strong></p>
                            <div class="form-group">
                                <label>Change (+ to add, − to remove)</label>
                                <input class="form-control" id="adjustDelta" type="number" step="1" placeholder="e.g. 5 or -3">
                            </div>
                            <div class="form-group">
                                <label>Reason</label>
                                <select class="form-control" id="adjustReason">
                                    <option value="Stock count">Stock count / inventory</option>
                                    <option value="Damaged">Damaged / expired</option>
                                    <option value="Lost">Lost / theft</option>
                                    <option value="Found">Found extra</option>
                                    <option value="Transfer">Transfer</option>
                                    <option value="Correction">Data correction</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Note (optional)</label>
                                <input class="form-control" id="adjustNote" placeholder="Extra details">
                            </div>
                            <button class="btn btn-success btn-block" onclick="Products.applyAdjust()">Apply Adjustment</button>
                        </div>
                    `;
                    document.body.appendChild(modal);
                }

                document.getElementById('adjustProductId').value = product.id;
                document.getElementById('adjustProductName').textContent = product.name;
                document.getElementById('adjustCurrentStock').textContent = product.stock || 0;
                document.getElementById('adjustDelta').value = '';
                document.getElementById('adjustNote').value = '';
                Modals.open('adjustStockModal');
            },

            applyAdjust() {
                const id = document.getElementById('adjustProductId')?.value;
                const product = State.products.find(p => p.id === id);
                if (!product) return Toast.error('Product not found');

                const delta = parseInt(document.getElementById('adjustDelta')?.value, 10);
                if (!Number.isFinite(delta) || delta === 0) return Toast.warning('Enter a non-zero stock change');

                const reason = document.getElementById('adjustReason')?.value || 'Adjustment';
                const note = (document.getElementById('adjustNote')?.value || '').trim();
                const fullReason = note ? `${reason}: ${note}` : reason;

                State.saveUndoState('Stock adjust: ' + product.name);
                State.runAtomic('Stock adjustment', () => {
                    product.stock = (Number(product.stock) || 0) + delta;
                    if (window.StockHistory) {
                        StockHistory.recordChange(product.id, product.name, delta, fullReason, 'adjustment');
                    }
                });

                Toast.success(`Stock ${delta > 0 ? 'increased' : 'decreased'} by ${Math.abs(delta)}. New: ${product.stock}`);
                Modals.close('adjustStockModal');
                this.render();
                if (typeof Dashboard !== 'undefined' && Dashboard.update) Dashboard.update();
            },

            exportCSV() {
                if (!State.products.length) return Toast.warning('No products to export');
                
                let csv = 'Name,Category,Barcode,Buy Price,Sell Price,Stock,Min Stock\n';
                State.products.forEach(p => {
                    csv += `"${p.name}","${p.category || ''}","${p.barcode || ''}",${p.buy},${p.sell},${p.stock},${p.minStock != null ? p.minStock : 5}\n`;
                });
                
                Helpers.downloadFile(csv, 'products.csv');
                Toast.success('Exported successfully');
            },

            importCSV() {
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = '.csv';
                input.onchange = async (e) => {
                    const reader = new FileReader();
                    reader.onload = (ev) => {
                        const lines = ev.target.result.split('\n');
                        let count = 0;
                        
                        State.saveUndoState('Import products');
                        
                        for (let i = 1; i < lines.length; i++) {
                            const line = lines[i].trim();
                            if (!line) continue;
                            
                            // Support both old and new CSV formats
                            const parts = line.match(/(".*?"|[^,]+)/g) || line.split(',');
                            const clean = (s) => (s || '').replace(/^"|"$/g, '').trim();
                            if (parts.length >= 4) {
                                const name = clean(parts[0]);
                                if (name) {
                                    // Detect if barcode column exists (new format has 7 cols)
                                    const hasBarcode = parts.length >= 6;
                                    State.products.push({
                                        id: Helpers.uid(),
                                        name,
                                        category: clean(parts[1]) || 'Uncategorized',
                                        barcode: hasBarcode ? clean(parts[2]) : '',
                                        buy: parseFloat(hasBarcode ? parts[3] : parts[2]) || 0,
                                        sell: parseFloat(hasBarcode ? parts[4] : parts[3]) || 0,
                                        stock: parseInt(hasBarcode ? parts[5] : parts[4]) || 0,
                                        minStock: hasBarcode && parts[6] != null ? (parseInt(parts[6]) || 5) : 5,
                                        notes: '',
                                        initialStock: parseInt(hasBarcode ? parts[5] : parts[4]) || 0,
                                        images: [],
                                        createdAt: new Date().toISOString()
                                    });
                                    count++;
                                }
                            }
                        }
                        
                        Storage.save('products', State.products);
                        Toast.success(`Imported ${count} products`);
                        this.render();
                        Dashboard.update();
                        App.populateDropdowns();
                    };
                    reader.readAsText(e.target.files[0]);
                };
                input.click();
            }
        };
        
        window.Products = Products;
        console.log('✅ ' + MODULE_NAME + ' loaded successfully');
        return Products;
    });
    
})();