// ============================================
// EXPENSES MODULE
// ============================================

(function() {
    'use strict';
    
    const MODULE_NAME = 'Expenses';
    
    console.log('📦 Registering ' + MODULE_NAME + '...');
    
    window.registerModule(MODULE_NAME, function() {
        console.log('✅ ' + MODULE_NAME + ' initializing...');
        
        const Expenses = {
            openTypeModal(id) {
                let modal = document.getElementById('expenseModal');
                if (!modal) {
                    modal = document.createElement('div');
                    modal.className = 'modal-overlay';
                    modal.id = 'expenseModal';
                    modal.innerHTML = `
                        <div class="modal" style="max-width:400px;">
                            <button class="close-btn" data-cashtracker-onclick="Modals.close('expenseModal')">✕</button>
                            <h3>💸 Expense Type</h3>
                            <input type="hidden" id="editExpenseId">
                            <div class="form-group"><label>Name</label><input class="form-control" id="expenseName"></div>
                            <div class="form-group"><label>Description</label><input class="form-control" id="expenseDesc"></div>
                            <button class="btn btn-success" data-cashtracker-onclick="Expenses.saveType()">💾 Save</button>
                        </div>
                    `;
                    document.body.appendChild(modal);
                }

                document.getElementById('editExpenseId').value = '';
                document.getElementById('expenseName').value = '';
                document.getElementById('expenseDesc').value = '';

                if (id) {
                    const expense = State.expenseTypes.find(e => e.id === id);
                    if (expense) {
                        document.getElementById('editExpenseId').value = id;
                        document.getElementById('expenseName').value = expense.name;
                        document.getElementById('expenseDesc').value = expense.description || '';
                    }
                }

                Modals.open('expenseModal');
            },

            saveType() {
                const id = document.getElementById('editExpenseId').value;
                const name = document.getElementById('expenseName').value.trim();

                if (!name) return Toast.warning('Name required');

                if (id) {
                    const expense = State.expenseTypes.find(e => e.id === id);
                    if (expense) {
                        expense.name = name;
                        expense.description = document.getElementById('expenseDesc').value.trim();
                    }
                } else {
                    State.expenseTypes.push({
                        id: Helpers.uid(),
                        name,
                        description: document.getElementById('expenseDesc').value.trim()
                    });
                }

                Storage.save('expenseTypes', State.expenseTypes);
                Toast.success('Expense type saved');
                Modals.close('expenseModal');
                this.renderTypes();
                App.populateDropdowns();
            },

            deleteType(id) {
                if (!confirm('Delete this expense type?')) return;
                State.expenseTypes = State.expenseTypes.filter(e => e.id !== id);
                Storage.save('expenseTypes', State.expenseTypes);
                Toast.success('Expense type deleted');
                this.renderTypes();
                App.populateDropdowns();
            },

            renderTypes() {
                const container = document.getElementById('expenseList');
                if (!container) return;

                if (!State.expenseTypes.length) {
                    container.innerHTML = '<div class="empty-state">No expense types defined</div>';
                    return;
                }

                container.innerHTML = State.expenseTypes.map(e => `
                    <div class="list-item">
                        <div class="info">
                            <span class="title">${Helpers.esc(e.name)}</span>
                            <span class="meta">${Helpers.esc(e.description || '')}</span>
                        </div>
                        <div class="actions">
                            <button class="btn btn-warning btn-sm" data-cashtracker-onclick="Expenses.openTypeModal('${e.id}')">✏️</button>
                            <button class="btn btn-danger btn-sm" data-cashtracker-onclick="Expenses.deleteType('${e.id}')">🗑️</button>
                        </div>
                    </div>
                `).join('');
            },

            openDirectModal() {
                let modal = document.getElementById('directExpenseModal');
                if (!modal) {
                    modal = document.createElement('div');
                    modal.className = 'modal-overlay';
                    modal.id = 'directExpenseModal';
                    modal.innerHTML = `
                        <div class="modal" style="max-width:400px;">
                            <button class="close-btn" data-cashtracker-onclick="Modals.close('directExpenseModal')">✕</button>
                            <h3>➕ Record Expense</h3>
                            <div class="form-group"><label>Date</label><input class="form-control" type="date" id="directExpenseDate"></div>
                            <div class="form-group"><label>Type</label><select class="form-control" id="directExpenseTypeId"><option value="">-- Select --</option></select></div>
                            <div class="form-group"><label>Amount</label><input class="form-control" id="directExpenseAmount" type="number" min="0.01" step="0.01"></div>
                            <div class="form-group"><label>Paid from</label><select class="form-control" id="directExpenseAccount"></select></div>
                            <div class="form-group"><label>Reason</label><input class="form-control" id="directExpenseReason"></div>
                            <button class="btn btn-success" data-cashtracker-onclick="Expenses.submitDirect()">💾 Save</button>
                        </div>
                    `;
                    document.body.appendChild(modal);
                }

                document.getElementById('directExpenseDate').value = Helpers.getToday();
                document.getElementById('directExpenseAmount').value = '';
                document.getElementById('directExpenseReason').value = '';
                
                App.populateDropdowns();
                // The expense account selector is created dynamically, so the
                // general dropdown population must explicitly fill it.
                if (window.CashBanks && typeof CashBanks.selectOptions === 'function') {
                    CashBanks.init();
                    const accountSelect = document.getElementById('directExpenseAccount');
                    if (accountSelect) {
                        accountSelect.innerHTML = '<option value="">-- Select account --</option>' + CashBanks.selectOptions('');
                    }
                }
                Modals.open('directExpenseModal');
            },

            submitDirect() {
                const typeId = document.getElementById('directExpenseTypeId').value;
                const amount = +document.getElementById('directExpenseAmount').value;
                const accountId = document.getElementById('directExpenseAccount')?.value || '';

                if (!typeId) return Toast.warning('Select expense type');
                if (amount <= 0) return Toast.warning('Enter valid amount');
                if (!accountId) return Toast.warning('Select the account used to pay the expense');
                if(window.CashBanks && CashBanks.balance(accountId) < amount) return Toast.warning('Insufficient available balance');

                State.saveUndoState('Record expense');
                const expense = {
                    id: Helpers.uid(),
                    date: document.getElementById('directExpenseDate').value || Helpers.getToday(),
                    typeId,
                    typeName: State.expenseTypes.find(e => e.id === typeId)?.name || '',
                    amount,
                    accountId,
                    reason: document.getElementById('directExpenseReason').value.trim(),
                    createdAt: new Date().toISOString()
                };

                try {
                    State.runAtomic('Record expense', () => {
                        State.directExpenses.push(expense);
                        if (window.CashBanks) CashBanks.link(accountId, amount, 'out', {
                            date: expense.date, sourceType: 'expense', sourceId: expense.id, note: expense.reason || expense.typeName
                        });
                    });
                } catch (error) {
                    console.error('Expense recording failed:', error);
                    return Toast.warning(error?.message || 'Could not record expense');
                }

                Toast.success(`Expense recorded: ${Helpers.formatCurrency(amount)}`);
                EntryDrafts.markSaved('directExpenseModal'); Modals.close('directExpenseModal');
                this.renderDirect();
                Dashboard.update();
            },

            recordExclusive() {
                const amount = prompt('💰 Amount:');
                if (!amount || isNaN(amount) || +amount <= 0) {
                    return Toast.warning('Invalid amount');
                }

                const reason = prompt('📝 Reason (optional):');
                const account = window.CashBanks ? CashBanks.accounts().find(a=>a.type==='cash') : null;
                if(window.CashBanks && !account) return Toast.warning('Create a cash account before recording a cash expense');
                if(account && CashBanks.balance(account.id) < +amount) return Toast.warning('Insufficient cash balance');

                State.saveUndoState('Record quick expense');
                const expense = {
                    id: Helpers.uid(),
                    date: Helpers.getToday(),
                    typeId: 'direct',
                    typeName: 'General Expense',
                    amount: +amount,
                    accountId: account?.id || '',
                    reason: reason || '',
                    createdAt: new Date().toISOString()
                };
                State.directExpenses.push(expense);
                if(account) CashBanks.link(account.id,+amount,'out',{date:expense.date,sourceType:'expense',sourceId:expense.id,note:expense.reason||expense.typeName});

                Storage.save('directExpenses', State.directExpenses);
                Toast.success(`${Helpers.formatCurrency(+amount)} recorded`);
                this.renderDirect();
                Dashboard.update();
            },

            renderDirect() {
                const container = document.getElementById('directExpenseList');
                if (!container) return;

                if (!State.directExpenses.length) {
                    container.innerHTML = '<div class="empty-state">No expenses recorded</div>';
                    return;
                }

                const sorted = State.directExpenses
                    .slice()
                    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

                container.innerHTML = sorted.map(e => `
                    <div class="list-item">
                        <div class="info">
                            <span class="title">${Helpers.formatCurrency(e.amount)} - ${Helpers.esc(e.typeName)}</span>
                            <span class="meta">${Helpers.formatDate(e.date)} - ${Helpers.esc(e.reason || '')}</span>
                        </div>
                        <button class="btn btn-danger btn-sm" data-cashtracker-onclick="Expenses.voidDirect('${e.id}')">↩️</button>
                    </div>
                `).join('');
            },

            voidDirect(id) {
                const expense = State.directExpenses.find(e => e.id === id);
                if (!expense) return;
                if (expense.status === 'void' || expense.voided) return Toast.warning('Expense is already voided');
                const reason = prompt('Reason for voiding this expense:');
                if (!reason || !reason.trim()) return Toast.warning('A void reason is required');
                try {
                    State.saveUndoState('Void expense');
                    State.runAtomic('Void expense',()=>{
                        expense.status='void'; expense.voided=true; expense.voidedAt=new Date().toISOString(); expense.voidReason=reason.trim();
                        (State.moneyTransactions||[]).forEach(t=>{if(t.sourceType==='expense'&&t.sourceId===id&&t.status!=='void')t.status='void';});
                        Security?.audit('void','expense',id,{amount:expense.amount,reason:expense.voidReason});
                    });
                    Storage.save('directExpenses', State.directExpenses); Storage.save('moneyTransactions', State.moneyTransactions||[]);
                    Toast.success('Expense voided; original record retained'); this.renderDirect(); if(window.CashBanks)CashBanks.render(); Dashboard.update();
                } catch(e){Toast.error('Expense void failed: '+(e.message||e));}
            },
            deleteDirect(id) { return this.voidDirect(id); }
        };
        
        window.Expenses = Expenses;
        console.log('✅ ' + MODULE_NAME + ' loaded successfully');
        return Expenses;
    });
    
})();
