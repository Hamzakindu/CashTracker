// ============================================
// PURCHASES MODULE - COMPLETE FIXED
// ============================================

(function() {
    'use strict';
    
    const MODULE_NAME = 'Purchases';
    
    console.log('📦 Registering ' + MODULE_NAME + '...');
    
    window.registerModule(MODULE_NAME, function() {
        console.log('✅ ' + MODULE_NAME + ' initializing...');
        
        const Purchases = {
            init() {
                const container = document.getElementById('tab-purchases');
                if (!container) return;

                container.innerHTML = `
                    <div class="card">
                        <div class="flex-between">
                            <div class="card-title">📥 Purchase History</div>
                            <button class="btn btn-success btn-sm" onclick="Purchases.openModal()">➕ New Purchase</button>
                        </div>
                        <div id="purchaseList"></div>
                    </div>
                `;
                
                this.render();
            },

            openModal(calcItems) {
                let modal = document.getElementById('purchaseModal');
                if (!modal) {
                    modal = document.createElement('div');
                    modal.className = 'modal-overlay';
                    modal.id = 'purchaseModal';
                    modal.innerHTML = `
                        <div class="modal">
                            <button class="close-btn" onclick="Modals.close('purchaseModal')">✕</button>
                            <h3>📥 Purchase Products</h3>
                            <button class="btn btn-sm btn-outline" onclick="Purchases.addItem()" style="margin-bottom:8px;">➕ Add Item</button>
                            <table class="transaction-table">
                                <thead><tr><th>Product</th><th>Qty</th><th>Cost</th><th>Amount</th><th></th></tr></thead>
                                <tbody id="purchaseItemsBody"></tbody>
                            </table>
                            <div style="display:flex;justify-content:space-between;margin:10px 0;font-weight:700;">
                                <span>Total:</span>
                                <span id="purchaseTotalDisplay">ETB 0.00</span>
                            </div>
                            <div class="form-group"><label>Date</label><input class="form-control" type="date" id="purchaseDate"></div>
                            <div class="form-group"><label>Supplier</label><input class="form-control" id="purchaseSupplierSearch" list="purchaseSupplierOptions" placeholder="🔍 Search supplier"><datalist id="purchaseSupplierOptions"></datalist><select class="form-control" id="purchaseSupplier" style="margin-top:6px;"><option value="">-- Select --</option></select></div>
                            <div class="form-group"><label>Cash/Bank Paid Now</label><input class="form-control" id="purchasePaid" type="number" min="0" step="0.01" placeholder="0"></div><div class="form-group"><label>Money account</label><select class="form-control" id="purchaseMoneyAccount"></select></div><div id="purchaseAdvanceBox" class="form-group" style="display:none"><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="purchaseUseAdvance"><span>Use supplier advance</span></label><small id="purchaseAdvanceInfo">Available advance: ETB 0.00</small></div>
                            <button class="btn btn-success" id="purchaseSubmitBtn" onclick="Purchases.submit()">📥 Complete Purchase</button>
                        </div>
                    `;
                    document.body.appendChild(modal);
                }

                document.getElementById('purchaseItemsBody').innerHTML = '';
                document.getElementById('purchaseDate').value = Storage.getSetting('lastTransactionDate', Helpers.getToday());
                document.getElementById('purchasePaid').value = ''; if(window.CashBanks){CashBanks.init();document.getElementById('purchaseMoneyAccount').innerHTML=CashBanks.selectOptions();}
                document.getElementById('purchaseSubmitBtn').textContent = '📥 Complete Purchase';
                document.getElementById('purchaseSubmitBtn').onclick = () => Purchases.submit();

                App.populateDropdowns();
                const ss=document.getElementById('purchaseSupplierSearch'), sel=document.getElementById('purchaseSupplier'); if(ss&&sel){ ss.oninput=()=>{const v=ss.value.trim().toLowerCase();const sp=(State.suppliers||[]).find(x=>x.name.toLowerCase()===v);if(sp){sel.value=sp.id;this.updateAdvanceInfo();}}; sel.onchange=()=>this.updateAdvanceInfo(); }
                const imported = Array.isArray(calcItems) ? calcItems.filter(x => !x.adjustment && Number(x.quantity) > 0 && Number(x.price) > 0) : [];
                if (imported.length) {
                    document.getElementById('purchaseItemsBody').innerHTML = '';
                    imported.forEach(item => {
                        this.addItem();
                        const rows = document.querySelectorAll('.purchase-item-row');
                        const row = rows[rows.length - 1];
                        if (row) {
                            row.querySelector('.purchase-qty').value = Number(item.quantity);
                            row.querySelector('.purchase-cost').value = Number(item.price);
                            this.updateRow(row.querySelector('.purchase-cost'));
                        }
                    });
                } else {
                    this.addItem();
                }
                this.updateAdvanceInfo();
                Modals.open('purchaseModal');
            },

            updateAdvanceInfo() { const sel=document.getElementById('purchaseSupplier'),box=document.getElementById('purchaseAdvanceBox'),info=document.getElementById('purchaseAdvanceInfo'); if(!sel||!box||!info)return; const s=(State.suppliers||[]).find(x=>x.id===sel.value),a=Number(s?.supplierAdvance||0); box.style.display=s?'block':'none'; info.textContent='Available advance: '+Helpers.formatCurrency(a); const cb=document.getElementById('purchaseUseAdvance'); if(cb&&a<=0)cb.checked=false; },

            addItem() {
                const tbody = document.getElementById('purchaseItemsBody');
                if (!tbody) return;

                const row = document.createElement('tr');
                row.className = 'purchase-item-row';
                row.innerHTML = `
                    <td><input class="form-control purchase-product-search" list="purchaseProductOptions" placeholder="🔍 Search"><datalist id="purchaseProductOptions"></datalist><select class="form-control purchase-product-select" style="margin-top:5px;"><option value="">-- Select --</option></select></td>
                    <td><input class="form-control purchase-qty" type="number" min="1" value="1" oninput="Purchases.updateRow(this)"></td>
                    <td><input class="form-control purchase-cost" type="number" step="0.01" value="0" oninput="Purchases.updateRow(this)"></td>
                    <td><input class="form-control purchase-amount" type="number" readonly value="0"></td>
                    <td><button style="background:none;border:none;color:var(--danger);cursor:pointer;font-size:1.2rem;" onclick="this.closest('tr').remove();Purchases.updateTotal()">✕</button></td>
                `;
                tbody.appendChild(row);

                const select = row.querySelector('.purchase-product-select');
                Helpers.getSorted(State.products).forEach(p => {
                    const option = document.createElement('option');
                    option.value = p.id;
                    option.textContent = p.name;
                    select.appendChild(option);
                });

                const search = row.querySelector('.purchase-product-search'); const dl=row.querySelector('#purchaseProductOptions');
                if(dl){dl.innerHTML='';(State.products||[]).forEach(p=>{const o=document.createElement('option');o.value=p.name;o.label='Stock: '+(p.stock||0);dl.appendChild(o);});}
                if(search) search.oninput=()=>{const p=(State.products||[]).find(x=>x.name.toLowerCase()===search.value.trim().toLowerCase());if(p){select.value=p.id;select.dispatchEvent(new Event('change'));}};
                select.onchange=()=>{const p=State.products.find(x=>x.id===select.value);if(p)row.querySelector('.purchase-cost').value=p.buy||0;this.updateRow(row.querySelector('.purchase-cost'));};
                this.updateTotal();
            },

            updateRow(el) {
                const row = el.closest('tr');
                const qty = +row.querySelector('.purchase-qty').value || 0;
                const cost = +row.querySelector('.purchase-cost').value || 0;
                row.querySelector('.purchase-amount').value = (qty * cost).toFixed(2);
                this.updateTotal();
            },

            updateTotal() {
                let total = 0;
                document.querySelectorAll('.purchase-item-row').forEach(row => {
                    total += +row.querySelector('.purchase-amount').value || 0;
                });
                const display = document.getElementById('purchaseTotalDisplay');
                if (display) display.textContent = Helpers.formatCurrency(total);
            },

            submit() {
                const items = [];
                document.querySelectorAll('.purchase-item-row').forEach(row => {
                    const productId = row.querySelector('.purchase-product-select').value;
                    const qty = Number(row.querySelector('.purchase-qty').value);
                    const cost = Number(row.querySelector('.purchase-cost').value);
                    if (productId && Number.isFinite(qty) && qty > 0 && Number.isFinite(cost) && cost > 0) {
                        const product = State.products.find(p => p.id === productId);
                        if (product) items.push({ productId, productName: product.name, quantity: qty, cost, amount: qty * cost });
                    }
                });
                if (!items.length) return Toast.warning('Add at least one valid item');
                const supplierId = document.getElementById('purchaseSupplier').value;
                const supplier = State.suppliers.find(s => s.id === supplierId);
                if (!supplier) return Toast.warning('Supplier not found');
                const paid = Number(document.getElementById('purchasePaid').value || 0);
                if (!Number.isFinite(paid) || paid < 0) return Toast.warning('Payment cannot be negative');
                const total = items.reduce((sum, item) => sum + item.amount, 0);
                const useAdvance = !!document.getElementById('purchaseUseAdvance')?.checked;
                const availableAdvance = Number(supplier.supplierAdvance || 0);
                const advanceUsed = useAdvance ? Math.min(availableAdvance, total) : 0;
                const remaining = total - advanceUsed;
                const excessPaid = Math.max(0, paid - remaining);
                const debit = Math.max(0, remaining - paid);
                const date = document.getElementById('purchaseDate').value || Storage.getSetting('lastTransactionDate', Helpers.getToday());
                const purchaseId = Helpers.uid();
                try {
                    State.saveUndoState('Purchase: ' + Helpers.formatCurrency(total));
                    State.runAtomic('Create purchase', () => {
                        items.forEach(item => {
                            const product = State.products.find(p => p.id === item.productId);
                            if (!product) throw new Error('Product not found: ' + item.productId);
                            product.stock += item.quantity;
                            if (window.StockHistory) StockHistory.recordChange(item.productId, product.name, Number(item.quantity), 'Purchase completed', 'purchase');
                        });
                        supplier.balance = (supplier.balance || 0) + debit;
                        if (advanceUsed > 0) { supplier.supplierAdvance = Math.max(0, Number(supplier.supplierAdvance || 0) - advanceUsed); if(!Array.isArray(State.supplierAdvances)) State.supplierAdvances=[]; State.supplierAdvances.unshift({id:Helpers.uid(),supplierId,supplier:supplier.name,amount:advanceUsed,type:'applied',date,createdAt:new Date().toISOString()}); }
                        State.purchases.unshift({ id: purchaseId, transactionId: purchaseId, sourceType: 'purchase', items, supplier: supplier.name || '', supplierId, total, paid, advanceUsed, excessPaid, debit, date, createdAt: new Date().toISOString() });
                        State.paymentLedger = State.paymentLedger || [];
                        if (paid > 0) { const aid=document.getElementById('purchaseMoneyAccount')?.value; if(!aid) throw new Error('Select the cash/bank account used for payment'); const ledgerId=Helpers.uid(); const ledger={id:ledgerId,entityType:'supplier',entityId:supplierId,entityName:supplier.name,amount:paid,method:document.getElementById('purchasePaymentMethod')?.value||'Cash',accountId:aid,reference:'Purchase',sourceId:purchaseId,sourceType:'purchase',date,kind:'purchase_payment',createdAt:new Date().toISOString(),status:'posted'}; State.paymentLedger.unshift(ledger); if(window.CashBanks)CashBanks.link(aid,paid,'out',{date,sourceType:'purchase_payment',sourceId:purchaseId,note:'Purchase payment',paymentId:ledgerId}); }
                        if (advanceUsed > 0) State.paymentLedger.unshift({id:Helpers.uid(),entityType:'supplier',entityId:supplierId,entityName:supplier.name,amount:advanceUsed,method:'Supplier Advance',reference:'Purchase',sourceId:purchaseId,sourceType:'purchase',date,kind:'advance_applied',createdAt:new Date().toISOString(),status:'posted'});
                    });
                    Storage.setSetting('lastTransactionDate', date);
                    Toast.success(`Purchase completed: ${Helpers.formatCurrency(total)}`); Modals.close('purchaseModal'); App.populateDropdowns(); Products.render(); this.render(); Dashboard.update();
                } catch (error) { Toast.error('Purchase failed: ' + (error.message || error)); }
            },

            render() {
                const container = document.getElementById('purchaseList');
                if (!container) return;

                if (!State.purchases || State.purchases.length === 0) {
                    container.innerHTML = '<div class="empty-state">No purchases recorded</div>';
                    return;
                }

                const sorted = State.purchases
                    .slice()
                    .sort((a, b) => {
                        const dateA = a.createdAt || a.date || '1970-01-01';
                        const dateB = b.createdAt || b.date || '1970-01-01';
                        return new Date(dateB).getTime() - new Date(dateA).getTime();
                    })
                    .slice(0, 50);

                container.innerHTML = sorted.map(purchase => {
                    const items = (purchase.items || []).map(i => Helpers.esc(i.productName) + ' x' + i.quantity).join(', ');
                    const cls = (purchase.debit || 0) > 0 ? 'balance-positive' : 'balance-zero';
                    const status = (purchase.debit || 0) > 0 ? 'Debit' : 'Paid';

                    return `
                        <div class="list-item" onclick="TransactionDetail.show('purchase', '${purchase.id}')">
                            <div class="info">
                                <span class="title">${items}</span>
                                <span class="meta">${Helpers.formatDate(purchase.date)} | ${Helpers.esc(purchase.supplier || '')}</span>
                            </div>
                            <div>
                                ${Helpers.formatCurrency(purchase.total)}
                                <span class="balance-badge ${cls}">${status} ${Helpers.formatCurrency(Math.abs(purchase.debit || 0))}</span>
                            </div>
                            <div class="actions" onclick="event.stopPropagation();">
                                <button class="btn btn-warning btn-sm" onclick="Purchases.edit('${purchase.id}')">✏️</button>
                                <button class="btn btn-danger btn-sm" onclick="Purchases.delete('${purchase.id}')">🗑️</button>
                            </div>
                        </div>
                    `;
                }).join('');
            },

            viewDetail(id) {
                try {
                    const purchase = State.purchases.find(p => p.id === id);
                    if (!purchase) {
                        Toast.error('Purchase not found');
                        return;
                    }

                    const itemsHtml = (purchase.items || []).map(item => `
                        <tr onclick="TransactionDetail.show('product', '${item.productId}')" style="cursor:pointer;">
                            <td style="color:var(--primary);">${Helpers.esc(item.productName)}</td>
                            <td>${item.quantity}</td>
                            <td>${Helpers.formatCurrency(item.cost)}</td>
                            <td>${Helpers.formatCurrency(item.amount)}</td>
                        </tr>
                    `).join('');

                    const html = `
                        <div class="detail-section">
                            <h4>📥 Purchase #${purchase.id ? purchase.id.slice(0, 8) : 'N/A'}</h4>
                            <div class="detail-row"><span class="detail-label">Date:</span><span class="detail-value">${Helpers.formatDate(purchase.date)}</span></div>
                            <div class="detail-row"><span class="detail-label">Supplier:</span><span class="detail-value">${Helpers.esc(purchase.supplier || 'Unknown')}</span></div>
                            <div class="detail-row"><span class="detail-label">Total:</span><span class="detail-value">${Helpers.formatCurrency(purchase.total)}</span></div>
                            <div class="detail-row"><span class="detail-label">Paid:</span><span class="detail-value">${Helpers.formatCurrency(purchase.paid || 0)}</span></div>
                            <div class="detail-row"><span class="detail-label">Balance:</span><span class="detail-value"><span class="status-badge ${(purchase.debit || 0) > 0 ? 'status-debit' : 'status-paid'}">${(purchase.debit || 0) > 0 ? 'Debit: ' + Helpers.formatCurrency(purchase.debit) : 'Paid'}</span></span></div>
                        </div>
                        <div class="detail-section">
                            <h4>📦 Items</h4>
                            <table class="transaction-table">
                                <thead><tr><th>Product</th><th>Qty</th><th>Cost</th><th>Amount</th></tr></thead>
                                <tbody>${itemsHtml}</tbody>
                            </table>
                        </div>
                        <div class="detail-section">
                            <h4>⚡ Quick Actions</h4>
                            <div style="display:flex;gap:8px;flex-wrap:wrap;">
                                <button class="btn btn-warning btn-sm" onclick="Purchases.edit('${purchase.id}')">✏️ Edit</button>
                                ${purchase.supplierId ? `<button class="btn btn-success btn-sm" onclick="TransactionDetail.show('supplier', '${purchase.supplierId}')">🏢 View Supplier</button>` : ''}
                            </div>
                        </div>
                    `;

                    document.getElementById('detailModalContent').innerHTML = html;
                    document.getElementById('detailModalTitle').textContent = '📥 Purchase Details';
                    Modals.open('detailModal');
                    
                } catch (error) {
                    console.error('viewDetail error:', error);
                    Toast.error('Error loading purchase details');
                }
            },

            edit(id) {
                const purchase = State.purchases.find(p => p.id === id);
                if (!purchase) return;

                this.openModal();
                
                document.getElementById('purchaseItemsBody').innerHTML = '';
                (purchase.items || []).forEach(item => {
                    this.addItem();
                    const rows = document.querySelectorAll('.purchase-item-row');
                    const lastRow = rows[rows.length - 1];
                    if (lastRow) {
                        lastRow.querySelector('.purchase-product-select').value = item.productId;
                        lastRow.querySelector('.purchase-qty').value = item.quantity;
                        lastRow.querySelector('.purchase-cost').value = item.cost;
                        this.updateRow(lastRow.querySelector('.purchase-cost'));
                    }
                });

                document.getElementById('purchaseDate').value = purchase.date;
                document.getElementById('purchaseSupplier').value = purchase.supplierId || '';
                document.getElementById('purchasePaid').value = purchase.paid || 0;

                App.populateDropdowns();
                if(document.getElementById('purchaseUseAdvance')) document.getElementById('purchaseUseAdvance').checked=Number(purchase.advanceUsed||0)>0;
                const oldMoney=(State.moneyTransactions||[]).find(t=>t.sourceId===purchase.id&&t.status!=='void');
                if(oldMoney&&document.getElementById('purchaseMoneyAccount')) document.getElementById('purchaseMoneyAccount').value=oldMoney.accountId||'';
                
                const submitBtn = document.getElementById('purchaseSubmitBtn');
                submitBtn.textContent = '💾 Update Purchase';
                submitBtn.onclick = () => Purchases.update(id);
            },

            update(id) {
                const purchase = State.purchases.find(p => p.id === id);
                if (!purchase) return;
                const items = [];
                document.querySelectorAll('.purchase-item-row').forEach(row => {
                    const productId = row.querySelector('.purchase-product-select').value;
                    const qty = Number(row.querySelector('.purchase-qty').value);
                    const cost = Number(row.querySelector('.purchase-cost').value);
                    if (productId && Number.isFinite(qty) && qty > 0 && Number.isFinite(cost) && cost > 0) {
                        const product = State.products.find(p => p.id === productId);
                        if (product) items.push({ productId, productName: product.name, quantity: qty, cost, amount: qty * cost });
                    }
                });
                if (!items.length) return Toast.warning('Add at least one valid item');
                const supplierId = document.getElementById('purchaseSupplier').value;
                const supplier = State.suppliers.find(s => s.id === supplierId);
                if (!supplier) return Toast.warning('Supplier not found');
                const paid = Number(document.getElementById('purchasePaid').value);
                if (!Number.isFinite(paid) || paid < 0) return Toast.warning('Payment cannot be negative');
                const total = items.reduce((sum, item) => sum + item.amount, 0);
                const useAdvance = !!document.getElementById('purchaseUseAdvance')?.checked;
                const availableAdvance = Number(supplier.supplierAdvance || 0);
                const advanceUsed = useAdvance ? Math.min(availableAdvance, total) : 0;
                const remaining = total - advanceUsed;
                const excessPaid = Math.max(0, paid - remaining);
                const debit = Math.max(0, remaining - paid);
                const date = document.getElementById('purchaseDate').value || Storage.getSetting('lastTransactionDate', Helpers.getToday());
                try {
                    State.saveUndoState('Update purchase: ' + Helpers.formatCurrency(total));
                    State.runAtomic('Update purchase', () => {
                        (State.paymentLedger||[]).forEach(x=>{if(x.sourceId===purchase.id&&x.status!=='void')x.status='void';});
                        (State.moneyTransactions||[]).forEach(x=>{if(x.sourceId===purchase.id&&x.status!=='void')x.status='void';});
                        (purchase.items || []).forEach(old => {
                            const product = State.products.find(p => p.id === old.productId);
                            if (!product) throw new Error('Old product not found: ' + old.productId);
                            product.stock -= Number(old.quantity);
                            if (window.StockHistory) StockHistory.recordChange(old.productId, product.name, -Number(old.quantity), 'Purchase updated - old quantity reversed', 'purchase-reversal');
                        });
                        if (purchase.supplierId) {
                            const oldSupplier = State.suppliers.find(s => s.id === purchase.supplierId);
                            if (!oldSupplier) throw new Error('Old supplier not found: ' + purchase.supplierId);
                            oldSupplier.balance = (oldSupplier.balance || 0) - (purchase.debit || 0);
                            oldSupplier.supplierAdvance = Number(oldSupplier.supplierAdvance||0) + Number(purchase.advanceUsed||0) - Number(purchase.excessPaid||0);
                        }
                        items.forEach(item => {
                            const product = State.products.find(p => p.id === item.productId);
                            if (!product) throw new Error('Product not found: ' + item.productId);
                            product.stock += item.quantity;
                            if (window.StockHistory) StockHistory.recordChange(item.productId, product.name, Number(item.quantity), 'Purchase updated', 'purchase');
                        });
                        supplier.balance = (supplier.balance || 0) + debit;
                        supplier.supplierAdvance = Number(supplier.supplierAdvance||0) + excessPaid;
                        if(paid>0){ const aid=document.getElementById('purchaseMoneyAccount')?.value || (State.moneyTransactions||[]).find(t=>t.sourceId===purchase.id&&t.status==='void')?.accountId; if(!aid) throw new Error('Select the cash/bank account used for payment'); const ledgerId=Helpers.uid(); State.paymentLedger.unshift({id:ledgerId,entityType:'supplier',entityId:supplierId,entityName:supplier.name,amount:paid,method:document.getElementById('purchasePaymentMethod')?.value||'Cash',accountId:aid,reference:'Purchase',sourceId:purchase.id,sourceType:'purchase',date,kind:'purchase_payment',createdAt:new Date().toISOString(),status:'posted'}); if(window.CashBanks)CashBanks.link(aid,paid,'out',{date,sourceType:'purchase_payment',sourceId:purchase.id,note:'Purchase payment (edited)',paymentId:ledgerId}); }
                        if(advanceUsed>0) { supplier.supplierAdvance=Number(supplier.supplierAdvance||0)-advanceUsed; State.supplierAdvances=State.supplierAdvances||[]; State.supplierAdvances.unshift({id:Helpers.uid(),supplierId,supplier:supplier.name,amount:advanceUsed,type:'applied',date,createdAt:new Date().toISOString()}); }
                        Object.assign(purchase, { items, supplier: supplier.name || '', supplierId, total, paid, advanceUsed, excessPaid, debit, date, updatedAt: new Date().toISOString() });
                        Security?.audit('update','purchase',purchase.id,{total,paid,accountId:(State.paymentLedger||[]).find(x=>x.sourceId===purchase.id&&x.status==='posted'&&x.kind==='purchase_payment')?.accountId});
                    });
                    Storage.setSetting('lastTransactionDate', date);
                    Toast.success(`Purchase updated: ${Helpers.formatCurrency(total)}`); Modals.close('purchaseModal'); App.populateDropdowns(); Products.render(); this.render(); Dashboard.update();
                } catch (error) { Toast.error('Purchase update failed: ' + (error.message || error)); }
            },

            delete(id) {
                if (!confirm('Delete this purchase? Stock will be adjusted.')) return;
                const purchase = State.purchases.find(p => p.id === id);
                if (!purchase) return;
                try {
                    State.saveUndoState('Delete purchase: ' + Helpers.formatCurrency(purchase.total));
                    State.runAtomic('Delete purchase', () => {
                        (purchase.items || []).forEach(item => {
                            const product = State.products.find(p => p.id === item.productId);
                            if (!product) throw new Error('Product not found: ' + item.productId);
                            product.stock -= Number(item.quantity);
                            if (window.StockHistory) StockHistory.recordChange(item.productId, product.name, -Number(item.quantity), 'Purchase deleted', 'purchase-delete');
                        });
                        (State.paymentLedger||[]).forEach(x=>{if(x.sourceId===id&&x.status!=='void')x.status='void';});
                        (State.moneyTransactions||[]).forEach(x=>{if(x.sourceId===id&&x.status!=='void')x.status='void';});
                        if (purchase.supplierId) {
                            const supplier = State.suppliers.find(s => s.id === purchase.supplierId);
                            if (!supplier) throw new Error('Supplier not found: ' + purchase.supplierId);
                            supplier.balance = (supplier.balance || 0) - (purchase.debit || 0);
                            supplier.supplierAdvance = Number(supplier.supplierAdvance||0) + Number(purchase.advanceUsed||0) - Number(purchase.excessPaid||0);
                        }
                        State.purchases = State.purchases.filter(p => p.id !== id);
                        Security?.audit('delete','purchase',id,{total:purchase.total,financialTransactionsVoided:true});
                    });
                    Toast.success('Purchase deleted and stock adjusted'); Products.render(); this.render(); Dashboard.update();
                } catch (error) { Toast.error('Purchase deletion failed: ' + (error.message || error)); }
            }
        };
        
        window.Purchases = Purchases;
        console.log('✅ ' + MODULE_NAME + ' loaded successfully');
        return Purchases;
    });
    
})();