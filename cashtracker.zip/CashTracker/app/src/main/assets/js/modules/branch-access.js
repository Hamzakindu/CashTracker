// CashTracker V5.10.34 — branch directory and staff-role setup foundation.
// This is local profile/metadata management, NOT authenticated or server-enforced access control.
(function(){'use strict';
window.registerModule('BranchAccess',function(){
 const roles={
  owner:{label:'Owner / Admin',description:'Setup and overall business oversight'},
  manager:{label:'Manager',description:'Daily operations and reports'},
  cashier:{label:'Cashier',description:'Sales and payment handling'},
  inventory:{label:'Inventory Clerk',description:'Products and stock operations'},
  accountant:{label:'Accountant',description:'Finance and reports'},
  viewer:{label:'Read-only Viewer',description:'View-only role label'}
 };
 const id=()=> 'ba_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7);
 const esc=v=>Helpers.esc(String(v==null?'':v));
 const active=()=> (State.branches||[]).find(b=>b.id===State.branchAccessMeta?.activeBranchId)||State.branches?.[0];
 function persist(){State.save('branches');State.save('staffUsers');State.save('branchAccessMeta');if(typeof SecurityHardening!=='undefined'&&SecurityHardening.log)SecurityHardening.log('branch_access_setup','branch_access','', {branches:State.branches.length,staff:State.staffUsers.length});}
 const A={
  roles,
  render(){const host=document.getElementById('branchAccessOutput');if(!host)return;
   const branches=State.branches||[],staff=State.staffUsers||[],cur=active();
   host.innerHTML=`<div class="card" style="margin-top:12px"><div class="card-title">🏬 Branch directory & staff role setup</div><p><small>Optional setup for future multi-branch workflows. Existing transactions are not moved, filtered, or changed by this screen.</small></p>
   <div class="form-group"><label>Current working branch context</label><select class="form-control" id="baActiveBranch">${branches.map(b=>`<option value="${esc(b.id)}" ${cur&&b.id===cur.id?'selected':''}>${esc(b.name)}${b.active===false?' (inactive)':''}</option>`).join('')}</select></div>
   <div class="flex-between"><b>Branches (${branches.length})</b><button class="btn btn-outline btn-sm" onclick="BranchAccess.addBranch()">＋ Add branch</button></div>
   <div style="overflow-x:auto"><table class="transaction-table"><thead><tr><th>Branch</th><th>Code</th><th>Contact</th><th>Status</th><th>Action</th></tr></thead><tbody>${branches.map(b=>`<tr><td>${esc(b.name)}</td><td>${esc(b.code||'')}</td><td>${esc(b.phone||'')}</td><td>${b.active===false?'Inactive':'Active'}</td><td><button class="btn btn-outline btn-sm" onclick="BranchAccess.editBranch('${esc(b.id)}')">Edit</button> <button class="btn btn-outline btn-sm" onclick="BranchAccess.toggleBranch('${esc(b.id)}')">${b.active===false?'Activate':'Deactivate'}</button></td></tr>`).join('')}</tbody></table></div>
   <hr style="margin:16px 0"><div class="flex-between"><b>Staff directory (${staff.length})</b><button class="btn btn-outline btn-sm" onclick="BranchAccess.addStaff()">＋ Add staff profile</button></div>
   <div style="overflow-x:auto"><table class="transaction-table"><thead><tr><th>Name</th><th>Role</th><th>Assigned branch</th><th>Status</th><th>Action</th></tr></thead><tbody>${staff.map(u=>`<tr><td>${esc(u.name)}</td><td>${esc(roles[u.role]?.label||u.role)}</td><td>${esc(branches.find(b=>b.id===u.branchId)?.name||'Not assigned')}</td><td>${u.active===false?'Inactive':'Active'}</td><td><button class="btn btn-outline btn-sm" onclick="BranchAccess.editStaff('${esc(u.id)}')">Edit</button> <button class="btn btn-outline btn-sm" onclick="BranchAccess.toggleStaff('${esc(u.id)}')">${u.active===false?'Activate':'Deactivate'}</button></td></tr>`).join('')||'<tr><td colspan="5">No staff profiles yet.</td></tr>'}</tbody></table></div>
   <div class="alert alert-warning" style="margin-top:12px"><b>Security limitation:</b> staff profiles and role labels do not create login accounts or block actions. Do not rely on this screen to protect sensitive data on a shared device. Real permissions require authenticated users and server-side enforcement.</div>
   <div class="form-group"><label>Permission guide (role descriptions only)</label><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px">${Object.values(roles).map(r=>`<div class="stock-summary-item"><b>${esc(r.label)}</b><small>${esc(r.description)}</small></div>`).join('')}</div></div></div>`;
   document.getElementById('baActiveBranch')?.addEventListener('change',e=>{State.branchAccessMeta.activeBranchId=e.target.value;persist();Toast.success('Working branch context updated. Existing records are unchanged.');this.render();});
  },
  addBranch(){const name=prompt('Branch name:');if(!name||!name.trim())return;const code=(prompt('Branch code (optional):')||'').trim();const phone=(prompt('Phone (optional):')||'').trim();const address=(prompt('Address (optional):')||'').trim();State.branches.push({id:id(),name:name.trim(),code,phone,address,active:true,createdAt:new Date().toISOString()});persist();this.render();Toast.success('Branch profile added.');},
  editBranch(bid){const b=State.branches.find(x=>x.id===bid);if(!b)return;const name=prompt('Branch name:',b.name);if(name===null||!name.trim())return;b.name=name.trim();b.code=(prompt('Branch code:',b.code||'')??b.code)||'';b.phone=(prompt('Phone:',b.phone||'')??b.phone)||'';b.address=(prompt('Address:',b.address||'')??b.address)||'';persist();this.render();},
  toggleBranch(bid){const b=State.branches.find(x=>x.id===bid);if(!b)return;if(b.id===State.branchAccessMeta.activeBranchId&&b.active!==false){Toast.error('Select another branch before deactivating the current context.');return;}b.active=b.active===false;persist();this.render();},
  addStaff(){const name=prompt('Staff display name:');if(!name||!name.trim())return;const role=prompt('Role: owner, manager, cashier, inventory, accountant, viewer','cashier');if(!roles[role]){Toast.error('Unknown role. Use one of the listed role keys.');return;}const branchId=prompt('Assign to branch ID:\n'+State.branches.map(b=>b.id+' = '+b.name).join('\n'),active()?.id||'main');if(branchId===null)return;if(!State.branches.some(b=>b.id===branchId)){Toast.error('Branch ID not found.');return;}State.staffUsers.push({id:id(),name:name.trim(),role,branchId,active:true,createdAt:new Date().toISOString()});persist();this.render();Toast.success('Staff profile added (not a login account).');},
  editStaff(uid){const u=State.staffUsers.find(x=>x.id===uid);if(!u)return;const name=prompt('Staff display name:',u.name);if(name===null||!name.trim())return;const role=prompt('Role: owner, manager, cashier, inventory, accountant, viewer',u.role);if(!roles[role]){Toast.error('Unknown role.');return;}const branchId=prompt('Branch ID:\n'+State.branches.map(b=>b.id+' = '+b.name).join('\n'),u.branchId);if(branchId===null)return;if(!State.branches.some(b=>b.id===branchId)){Toast.error('Branch ID not found.');return;}u.name=name.trim();u.role=role;u.branchId=branchId;persist();this.render();},
  toggleStaff(uid){const u=State.staffUsers.find(x=>x.id===uid);if(!u)return;u.active=u.active===false;persist();this.render();},
  currentBranch(){return active();}
 };window.BranchAccess=A;return A;
});})();
