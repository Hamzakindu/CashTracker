import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = p => readFileSync(new URL(p, import.meta.url), 'utf8');

test('report summary includes selected-period sales and purchase piece totals', () => {
  const source = read('../app/src/main/assets/js/modules/reports.js');
  assert.match(source, /Total Sales Pieces:/);
  assert.match(source, /Total Purchase Pieces:/);
  assert.match(source, /const totalSalesPieces = .*piecesCount/);
  assert.match(source, /const totalPurchasePieces = .*piecesCount/);
});

test('CSV export awaits the save result and never reports unverified browser requests as saved', () => {
  const source = read('../app/src/main/assets/js/modules/reports.js');
  assert.match(source, /async exportCSV\(\)/);
  assert.match(source, /await Helpers\.downloadFile\(csv/);
  assert.match(source, /if \(result\.confirmed\) Toast\.success/);
  assert.match(source, /CSV export failed/);
  assert.match(source, /salesMetrics\.reduce\(\(n,m\)=>n\+this\.piecesCount\(m\.items\)/);
  assert.match(source, /purchaseMetrics\.reduce\(\(n,m\)=>n\+this\.piecesCount\(m\.items\)/);
});

test('local safety backup uses IndexedDB and does not write the full dataset to Local Storage', () => {
  const source = read('../app/src/main/assets/js/backup.js');
  const block = source.slice(source.indexOf('async manualBackup()'), source.indexOf('// Export backup as downloadable JSON file'));
  assert.match(block, /await StorageIDB\.put\(key, data\)/);
  assert.match(block, /await StorageIDB\.get\(key\)/);
  assert.match(block, /await StorageIDB\.flush\(\)/);
  assert.doesNotMatch(block, /localStorage\.setItem/);
  assert.match(block, /Local safety backup verification failed/);
});

test('CSV export writes selected transaction pieces and an aggregate total row', async () => {
  const vm = await import('node:vm');
  const source = read('../app/src/main/assets/js/modules/reports.js');
  let factory;
  let saved;
  const context = {
    console,
    window: { registerModule: (_name, fn) => { factory = fn; } },
    State: {
      cashAccounts: [],
      reportData: {
        sales: [{ id:'s1', date:'2026-11-20', customer:'Buyer', items:[], total:99 }],
        salesMetrics: [{ sale:{id:'s1',date:'2026-11-20',customer:'Buyer'}, items:[{productName:'Sock',quantity:2}], amount:20, profit:5 }],
        purchases: [{ id:'p1', date:'2026-11-19', supplier:'Vendor', items:[], total:50, paid:30 }],
        purchaseMetrics: [{ purchase:{id:'p1',date:'2026-11-19',supplier:'Vendor'}, items:[{productName:'Tight',quantity:7}], amount:35, paid:20 }],
        directExpenses: [], payments: [], receivedPayments: []
      }
    },
    Money: { add: (a,b) => a+b },
    Helpers: { downloadFile: async (content, filename) => { saved={content,filename}; return {ok:true,confirmed:true,message:'Downloads/file verified'}; } },
    Toast: { warning(){}, success(){}, info(){}, error(){} }
  };
  vm.runInNewContext(source, context);
  const reports = factory();
  const result = await reports.exportCSV();
  assert.equal(result.confirmed, true);
  assert.match(saved.content, /"Sale"/);
  assert.match(saved.content, /"2"/);
  assert.match(saved.content, /"TOTAL","","","","2","20","5"/);
  assert.match(saved.content, /"Purchase"/);
  assert.match(saved.content, /"TOTAL","","","","7","35","20"/);
});
