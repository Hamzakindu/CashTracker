import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const source = readFileSync(new URL('../app/src/main/assets/js/utils/storage.js', import.meta.url), 'utf8');
function harness({ fail = false } = {}) {
  const data = new Map([['currentProfileId', 'shop-a'], ['SMDB_shop-a_products', '[{"id":"legacy"}]']]);
  const batches = [];
  const cache = new Map();
  const localStorage = {
    getItem: k => data.has(k) ? data.get(k) : null,
    setItem(k, v) { data.set(k, String(v)); },
    removeItem: k => data.delete(k),
    get length() { return data.size; },
    key(i) { return [...data.keys()][i] ?? null; }
  };
  const window = { Money: null, StorageIDB: {
    cache,
    putMany: async entries => { if (fail) throw new Error('simulated IndexedDB failure'); batches.push(entries); entries.forEach(x => cache.set(x.key, x.value)); return true; },
    checkAndWarn: async () => true,
    flush: async () => ({ ok: !fail, error: fail ? 'simulated IndexedDB failure' : null })
  } };
  vm.runInNewContext(source, { window, localStorage, console, Toast: null, JSON, Date, Object, String, Error });
  return { Storage: window.Storage, data, batches, cache };
}

test('multi-store save queues one IndexedDB transaction and does not write business data to Local Storage', async () => {
  const { Storage, data, batches } = harness();
  assert.equal(Storage.saveBatch({ products: [{ id: 'p1' }], sales: [{ id: 's1' }] }), true);
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(batches.length, 1);
  assert.deepEqual(batches[0].map(x => x.key), ['SMDB_shop-a_products', 'SMDB_shop-a_sales']);
  assert.equal(data.get('SMDB_shop-a_products'), '[{"id":"legacy"}]');
  assert.equal(data.has('SMDB_shop-a_sales'), false);
});

test('large sales payloads are not rejected by the old Local Storage 4 MB ceiling', async () => {
  const { Storage, batches } = harness();
  const large = 'x'.repeat(4 * 1024 * 1024 + 1);
  assert.equal(Storage.saveBatch({ sales: [{ id: 'large', note: large }] }), true);
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(batches.length, 1);
  assert.ok(batches[0][0].value[0].note.length > 4 *  1024 * 1024);
});

test('business data remains untouched in Local Storage when IndexedDB reports a failure', async () => {
  const { Storage, data } = harness({ fail: true });
  assert.equal(Storage.saveBatch({ sales: [{ id: 's1' }] }), true);
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(data.get('SMDB_shop-a_products'), '[{"id":"legacy"}]');
  assert.equal(data.has('SMDB_shop-a_sales'), false);
});
