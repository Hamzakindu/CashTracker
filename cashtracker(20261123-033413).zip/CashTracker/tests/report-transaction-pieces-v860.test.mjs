import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const reports = fs.readFileSync(new URL('../app/src/main/assets/js/modules/reports.js', import.meta.url), 'utf8');

test('sales and purchase reports show piece count per transaction and in totals', () => {
  assert.match(reports, /piecesCount\(items\)/);
  assert.match(reports, /<th>Pieces<\/th>/);
  assert.match(reports, /this\.piecesCount\(m\.items\)/);
  assert.match(reports, /const totalPieces = salesMetrics\.reduce/);
  assert.match(reports, /const totalPieces = purchaseMetrics\.reduce/);
});

test('sales and purchase CSV exports include transaction piece counts', () => {
  assert.match(reports, /Type,Date,Customer,Items,Pieces,Total,Profit/);
  assert.match(reports, /Type,Date,Supplier,Items,Pieces,Total,Paid/);
});
