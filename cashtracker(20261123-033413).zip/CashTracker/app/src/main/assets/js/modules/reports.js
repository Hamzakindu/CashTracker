// ============================================
// REPORTS MODULE - WITH CLICKABLE TRANSACTIONS
// ============================================

(function() {
    'use strict';
    
    const MODULE_NAME = 'Reports';
    
    console.log('📦 Registering ' + MODULE_NAME + '...');
    
    window.registerModule(MODULE_NAME, function() {
        console.log('✅ ' + MODULE_NAME + ' initializing...');
        
        const Reports = {
            // Shared report calculations: totals follow the visible transaction lines and active filters.
            number(value) { const n = Number(value); return Number.isFinite(n) ? n : 0; },
            piecesCount(items) { return (items || []).reduce((sum, item) => sum + Math.max(0, this.number(item.quantity)), 0); },
            selectedProductIds(kind) {
                const checkboxId = kind === 'sales' ? 'filterSalesByProduct' : 'filterPurchasesByProduct';
                const className = kind === 'sales' ? 'sales-product-filter' : 'purchases-product-filter';
                if (!document.getElementById(checkboxId)?.checked) return [];
                return this.getCheckedValues(className);
            },
            saleMetrics(sale, selectedProducts = []) {
                const allItems = sale.items || [];
                const items = allItems.filter(i => !selectedProducts.length || selectedProducts.includes(i.productId));
                const amount = items.reduce((sum, i) => Money.add(sum, this.number(i.amount ?? Money.mul(this.number(i.price), this.number(i.quantity)))), 0);
                const fullSale = items.length === allItems.length;
                let cost = 0;
                let costKnown = false;
                if (fullSale && typeof BusinessEngine !== 'undefined' && BusinessEngine.saleCost) {
                    const projectedCost = BusinessEngine.saleCost(sale);
                    if (projectedCost !== null) { cost = projectedCost; costKnown = true; }
                } else if (items.length) {
                    const costs = items.map(i => typeof BusinessEngine !== 'undefined' && BusinessEngine.itemCost
                        ? BusinessEngine.itemCost(i)
                        : (i.costAmount != null ? this.number(i.costAmount) : (i.costPriceAtSale != null ? this.number(i.costPriceAtSale) * this.number(i.quantity) : (i.cost != null ? this.number(i.cost) * this.number(i.quantity) : null))));
                    costKnown = costs.every(x => x !== null);
                    if (costKnown) cost = costs.reduce((sum, x) => sum + x, 0);
                }
                const profit = costKnown ? Money.sub(amount, cost) : null;
                return { items, amount, cost, profit, costKnown };
            },
            purchaseMetrics(purchase, selectedProducts = []) {
                const items = (purchase.items || []).filter(i => !selectedProducts.length || selectedProducts.includes(i.productId));
                const amount = items.reduce((sum, i) => Money.add(sum, this.number(i.amount ?? Money.mul(this.number(i.cost ?? i.price), this.number(i.quantity)))), 0);
                const fullAmount = this.number(purchase.total);
                const fullItemsAmount = (purchase.items || []).reduce((sum, i) => Money.add(sum, this.number(i.amount ?? Money.mul(this.number(i.cost ?? i.price), this.number(i.quantity)))), 0);
                const paid = !selectedProducts.length ? this.number(purchase.paid) : (fullItemsAmount > 0 ? this.number(purchase.paid) * amount / fullItemsAmount : 0);
                return { items, amount: (!selectedProducts.length && !items.length) ? fullAmount : amount, paid };
            },
            toggleFilters() {
                const salesChecked = document.getElementById('repSales')?.checked;
                const purchasesChecked = document.getElementById('repPurchases')?.checked;
                
                const salesFilters = document.getElementById('salesFilters');
                const purchaseFilters = document.getElementById('purchaseFilters');
                
                if (salesFilters) salesFilters.style.display = salesChecked ? 'block' : 'none';
                if (purchaseFilters) purchaseFilters.style.display = purchasesChecked ? 'block' : 'none';
            },

            prepareFilters() {
                this.toggleFilters();
                
                ['filterSalesByCustomer', 'filterSalesByProduct', 'filterPurchasesBySupplier', 'filterPurchasesByProduct'].forEach(id => {
                    const el = document.getElementById(id);
                    if (el) el.checked = false;
                });
                
                ['salesCustomerFilter', 'salesProductFilter', 'purchaseSupplierFilter', 'purchaseProductFilter'].forEach(id => {
                    const el = document.getElementById(id);
                    if (el) el.style.display = 'none';
                });
            },

            generate() {
                const from = document.getElementById('reportFromDate')?.value;
                const to = document.getElementById('reportToDate')?.value;

                if (!from || !to) return Toast.warning('Select date range');

                const fromEth = EthiopianDate.gregorianToEthiopian(from);
                const toEth = EthiopianDate.gregorianToEthiopian(to);

                let html = `
                    <div style="background:var(--gradient);color:#fff;padding:15px;border-radius:8px;margin-bottom:15px;text-align:center;">
                        <h3>📈 ${fromEth.formattedShort} - ${toEth.formattedShort} (${fromEth.year} ዓ.ም)</h3>
                        <small>${from} to ${to}</small>
                    </div>
                `;

                const reportSort = document.getElementById('reportSortMode')?.value || 'newest';
                const sortOccurrences = arr => Helpers.sortByOccurrence(arr || [], reportSort !== 'oldest');

                State.reportData = { sales: [], purchases: [], returns: [], directExpenses: [], payments: [], receivedPayments: [] };

                // Sales report
                if (document.getElementById('repSales')?.checked) {
                    let filteredSales = sortOccurrences(State.activeSales().filter(s => s.date >= from && s.date <= to));
                    
                    if (document.getElementById('filterSalesByCustomer')?.checked) {
                        const selectedCustomers = this.getCheckedValues('customer-filter');
                        if (selectedCustomers.length) {
                            filteredSales = filteredSales.filter(s => selectedCustomers.includes(s.customerId));
                        }
                    }
                    
                    if (document.getElementById('filterSalesByProduct')?.checked) {
                        const selectedProducts = this.getCheckedValues('sales-product-filter');
                        if (selectedProducts.length) {
                            filteredSales = filteredSales.filter(s => 
                                (s.items || []).some(i => selectedProducts.includes(i.productId))
                            );
                        }
                    }

                    const selectedSalesProducts = this.selectedProductIds('sales');
                    const salesMetrics = filteredSales.map(s => ({ sale: s, ...this.saleMetrics(s, selectedSalesProducts) }));
                    State.reportData.sales = filteredSales;
                    State.reportData.salesMetrics = salesMetrics;
                    const total = salesMetrics.reduce((sum, x) => Money.add(sum, x.amount), 0);
                    const totalPieces = salesMetrics.reduce((sum, x) => sum + this.piecesCount(x.items), 0);
                    const knownProfit = salesMetrics.filter(x => x.profit != null).reduce((sum, x) => Money.add(sum, x.profit), 0);
                    const unknownProfitCount = salesMetrics.filter(x => x.profit == null).length;
                    const profitLabel = unknownProfitCount ? `${Helpers.formatCurrency(knownProfit)} + ${unknownProfitCount} transaction(s) with unavailable cost` : Helpers.formatCurrency(knownProfit);

                    html += `<h4>💰 Sales (${filteredSales.length}) - Pieces: ${totalPieces} - Total: ${Helpers.formatCurrency(total)} - Profit: ${profitLabel}</h4>`;
                    
                    if (filteredSales.length) {
                        html += `
                            <table class="transaction-table">
                                <thead><tr><th>Date</th><th>Customer</th><th>Items</th><th>Pieces</th><th>Total</th><th>Profit</th></tr></thead>
                                <tbody>
                                    ${salesMetrics.map(m => { const s=m.sale; return `
                                        <tr data-cashtracker-onclick=" showDetail('sale', '${s.id}')" style="cursor:pointer;">
                                            <td>${Helpers.formatDate(s.date)}</td>
                                            <td data-cashtracker-onclick="event.stopPropagation(); showDetail('customer', '${s.customerId || ''}')" style="cursor:pointer;color:var(--primary);">${Helpers.esc(s.customer || 'Walk-in')}</td>
                                            <td>${m.items.map(i => `<span data-cashtracker-onclick="event.stopPropagation(); showDetail('product', '${i.productId}')" style="cursor:pointer;color:var(--primary);">${Helpers.esc(i.productName)}</span> x${i.quantity}`).join(', ')}</td>
                                            <td><b>${this.piecesCount(m.items)}</b></td>
                                            <td>${Helpers.formatCurrency(m.amount)}</td>
                                            <td>${m.profit == null ? 'Cost unavailable' : Helpers.formatCurrency(m.profit)}</td>
                                        </tr>
                                    `; }).join('')}
                                </tbody>
                            </table>
                        `;
                    } else {
                        html += '<div class="empty-state">No sales in this period</div>';
                    }

                    // V5: separate the same product when it was sold at different prices.
                    if (document.getElementById('repSalesByPrice')?.checked) {
                        const groups = new Map();
                        filteredSales.forEach(sale => {
                            (sale.items || []).filter(item => !selectedSalesProducts.length || selectedSalesProducts.includes(item.productId)).forEach(item => {
                                const price = Number(item.price || 0);
                                const productId = item.productId || item.productName || 'unknown';
                                // Price is deliberately part of the key so one product can appear
                                // as multiple rows when sold at different unit prices.
                                const key = productId + '::' + price.toFixed(2);
                                if (!groups.has(key)) {
                                    groups.set(key, {
                                        productId,
                                        productName: item.productName || 'Unknown',
                                        price,
                                        quantity: 0,
                                        amount: 0,
                                        profit: 0,
                                        costUnavailable: 0,
                                        transactions: 0
                                    });
                                }
                                const g = groups.get(key);
                                const qty = Number(item.quantity || 0);
                                g.quantity += qty;
                                g.amount = Money.add(g.amount, Number(item.amount ?? Money.mul(price, qty)));
                                // Item-level profit is used when available; otherwise derive it
                                // from the item's buy/cost fields when present.
                                if (item.profit != null) g.profit += Number(item.profit || 0);
                                else if (item.costAmount != null) g.profit = Money.add(g.profit, Money.sub(Number(item.amount ?? Money.mul(price, qty)), Number(item.costAmount || 0)));
                                else if (item.costPriceAtSale != null) g.profit = Money.add(g.profit, Money.sub(Number(item.amount ?? Money.mul(price, qty)), Money.mul(Number(item.costPriceAtSale || 0), qty)));
                                else g.costUnavailable += 1;
                                g.transactions += 1;
                            });
                        });

                        const grouped = Array.from(groups.values()).sort((a,b) =>
                            a.productName.localeCompare(b.productName) || a.price - b.price
                        );
                        const groupedTotal = grouped.reduce((sum, g) => Money.add(sum, g.amount), 0);
                        const groupedProfit = grouped.reduce((sum, g) => Money.add(sum, g.profit), 0);

                        html += `<h4>🏷️ Sales by Product &amp; Selling Price (${grouped.length}) - Total: ${Helpers.formatCurrency(groupedTotal)} - Profit: ${Helpers.formatCurrency(groupedProfit)}</h4>`;
                        html += grouped.length ? `
                            <div style="overflow-x:auto;">
                            <table class="transaction-table">
                                <thead><tr><th>Product</th><th>Unit Selling Price</th><th>Quantity Sold</th><th>Sales Amount</th><th>Profit</th><th>Transactions</th></tr></thead>
                                <tbody>
                                    ${grouped.map(g => `
                                        <tr>
                                            <td style="color:var(--primary);">${Helpers.esc(g.productName)}</td>
                                            <td>${Helpers.formatCurrency(g.price)}</td>
                                            <td>${g.quantity}</td>
                                            <td>${Helpers.formatCurrency(g.amount)}</td>
                                            <td>${g.costUnavailable ? Helpers.formatCurrency(g.profit) + ' (partial)' : Helpers.formatCurrency(g.profit)}</td>
                                            <td>${g.transactions}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                            </div>
                            <small style="display:block;margin-top:6px;opacity:.75;">The same product is intentionally shown on separate rows for each unit selling price. Profit may be partial when legacy items have no saved cost.</small>
                        ` : '<div class="empty-state">No sold products in this period</div>';

                        State.reportData.salesByPrice = grouped;
                    } else {
                        State.reportData.salesByPrice = [];
                    }
                }

                // Purchases report
                if (document.getElementById('repPurchases')?.checked) {
                    let filteredPurchases = sortOccurrences(State.purchases.filter(p => p.status !== 'void' && !p.voided && p.date >= from && p.date <= to));
                    
                    if (document.getElementById('filterPurchasesBySupplier')?.checked) {
                        const selectedSuppliers = this.getCheckedValues('supplier-filter');
                        if (selectedSuppliers.length) {
                            filteredPurchases = filteredPurchases.filter(p => selectedSuppliers.includes(p.supplierId));
                        }
                    }
                    
                    if (document.getElementById('filterPurchasesByProduct')?.checked) {
                        const selectedProducts = this.getCheckedValues('purchases-product-filter');
                        if (selectedProducts.length) {
                            filteredPurchases = filteredPurchases.filter(p => 
                                (p.items || []).some(i => selectedProducts.includes(i.productId))
                            );
                        }
                    }

                    const selectedPurchaseProducts = this.selectedProductIds('purchases');
                    const purchaseMetrics = filteredPurchases.map(p => ({ purchase: p, ...this.purchaseMetrics(p, selectedPurchaseProducts) }));
                    State.reportData.purchases = filteredPurchases;
                    State.reportData.purchaseMetrics = purchaseMetrics;
                    const total = purchaseMetrics.reduce((sum, x) => Money.add(sum, x.amount), 0);
                    const totalPieces = purchaseMetrics.reduce((sum, x) => sum + this.piecesCount(x.items), 0);
                    const paid = purchaseMetrics.reduce((sum, x) => Money.add(sum, x.paid), 0);

                    html += `<h4>📥 Purchases (${filteredPurchases.length}) - Pieces: ${totalPieces} - Total: ${Helpers.formatCurrency(total)} - Paid (allocated): ${Helpers.formatCurrency(paid)}</h4>`;
                    
                    if (filteredPurchases.length) {
                        html += `
                            <table class="transaction-table">
                                <thead><tr><th>Date</th><th>Supplier</th><th>Items</th><th>Pieces</th><th>Total</th><th>Paid</th></tr></thead>
                                <tbody>
                                    ${purchaseMetrics.map(m => { const p=m.purchase; return `
                                        <tr data-cashtracker-onclick=" showDetail('purchase', '${p.id}')" style="cursor:pointer;">
                                            <td>${Helpers.formatDate(p.date)}</td>
                                            <td data-cashtracker-onclick="event.stopPropagation(); showDetail('supplier', '${p.supplierId || ''}')" style="cursor:pointer;color:var(--primary);">${Helpers.esc(p.supplier || 'Unknown')}</td>
                                            <td>${m.items.map(i => `<span data-cashtracker-onclick="event.stopPropagation(); showDetail('product', '${i.productId}')" style="cursor:pointer;color:var(--primary);">${Helpers.esc(i.productName)}</span> x${i.quantity}`).join(', ')}</td>
                                            <td><b>${this.piecesCount(m.items)}</b></td>
                                            <td>${Helpers.formatCurrency(m.amount)}</td>
                                            <td>${Helpers.formatCurrency(m.paid)}</td>
                                        </tr>
                                    `; }).join('')}
                                </tbody>
                            </table>
                        `;
                    } else {
                        html += '<div class="empty-state">No purchases in this period</div>';
                    }
                }

                // Independent cash payment reports. Only standalone payment-ledger entries
                // (sourceType=payment) are included; sale/purchase settlement rows are excluded
                // to prevent counting the same cash movement again in Sales or Purchases.
                const paymentRows = (State.paymentLedger || []).filter(p =>
                    p.status !== 'void' && p.sourceType === 'payment' && p.date >= from && p.date <= to &&
                    Number(p.amountNumber ?? p.amount) > 0
                );
                const activePayments = sortOccurrences(paymentRows.filter(p => p.entityType === 'supplier'));
                const activeReceived = sortOccurrences(paymentRows.filter(p => p.entityType === 'customer'));

                if (document.getElementById('repPayments')?.checked) {
                    State.reportData.payments = activePayments;
                    const totalOut = activePayments.reduce((sum, p) => Money.add(sum, this.number(p.amountNumber ?? p.amount)), 0);
                    html += `<h4>💸 Payments — Money Out (${activePayments.length}) · Total: ${Helpers.formatCurrency(totalOut)}</h4>`;
                    html += activePayments.length ? `
                        <table class="transaction-table"><thead><tr><th>Date</th><th>Paid to</th><th>Amount</th><th>Method</th><th>Account</th><th>Type</th><th>Reference / Note</th></tr></thead><tbody>
                        ${activePayments.map(p => `<tr><td>${Helpers.formatDate(p.date)}</td><td>${Helpers.esc(p.entityName || 'Supplier')}</td><td>${Helpers.formatCurrency(p.amountNumber ?? p.amount)}</td><td>${Helpers.esc(p.method || '')}</td><td>${Helpers.esc((State.cashAccounts || []).find(a => a.id === p.accountId)?.name || '')}</td><td>${Helpers.esc(p.kind || '')}</td><td>${Helpers.esc(p.reference || '')}</td></tr>`).join('')}
                        </tbody></table>` : '<div class="empty-state">No standalone payments in this period</div>';
                }

                if (document.getElementById('repReceivedPayments')?.checked) {
                    State.reportData.receivedPayments = activeReceived;
                    const totalIn = activeReceived.reduce((sum, p) => Money.add(sum, this.number(p.amountNumber ?? p.amount)), 0);
                    html += `<h4>💰 Received Payments — Money In (${activeReceived.length}) · Total: ${Helpers.formatCurrency(totalIn)}</h4>`;
                    html += activeReceived.length ? `
                        <table class="transaction-table"><thead><tr><th>Date</th><th>Received from</th><th>Amount</th><th>Method</th><th>Account</th><th>Type</th><th>Reference / Note</th></tr></thead><tbody>
                        ${activeReceived.map(p => `<tr><td>${Helpers.formatDate(p.date)}</td><td>${Helpers.esc(p.entityName || 'Customer')}</td><td>${Helpers.formatCurrency(p.amountNumber ?? p.amount)}</td><td>${Helpers.esc(p.method || '')}</td><td>${Helpers.esc((State.cashAccounts || []).find(a => a.id === p.accountId)?.name || '')}</td><td>${Helpers.esc(p.kind || '')}</td><td>${Helpers.esc(p.reference || '')}</td></tr>`).join('')}
                        </tbody></table>` : '<div class="empty-state">No standalone received payments in this period</div>';
                }

                // Returns report
                if (document.getElementById('repReturns')?.checked) {
                    const filteredReturns = sortOccurrences(State.returns.filter(r => r.date >= from && r.date <= to));
                    State.reportData.returns = filteredReturns;
                    const totalRefund = filteredReturns.reduce((sum, r) => Money.add(sum, (r.totalRefund || 0)), 0);

                    html += `<h4>↩️ Returns (${filteredReturns.length}) - Total Refund: ${Helpers.formatCurrency(totalRefund)}</h4>`;
                    
                    if (filteredReturns.length) {
                        html += `
                            <table class="transaction-table">
                                <thead><tr><th>Date</th><th>Product</th><th>Qty</th><th>Refund</th></tr></thead>
                                <tbody>
                                    ${filteredReturns.map(r => `
                                        <tr data-cashtracker-onclick=" showDetail('return', '${r.id}')" style="cursor:pointer;">
                                            <td>${Helpers.formatDate(r.date)}</td>
                                            <td data-cashtracker-onclick="event.stopPropagation(); showDetail('product', '${r.productId}')" style="cursor:pointer;color:var(--primary);">${Helpers.esc(r.productName)}</td>
                                            <td>${r.quantity}</td>
                                            <td>${Helpers.formatCurrency(r.totalRefund || 0)}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        `;
                    } else {
                        html += '<div class="empty-state">No returns in this period</div>';
                    }
                }

                // Expenses report
                if (document.getElementById('repExpenses')?.checked) {
                    const filteredExpenses = sortOccurrences(State.directExpenses.filter(e => e.status !== 'void' && !e.voided && e.date >= from && e.date <= to));
                    State.reportData.directExpenses = filteredExpenses;
                    const total = filteredExpenses.reduce((sum, e) => Money.add(sum, (e.amount || 0)), 0);

                    html += `<h4>💸 Expenses (${filteredExpenses.length}) - Total: ${Helpers.formatCurrency(total)}</h4>`;
                    
                    if (filteredExpenses.length) {
                        html += `
                            <table class="transaction-table">
                                <thead><tr><th>Date</th><th>Type</th><th>Amount</th><th>Reason</th></tr></thead>
                                <tbody>
                                    ${filteredExpenses.map(e => `
                                        <tr>
                                            <td>${Helpers.formatDate(e.date)}</td>
                                            <td>${Helpers.esc(e.typeName)}</td>
                                            <td>${Helpers.formatCurrency(e.amount)}</td>
                                            <td>${Helpers.esc(e.reason || '')}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        `;
                    } else {
                        html += '<div class="empty-state">No expenses in this period</div>';
                    }
                }

                // Summary section
                if (State.reportData.sales.length || State.reportData.purchases.length || 
                    State.reportData.returns.length || State.reportData.directExpenses.length) {
                    
                    const totalSales = (State.reportData.salesMetrics || State.reportData.sales.map(s => ({amount:this.number(s.total),profit:s.profit==null?null:this.number(s.profit)}))).reduce((sum, m) => Money.add(sum, this.number(m.amount)), 0);
                    const profitRows = State.reportData.salesMetrics || State.reportData.sales.map(s => ({profit:s.profit==null?null:this.number(s.profit)}));
                    const totalProfit = profitRows.filter(m => m.profit != null).reduce((sum, m) => Money.add(sum, this.number(m.profit)), 0);
                    const unknownCostCount = profitRows.filter(m => m.profit == null).length;
                    const totalPurchases = (State.reportData.purchaseMetrics || State.reportData.purchases.map(p => ({amount:this.number(p.total)}))).reduce((sum, m) => Money.add(sum, this.number(m.amount)), 0);
                    const totalReturns = State.reportData.returns.reduce((sum, r) => Money.add(sum, (r.totalRefund || 0)), 0);
                    const totalExpenses = State.reportData.directExpenses.reduce((sum, e) => Money.add(sum, (e.amount || 0)), 0);
                    const netIncome = totalProfit - totalExpenses;

                    html += `
                        <div class="detail-section" style="margin-top:15px;background:var(--gradient);color:#fff;">
                            <h4 style="color:#fff;">📊 Summary</h4>
                            <div class="detail-row"><span class="detail-label" style="color:#e0e0e0;">Total Sales:</span><span class="detail-value" style="color:#fff;">${Helpers.formatCurrency(totalSales)}</span></div>
                            <div class="detail-row"><span class="detail-label" style="color:#e0e0e0;">Known Profit${unknownCostCount ? ` (${unknownCostCount} transaction(s) missing cost)` : ''}:</span><span class="detail-value" style="color:#fff;">${Helpers.formatCurrency(totalProfit)}</span></div>
                            <div class="detail-row"><span class="detail-label" style="color:#e0e0e0;">Total Purchases:</span><span class="detail-value" style="color:#fff;">${Helpers.formatCurrency(totalPurchases)}</span></div>
                            <div class="detail-row"><span class="detail-label" style="color:#e0e0e0;">Total Returns:</span><span class="detail-value" style="color:#fff;">${Helpers.formatCurrency(totalReturns)}</span></div>
                            ${totalReturns > 0 ? '<div class="detail-row"><span class="detail-label" style="color:#ffe082;">Note:</span><span class="detail-value" style="color:#ffe082;">Return records are not fully linked to original sale cost/profit; net income excludes return adjustment.</span></div>' : ''}
                            <div class="detail-row"><span class="detail-label" style="color:#e0e0e0;">Total Expenses:</span><span class="detail-value" style="color:#fff;">${Helpers.formatCurrency(totalExpenses)}</span></div>
                            <div class="detail-row" style="font-weight:800;font-size:1.1rem;">
                                <span class="detail-label" style="color:#e0e0e0;">${totalReturns > 0 ? 'Net Income (before unlinked returns):' : 'Net Income:'}</span>
                                <span class="detail-value" style="color:#fff;">${Helpers.formatCurrency(netIncome)}</span>
                            </div>
                        </div>
                    `;
                }

                // Customers list
                if (document.getElementById('repCustomers')?.checked) {
                    html += `
                        <h4>👤 Customers</h4>
                        <table class="transaction-table">
                            <thead><tr><th>Name</th><th>Phone</th><th>Balance</th></tr></thead>
                            <tbody>
                                ${Helpers.getPartySort(State.customers || [], 'customer', 'name').map(c => `
                                    <tr data-cashtracker-onclick=" showDetail('customer', '${c.id}')" style="cursor:pointer;">
                                        <td style="color:var(--primary);">${Helpers.esc(c.name)}</td>
                                        <td>${Helpers.esc(c.contact || '')}</td>
                                        <td>${Helpers.formatCurrency(c.balance || 0)}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    `;
                }

                // Suppliers list
                if (document.getElementById('repSuppliers')?.checked) {
                    html += `
                        <h4>🏢 Suppliers</h4>
                        <table class="transaction-table">
                            <thead><tr><th>Name</th><th>Phone</th><th>Balance</th></tr></thead>
                            <tbody>
                                ${Helpers.getPartySort(State.suppliers || [], 'supplier', 'name').map(s => `
                                    <tr data-cashtracker-onclick=" showDetail('supplier', '${s.id}')" style="cursor:pointer;">
                                        <td style="color:var(--primary);">${Helpers.esc(s.name)}</td>
                                        <td>${Helpers.esc(s.contact || '')}</td>
                                        <td>${Helpers.formatCurrency(s.balance || 0)}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    `;
                }

                // Products list
                if (document.getElementById('repProducts')?.checked) {
                    html += `
                        <h4>📦 Products</h4>
                        <table class="transaction-table">
                            <thead><tr><th>Name</th><th>Category</th><th>Buy</th><th>Sell</th><th>Stock</th></tr></thead>
                            <tbody>
                                ${State.products.filter(p=>!p.archived).map(p => `
                                    <tr data-cashtracker-onclick=" showDetail('product', '${p.id}')" style="cursor:pointer;">
                                        <td style="color:var(--primary);">${Helpers.esc(p.name)}</td>
                                        <td>${Helpers.esc(p.category || '')}</td>
                                        <td>${Helpers.formatCurrency(p.buy || 0)}</td>
                                        <td>${Helpers.formatCurrency(p.sell || 0)}</td>
                                        <td>${p.stock || 0}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    `;
                }

                document.getElementById('reportOutput').innerHTML = html || '<div class="empty-state">No data to display</div>';
                EthiopianDate.updateDisplay(from, to);
            },

            getCheckedValues(className) {
                return Array.from(document.querySelectorAll(`.${className}:checked`)).map(cb => cb.value);
            },

            exportCSV() {
                if (!State.reportData) return Toast.warning('Generate report first');

                let csv = '';

                if (State.reportData.sales && State.reportData.sales.length) {
                    csv += 'Type,Date,Customer,Items,Pieces,Total,Profit\n';
                    State.reportData.sales.forEach(s => {
                        const items = (s.items || []).map(i => i.productName + ' x' + i.quantity).join('; ');
                        const pieces = (s.items || []).reduce((sum, i) => sum + Math.max(0, Number(i.quantity) || 0), 0);
                        csv += `Sale,${s.date},"${s.customer || ''}","${items}",${pieces},${s.total},${s.profit || 0}\n`;
                    });
                }

                if (State.reportData.salesByPrice && State.reportData.salesByPrice.length) {
                    if (csv) csv += '\n';
                    csv += 'Type,Product,Unit Selling Price,Quantity Sold,Sales Amount,Profit,Transactions\n';
                    State.reportData.salesByPrice.forEach(g => {
                        csv += `SaleByPrice,"${String(g.productName || '').replace(/"/g, '""')}",${g.price},${g.quantity},${g.amount},${g.profit},${g.transactions}\n`;
                    });
                }

                if (State.reportData.purchases && State.reportData.purchases.length) {
                    if (csv) csv += '\n';
                    csv += 'Type,Date,Supplier,Items,Pieces,Total,Paid\n';
                    State.reportData.purchases.forEach(p => {
                        const items = (p.items || []).map(i => i.productName + ' x' + i.quantity).join('; ');
                        const pieces = (p.items || []).reduce((sum, i) => sum + Math.max(0, Number(i.quantity) || 0), 0);
                        csv += `Purchase,${p.date},"${p.supplier || ''}","${items}",${pieces},${p.total},${p.paid || 0}\n`;
                    });
                }

                if (State.reportData.directExpenses && State.reportData.directExpenses.length) {
                    if (csv) csv += '\n';
                    csv += 'Type,Date,Expense Type,Amount,Reason\n';
                    State.reportData.directExpenses.forEach(e => {
                        csv += `Expense,${e.date},"${e.typeName}",${e.amount},"${e.reason || ''}"\n`;
                    });
                }

                if (State.reportData.payments?.length) {
                    if (csv) csv += '\n';
                    csv += 'Type,Date,Paid To,Amount,Method,Account,Kind,Reference\n';
                    State.reportData.payments.forEach(p => { const account=(State.cashAccounts||[]).find(a=>a.id===p.accountId)?.name||''; csv += `Payment,${p.date},"${String(p.entityName||'').replace(/"/g,'""')}",${p.amountNumber??p.amount},"${String(p.method||'').replace(/"/g,'""')}","${String(account).replace(/"/g,'""')}",${p.kind||''},"${String(p.reference||'').replace(/"/g,'""')}"\n`; });
                }
                if (State.reportData.receivedPayments?.length) {
                    if (csv) csv += '\n';
                    csv += 'Type,Date,Received From,Amount,Method,Account,Kind,Reference\n';
                    State.reportData.receivedPayments.forEach(p => { const account=(State.cashAccounts||[]).find(a=>a.id===p.accountId)?.name||''; csv += `Received Payment,${p.date},"${String(p.entityName||'').replace(/"/g,'""')}",${p.amountNumber??p.amount},"${String(p.method||'').replace(/"/g,'""')}","${String(account).replace(/"/g,'""')}",${p.kind||''},"${String(p.reference||'').replace(/"/g,'""')}"\n`; });
                }

                if (csv) {
                    Helpers.downloadFile(csv, 'report.csv');
                    Toast.success('Report exported');
                } else {
                    Toast.warning('No data to export');
                }
            },

            generateDailyFull() {
                const now = new Date();
                const hour = now.getHours();
                let date;

                if (hour < 18) {
                    const yesterday = new Date(now);
                    yesterday.setDate(yesterday.getDate() - 1);
                    date = yesterday.toISOString().slice(0, 10);
                } else {
                    date = now.toISOString().slice(0, 10);
                }

                const input = prompt(`📊 Report Date (YYYY-MM-DD):\n(Default: ${date})`, date);
                if (!input || !/^\d{4}-\d{2}-\d{2}$/.test(input)) {
                    return Toast.warning('Invalid date format');
                }

                const ethDate = EthiopianDate.gregorianToEthiopian(input);
                if (!confirm(`Generate report for ${ethDate.formattedShort}?`)) return;

                document.getElementById('reportFromDate').value = input;
                document.getElementById('reportToDate').value = input;

                ['repSales', 'repSalesByPrice', 'repPurchases', 'repExpenses', 'repPayments', 'repReceivedPayments', 'repCustomers', 'repSuppliers', 'repProducts'].forEach(id => {
                    const el = document.getElementById(id);
                    if (el) el.checked = true;
                });

                this.generate();
                EthiopianDate.updateDisplay(input, input);
                Tabs.switchTo('reports');

                const dailySales = State.activeSales().filter(s => s.date === input);
                const total = dailySales.reduce((sum, s) => Money.add(sum, this.number(s.total)), 0);
                const profit = dailySales.filter(s => s.profit != null).reduce((sum, s) => Money.add(sum, this.number(s.profit)), 0);
                const expenses = State.directExpenses.filter(e => e.status !== 'void' && !e.voided && e.date === input).reduce((sum, e) => Money.add(sum, (e.amount || 0)), 0);
                const net = profit - expenses;

                const report = {
                    id: 'dr_' + input,
                    date: input,
                    ethDate: ethDate.formattedShort,
                    totalSales: total,
                    totalProfit: profit,
                    totalExpenses: expenses,
                    netIncome: net
                };

                Storage.setSetting('dr_' + input, JSON.stringify(report));
                Storage.setSetting('ldr', input);

                Toast.success(
                    `📊 Report Ready!\nSales: ${Helpers.formatCurrency(total)}\nProfit: ${Helpers.formatCurrency(profit)}\nExpenses: ${Helpers.formatCurrency(expenses)}\nNet: ${Helpers.formatCurrency(net)}`,
                    5000
                );

                setTimeout(() => {
                    let csv = `Date,${input}\nEthiopian,${ethDate.formattedShort}\nSales,${Helpers.formatCurrency(total)}\nProfit,${Helpers.formatCurrency(profit)}\nExpenses,${Helpers.formatCurrency(expenses)}\nNet,${Helpers.formatCurrency(net)}`;
                    Helpers.downloadFile(csv, `report-${input}.csv`);
                }, 1000);
            }
        };
        
        window.Reports = Reports;
        console.log('✅ ' + MODULE_NAME + ' loaded successfully');
        return Reports;
    });
    
})();
