# V8.56 startup recovery hardening

Release: 5.10.99 / Android versionCode 5123.

- State initialization no longer creates default/sample data after an initialization failure. It propagates the error so existing records are not silently replaced.
- App startup now displays the actual initialization error in the dashboard area with a retry action, instead of leaving only navigation ribbons above a blank screen.
- Android encrypted-backup MediaStore save and read-back verification from the previous source are retained.
- Sale branch ID correction from the previous source is retained.

Validation performed in this environment: all JavaScript files pass `node --check`; ZIP integrity is checked after packaging. Android APK compilation and on-device WebView testing still need to run in GitHub Actions and on the target phone.
