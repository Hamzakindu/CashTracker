# CashTracker V8.57 — Unlimited Audit Retention

- Removed the 5,000-row truncation from AccountingLedger.audit() and Security.audit().
- Audit health now reports an unlimited logical retention policy.
- Financial derivation keeps the conservative legacy warning only when the log has exactly 5,000 entries, because older versions may have truncated it at that exact size. Logs larger than 5,000 are no longer flagged solely due to their size.
- No existing records are deliberately deleted by this patch.

## Important storage limitation

This removes the application-level 5,000-entry cap; it does not create infinite physical storage. The current storage layer still commits to WebView localStorage first and mirrors to IndexedDB asynchronously. Device quota can therefore still cause a save failure, especially with a large audit log. A separate, tested migration to IndexedDB-primary asynchronous persistence is required to eliminate that architectural limit safely. Do not clear app data to address quota errors.
