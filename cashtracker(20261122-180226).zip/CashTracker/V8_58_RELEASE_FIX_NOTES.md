# CashTracker V8.58 release metadata fix

## Root cause of the failed GitHub Actions run

Two automated tests still expected release metadata `5.10.99` / version code `5123`, while `gradle.properties` had already been advanced to `5.10.100` / `5124`. The stale test expectations caused 2 of 306 tests to fail before the Android APK build.

## Changes

- Aligned package, Android Gradle defaults, appmint metadata, PWA manifest, and runtime config to version `5.10.100` and version code `5124`.
- Updated the two release metadata tests to validate the current release values.
- Kept the workflow's minimum accepted prior version-code baseline at `5123`.
- Updated GitHub Actions checkout, setup-java, and setup-node to v5 to address the Node.js 20 deprecation warnings.

## Validation

- `node --test tests/*.test.mjs`: 306 passed, 0 failed.
- ZIP integrity checked after packaging.
- This is source/test validation only; an APK build and installed-device test must still be confirmed by GitHub Actions and the device.

No user business records or app database are modified by these source changes.
