# CashTracker V8.37 — Persistent Financial Posting Ledger

Release: 5.10.81 / Android versionCode 81

## Objective
Add a durable, append-only double-entry posting layer without changing existing business-store schemas or rewriting V8.36 source transactions.

## Architecture and compatibility
- Reuses the existing `accountingMeta` store. The new ledger is stored as additive metadata fields (`postingLedger`, `postingLedgerEnabled`, version and capture timestamps); no new business store or Cloudflare D1 table is required.
- Existing sales, purchases, customers, suppliers, payment ledger, expenses, returns, cash accounts, money movements and inventory records retain their current formats and identifiers.
- Existing V8.36 derived-journal reporting remains the default until the owner explicitly initializes the persistent posting ledger from the accounting statements screen.
- Initialization is append-only and idempotent. It refuses to post when the current derived source journal has unbalanced groups or when existing persisted groups conflict with current source records.
- Once initialized, the shared `State.saveAll()` and individual financial-store save paths append newly-created balanced journal groups into the same `accountingMeta` save batch. This keeps source transaction and journal capture in the existing synchronous persistence boundary.
- Trial balance, profit and loss and general-ledger views use persisted posted lines after initialization; before initialization they continue using the V8.36 derived journal.
- Existing posted lines are never updated or deleted by the capture path. A source transaction that is edited, voided or removed after posting is reported as a conflict rather than silently rewritten.
- Explicit reversal appends inverse debit/credit lines with a required reason and an audit-log event. Original posted rows remain intact. Only one reversal per original group is accepted.
- Existing `accountingMeta` properties are preserved during the V5/V6 accounting metadata migration instead of replacing the metadata object.
- The V8.36 backup, restore, safety snapshot and whole-profile cloud snapshot paths already include `accountingMeta`; the ledger therefore travels with those existing backup/sync mechanisms.

## Safety boundaries
- Ledger initialization is opt-in. Installing V8.37 alone does not migrate or post historical transactions.
- The ledger does not automatically correct an unbalanced source transaction, infer a reversal, or rewrite a source record.
- A changed or voided posted source blocks further automatic capture until the discrepancy is reviewed. For a voided transaction, append a reasoned reversal; for a changed transaction, restore/reconcile its source lifecycle before reposting a corrected transaction under a new identity.
- The derived accounting mappings retain V8.36 limitations. This release does not certify tax compliance, inventory valuation, customer/supplier subledger completeness, or statutory accounts.
- The posting ledger is persisted within `accountingMeta` to preserve compatibility, but large histories may eventually approach localStorage store-size limits. Monitor store size and plan a dedicated normalized ledger store/database migration only as a separately tested future release.

## V8.37 implementation
- Added deterministic entry IDs, source-group financial fingerprints and per-entry content fingerprints.
- Added preview, explicit initialization, incremental capture, ledger audit and reasoned reversal APIs.
- Added ledger status, pending group and conflict reporting to the accounting statements screen.
- Added an explicit reversal UI for existing posted groups.
- Added ledger audit results to the unified financial integrity audit when the ledger is enabled.
- Added automatic capture hooks to normal financial State saves after explicit initialization.
- Incremented app version to 5.10.81 / versionCode 81.

## Verification
- V8.37-specific tests: 7 passed, 0 failed. They cover backward-compatible opt-in, idempotent initialization, incremental capture, source-change blocking, append-only reversals, State save integration and persisted-line tamper detection.
- Full automated suite: 251 passed, 0 failed.
- TypeScript strict typecheck: passed.
- Android TypeScript asset build: passed.
- JavaScript syntax checks: 94 files passed.
- JSON validation and AndroidManifest XML validation: passed.
- Full test suite, TypeScript checks, Android asset build, syntax checks, metadata validation and ZIP integrity must pass before release packaging.
- Vite production build could not run because Vite is not installed in this environment. Android Gradle APK build could not run because neither Gradle nor a Gradle wrapper is available. Physical-device transaction/restore tests, deployed Cloudflare tests and multi-device sync remain external release checks and must not be claimed as completed unless run in their target environments.
