# CashTracker V8.22 — Financial Audit Consistency

Version: 5.10.66 (Android versionCode 66)

## Changes

- FinancialAudit now treats supplier returns using the same classification as BusinessEngine.
- A supplier return reduces the supplier payable only by the non-cash portion. An explicitly recorded cash refund is excluded from the payable offset and remains a cash/bank receipt in the journal.
- Supplier returns are excluded from customer receivable offsets, even if legacy records contain a customerId field.
- Soft-deleted records (`deletedAt`) are excluded consistently by the financial audit.
- Receivables and payables aging/reminder views use BusinessEngine-derived balances when source history is complete, and retain cached balances when the projection marks a party as legacy fallback.
- Corrected stale release metadata in `gradle.properties`, `appmint.json`, `config.js`, and Android Gradle defaults. All version surfaces now identify 5.10.66 / code 66.

## Verification

- Automated Node test suite: 153 tests passing.
- TypeScript typecheck and Android TypeScript asset build: run for this release.
- JavaScript syntax and Android manifest validation: run for this release.
- ZIP integrity: checked.

## Limitations

- No Android Gradle APK build or physical-device testing was performed.
- Existing cached party balances are not automatically rewritten. Legacy fallback remains visible rather than guessed.
- Customer/supplier balance adjustments and legacy data still require review through the read-only financial audit before relying on a period close.
