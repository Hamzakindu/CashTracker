# CashTracker V8.23 — Party Aging Consistency

Version: 5.10.67 (Android versionCode 67)

## Changes
- Added one read-only BusinessEngine aging allocator shared by Receivables and Payables.
- Allocates a reconciled party balance to newest unpaid source documents, consistent with oldest-first settlement allocation.
- Keeps opening balances, adjustments, and other unmatched amounts in the 90+ bucket instead of silently dropping them.
- Uses local calendar dates for age calculation and handles invalid/future dates and zero balances safely.
- Updated release metadata and release-readiness regression assertions.

## Verification limits
Automated tests cover the pure allocator and module integration. Android Gradle compilation, WebView interaction, and physical-device aging display remain unverified.
