# V8.18 — Calculator reliability and synchronization

Version: 5.10.62 (versionCode 62)

## Changes
- Embedded and standalone calculator continue to use the same profile-scoped history key.
- Added cross-document `storage` synchronization so changes in one calculator view refresh the other without a reload.
- History writes merge by stable entry ID, sort by timestamp, and avoid duplicate entries when both views write close together.
- Restored swipe-down on the calculator display to open History and swipe-up to open Saved Operations; horizontal swipes and gestures during settings are ignored.
- Clearing history writes an explicit empty list so other views receive a storage event; the existing short-lived Undo action restores the captured entries.
- Preserved the editable share header, share confirmation, right-aligned history options menu, and existing horizontal history layout.

## Verification limits
- Automated tests check the shared-storage contract, merge path, gesture wiring, sharing confirmation, clear/undo path, and menu alignment.
- `npm test`, typecheck, Android asset build, JavaScript syntax, manifest JSON and ZIP integrity are run for this update.
- These checks do not simulate Android WebView touch dispatch, native Android share sheets, back-button behavior, or two physical phones. Those still require device testing.
