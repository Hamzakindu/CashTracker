// Android shell shim: save WebView downloads through MediaStore and report the
// actual native write result back to JavaScript. Never report success merely
// because an anchor click was dispatched.
(function () {
  'use strict';

  let nextId = 1;
  const pending = new Map();
  const blobs = new Map();
  const nativeCreate = URL.createObjectURL.bind(URL);
  const nativeRevoke = URL.revokeObjectURL.bind(URL);

  window.__cashTrackerDownloadResult = function (id, ok, message) {
    const item = pending.get(String(id));
    if (!item) return;
    clearTimeout(item.timer);
    pending.delete(String(id));
    if (ok) item.resolve({ ok: true, confirmed: true, message: String(message || 'File saved') });
    else item.reject(new Error(String(message || 'Android could not save the file')));
  };

  window.CashTrackerDownload = {
    save: function (blob, filename) {
      if (!(blob instanceof Blob)) return Promise.reject(new Error('Invalid download data'));
      if (window.Android && typeof window.Android.saveFile === 'function') {
        return new Promise(function (resolve, reject) {
          const id = String(nextId++);
          const reader = new FileReader();
          const timer = setTimeout(function () {
            pending.delete(id);
            reject(new Error('Android did not confirm the file save. Check Downloads before retrying.'));
          }, 30000);
          pending.set(id, { resolve: resolve, reject: reject, timer: timer });
          reader.onerror = function () {
            clearTimeout(timer);
            pending.delete(id);
            reject(new Error('Could not read backup data for saving'));
          };
          reader.onload = function () {
            try {
              const dataUrl = String(reader.result || '');
              const comma = dataUrl.indexOf(',');
              if (comma < 0) throw new Error('Could not encode download');
              window.Android.saveFile(String(filename || 'cashtracker-backup.json'), dataUrl.slice(comma + 1), id);
            } catch (error) {
              clearTimeout(timer);
              pending.delete(id);
              reject(error);
            }
          };
          reader.readAsDataURL(blob);
        });
      }

      // Browser downloads cannot expose a reliable filesystem confirmation.
      // The caller must describe this as a download request, not a verified save.
      return new Promise(function (resolve, reject) {
        try {
          const url = nativeCreate(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = String(filename || 'cashtracker-backup.json');
          a.style.display = 'none';
          document.body.appendChild(a);
          a.click();
          a.remove();
          setTimeout(function () { nativeRevoke(url); }, 1500);
          resolve({ ok: true, confirmed: false, message: 'Download request sent to the browser' });
        } catch (error) { reject(error); }
      });
    }
  };

  // Keep compatibility for older modules that create blob URLs and click an
  // anchor directly. This path also waits for the native callback internally.
  URL.createObjectURL = function (blob) {
    const url = nativeCreate(blob);
    blobs.set(url, blob);
    return url;
  };
  HTMLAnchorElement.prototype.click = new Proxy(HTMLAnchorElement.prototype.click, {
    apply: function (target, self, args) {
      const url = self && self.href;
      const blob = url ? blobs.get(url) : null;
      if (self && self.download && blob && window.Android && typeof window.Android.saveFile === 'function') {
        window.CashTrackerDownload.save(blob, self.download).catch(function (error) {
          console.error('Android download failed:', error);
          if (window.Toast && Toast.error) Toast.error('Download failed: ' + error.message);
        }).finally(function () { blobs.delete(url); nativeRevoke(url); });
        return;
      }
      return Reflect.apply(target, self, args);
    }
  });
  URL.revokeObjectURL = function (url) {
    if (blobs.has(url)) return;
    nativeRevoke(url);
  };
})();
