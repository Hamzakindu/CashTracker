// PAYMENTS V4 - money ledger, customer/supplier advances, payment methods
(function(){'use strict';
window.registerModule('Payments',function(){
const Payments={
 openModal(type,id){
  let m=document.getElementById('paymentModal');
  if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='paymentModal';m.innerHTML=`
  <div class="modal" style="max-width:460px"><button class="close-btn" data-cashtracker-onclick="Modals.close('paymentModal')">✕</button>
  <h3 id="paymentModalTitle">Payment</h3><input type="hidden" id="paymentEntityId"><input type="hidden" id="paymentEntityType"><input type="hidden" id="paymentIdempotencyKey">
  <div class="form-group"><label>Date</label><input class="form-control" type="date" id="paymentDate"></div>
  <div class="form-group"><label>Amount</label><input class="form-control" id="paymentAmount" type="number" min="0.01" step=".01"></div>
  <div class="form-group"><label>Payment method</label><select class="form-control" id="paymentMethod"><option>Cash</option><option>Bank</option><option>Telebirr</option><option>CBE Birr</option><option>Other</option></select></div>
  <div class="form-group"><label>Money account</label><select class="form-control" id="paymentMoneyAccount"></select></div>
  <div class="form-group"><label>Reference / note</label><input class="form-control" id="paymentReference" placeholder="Optional"></div>
  <div class="form-group"><label style="display:flex;gap:8px"><input type="checkbox" id="paymentAsAdvance"><span>Prepayment / advance</span></label></div>
  <button class="btn btn-success" data-cashtracker-onclick="Payments.submit()">Record Payment</button></div>`;document.body.appendChild(m)}
  document.getElementById('paymentEntityId').value=id;document.getElementById('paymentEntityType').value=type;document.getElementById('paymentIdempotencyKey').value=Helpers.uid();
  document.getElementById('paymentDate').value=Storage.getSetting('lastTransactionDate',Helpers.getToday());
  document.getElementById('paymentAmount').value='';document.getElementById('paymentReference').value='';document.getElementById('paymentMethod').value='Cash';
  document.getElementById('paymentAsAdvance').checked=false;if(window.CashBanks){CashBanks.init();document.getElementById('paymentMoneyAccount').innerHTML=CashBanks.selectOptions();}document.getElementById('paymentModalTitle').textContent=type==='customer'?'Customer Payment / Advance':'Supplier Payment / Advance';
  Modals.open('paymentModal');
 },
 async submit(){
  if(this._saving)return Toast.warning('A payment is already being saved. Please wait.');
  const type=document.getElementById('paymentEntityType').value,id=document.getElementById('paymentEntityId').value;
  const amount=Number(document.getElementById('paymentAmount').value),date=document.getElementById('paymentDate').value||Helpers.getToday();
  const method=document.getElementById('paymentMethod').value,reference=document.getElementById('paymentReference').value.trim(),advance=document.getElementById('paymentAsAdvance').checked,accountId=document.getElementById('paymentMoneyAccount')?.value||'',idempotencyKey=document.getElementById('paymentIdempotencyKey')?.value||'';
  if(!idempotencyKey)return Toast.warning('Reopen the payment form before saving');
  const priorRows=(State.paymentLedger||[]).filter(x=>x&&x.idempotencyKey===idempotencyKey&&x.status!=='void');
  if(priorRows.length){const prior=priorRows[0],movement=(State.moneyTransactions||[]).filter(x=>x&&x.paymentId===prior.id&&x.status!=='void');if(priorRows.length===1&&movement.length===1){Toast.info('This payment was already recorded; no duplicate was created.');Modals.close('paymentModal');return;}return Toast.error('This payment may be partially saved or duplicated. Run the payment audit before retrying.');}
  if(!Number.isFinite(amount)||amount<=0)return Toast.warning('Enter a valid positive amount');
  if(!accountId)return Toast.warning('Select the cash/bank account for this payment');
  this._saving=true;let postedLedgerId='',balanceApplied=0,advanceAdded=0;
  try{State.saveUndoState('Payment '+Helpers.formatCurrency(amount));await State.runAtomicDurable('Record payment',()=>{
   const duplicate=(State.paymentLedger||[]).find(x=>x&&x.idempotencyKey===idempotencyKey&&x.status!=='void');if(duplicate)throw Error('This payment attempt was already recorded; refresh and verify it before retrying');
   const e=(type==='customer'?State.customers:State.suppliers).find(x=>x.id===id);if(!e)throw Error('Entity not found');
   if(type==='customer'){
    e.customerAdvance=Number(e.customerAdvance||0);e.balance=Number(e.balance||0);
    if(advance){e.customerAdvance+=amount;advanceAdded=amount;} else {balanceApplied=Math.min(amount,e.balance);e.balance-=balanceApplied;advanceAdded=amount-balanceApplied;e.customerAdvance+=advanceAdded;}
   }else{
    e.supplierAdvance=Number(e.supplierAdvance||0);e.balance=Number(e.balance||0);
    if(advance){e.supplierAdvance+=amount;advanceAdded=amount;}else{balanceApplied=Math.min(amount,e.balance);e.balance-=balanceApplied;advanceAdded=amount-balanceApplied;e.supplierAdvance+=advanceAdded;}
   }
   State.paymentLedger=State.paymentLedger||[];postedLedgerId=Helpers.uid();State.paymentLedger.unshift({id:postedLedgerId,entityType:type,entityId:id,entityName:e.name,amount,amountNumber:amount,balanceApplied,advanceAdded,method,accountId,reference,date,idempotencyKey,kind:advance?'advance':'settlement',sourceType:'payment',createdAt:new Date().toISOString(),status:'posted'}); if(window.CashBanks)CashBanks.link(accountId,amount,type==='customer'?'in':'out',{date,sourceType:'payment',sourceId:postedLedgerId,note:reference||e.name,paymentId:postedLedgerId});
  },()=>{const rows=Storage.load('paymentLedger')||[],moves=Storage.load('moneyTransactions')||[];return rows.some(x=>x&&x.id===postedLedgerId&&x.entityId===id&&x.amount===amount&&x.sourceType==='payment')&&moves.some(x=>x&&x.paymentId===postedLedgerId&&x.sourceType==='payment');});Storage.setSetting('lastTransactionDate',date);this._saving=false;Toast.success('Payment recorded');EntryDrafts.markSaved('paymentModal');Modals.close('paymentModal');type==='customer'?Customers.render():Suppliers.render();Dashboard.update();
  }catch(e){this._saving=false;Toast.error('Payment failed: '+(e.message||e))}
 },
 openAdjustBalance(type,id){
  let m=document.getElementById('adjustBalanceModal');if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='adjustBalanceModal';m.innerHTML=`<div class="modal"><button class="close-btn" data-cashtracker-onclick="Modals.close('adjustBalanceModal')">✕</button><h3>Balance Adjustment</h3><input type="hidden" id="adjustEntityId"><input type="hidden" id="adjustEntityType"><input class="form-control" id="adjustAmount" type="number" step=".01"><button class="btn btn-success" data-cashtracker-onclick="Payments.submitAdjust()">Save</button></div>`;document.body.appendChild(m)}
  document.getElementById('adjustEntityId').value=id;document.getElementById('adjustEntityType').value=type;document.getElementById('adjustAmount').value='';Modals.open('adjustBalanceModal');
 },
 submitAdjust(){const type=document.getElementById('adjustEntityType').value,id=document.getElementById('adjustEntityId').value,a=Number(document.getElementById('adjustAmount').value);if(!Number.isFinite(a)||a===0)return Toast.warning('Enter adjustment amount');try{State.saveUndoState('Balance adjustment');State.runAtomic('Balance adjustment',()=>{const e=(type==='customer'?State.customers:State.suppliers).find(x=>x.id===id);if(!e)throw Error('Entity not found');e.balance=Number(e.balance||0);const before=e.balance,next=before+a;let balanceApplied=a,advanceAdded=0;if(next<0){balanceApplied=-before;advanceAdded=Math.abs(next);if(type==='customer')e.customerAdvance=(e.customerAdvance||0)+advanceAdded;else e.supplierAdvance=(e.supplierAdvance||0)+advanceAdded;e.balance=0;}else e.balance=next;if(window.AccountingLedger&&AccountingLedger.audit)AccountingLedger.audit('user','balance_adjustment',type,{entityId:id,amount:a,balanceApplied,advanceAdded});});Toast.success('Balance adjusted');EntryDrafts.markSaved('adjustBalanceModal');Modals.close('adjustBalanceModal');type==='customer'?Customers.render():Suppliers.render();Dashboard.update()}catch(e){Toast.error('Adjustment failed: '+e.message)}}
};window.Payments=Payments;return Payments;});})();
