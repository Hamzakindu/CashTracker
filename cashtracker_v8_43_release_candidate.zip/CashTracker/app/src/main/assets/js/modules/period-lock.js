// V8.28 - Financial period close. Closures are profile-persisted, backed up and cloud-synced.
(function(){'use strict';
const LEGACY_KEY='SP_lock_date';
const validDate=d=>{const s=String(d||'').trim();if(!/^\d{4}-\d{2}-\d{2}$/.test(s))return false;const x=new Date(s+'T00:00:00Z');return !Number.isNaN(x.getTime())&&x.toISOString().slice(0,10)===s;};
const dateOf=x=>String(x&&x.date||'').slice(0,10);
const live=x=>!!x&&!['void','voided','cancelled','canceled','deleted'].includes(String(x.status||'').toLowerCase())&&x.voided!==true&&x.deleted!==true&&x.cancelled!==true&&x.deletedAt==null;
const uid=()=>`pc_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,8)}`;
const esc=s=>window.Helpers&&Helpers.esc?Helpers.esc(String(s??'')):String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const PeriodLock={
 _authorize(permission){if(window.Roles&&typeof Roles.isStaffLoginEnabled==='function'&&Roles.isStaffLoginEnabled()){if(typeof Roles.requirePermission!=='function'||!Roles.requirePermission(permission))throw new Error('Your staff role is not authorized to '+permission.replace(/_/g,' ')+'.');}return true;},
 _actor(){const u=window.Roles&&typeof Roles.currentUser==='function'?Roles.currentUser():null;return u?{id:u.id,name:u.name,role:u.role} : {id:'',name:localStorage.getItem('stockpro_actor')||'Current user',role:'unconfigured'};},
 get(){try{return localStorage.getItem(LEGACY_KEY)||''}catch(e){return ''}},
 list(){return (window.State&&Array.isArray(State.periodClosures)?State.periodClosures:[]).filter(x=>x&&x.status!=='reopened').slice().sort((a,b)=>String(a.from).localeCompare(String(b.from)));},
 isLocked(date){const d=String(date||'').slice(0,10);if(!validDate(d))return false;const legacy=this.get();if(legacy&&validDate(legacy)&&d<=legacy)return true;return this.list().some(c=>d>=c.from&&d<=c.to);},
 blocked(date){if(!this.isLocked(date))return false;const d=String(date||'').slice(0,10);if(window.Toast)Toast.error('🔒 '+d+' belongs to a closed financial period. Review Finance → Close the books.');return true;},
 _save(){if(!window.State||typeof State.save!=='function')throw new Error('Business storage is not ready.');if(!State.save('periodClosures'))throw new Error('Could not save the period closure.');},
 preview(from,to){
  if(!validDate(from)||!validDate(to)||from>to)throw new Error('Enter a valid date range. The start date must not be after the end date.');
  const s=window.State||{};const sales=(s.sales||[]).filter(x=>live(x)&&dateOf(x)>=from&&dateOf(x)<=to),purchases=(s.purchases||[]).filter(x=>live(x)&&dateOf(x)>=from&&dateOf(x)<=to),expenses=(s.directExpenses||[]).filter(x=>live(x)&&dateOf(x)>=from&&dateOf(x)<=to),returns=(s.returns||[]).filter(x=>live(x)&&dateOf(x)>=from&&dateOf(x)<=to),money=(s.moneyTransactions||[]).filter(x=>live(x)&&dateOf(x)>=from&&dateOf(x)<=to);
  const audit=window.FinancialAudit?FinancialAudit.run({customers:s.customers||[],suppliers:s.suppliers||[],sales:s.sales||[],purchases:s.purchases||[],returns:s.returns||[],paymentLedger:s.paymentLedger||[],moneyTransactions:s.moneyTransactions||[],cashAccounts:s.cashAccounts||[],auditLog:s.auditLog||[]}):{issueCount:null};
  return {from,to,counts:{sales:sales.length,purchases:purchases.length,expenses:expenses.length,returns:returns.length,moneyMovements:money.length},auditIssueCount:audit.issueCount,overlap:this.list().filter(c=>from<=c.to&&to>=c.from)};
 },
 close(from,to){
  this._authorize('close_period');
  const p=this.preview(from,to);if(p.overlap.length)throw new Error('This date range overlaps an already closed period. Reopen the existing period first if a correction is necessary.');
  const actor=this._actor();const record={id:uid(),from:p.from,to:p.to,status:'closed',closedAt:new Date().toISOString(),closedBy:actor.name,closedById:actor.id,closedByRole:actor.role,counts:p.counts,auditIssueCount:p.auditIssueCount};
  State.periodClosures=Array.isArray(State.periodClosures)?State.periodClosures:[];State.periodClosures.push(record);
  try{this._save();}catch(e){State.periodClosures=State.periodClosures.filter(x=>x.id!==record.id);throw e;}
  if(window.Security&&Security.audit)try{Security.audit('financial_period_closed','finance_period',record.id,{from,to,counts:p.counts,auditIssueCount:p.auditIssueCount});}catch(e){}
  if(window.Toast)Toast.success('🔒 Period closed: '+from+' to '+to);return record;
 },
 reopen(id,reason){
  this._authorize('reopen_period');
  const r=(State.periodClosures||[]).find(x=>x.id===id&&x.status!=='reopened');if(!r)throw new Error('Closed period not found.');
  const why=String(reason||'').trim();if(why.length<5)throw new Error('Enter a correction reason of at least 5 characters.');
  const actor=this._actor();const before={...r};r.status='reopened';r.reopenedAt=new Date().toISOString();r.reopenedBy=actor.name;r.reopenedById=actor.id;r.reopenedByRole=actor.role;r.reopenReason=why;
  try{this._save();}catch(e){Object.assign(r,before);throw e;}
  if(window.Security&&Security.audit)try{Security.audit('financial_period_reopened','finance_period',id,{from:r.from,to:r.to,reason:why});}catch(e){}
  if(window.Toast)Toast.warning('Period reopened. Corrections will be recorded in normal transaction history.');return r;
 },
 closeFromForm(){
  const from=document.getElementById('periodCloseFrom')?.value,to=document.getElementById('periodCloseTo')?.value;
  try{const p=this.preview(from,to);const summary=`Close ${from} through ${to}?\n\nSales: ${p.counts.sales}\nPurchases: ${p.counts.purchases}\nExpenses: ${p.counts.expenses}\nReturns: ${p.counts.returns}\nCash/bank movements: ${p.counts.moneyMovements}\nFinancial audit issues: ${p.auditIssueCount===null?'not available':p.auditIssueCount}\n\nNo transactions will be changed.`;if(!confirm(summary))return;const typed=prompt('Type CLOSE to confirm this period closing.');if(typed!=='CLOSE')return Toast.warning('Period closing cancelled.');this.close(from,to);if(window.FinanceControl)FinanceControl.render();}catch(e){Toast.error(e.message||'Could not close period.');}
 },
 clearLegacyPrompt(){try{this._authorize('reopen_period')}catch(e){Toast.error(e.message);return}const reason=prompt('Why are you removing the old single-date lock? Enter a reason (minimum 5 characters).');if(reason===null)return;if(String(reason).trim().length<5)return Toast.warning('Enter a reason of at least 5 characters.');if(prompt('Type UNLOCK to confirm removal of the legacy lock.')!=='UNLOCK')return Toast.warning('Unlock cancelled.');this.set('');if(window.Security&&Security.audit)try{Security.audit('legacy_period_lock_removed','finance_period','',{reason:String(reason).trim()});}catch(e){}if(window.Toast)Toast.warning('Legacy lock removed. New closed periods remain locked.');if(window.FinanceControl)FinanceControl.render();},
 reopenPrompt(id){try{this._authorize('reopen_period')}catch(e){Toast.error(e.message);return}const reason=prompt('Why are you reopening this period? Enter a reason (minimum 5 characters).');if(reason===null)return;const confirmText=prompt('Type REOPEN to confirm. This action will be recorded in the audit log.');if(confirmText!=='REOPEN')return Toast.warning('Reopening cancelled.');try{this.reopen(id,reason);if(window.FinanceControl)FinanceControl.render();}catch(e){Toast.error(e.message||'Could not reopen period.');}},
 renderPanel(){
  const all=(State.periodClosures||[]).slice().sort((a,b)=>String(b.closedAt||'').localeCompare(String(a.closedAt||'')));
  const rows=all.map(c=>`<tr><td>${esc(c.from)} → ${esc(c.to)}</td><td>${esc(c.closedAt?new Date(c.closedAt).toLocaleString(): '')}<br><small>${esc(c.closedBy||'')} · ${esc(c.closedByRole||'legacy')}</small></td><td>${Number(c.counts?.sales||0)} / ${Number(c.counts?.purchases||0)} / ${Number(c.counts?.expenses||0)}</td><td>${c.auditIssueCount===null?'N/A':Number(c.auditIssueCount||0)}</td><td>${c.status==='reopened'?`<b>Reopened</b><br><small>${esc(c.reopenReason||'')}<br>${esc(c.reopenedBy||'')} · ${esc(c.reopenedByRole||'legacy')}</small>`:`<b>Closed</b><br><button class="btn btn-outline btn-sm" data-cashtracker-onclick="PeriodLock.reopenPrompt('${esc(c.id)}')">Reopen with reason</button>`}</td></tr>`).join('');
  return `<div class="card" style="margin-top:12px"><div class="card-title">🔒 Financial period closing</div><small>Closed periods block dated financial changes. With staff login enabled, Managers and Accountants may close periods; only Owners may reopen them or remove legacy locks. The actor, role, time and reason are recorded. Audit records are stored locally with business data; use encrypted backups and trusted device access. This is app-level permission control, not server-enforced authorization.</small><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:8px;margin-top:10px"><div class="form-group"><label>Period start</label><input class="form-control" type="date" id="periodCloseFrom" value="${esc(this.defaultRange().from)}"></div><div class="form-group"><label>Period end</label><input class="form-control" type="date" id="periodCloseTo" value="${esc(this.defaultRange().to)}"></div></div><button class="btn btn-primary btn-sm" data-cashtracker-onclick="PeriodLock.closeFromForm()">🔐 Review and close period</button><div style="overflow:auto;margin-top:12px"><table class="transaction-table"><thead><tr><th>Closed range</th><th>Closed at</th><th>Sales / Purchases / Expenses</th><th>Audit issues at close</th><th>Status / action</th></tr></thead><tbody>${rows||'<tr><td colspan="5">No period history yet.</td></tr>'}</tbody></table></div>${this.get()?`<div style="margin-top:10px"><small>Legacy lock still active through ${esc(this.get())}. New period closures are separate.</small> <button class="btn btn-outline btn-sm" data-cashtracker-onclick="PeriodLock.clearLegacyPrompt()">Remove legacy lock with reason</button></div>`:''}</div>`;
 },
 defaultRange(){const d=new Date(),first=new Date(d.getFullYear(),d.getMonth(),1),last=new Date(d.getFullYear(),d.getMonth()+1,0);const fmt=x=>`${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,'0')}-${String(x.getDate()).padStart(2,'0')}`;return {from:fmt(first),to:fmt(last)};},
 // Legacy compatibility: retain the old single-date lock, but never use it for new closings.
 set(d){if(!d)this._authorize('reopen_period');else this._authorize('close_period');try{d?localStorage.setItem(LEGACY_KEY,d):localStorage.removeItem(LEGACY_KEY)}catch(e){}if(window.Security&&Security.audit)Security.audit('legacy_period_lock_set','security','',{lockDate:d||''});},
 dialog(){const cur=this.get(),v=prompt('Legacy lock date (YYYY-MM-DD). Leave empty to remove only this old lock.',cur||'');if(v===null)return;const t=v.trim();if(t&&!validDate(t))return Toast.warning('Enter a real date in YYYY-MM-DD format.');this.set(t);Toast.success(t?'Legacy lock set through '+t:'Legacy lock removed');if(window.FinanceControl)FinanceControl.render();},
 label(){const n=this.list().length;return `${n} closed period(s)${this.get()?' · legacy lock through '+this.get():''}`;}
};
const dom=id=>document.getElementById(id)?.value||'';const find=(list,id)=>(list||[]).find(x=>x.id===id);
function wrap(objName,fn,datesOf){const o=window[objName];if(!o||typeof o[fn]!=='function'||o[fn].__locked)return;const orig=o[fn];const w=function(...a){let ds=[];try{ds=datesOf(...a)||[]}catch(e){}for(const d of ds){if(PeriodLock.blocked(d))return}return orig.apply(this,a)};w.__locked=true;o[fn]=w;}
function install(){
 wrap('Sales','submit',()=>[dom('sellDate')]);wrap('Sales','update',id=>[dom('sellDate'),dateOf(find(State.sales,id))]);wrap('Sales','delete',id=>[dateOf(find(State.sales,id))]);
 wrap('Purchases','submit',()=>[dom('purchaseDate')]);wrap('Purchases','update',id=>[dom('purchaseDate'),dateOf(find(State.purchases,id))]);wrap('Purchases','delete',id=>[dateOf(find(State.purchases,id))]);
 wrap('Expenses','submitDirect',()=>[dom('directExpenseDate')]);wrap('Expenses','recordExclusive',()=>[window.Helpers?.getToday?.()||'']);wrap('Expenses','deleteDirect',id=>[dateOf(find(State.directExpenses,id))]);wrap('Expenses','voidDirect',id=>[dateOf(find(State.directExpenses,id))]);
 wrap('Payments','submit',()=>[dom('paymentDate')]);wrap('Payments','submitAdjust',()=>[window.Helpers?.getToday?.()||'']);
 wrap('CashBanks','movement',()=>[dom('cmDate')]);wrap('CashBanks','addAccount',()=>[dom('cbDate')]);
 wrap('PeopleMoney','addEntry',()=>[dom('pmDate')]);
 wrap('Returns','submit',()=>[dom('returnDate')]);wrap('Returns','update',id=>[dom('returnDate'),dateOf(find(State.returns,id))]);wrap('Returns','delete',id=>[dateOf(find(State.returns,id))]);
}
window.PeriodLock=PeriodLock;install();window.addEventListener('load',()=>{setTimeout(install,1500);setTimeout(install,6000)});
})();
