// ============================================
// EXPORT MODULE
// ============================================

(function() {
    'use strict';
    
    const MODULE_NAME = 'Export';
    
    console.log('📦 Registering ' + MODULE_NAME + '...');
    
    window.registerModule(MODULE_NAME, function() {
        console.log('✅ ' + MODULE_NAME + ' initializing...');
        
        const Export = {
            // Use the same complete, encrypted, integrity-sealed backup path as
            // the dedicated Backup screen. Never create a weaker second format.
            async exportAllJSON() {
                if (typeof Backup === 'undefined' || typeof Backup.exportBackup !== 'function') {
                    Toast.error('Full backup is unavailable. Reopen CashTracker and try again.');
                    return { ok: false, error: 'Backup module unavailable' };
                }
                return Backup.exportBackup();
            },

            // RFC 4180-compatible cell encoding plus spreadsheet-formula defense.
            csvCell(value) {
                let text = value === null || value === undefined ? '' : String(value);
                if (/^[\s]*[=+@\-]/.test(text) || /^[\t\r]/.test(text)) text = "'" + text;
                return '"' + text.replace(/"/g, '""') + '"';
            },

            csvRow(values) {
                return values.map(value => this.csvCell(value)).join(',');
            },

            async exportCSV() {
                const lines = [];
                const section = (title, headers, records, mapper) => {
                    lines.push(this.csvRow([title]));
                    lines.push(this.csvRow(headers));
                    (Array.isArray(records) ? records : []).forEach(record => lines.push(this.csvRow(mapper(record))));
                    lines.push('');
                };
                const activeSales = typeof State.activeSales === 'function'
                    ? State.activeSales()
                    : (State.sales || []).filter(s => !(s.voided || s.status === 'void'));

                let financialProjection = null;
                if (typeof BusinessEngine !== 'undefined' && typeof BusinessEngine.calculate === 'function') {
                    financialProjection = BusinessEngine.calculate({
                        products: State.products || [], sales: State.sales || [], purchases: State.purchases || [],
                        customers: State.customers || [], suppliers: State.suppliers || [],
                        directExpenses: State.directExpenses || [], returns: State.returns || [],
                        stockHistory: State.stockHistory || [], paymentLedger: State.paymentLedger || [], auditLog: State.auditLog || []
                    });
                }
                const customerBalances = new Map((financialProjection?.customerBalanceDetails || []).map(x => [x.id, x]));
                const supplierBalances = new Map((financialProjection?.supplierBalanceDetails || []).map(x => [x.id, x]));
                section('PRODUCTS', ['ID','Name','Category','Buy price','Sell price','Stock','Unit'], State.products,
                    p => [p.id, p.name, p.category, p.buy, p.sell, p.stock, p.unit]);
                section('CUSTOMERS', ['ID','Name','Phone','Address','Balance','Balance basis'], State.customers,
                    c => { const b = customerBalances.get(c.id); return [c.id, c.name, c.contact || c.phone, c.address, b?.basis === 'derived' ? b.balance : c.balance, b?.basis === 'derived' ? 'derived from records' : 'legacy cached']; });
                section('SUPPLIERS', ['ID','Name','Phone','Address','Balance','Balance basis'], State.suppliers,
                    s => { const b = supplierBalances.get(s.id); return [s.id, s.name, s.contact || s.phone, s.address, b?.basis === 'derived' ? b.balance : s.balance, b?.basis === 'derived' ? 'derived from records' : 'legacy cached']; });
                section('SALES', ['ID','Date','Customer','Total','Paid','Remaining','Profit','Status'], activeSales,
                    s => [s.id, s.date, s.customer || s.customerName, s.total, s.paid ?? s.paymentReceived, s.debitRemaining ?? s.remaining, s.profit, s.status]);
                section('PURCHASES', ['ID','Date','Supplier','Total','Paid','Remaining','Status'], State.purchases,
                    p => [p.id, p.date, p.supplier || p.supplierName, p.total, p.paid, p.debit ?? p.remaining, p.status]);
                section('EXPENSES', ['ID','Date','Type','Amount','Reason','Payment method','Account'], State.directExpenses,
                    e => [e.id, e.date, e.typeName || e.type, e.amount, e.reason, e.paymentMethod, e.accountName || e.accountId]);
                section('RETURNS', ['ID','Date','Type','Party','Total','Refund','Status'], State.returns,
                    r => [r.id, r.date, r.type, r.customerName || r.supplierName || r.partyName, r.total ?? r.amount, r.refundAmount, r.status]);
                section('PAYMENT LEDGER', ['ID','Date','Entity type','Entity','Amount','Method','Account','Status'], State.paymentLedger,
                    x => [x.id, x.date, x.entityType, x.entityName || x.entityId, x.amount, x.method || x.paymentMethod, x.accountName || x.accountId, x.status]);
                section('CASH AND BANK MOVEMENTS', ['ID','Date','Type','Amount','Account','Description'], State.moneyTransactions,
                    x => [x.id, x.date, x.type, x.amount, x.accountName || x.accountId, x.description || x.note]);

                const csv = '\uFEFF' + lines.join('\r\n');
                const filename = `cashtracker-data-${new Date().toISOString().slice(0, 10)}.csv`;
                try {
                    const result = await Helpers.downloadFile(csv, filename, 'text/csv;charset=utf-8');
                    if (!result || result.ok !== true) throw new Error('The download was not confirmed.');
                    if (result.confirmed) Toast.success('CSV saved and verified: ' + filename);
                    else Toast.info('CSV download requested: ' + filename + '. Check your Downloads list; the browser has not confirmed the save.');
                    return result;
                } catch (error) {
                    Toast.error('CSV export failed: ' + (error.message || error));
                    return { ok: false, error: error.message || String(error) };
                }
            }
        };
        window.Export = Export;
        console.log('✅ ' + MODULE_NAME + ' loaded successfully');
        return Export;
    });
    
})();