// ============================================
// STOCK HISTORY MODULE
// ============================================

(function() {
    'use strict';
    
    const MODULE_NAME = 'StockHistory';
    
    console.log('📦 Registering ' + MODULE_NAME + '...');
    
    window.registerModule(MODULE_NAME, function() {
        console.log('✅ ' + MODULE_NAME + ' initializing...');
        
        const StockHistory = {
            // Record stock change
            recordChange(productId, productName, change, reason, type = 'adjustment', metadata = {}) {
                // Keep State and persistent storage in sync. This is important because
                // sales/purchases are committed atomically by State.runAtomic().
                const history = Array.isArray(State.stockHistory) ? State.stockHistory : this.getHistory();
                
                // recordChange is called after the stock mutation, so currentStock is the new value.
                const product = State.products.find(p => p.id === productId);
                const currentStock = product ? Number(product.stock) || 0 : 0;
                const previousStock = currentStock - Number(change);
                
                history.unshift({
                    id: Helpers.uid(),
                    productId: productId,
                    productName: productName,
                    change: change,
                    previousStock: previousStock,
                    newStock: currentStock,
                    reason: reason || 'Manual adjustment',
                    type: type, // 'sale', 'purchase', 'return', 'adjustment'
                    sourceId: metadata.sourceId || '',
                    sourceType: metadata.sourceType || type,
                    sourceItemId: metadata.sourceItemId || '',
                    branchId: metadata.branchId || (metadata.sourceId && ((State.sales||[]).find(x=>x.id===metadata.sourceId)?.branchId || (State.purchases||[]).find(x=>x.id===metadata.sourceId)?.branchId)) || State.branchAccessMeta?.activeBranchId || State.branches?.[0]?.id || 'main',
                    unitCost: Number.isFinite(Number(metadata.unitCost)) ? Number(metadata.unitCost) : null,
                    date: metadata.date || Helpers.getToday(),
                    timestamp: new Date().toISOString(),
                    user: this.getCurrentUser()
                });
                
                // Keep only last 1000 records
                if (history.length > 1000) {
                    history.length = 1000;
                }
                
                State.stockHistory = history;
            },
            
            getHistory() {
                return Storage.load('stockHistory') || [];
            },
            
            getHistoryForProduct(productId) {
                return this.getHistory().filter(h => h.productId === productId);
            },
            
            getCurrentUser() {
                const profile = JSON.parse(localStorage.getItem('stockProfile') || '{}');
                return profile.username || 'System';
            },
            
            renderHistory(productId) {
                const history = this.getHistoryForProduct(productId);
                if (!history.length) return '<div class="empty-state">No stock history for this product</div>';
                
                return `
                    <table class="transaction-table">
                        <thead><tr><th>Date</th><th>Change</th><th>Previous</th><th>New</th><th>Reason</th><th>Type</th></tr></thead>
                        <tbody>
                            ${history.slice(0, 50).map(h => `
                                <tr>
                                    <td>${Helpers.formatDate(h.date)}</td>
                                    <td style="color:${h.change > 0 ? 'var(--success)' : 'var(--danger)'};font-weight:700;">
                                        ${h.change > 0 ? '+' : ''}${h.change}
                                    </td>
                                    <td>${h.previousStock}</td>
                                    <td>${h.newStock}</td>
                                    <td>${Helpers.esc(h.reason)}</td>
                                    <td>${this.getTypeIcon(h.type)} ${h.type}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                    ${history.length > 50 ? `<div style="text-align:center;padding:8px;color:var(--text2);font-size:0.8rem;">Showing last 50 of ${history.length} records</div>` : ''}
                `;
            },
            
            getTypeIcon(type) {
                const icons = {
                    'sale': '💰',
                    'purchase': '📥',
                    'return': '↩️',
                    'adjustment': '⚖️'
                };
                return icons[type] || '📌';
            }
        };
        
        window.StockHistory = StockHistory;
        console.log('✅ ' + MODULE_NAME + ' loaded successfully');
        return StockHistory;
    });
    
})();