// STOCKPRO V5.2 - CASH, BANKS & MONEY CONTROL
(function(){
'use strict';
window.registerModule('CashBanks', function(){
const CashBanks={
  init(){
    State.cashAccounts=Array.isArray(State.cashAccounts)?State.cashAccounts:[];
    State.moneyTransactions=Array.isArray(State.moneyTransactions)?State.moneyTransactions:[];
    State.cashReconciliations=Array.isArray(State.cashReconciliations)?State.cashReconciliations:[];
    if(!State.cashAccounts.length){
      State.cashAccounts=[{id:'cash_main',name:'Cash',type:'cash',bankName:'',accountNumber:'',openingBalance:0,openingDate:Helpers.getToday(),active:true,createdAt:new Date().toISOString()}];
      State.save('cashAccounts'); State.save('moneyTransactions');
    }
  },
  accounts(){this.init();return State.cashAccounts.filter(a=>a.active!==false);},
  get(id){return this.accounts().find(a=>a.id===id);},
  balance(id){
    const a=this.get(id); if(!a)return 0;
    let b=Number(a.openingBalance||0);
    const today=Helpers.getToday();
    State.moneyTransactions.filter(t=>t.status!=='void'&&t.accountId===id&&(!t.date||t.date<=today)).forEach(t=>{
      const n=Number(t.amount||0);
      // openingBalance is already the account's opening snapshot; opening
      // transactions are audit records and must not be counted again.
      if(t.type==='opening') return;
      if(['in','income','transfer_in','adjustment_in'].includes(t.type))b+=n;
      else if(['out','expense','transfer_out','adjustment_out'].includes(t.type))b-=n;
    });
    return b;
  },
  totals(){
    const rows=this.accounts().map(a=>({a,b:this.balance(a.id)}));
    return {cash:rows.filter(x=>x.a.type==='cash').reduce((n,x)=>n+x.b,0),
      bank:rows.filter(x=>x.a.type==='bank').reduce((n,x)=>n+x.b,0),
      wallet:rows.filter(x=>x.a.type==='wallet').reduce((n,x)=>n+x.b,0),
      total:rows.reduce((n,x)=>n+x.b,0),rows};
  },
  balanceAsOf(id,date){
    const a=this.get(id);if(!a)return 0;let b=Number(a.openingBalance||0);
    (State.moneyTransactions||[]).filter(t=>t.status!=='void'&&t.accountId===id&&(!t.date||String(t.date)<=String(date))).forEach(t=>{
      const n=Number(t.amount||0);if(t.type==='opening')return;
      if(['in','income','transfer_in','adjustment_in'].includes(t.type))b+=n;
      else if(['out','expense','transfer_out','adjustment_out'].includes(t.type))b-=n;
    });return b;
  },
  reconcile(){
    this.init();
    const rows=this.totals().rows;
    const unassigned=(State.paymentLedger||[]).filter(p=>p.status!=='void'&&!p.accountId);
    return {rows,unassigned,history:(State.cashReconciliations||[]).slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)))};
  },
  parseStatementCSV(text){
    const input=String(text||'').replace(/^\uFEFF/,'');
    const first=input.split(/\r?\n/).find(x=>x.trim());if(!first)return {ok:false,error:'The CSV file is empty'};
    const delimiter=(first.match(/;/g)||[]).length>(first.match(/,/g)||[]).length?';':',';
    const rows=[];let row=[],cell='',quoted=false;
    for(let i=0;i<input.length;i++){const ch=input[i];if(ch==='"'){if(quoted&&input[i+1]==='"'){cell+='"';i++;}else quoted=!quoted;}else if(ch===delimiter&&!quoted){row.push(cell);cell='';}else if((ch==='\n'||ch==='\r')&&!quoted){if(ch==='\r'&&input[i+1]==='\n')i++;row.push(cell);if(row.some(v=>String(v).trim()))rows.push(row);row=[];cell='';}else cell+=ch;}
    row.push(cell);if(row.some(v=>String(v).trim()))rows.push(row);
    if(rows.length<2)return {ok:false,error:'CSV must contain a header and at least one statement row'};
    const norm=v=>String(v||'').trim().toLowerCase().replace(/[ _-]+/g,'');
    const headers=rows[0].map(norm),find=names=>headers.findIndex(h=>names.includes(h));
    const ix={date:find(['date','transactiondate','valuedate','postingdate']),description:find(['description','details','narration','particulars','transactiondetails','memo']),amount:find(['amount','transactionamount','value']),debit:find(['debit','withdrawal','withdrawals','paid']),credit:find(['credit','deposit','deposits','received']),direction:find(['type','direction','transactiontype']),reference:find(['reference','ref','referenceno','transactionid','trnref'])};
    if(ix.date<0||ix.amount<0&&(ix.debit<0&&ix.credit<0))return {ok:false,error:'Required columns not found. Include Date and Amount, or Date with Debit and Credit columns.'};
    const parsed=[];for(let n=1;n<rows.length;n++){const r=rows[n],rawDate=ix.date>=0?String(r[ix.date]||'').trim():'',date=this.normalizeStatementDate(rawDate);let amount=0,direction='';
      if(ix.debit>=0||ix.credit>=0){const debit=this.parseStatementAmount(r[ix.debit],delimiter),credit=this.parseStatementAmount(r[ix.credit],delimiter);if(debit>0){amount=debit;direction='out';}else if(credit>0){amount=credit;direction='in';}}
      else {let raw=String(r[ix.amount]||'').trim().replace(/[()]/g,m=>m==='('?'-':'');if(delimiter===';'&&raw.includes(','))raw=raw.replace(/\./g,'').replace(',', '.');else raw=raw.replace(/,/g,'');raw=raw.replace(/\s/g,'');const nAmount=Number(raw);if(Number.isFinite(nAmount)){amount=Math.abs(nAmount);direction=nAmount<0?'out':'in';}}
      if(ix.direction>=0){const d=String(r[ix.direction]||'').toLowerCase();if(/debit|withdraw|paid|out/.test(d))direction='out';else if(/credit|deposit|received|in/.test(d))direction='in';}
      if(!date||!Number.isFinite(amount)||amount<=0||!direction)continue;
      parsed.push({id:'stmt_'+n+'_'+Date.now().toString(36),date,description:ix.description>=0?String(r[ix.description]||'').trim():'',amount:Number(amount.toFixed(2)),direction,reference:ix.reference>=0?String(r[ix.reference]||'').trim():'',status:'unmatched',candidateIds:[]});
    }
    return parsed.length?{ok:true,rows:parsed,skipped:rows.length-1-parsed.length}:{ok:false,error:'No valid statement transactions found. Check date, amount, debit/credit and direction columns.'};
  },
  parseStatementAmount(value,delimiter=','){let raw=String(value||'').trim().replace(/[()]/g,m=>m==='('?'-':'');if(delimiter===';'&&raw.includes(','))raw=raw.replace(/\./g,'').replace(',', '.');else raw=raw.replace(/,/g,'');raw=raw.replace(/\s/g,'');const n=Number(raw);return Number.isFinite(n)?Math.abs(n):0;},
  normalizeStatementDate(value){const s=String(value||'').trim();if(/^\d{4}-\d{2}-\d{2}$/.test(s))return s;let m=s.match(/^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})$/);if(m){let a=Number(m[1]),b=Number(m[2]),y=m[3];if(a>12)[a,b]=[b,a];else if(b<=12)[a,b]=[b,a];if(a>12||b>31||a<1||b<1)return '';return `${y}-${String(a).padStart(2,'0')}-${String(b).padStart(2,'0')}`;}const d=new Date(s);return Number.isNaN(d.getTime())?'':`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;},
  suggestStatementMatches(row,accountId){
    const day=d=>{const x=new Date(String(d||'')+'T00:00:00');return Number.isNaN(x.getTime())?Infinity:Math.abs(x.getTime()-new Date(row.date+'T00:00:00').getTime())/86400000;};
    const alreadyMatched=new Set((State.cashReconciliations||[]).filter(x=>x.recordType==='statement_import').flatMap(x=>(x.rows||[]).filter(r=>r.status==='matched').map(r=>r.matchedTransactionId)));
    return (State.moneyTransactions||[]).filter(t=>t&&!alreadyMatched.has(t.id)&&t.status!=='void'&&t.accountId===accountId&&Number(t.amount)>0&&Math.abs(Number(t.amount)-Number(row.amount))<0.005&&(['in','income','transfer_in','adjustment_in','opening'].includes(t.type)?'in':['out','expense','transfer_out','adjustment_out'].includes(t.type)?'out':'')===row.direction&&day(t.date)<=3).sort((a,b)=>{const ref=String(row.reference||'').trim().toLowerCase();const score=t=>ref&&[t.reference,t.note,t.sourceId].some(v=>String(v||'').trim().toLowerCase()===ref)?0:1;return score(a)-score(b)||day(a.date)-day(b.date);});
  },
  async importStatement(){
    const accountId=document.getElementById('statementAccount')?.value,file=document.getElementById('statementFile')?.files?.[0];
    if(file&&file.size>10*1024*1024)return Toast.warning('CSV file is larger than 10 MB. Export a smaller date range.');
    if(!accountId||!this.get(accountId))return Toast.warning('Choose the account for this statement');if(!file)return Toast.warning('Choose a CSV statement file');
    try{const contents=typeof file.text==='function'?await file.text():await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result||''));reader.onerror=()=>reject(new Error('Could not read the selected CSV file'));reader.readAsText(file);});const parsed=this.parseStatementCSV(contents);if(!parsed.ok)return Toast.warning(parsed.error);
      const used=new Set((State.cashReconciliations||[]).filter(x=>x.recordType==='statement_import').flatMap(x=>(x.rows||[]).map(r=>r.fingerprint||`${x.accountId}|${r.date}|${r.amount}|${r.direction}|${r.reference}`)));
      const rows=parsed.rows.map(r=>{r.fingerprint=`${accountId}|${r.date}|${r.amount}|${r.direction}|${r.reference}`;r.duplicateImport=used.has(r.fingerprint);used.add(r.fingerprint);r.candidateIds=this.suggestStatementMatches(r,accountId).map(t=>t.id);r.status=r.duplicateImport?'duplicate_import':'unmatched';return r;});
      const record={id:Helpers.uid(),recordType:'statement_import',accountId,accountName:this.get(accountId).name,fileName:file.name||'statement.csv',importedAt:new Date().toISOString(),rows,skipped:parsed.skipped};
      State.saveUndoState('Import bank statement');State.cashReconciliations.unshift(record);State.save('cashReconciliations');this.render();Toast.success(`Imported ${rows.length} statement rows for review; ${parsed.skipped} invalid rows skipped. No balances changed.`);
    }catch(e){Toast.error('Statement import failed: '+(e.message||e));}
  },
  confirmStatementMatch(importId,rowId,transactionId){
    const imp=(State.cashReconciliations||[]).find(x=>x.id===importId&&x.recordType==='statement_import');if(!imp)return Toast.warning('Statement import not found');
    const row=(imp.rows||[]).find(x=>x.id===rowId);if(!row)return Toast.warning('Statement row not found');if(row.status==='matched')return Toast.info('This statement row is already matched');
    const tx=(State.moneyTransactions||[]).find(x=>x.id===transactionId&&x.status!=='void'&&x.accountId===imp.accountId);if(!tx)return Toast.warning('The selected app movement is unavailable');
    if(Math.abs(Number(tx.amount)-Number(row.amount))>=0.005)return Toast.warning('Amount differs; matching cancelled');
    const dir=['in','income','transfer_in','adjustment_in','opening'].includes(tx.type)?'in':['out','expense','transfer_out','adjustment_out'].includes(tx.type)?'out':'';if(dir!==row.direction)return Toast.warning('Money direction differs; matching cancelled');
    const already=(State.cashReconciliations||[]).some(x=>x.recordType==='statement_import'&&(x.rows||[]).some(r=>r.id!==rowId&&r.status==='matched'&&r.matchedTransactionId===tx.id));if(already)return Toast.warning('This app movement is already matched to another statement row');
    State.saveUndoState('Confirm statement match');row.status='matched';row.matchedTransactionId=tx.id;row.matchedAt=new Date().toISOString();row.matchConfirmed=true;State.save('cashReconciliations');if(typeof Security!=='undefined'&&Security.audit)Security.audit('statement_row_matched','cash_account',imp.accountId,{importId,rowId,transactionId:tx.id});this.render();Toast.success('Match confirmed. No accounting transaction was changed.');
  },
  statementImportsHTML(){
    const imports=(State.cashReconciliations||[]).filter(x=>x.recordType==='statement_import').slice(0,20);if(!imports.length)return '<div class="empty-state">No statement files imported yet.</div>';
    return imports.map(imp=>{const rows=imp.rows||[],matched=rows.filter(r=>r.status==='matched').length;return `<div style="border:1px solid var(--border-color,#ddd);border-radius:8px;padding:10px;margin:8px 0"><b>${Helpers.esc(imp.fileName||'Statement')}</b> — ${Helpers.esc(imp.accountName||'Account')}<div><small>${Helpers.formatDate(imp.importedAt?.slice(0,10)||'')} · ${matched}/${rows.length} rows matched · ${rows.filter(r=>r.status==='duplicate_import').length} possible duplicate imports</small></div><div style="overflow:auto"><table class="transaction-table"><thead><tr><th>Date / details</th><th>Direction</th><th>Amount</th><th>Suggested app movement</th><th>Status / action</th></tr></thead><tbody>${rows.map(r=>{const candidates=this.suggestStatementMatches(r,imp.accountId),options=candidates.map(t=>`<option value="${Helpers.esc(t.id)}">${Helpers.formatDate(t.date)} · ${t.type} · ${Helpers.formatCurrency(t.amount)} · ${Helpers.esc(t.note||t.sourceType||'')}</option>`).join('');return `<tr><td>${Helpers.formatDate(r.date)}<br>${Helpers.esc(r.description||r.reference||'')}</td><td>${r.direction}</td><td>${Helpers.formatCurrency(r.amount)}</td><td>${candidates.length?`<select class="form-control" id="sm_${Helpers.esc(r.id)}">${options}</select>`:'No exact candidate'}</td><td>${r.status==='matched'?'✅ Matched':r.status==='duplicate_import'?'⚠️ Possible duplicate import':candidates.length>1?'⚠️ Multiple candidates':candidates.length===1?'Review candidate':''}${r.status!=='matched'&&r.status!=='duplicate_import'&&candidates.length?`<button class="btn btn-primary btn-sm" data-cashtracker-onclick="CashBanks.confirmStatementMatch('${Helpers.esc(imp.id)}','${Helpers.esc(r.id)}',document.getElementById('sm_${Helpers.esc(r.id)}').value)">Confirm match</button>`:''}</td></tr>`;}).join('')}</tbody></table></div></div>`;}).join('');
  },
  saveReconciliation(){
    const accountId=document.getElementById('crAccount')?.value,date=document.getElementById('crDate')?.value||Helpers.getToday();
    const actual=Number(document.getElementById('crActual')?.value);
    const note=(document.getElementById('crNote')?.value||'').trim();
    if(!accountId||!Number.isFinite(actual)||actual<0)return Toast.warning('Choose an account and enter a valid counted/statement balance');
    const account=this.get(accountId);if(!account)return Toast.warning('Account not found');
    const expected=this.balanceAsOf(accountId,date),difference=actual-expected;
    State.saveUndoState('Cash/bank reconciliation');
    State.cashReconciliations.unshift({id:Helpers.uid(),accountId,accountName:account.name,date,expectedBalance:expected,actualBalance:actual,difference,note,status:Math.abs(difference)<0.005?'matched':'difference',createdAt:new Date().toISOString()});
    State.save('cashReconciliations');
    if(typeof Security!=='undefined'&&Security.audit)Security.audit('cash_reconciled','cash_account',accountId,{date,expected,actual,difference});
    this.render();Toast.success(Math.abs(difference)<0.005?'Reconciliation matched':'Difference recorded; no automatic adjustment made');
  },
  selectOptions(selected=''){
    return this.accounts().map(a=>`<option value="${Helpers.esc(a.id)}" ${a.id===selected?'selected':''}>${Helpers.esc(a.name)}${a.bankName?' — '+Helpers.esc(a.bankName):''}</option>`).join('');
  },
  addAccount(){
    const name=document.getElementById('cbName').value.trim(),type=document.getElementById('cbType').value,
      bank=document.getElementById('cbBank').value.trim(),num=document.getElementById('cbNum').value.trim(),
      opening=Number(document.getElementById('cbOpening').value||0),date=document.getElementById('cbDate').value||Helpers.getToday();
    if(!name)return Toast.warning('Enter account name');
    if(type==='bank'&&!bank)return Toast.warning('Enter bank name');
    if(!Number.isFinite(opening)||opening<0)return Toast.warning('Opening balance must be zero or more');
    State.saveUndoState('Add money account');
    State.runAtomic('Add money account',()=>{
      const id=Helpers.uid();State.cashAccounts.unshift({id,name,type,bankName:bank,accountNumber:num,openingBalance:opening,openingDate:date,active:true,createdAt:new Date().toISOString()});
      if(opening)State.moneyTransactions.unshift({id:Helpers.uid(),accountId:id,type:'opening',amount:opening,date,note:'Opening balance',sourceType:'opening',status:'posted',createdAt:new Date().toISOString()});
    });
    EntryDrafts.markSaved('cashAccountModal'); Modals.close('cashAccountModal');this.render();Toast.success('Account added');
  },
  openAccountModal(){
    let m=document.getElementById('cashAccountModal');
    if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='cashAccountModal';m.innerHTML=`
    <div class="modal"><button class="close-btn" data-cashtracker-onclick="Modals.close('cashAccountModal')">✕</button><h3>🏦 Add Cash / Bank Account</h3>
    <div class="form-group"><label>Name</label><input class="form-control" id="cbName" placeholder="Main Cash / CBE Account"></div>
    <div class="form-group"><label>Type</label><select class="form-control" id="cbType" data-cashtracker-onchange="CashBanks.toggleBank()"><option value="cash">Cash</option><option value="bank">Bank</option><option value="wallet">Mobile Wallet</option></select></div>
    <div class="form-group" id="cbBankWrap" style="display:none"><label>Bank</label><input class="form-control" id="cbBank" placeholder="CBE / Awash / Dashen"></div>
    <div class="form-group"><label>Account number / identifier</label><input class="form-control" id="cbNum"></div>
    <div class="form-group"><label>Opening balance</label><input class="form-control" id="cbOpening" type="number" min="0" step=".01" value="0"></div>
    <div class="form-group"><label>Opening date</label><input class="form-control" id="cbDate" type="date"></div>
    <button class="btn btn-success" data-cashtracker-onclick="CashBanks.addAccount()">Save</button></div>`;document.body.appendChild(m);}
    document.getElementById('cbName').value='';document.getElementById('cbType').value='cash';document.getElementById('cbBank').value='';document.getElementById('cbNum').value='';
    document.getElementById('cbOpening').value='0';document.getElementById('cbDate').value=Helpers.getToday();this.toggleBank();Modals.open('cashAccountModal');
  },
  toggleBank(){const e=document.getElementById('cbBankWrap');if(e)e.style.display=document.getElementById('cbType')?.value==='bank'?'block':'none';},
  movement(){
    const aid=document.getElementById('cmAccount').value,type=document.getElementById('cmType').value,amt=Number(document.getElementById('cmAmount').value),
      date=document.getElementById('cmDate').value||Helpers.getToday(),note=document.getElementById('cmNote').value.trim(),to=document.getElementById('cmTo').value;
    if(!aid||!Number.isFinite(amt)||amt<=0)return Toast.warning('Enter account and positive amount');
    if((type==='out'||type==='transfer_out')&&this.balance(aid)<amt)return Toast.warning('Insufficient available balance');
    if(type==='transfer_out'&&(!to||to===aid))return Toast.warning('Choose another destination account');
    State.saveUndoState('Money movement');State.runAtomic('Money movement',()=>{
      State.moneyTransactions.unshift({id:Helpers.uid(),accountId:aid,type,amount:amt,date,note,sourceType:'manual',status:'posted',createdAt:new Date().toISOString()});
      if(type==='transfer_out')State.moneyTransactions.unshift({id:Helpers.uid(),accountId:to,type:'transfer_in',amount:amt,date,note,sourceType:'transfer',status:'posted',createdAt:new Date().toISOString()});
    });
    EntryDrafts.markSaved('cashMovementModal'); Modals.close('cashMovementModal');this.render();Toast.success('Money movement recorded');
  },
  openMovement(){
    if(!this.accounts().length)return this.openAccountModal();
    let m=document.getElementById('cashMovementModal');
    if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='cashMovementModal';m.innerHTML=`
    <div class="modal"><button class="close-btn" data-cashtracker-onclick="Modals.close('cashMovementModal')">✕</button><h3>💵 Money Movement</h3>
    <div class="form-group"><label>Date</label><input class="form-control" id="cmDate" type="date"></div>
    <div class="form-group"><label>Type</label><select class="form-control" id="cmType" data-cashtracker-onchange="CashBanks.toggleTransfer()"><option value="in">Money received</option><option value="out">Money paid</option><option value="transfer_out">Transfer to another account</option></select></div>
    <div class="form-group"><label>Account</label><select class="form-control" id="cmAccount"></select></div>
    <div class="form-group" id="cmToWrap" style="display:none"><label>To account</label><select class="form-control" id="cmTo"></select></div>
    <div class="form-group"><label>Amount</label><input class="form-control" id="cmAmount" type="number" min=".01" step=".01"></div>
    <div class="form-group"><label>Reference / note</label><input class="form-control" id="cmNote"></div>
    <button class="btn btn-success" data-cashtracker-onclick="CashBanks.movement()">Save</button></div>`;document.body.appendChild(m);}
    document.getElementById('cmDate').value=Helpers.getToday();document.getElementById('cmAmount').value='';document.getElementById('cmNote').value='';
    document.getElementById('cmAccount').innerHTML=this.selectOptions();document.getElementById('cmTo').innerHTML=this.selectOptions();document.getElementById('cmType').value='in';this.toggleTransfer();Modals.open('cashMovementModal');
  },
  toggleTransfer(){const yes=document.getElementById('cmType')?.value==='transfer_out',w=document.getElementById('cmToWrap');if(w)w.style.display=yes?'block':'none';},
  link(accountId,amount,direction,meta={}){
    if(!accountId||Number(amount)<=0)return;
    if(meta.paymentId){const linked=(State.moneyTransactions||[]).filter(x=>x&&x.paymentId===meta.paymentId&&x.status!=='void');if(linked.length>1)throw new Error('Duplicate cash/bank movements already exist for this payment');if(linked.length===1)return linked[0];}
    const tx={id:Helpers.uid(),accountId,type:direction==='in'?'in':'out',amount:Number(amount),date:meta.date||Helpers.getToday(),note:meta.note||'',sourceType:meta.sourceType||'payment',sourceId:meta.sourceId||'',paymentId:meta.paymentId||'',status:'posted',createdAt:new Date().toISOString()};
    if(tx.amount<=0)throw new Error('Money movement must be greater than zero');
    if(!this.get(accountId))throw new Error('Money account not found');
    State.moneyTransactions.unshift(tx); Security?.audit('money_posted','cash_account',accountId,{transactionId:tx.id,type:tx.type,amount:tx.amount,sourceType:tx.sourceType,sourceId:tx.sourceId});
  },
  render(){
    this.init();const p=document.getElementById('tab-cashbanks');if(!p)return;const t=this.totals();
    p.innerHTML=`<div class="card"><div class="flex-between"><div><div class="card-title">💵 Cash & Banks</div><small>See exactly how much money is available in cash, each bank and each wallet.</small></div><div><button class="btn btn-success btn-sm" data-cashtracker-onclick="CashBanks.openAccountModal()">➕ Account</button> <button class="btn btn-primary btn-sm" data-cashtracker-onclick="CashBanks.openMovement()">💵 Movement</button></div></div>
    <div class="stock-summary-grid" style="margin-top:12px"><div class="stock-summary-item"><span class="summary-label">💵 Cash</span><span class="summary-value">${Helpers.formatCurrency(t.cash)}</span></div><div class="stock-summary-item"><span class="summary-label">🏦 Banks</span><span class="summary-value">${Helpers.formatCurrency(t.bank)}</span></div><div class="stock-summary-item"><span class="summary-label">📱 Wallets</span><span class="summary-value">${Helpers.formatCurrency(t.wallet)}</span></div><div class="stock-summary-item"><span class="summary-label">💰 Total available</span><span class="summary-value">${Helpers.formatCurrency(t.total)}</span></div></div></div>
    <div class="card"><div class="card-title">🏦 Available by account</div><div style="overflow:auto"><table class="transaction-table"><thead><tr><th>Account</th><th>Type</th><th>Bank</th><th>Account No.</th><th>Available</th></tr></thead><tbody>${t.rows.map(x=>`<tr><td><b>${Helpers.esc(x.a.name)}</b></td><td>${x.a.type}</td><td>${Helpers.esc(x.a.bankName||'')}</td><td>${Helpers.esc(x.a.accountNumber||'')}</td><td><b>${Helpers.formatCurrency(x.b)}</b></td></tr>`).join('')}</tbody></table></div></div>
    <div class="card"><div class="card-title">🧮 Reconcile cash / bank / wallet</div><small>Compare the app balance with your physical cash count, bank statement, or mobile-wallet statement. Differences are recorded for review; CashTracker will not silently change your money balance.</small>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-top:10px"><div class="form-group"><label>Account</label><select class="form-control" id="crAccount">${this.selectOptions()}</select></div><div class="form-group"><label>Statement/count date</label><input class="form-control" id="crDate" type="date" value="${Helpers.getToday()}"></div><div class="form-group"><label>Actual counted/statement balance</label><input class="form-control" id="crActual" type="number" min="0" step="0.01" placeholder="0.00"></div><div class="form-group"><label>Note</label><input class="form-control" id="crNote" placeholder="Statement ref / difference reason"></div></div><button class="btn btn-primary btn-sm" data-cashtracker-onclick="CashBanks.saveReconciliation()">Save reconciliation</button></div>
    <div class="card"><div class="card-title">📄 Import bank / wallet statement (CSV)</div><small>Use a CSV exported by your bank or wallet. Required: Date and Amount, or Date with Debit and Credit. Matching is only suggested; you must confirm each match. Imported rows never change app balances.</small><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-top:10px"><div class="form-group"><label>Account</label><select class="form-control" id="statementAccount">${this.selectOptions()}</select></div><div class="form-group"><label>CSV statement</label><input class="form-control" id="statementFile" type="file" accept=".csv,text/csv"></div></div><button class="btn btn-primary btn-sm" data-cashtracker-onclick="CashBanks.importStatement()">Import statement for review</button></div>
    <div class="card"><div class="card-title">🔎 Imported statement review</div>${this.statementImportsHTML()}</div>
    <div class="card"><div class="card-title">📋 Reconciliation history</div>${this.reconciliationTable()}</div>
    <div class="card"><div class="card-title">🧾 Recent money movements</div>${this.txTable()}</div>`;
  },
  reconciliationTable(){
    const rows=(State.cashReconciliations||[]).filter(x=>x.recordType!=='statement_import').slice().sort((a,b)=>String(b.date).localeCompare(String(a.date))).slice(0,100);
    if(!rows.length)return '<div class="empty-state">No reconciliations recorded yet.</div>';
    return `<div style="overflow:auto"><table class="transaction-table"><thead><tr><th>Date</th><th>Account</th><th>App balance</th><th>Actual balance</th><th>Difference</th><th>Status / note</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${Helpers.formatDate(r.date)}</td><td>${Helpers.esc(r.accountName||this.get(r.accountId)?.name||'Account')}</td><td>${Helpers.formatCurrency(r.expectedBalance)}</td><td>${Helpers.formatCurrency(r.actualBalance)}</td><td><b>${Helpers.formatCurrency(r.difference)}</b></td><td>${r.status==='matched'?'✅ Matched':'⚠️ Review'} ${Helpers.esc(r.note||'')}</td></tr>`).join('')}</tbody></table></div>`;
  },
  txTable(){
    const tx=State.moneyTransactions.filter(x=>x.status!=='void').slice(0,100);if(!tx.length)return '<div class="empty-state">No money movements yet.</div>';
    return `<div style="overflow:auto"><table class="transaction-table"><thead><tr><th>Date</th><th>Account</th><th>Type</th><th>Amount</th><th>Reference</th></tr></thead><tbody>${tx.map(x=>{const a=this.get(x.accountId),pos=['in','opening','transfer_in','adjustment_in'].includes(x.type);return `<tr><td>${Helpers.formatDate(x.date)}</td><td>${Helpers.esc(a?.name||'Unknown')}</td><td>${x.type.replace('_',' ')}</td><td>${pos?'+':'-'} ${Helpers.formatCurrency(x.amount)}</td><td>${Helpers.esc(x.note||x.sourceType||'')}</td></tr>`}).join('')}</tbody></table></div>`;
  }
};
window.CashBanks=CashBanks;return CashBanks;});
})();
