// ============================================
// STOCK LEDGER & VALUATION - V5.10.30
// Additive module: preserves existing stock history and UI.
// ============================================
(function(){
'use strict';
const MODULE_NAME='StockLedger';
window.registerModule(MODULE_NAME,function(){
 const num=v=>Number(v)||0;
 const dateOf=x=>x?.date||x?.createdAt?.slice?.(0,10)||'';
 const sortAsc=(a,b)=>String(a.date||'').localeCompare(String(b.date||''))||String(a.timestamp||'').localeCompare(String(b.timestamp||''));
 const esc=s=>window.Helpers?.esc?Helpers.esc(s):String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
 const cur=n=>window.Helpers?.formatCurrency?Helpers.formatCurrency(num(n)):'ETB '+num(n).toFixed(2);
 const StockLedger={
   _unitCostFor(h,productId){
     if(h.unitCost!==null&&h.unitCost!==undefined&&Number.isFinite(Number(h.unitCost)))return Number(h.unitCost);
     const sourceId=h.sourceId||'';
     if(sourceId){
       const purchase=(State.purchases||[]).find(x=>x.id===sourceId||x.transactionId===sourceId);
       if(purchase){const i=(purchase.items||[]).find((x,idx)=>x.productId===productId&&(!h.sourceItemId||String(x.id||idx)===String(h.sourceItemId)));if(i){const c=i.cost??i.price??(Number(i.amount)/Math.max(1,Number(i.quantity)||1));if(Number.isFinite(Number(c)))return Number(c);}}
       const sale=(State.sales||[]).find(x=>x.id===sourceId||x.transactionId===sourceId);
       if(sale){const i=(sale.items||[]).find((x,idx)=>x.productId===productId&&(!h.sourceItemId||String(x.id||idx)===String(h.sourceItemId)));if(i){const c=i.costPriceAtSale??i.cost??(Number(i.costAmount)/Math.max(1,Number(i.quantity)||1));if(Number.isFinite(Number(c)))return Number(c);}}
       const ret=(State.returns||[]).find(x=>x.id===sourceId||x.transactionId===sourceId);
       if(ret&&Number(ret.quantity)>0&&ret.costAmount!=null)return Number(ret.costAmount)/Number(ret.quantity);
     }
     // Legacy stock-history rows did not retain a source ID. Do not guess from same-day
     // transactions: multiple purchases/sales on one date can have different unit costs.
     return null;
   },
   movements(productId,from,to){
     const hs=(State.stockHistory||[]).filter(h=>h.productId===productId && (!from||String(dateOf(h))>=String(from)) && (!to||String(dateOf(h))<=String(to))).map(h=>({
       id:h.id,date:dateOf(h),timestamp:h.timestamp||'',type:h.type||'adjustment',reason:h.reason||'',change:num(h.change),previousStock:num(h.previousStock),newStock:num(h.newStock),unitCost:this._unitCostFor(h,productId),unitCostBasis:(h.unitCost!==null&&h.unitCost!==undefined)?'recorded':'legacy-unavailable',sourceId:h.sourceId||'',user:h.user||'System'
     }));
     return hs.sort(sortAsc);
   },
   ledger(productId,from,to){
     const product=(State.products||[]).find(p=>p.id===productId); if(!product)return [];
     let rows=this.movements(productId,from,to);
     if(!rows.length && num(product.initialStock)!==0){
       rows=[{id:'opening-'+productId,date:dateOf(product)||'',timestamp:product.createdAt||'',type:'opening',reason:'Opening stock',change:num(product.initialStock),previousStock:0,newStock:num(product.initialStock),unitCost:num(product.buy),user:'System'}];
     }
     let balance=0, value=0, valueKnown=true;
     rows=rows.map(r=>{
       const q=num(r.change), cost=r.unitCost===null||r.unitCost===undefined?null:num(r.unitCost);
       const before=balance; balance+=q;
       if(cost===null)valueKnown=false;
       if(valueKnown&&cost!==null)value+=q*cost;
       return Object.assign({},r,{runningStock:balance,runningValue:valueKnown?value:null,unitCost:cost,movementValue:cost===null?null:q*cost});
     });
     // Current product stock is authoritative. If history is truncated (max 1000), expose the gap rather than rewriting it.
     if(rows.length && Math.abs(balance-num(product.stock))>1e-9){
       rows.push({id:'current-reconciliation',date:Helpers.getToday(),timestamp:new Date().toISOString(),type:'reconciliation',reason:'Current stock reconciliation (history may be truncated)',change:num(product.stock)-balance,previousStock:balance,newStock:num(product.stock),unitCost:null,unitCostBasis:'unvalued reconciliation',runningStock:num(product.stock),runningValue:null,movementValue:null,user:'System'});
     }
     return rows;
   },
   valuation(productId){
     const p=(State.products||[]).find(x=>x.id===productId); if(!p)return null;
     if(window.HistoricalCostEngine){
       const projection=HistoricalCostEngine.product({products:State.products||[],purchases:State.purchases||[],sales:State.sales||[],returns:State.returns||[],stockHistory:State.stockHistory||[]},productId);
       if(projection)return {productId,stock:projection.stock,averageCost:projection.averageCost,stockValue:projection.stockValue,retailValue:projection.retailValue,potentialMargin:projection.potentialMargin,rows:projection.rows.length,reconciled:projection.reconciled,reliable:projection.reliable,estimated:projection.estimated,issues:projection.issues};
     }
     return {productId,stock:num(p.stock),averageCost:null,stockValue:null,retailValue:num(p.stock)*num(p.sell),potentialMargin:null,rows:0,reconciled:false,reliable:false,estimated:true,issues:[{code:'COST_ENGINE_UNAVAILABLE'}]};
   },
   summary(productId){
     const rows=this.movements(productId); const p=(State.products||[]).find(x=>x.id===productId); if(!p)return null;
     return {opening:num(p.initialStock),purchased:rows.filter(r=>r.change>0&&(r.type==='purchase'||r.type==='purchase-reversal')).reduce((a,r)=>a+Math.max(0,r.change),0),sold:rows.filter(r=>r.change<0&&String(r.type).startsWith('sale')).reduce((a,r)=>a+Math.abs(r.change),0),returned:rows.filter(r=>r.change>0&&r.type==='return').reduce((a,r)=>a+r.change,0),adjusted:rows.filter(r=>r.type==='adjustment').reduce((a,r)=>a+r.change,0),current:num(p.stock)};
   },
   show(productId){
     const p=(State.products||[]).find(x=>x.id===productId); if(!p)return Toast.error('Product not found');
     const rows=this.ledger(productId); const val=this.valuation(productId); const s=this.summary(productId);
     let body=rows.slice().reverse().slice(0,200).map(r=>`<tr><td>${Helpers.formatDate(r.date)}</td><td>${esc(r.type)}</td><td>${esc(r.reason)}</td><td>${r.change>0?'+':''}${r.change}</td><td>${r.runningStock}</td><td>${r.unitCost===null?'Unknown':cur(r.unitCost)}</td><td>${r.movementValue===null?'Unknown':cur(r.movementValue)}</td></tr>`).join('');
     const html=`<div class="detail-section"><h4>📚 Stock Ledger</h4><div class="stock-summary-grid"><div class="stock-summary-item"><span class="summary-label">Current stock</span><span class="summary-value">${s.current}</span></div><div class="stock-summary-item"><span class="summary-label">Purchased</span><span class="summary-value">+${s.purchased}</span></div><div class="stock-summary-item"><span class="summary-label">Sold</span><span class="summary-value">-${s.sold}</span></div><div class="stock-summary-item"><span class="summary-label">Returned</span><span class="summary-value">+${s.returned}</span></div></div></div><div class="detail-section"><h4>💰 Valuation</h4><div class="stock-summary-grid"><div class="stock-summary-item"><span class="summary-label">Average cost</span><span class="summary-value">${cur(val.averageCost)}</span></div><div class="stock-summary-item"><span class="summary-label">Stock value</span><span class="summary-value">${cur(val.stockValue)}</span></div><div class="stock-summary-item"><span class="summary-label">Retail value</span><span class="summary-value">${cur(val.retailValue)}</span></div><div class="stock-summary-item"><span class="summary-label">Potential margin</span><span class="summary-value">${cur(val.potentialMargin)}</span></div></div><div style="font-size:.78rem;color:var(--text2);margin-top:8px">${val.reliable?'Historical perpetual weighted-average cost from recorded transactions.':'Estimated/incomplete historical cost. Review the valuation warnings before relying on this figure.'} Existing records are not rewritten.</div></div><div class="detail-section"><h4>📋 Movements</h4><div style="overflow:auto"><table class="transaction-table"><thead><tr><th>Date</th><th>Type</th><th>Reason</th><th>Change</th><th>Balance</th><th>Unit cost</th><th>Value</th></tr></thead><tbody>${body||'<tr><td colspan="7" class="empty-state">No stock movements recorded</td></tr>'}</tbody></table></div>${rows.length>200?'<div style="text-align:center;padding:8px;color:var(--text2)">Showing latest 200 movements</div>':''}</div>`;
     const c=document.getElementById('detailModalContent'); if(c)c.insertAdjacentHTML('beforeend',html);
   },
   audit(){
     const issues=[];(State.products||[]).forEach(p=>{const h=(State.stockHistory||[]).filter(x=>x.productId===p.id); if(h.length){const latest=h.slice().sort((a,b)=>new Date(b.timestamp||b.date)-new Date(a.timestamp||a.date))[0]; if(Math.abs(num(latest.newStock)-num(p.stock))>0.000001)issues.push({productId:p.id,name:p.name,current:num(p.stock),historyLatest:num(latest.newStock)});}}); return {ok:issues.length===0,issues};
   }
 };
 window.StockLedger=StockLedger; console.log('✅ StockLedger loaded'); return StockLedger;
});
})();
