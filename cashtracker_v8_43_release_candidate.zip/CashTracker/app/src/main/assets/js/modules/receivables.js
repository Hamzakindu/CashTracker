// OVERDUE / RECEIVABLES: who owes you, how old the debt is, one-tap reminders
(function(){'use strict';
window.registerModule('Receivables',function(){
const TPL='SP_remind_tpl',LOG='SP_reminded';
const DEF='Hello {name}, this is a friendly reminder from {store}. Your outstanding balance is {amount}{days}. Please arrange payment when you can. Thank you! 🙏';
const esc=s=>Helpers.esc(String(s==null?'':s));
const fmt=n=>Helpers.formatCurrency(Number(n)||0);
const store=()=>{try{return JSON.parse(localStorage.getItem('stockProfile')||'{}').storeName||'CashTracker'}catch(e){return 'CashTracker'}};
const tpl=()=>localStorage.getItem(TPL)||DEF;
const today=()=>new Date().toISOString().slice(0,10);
const log=()=>{try{return JSON.parse(localStorage.getItem(LOG)||'{}')}catch(e){return{}}};
const age=d=>{const t=new Date(String(d||'').slice(0,10)+'T00:00:00');return isNaN(t)?0:Math.max(0,Math.floor((Date.now()-t)/864e5))};
let minAge=0,picked=null;
// Use the central projection when source history is complete; otherwise retain the cached legacy balance.
function balanceMap(){
  if(typeof BusinessEngine==='undefined'||typeof BusinessEngine.calculate!=='function')return new Map();
  const p=BusinessEngine.calculate({products:State.products||[],sales:State.sales||[],purchases:State.purchases||[],customers:State.customers||[],suppliers:State.suppliers||[],directExpenses:State.directExpenses||[],returns:State.returns||[],stockHistory:State.stockHistory||[],paymentLedger:State.paymentLedger||[],auditLog:State.auditLog||[]});
  return new Map((p.customerBalanceDetails||[]).map(x=>[x.id,x]));
}
function balanceOf(c,map){const x=map&&map.get(c.id);return x&&x.basis==='derived'?Number(x.balance)||0:Number(c.balance)||0;}
// Payments clear the oldest debt first, so the balance still owed is assigned to the newest credit sales.
function aging(c,balance){
  const outstanding=Number(balance==null?c.balance:balance)||0;
  const sales=State.activeSales().filter(s=>s.customerId===c.id&&Number(s.debitRemaining)>0);
  if(window.BusinessEngine&&typeof BusinessEngine.allocateAging==='function')return BusinessEngine.allocateAging(outstanding,sales,s=>s.debitRemaining,s=>s.date);
  let rem=outstanding,oldest=0;const b=[0,0,0,0];
  for(const s of sales.sort((x,y)=>String(y.date).localeCompare(String(x.date)))){if(rem<=0)break;const amt=Math.min(rem,Number(s.debitRemaining));rem-=amt;const a=age(s.date);oldest=Math.max(oldest,a);b[a<=30?0:a<=60?1:a<=90?2:3]+=amt}
  if(rem>0){b[3]+=rem;oldest=Math.max(oldest,91)}return{b,oldest};
}
function debtors(){
  const balances=balanceMap();
  return (State.customers||[]).map(c=>({c,balance:balanceOf(c,balances)})).filter(x=>x.balance>0).map(x=>Object.assign(x,aging(x.c,x.balance)))
    .filter(x=>x.oldest>=minAge&&(!picked||picked.includes(x.c.id))).sort((x,y)=>y.oldest-x.oldest||y.balance-x.balance);
}
function msg(x){
  const d=x.oldest>90?' (over 90 days)':x.oldest>0?' ('+x.oldest+' days)':'';
  return tpl().split('{name}').join(x.c.name).split('{amount}').join(fmt(x.balance)).split('{store}').join(store()).split('{days}').join(d);
}
const CH=[['whatsapp','💬'],['telegram','✈️'],['imo','🟣'],['sms','📱'],['more','📤']];
function row(x){
  const l=log()[x.c.id],lab=x.oldest>90?'90+ days':x.oldest+' days';
  return `<div class="card" style="margin:8px 0;padding:10px"><div class="flex-between"><b>${esc(x.c.name)}</b><b style="color:#dc3545">${fmt(x.balance)}</b></div>
  <small>${x.oldest>0?'Oldest debt about '+lab:'New debt'}${x.c.contact?' · '+esc(x.c.contact):' · no phone saved'}${l?' · reminded '+(age(l)?age(l)+'d ago':'today'):''}</small>
  <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap">${CH.map(c=>`<button class="btn btn-primary btn-sm" data-cashtracker-onclick="Receivables.remind('${esc(x.c.id)}','${c[0]}')">${c[1]}</button>`).join('')}</div></div>`;
}
function render(){
  const p=document.getElementById('tab-receivables');if(!p)return;
  const balances=balanceMap();
  const all=(State.customers||[]).map(c=>({c,balance:balanceOf(c,balances)})).filter(x=>x.balance>0).map(x=>Object.assign(x,aging(x.c,x.balance)));
  const tot=all.reduce((a,x)=>a+x.balance,0),bk=[0,0,0,0];all.forEach(x=>x.b.forEach((v,i)=>bk[i]+=v));
  const list=debtors(),L=['0-30','31-60','61-90','90+'];
  const chip=(v,t)=>`<button class="btn ${minAge===v?'btn-primary':'btn-outline'} btn-sm" data-cashtracker-onclick="Receivables.setAge(${v})">${t}</button>`;
  const left=list.filter(x=>log()[x.c.id]!==today()).length;
  p.innerHTML=`<div class="card"><div class="card-title">⏰ Overdue Payments</div><div class="flex-between"><span>Total owed to you</span><b style="color:#dc3545">${fmt(tot)}</b></div>
  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:8px;text-align:center">${bk.map((v,i)=>`<div><small>${L[i]} d</small><br><b>${fmt(v)}</b></div>`).join('')}</div>
  <small style="opacity:.7">Ages are estimated from credit sales. Older or opening balances count as 90+.</small></div>
  <div class="card"><div style="display:flex;gap:6px;flex-wrap:wrap">${chip(0,'All')}${chip(31,'31+ days')}${chip(61,'61+ days')}${chip(91,'90+ days')}<button class="btn btn-outline btn-sm" data-cashtracker-onclick="Receivables.pick()">☑ ${picked?'Selected ('+picked.length+')':'Choose customers'}</button>${picked?'<button class="btn btn-outline btn-sm" data-cashtracker-onclick="Receivables.clearPick()">✕</button>':''}</div>
  <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px"><button class="btn btn-success btn-sm" data-cashtracker-onclick="Receivables.next('whatsapp')">▶ Next reminder: WhatsApp (${left} left)</button><button class="btn btn-outline btn-sm" data-cashtracker-onclick="Receivables.next('telegram')">✈️</button><button class="btn btn-outline btn-sm" data-cashtracker-onclick="Receivables.next('imo')">🟣</button><button class="btn btn-outline btn-sm" data-cashtracker-onclick="Receivables.next('sms')">📱</button></div>
  <div style="margin-top:8px"><button class="btn btn-outline btn-sm" data-cashtracker-onclick="Receivables.editTpl()">✏️ Edit message</button> <button class="btn btn-outline btn-sm" data-cashtracker-onclick="Receivables.resetTpl()">↺ Reset</button></div></div>
  ${list.map(row).join('')||'<div class="empty-state">Nobody owes you in this range 🎉</div>'}`;
}
function send(x,ch){
  if(!window.ShareHub)return Toast.error('Share module not loaded');
  ShareHub.send(ch,msg(x),x.c.contact);
  const l=log();l[x.c.id]=today();localStorage.setItem(LOG,JSON.stringify(l));
}
const Receivables={
  render,
  setAge(v){minAge=v;render()},
  pick(){const balances=balanceMap();const a=(State.customers||[]).map(c=>({c,balance:balanceOf(c,balances)})).filter(x=>x.balance>0).map(x=>Object.assign(x,aging(x.c,x.balance)));
    MultiPick.open({title:'Who to remind',items:a.map(x=>({id:x.c.id,label:x.c.name,sub:fmt(x.balance)+' · '+(x.oldest>90?'90+':x.oldest)+' days'+(x.c.contact?'':' · no phone')})),selected:picked||a.map(x=>x.c.id),
      onDone:ids=>{picked=ids.length===a.length?null:ids;render()}})},
  clearPick(){picked=null;render()},
  remind(id,ch){const x=debtors().concat((State.customers||[]).filter(c=>c.id===id).map(c=>{const balance=balanceOf(c,balanceMap());return Object.assign({c,balance},aging(c,balance))}).filter(x=>x.balance>0)).find(y=>y.c.id===id);if(!x)return;
    if(ch==='sms'&&!x.c.contact)return Toast.warning('📱 No phone number saved for '+x.c.name);send(x,ch);render()},
  next(ch){const x=debtors().find(y=>log()[y.c.id]!==today()&&(ch!=='sms'||y.c.contact));
    if(!x)return Toast.success('✅ Everyone in this list was reminded today');
    Toast.show('Sending to '+x.c.name+'. Come back and tap Next for the following customer.','info');send(x,ch);render()},
  editTpl(){const v=prompt('Reminder message. You can use {name} {amount} {store} {days}',tpl());if(v&&v.trim()){localStorage.setItem(TPL,v.trim());Toast.success('Message saved')}},
  resetTpl(){localStorage.removeItem(TPL);Toast.success('Message reset')}
};
window.Receivables=Receivables;
return Receivables;});
})();
