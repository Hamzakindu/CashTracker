// STATEMENTS: balance sheet, receivable/payable aging, inventory value and cash flow, built from live balances.
(function(){'use strict';
const n=v=>Number(v)||0;
const esc=s=>Helpers.esc(String(s==null?'':s));
const fmt=v=>Helpers.formatCurrency(n(v));
const today=()=>Helpers.getToday();
const days=d=>{const t=new Date(String(d||'').slice(0,10)+'T00:00:00');return isNaN(t)?9999:Math.max(0,Math.floor((Date.now()-t)/864e5))};
const BUCKETS=[['0-30',0,30],['31-60',31,60],['61-90',61,90],['90+',91,1e9]];
const bucketOf=a=>BUCKETS.findIndex(b=>a>=b[1]&&a<=b[2]);
const out=()=>document.getElementById('statementsOutput');
const live=x=>!!x&&!['void','voided','cancelled','canceled','deleted'].includes(String(x.status||'').toLowerCase())&&x.voided!==true&&x.deleted!==true&&x.cancelled!==true&&x.deletedAt==null&&String(x.accountingStatus||'').toLowerCase()!=='void';
function projection(){if(typeof BusinessEngine==='undefined'||typeof BusinessEngine.calculate!=='function')return null;return BusinessEngine.calculate({products:State.products||[],sales:State.sales||[],purchases:State.purchases||[],customers:State.customers||[],suppliers:State.suppliers||[],directExpenses:State.directExpenses||[],returns:State.returns||[],stockHistory:State.stockHistory||[],paymentLedger:State.paymentLedger||[],auditLog:State.auditLog||[]})}
function partyBalanceMap(kind,projected){const list=kind==='customer'?projected?.customerBalanceDetails:projected?.supplierBalanceDetails;return new Map((list||[]).map(x=>[x.id,x]));}
function qualityNotice(p){const issues=p?.dataQuality?.issues||[];if(!issues.length)return '';return `<div class="card" style="border-left:4px solid var(--warning);margin-bottom:10px"><b>⚠️ Data quality warning</b><ul>${issues.map(x=>`<li>${esc(x.message)} (${x.count})</li>`).join('')}</ul><small>These warnings do not change your records. Resolve missing source history before relying on affected totals.</small></div>`;}
const table=(head,rows,foot)=>`<div style="overflow-x:auto"><table class="table" style="width:100%;font-size:.9rem"><thead><tr>${head.map((h,i)=>`<th style="text-align:${i?'right':'left'}">${h}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map((c,i)=>`<td style="text-align:${i?'right':'left'}">${c}</td>`).join('')}</tr>`).join('')}${foot?`<tr style="font-weight:700">${foot.map((c,i)=>`<td style="text-align:${i?'right':'left'}">${c}</td>`).join('')}</tr>`:''}</tbody></table></div>`;
function inventoryRows(){
  return (State.products||[]).filter(p=>n(p.stock)>0).map(p=>{
    const h=window.HistoricalCostEngine?.product({products:State.products||[],purchases:State.purchases||[],sales:State.sales||[],returns:State.returns||[],stockHistory:State.stockHistory||[]},p.id);
    const useHistorical=!!h&&h.reconciled&&h.stockValue!==null;
    return {p,qty:n(p.stock),cost:useHistorical?h.averageCost:n(p.buy),val:useHistorical?h.stockValue:n(p.stock)*n(p.buy),retail:n(p.stock)*n(p.sell),costBasis:useHistorical?(h.reliable?'historical weighted average':'weighted average; legacy estimate'):'current buy-price estimate',costEstimated:!useHistorical||!h.reliable};
  });
}
// Allocate an outstanding balance to the newest unpaid invoices first (older ones were paid first); the rest is older/opening debt.
function ageParty(balance,docs,getAmt){
  const b=[0,0,0,0];let left=n(balance);if(left<=0)return b;
  docs.sort((x,y)=>String(y.date).localeCompare(String(x.date)));
  for(const d of docs){if(left<=0)break;const a=Math.min(left,n(getAmt(d)));if(a<=0)continue;b[bucketOf(days(d.date))]+=a;left-=a}
  if(left>0)b[3]+=left;
  return b;
}
function agingReport(kind){
  const cust=kind==='customer';
  const p=projection(),balances=partyBalanceMap(kind,p);
  const parties=(cust?State.customers:State.suppliers)||[];
  const docs=cust?(State.sales||[]).filter(s=>live(s)&&n(s.debitRemaining)>0):(State.purchases||[]).filter(x=>live(x)&&n(x.debit)>0);
  const rows=[],tot=[0,0,0,0];
  parties.forEach(x=>{
    const detail=balances.get(x.id),balance=detail?detail.balance:n(x.balance);if(balance<=0)return;
    const mine=docs.filter(d=>(cust?d.customerId:d.supplierId)===x.id).map(d=>({date:d.date||d.createdAt,amt:cust?d.debitRemaining:d.debit}));
    const b=ageParty(balance,mine,d=>d.amt);b.forEach((v,i)=>tot[i]+=v);
    rows.push({name:x.name,b,total:balance,basis:detail?.basis||'legacy_cached_fallback'});
  });
  rows.sort((a,b)=>b.total-a.total);
  const grand=tot.reduce((a,v)=>a+v,0);
  return `<div class="card"><div class="card-title">${cust?'🧾 Who owes you':'📤 Who you owe'} — aging</div>
  <small>${cust?'Unpaid customer balances':'Unpaid supplier balances'} grouped by how old the invoice is. Payments are assumed to settle the oldest invoices first.</small>
  ${qualityNotice(p)}
  ${rows.length?table(['Name',...BUCKETS.map(b=>b[0]+' d'),'Total'],rows.map(r=>[esc(r.name),...r.b.map(fmt),`<b>${fmt(r.total)}</b>`]),['Total',...tot.map(fmt),fmt(grand)]):'<p>Nothing outstanding 🎉</p>'}</div>`;
}
function balanceSheet(){
  const cb=window.CashBanks?CashBanks.totals():{cash:0,bank:0,wallet:0,total:0};
  const p=projection();
  const rec=p?p.customerBalances:(State.customers||[]).reduce((a,c)=>a+Math.max(0,n(c.balance)),0);
  const inv=p?p.stockValue:inventoryRows().reduce((a,r)=>a+r.val,0);
  const supAdv=(State.suppliers||[]).reduce((a,s)=>a+n(s.supplierAdvance),0);
  const pay=p?p.supplierBalances:(State.suppliers||[]).reduce((a,s)=>a+Math.max(0,n(s.balance)),0);
  const cusAdv=(State.customers||[]).reduce((a,c)=>a+n(c.customerAdvance),0);
  const assets=cb.total+rec+inv+supAdv,liab=pay+cusAdv,eq=assets-liab;
  const noCost=inventoryRows().filter(r=>r.cost<=0).length;
  const journal=window.AccountingDoubleEntry;
  const journalAudit=journal?.audit?.();
  const tb=journal?.trialBalance?.();
  const byCode=new Map((tb?.rows||[]).map(x=>[x.code,x]));
  const capital=(byCode.get('3000')?.credit||0)-(byCode.get('3000')?.debit||0);
  const retained=(byCode.get('4000')?.credit||0)-(byCode.get('4000')?.debit||0)
    -((byCode.get('4100')?.debit||0)-(byCode.get('4100')?.credit||0))
    -((byCode.get('5000')?.debit||0)-(byCode.get('5000')?.credit||0))
    -((byCode.get('6000')?.debit||0)-(byCode.get('6000')?.credit||0));
  const recordedEquity=capital+retained, reconciliation=eq-recordedEquity;
  const returnWarnings=p?.dataQuality?.supplierReturnExcess||0;
  return `<div class="card"><div class="card-title">⚖️ Balance sheet — ${esc(today())}</div>
  ${journalAudit&&!journalAudit.ok?`<p style="color:var(--warning)">⚠️ Accounting journal has ${journalAudit.issues.length} issue(s). Review the double-entry audit before relying on this balance sheet.</p>`:''}
  ${returnWarnings?`<p style="color:var(--warning)">⚠️ ${returnWarnings} supplier return(s) exceed the derived payable. Confirm whether a supplier refund or advance is due; no excess advance is assumed.</p>`:''}
  ${table(['Assets',''],[['Cash',fmt(cb.cash)],['Bank',fmt(cb.bank)],['Mobile wallets',fmt(cb.wallet)],['Customers owe you',fmt(rec)],['Stock (at cost)',fmt(inv)],['Advances paid to suppliers',fmt(supAdv)]],['Total assets',fmt(assets)])}
  ${table(['Liabilities',''],[['You owe suppliers',fmt(pay)],['Customer credit / advances',fmt(cusAdv)]],['Total liabilities',fmt(liab)])}
  ${table(['Equity reconciliation',''],[['Owner capital / opening equity (journal)',fmt(capital)],['Accumulated net profit (journal estimate)',fmt(retained)],['Recorded equity subtotal',fmt(recordedEquity)],['Net assets (assets − liabilities)',fmt(eq)],['Unreconciled difference',fmt(reconciliation)]],null)}
  ${Math.abs(reconciliation)>0.01?`<p style="color:var(--warning)">⚠️ Equity does not yet reconcile by ${fmt(reconciliation)}. Review missing opening balances, legacy transactions, stock valuation and journal mappings. No automatic adjustment has been posted.</p>`:`<p>✅ Net assets agree with the journal-based equity estimate.</p>`}
  ${noCost?`<p style="color:var(--warning)">⚠️ ${noCost} product(s) in stock have no buying price, so stock value is understated.</p>`:''}
  ${qualityNotice(p)}
  <small>${p?`Customer and supplier balances are projected by BusinessEngine. Inventory: ${esc(p.stockValueBasis)}.`:'BusinessEngine unavailable; cached balances are shown.'} This is a management estimate, not a certified accounting close. Capital and retained earnings are derived from the read-only journal; differences are shown, never silently posted.</small></div>`;
}
function inventoryValue(){
  const p=projection(),rows=inventoryRows(),groups={};
  rows.forEach(r=>{const k=r.p.category||'(no category)';const g=groups[k]||(groups[k]={units:0,val:0,retail:0,items:0});g.units+=r.qty;g.val+=r.val;g.retail+=r.retail;g.items++});
  const list=Object.keys(groups).sort((a,b)=>groups[b].val-groups[a].val);
  const T=rows.reduce((a,r)=>({units:a.units+r.qty,val:a.val+r.val,retail:a.retail+r.retail}),{units:0,val:0,retail:0});
  const top=rows.slice().sort((a,b)=>b.val-a.val).slice(0,10);
  const noCost=rows.filter(r=>r.cost<=0);const estimatedCost=rows.filter(r=>r.costEstimated).length;
  return `<div class="card"><div class="card-title">📦 Inventory value</div>
  ${qualityNotice(p)}
  ${table(['Category','Items','Units','At cost','At selling price'],list.map(k=>[esc(k),groups[k].items,groups[k].units,fmt(groups[k].val),fmt(groups[k].retail)]),['Total',rows.length,T.units,fmt(T.val),fmt(T.retail)])}
  <p>Estimated margin if everything sells: <b>${fmt(T.retail-T.val)}</b></p><small>Uses perpetual weighted-average costing where source history reconciles. Products with missing legacy cost data or stock-history gaps are marked as estimates; this is not realized profit.</small>
  <div class="card-title" style="margin-top:10px">Top 10 by money tied up</div>
  ${table(['Product','Units','Cost each','Value'],top.map(r=>[esc(r.p.name),r.qty,fmt(r.cost),fmt(r.val)]))}
  ${noCost.length?`<p style="color:var(--warning)">⚠️ No buying price: ${noCost.slice(0,8).map(r=>esc(r.p.name)).join(', ')}${noCost.length>8?' …':''}</p>`:''}${estimatedCost?`<p style="color:var(--warning)">⚠️ ${estimatedCost} product(s) have estimated/incomplete historical cost. Reconcile opening stock and stock movements before relying on total valuation.</p>`:''}</div>`;
}

function exportRowsFromReport(){
  const host=out();if(!host)throw new Error('No financial report is currently displayed');
  const card=[...host.querySelectorAll('.card')].find(x=>x.querySelector('table'));if(!card)throw new Error('The current report has no exportable table content');
  const title=card.querySelector('.card-title')?.textContent?.trim()||'CashTracker Financial Report';
  const rows=[];
  card.querySelectorAll('table').forEach((tbl,ti)=>{
    if(ti)rows.push([]);
    tbl.querySelectorAll('tr').forEach(tr=>{const cells=[...tr.querySelectorAll('th,td')].map(td=>td.textContent.trim());if(cells.length)rows.push(cells)});
  });
  if(!rows.length)throw new Error('No report table data is available to export');
  const notes=[...card.querySelectorAll('small,p')].map(x=>x.textContent.trim()).filter(Boolean);
  const ranges=[...host.querySelectorAll('input[type=\"date\"]')].map(x=>`${x.id||'Date'}: ${x.value||'not set'}`);
  if(ranges.length)notes.unshift('Selected dates — '+ranges.join(' · '));
  return {title,rows,notes};
}
function xmlEscape(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;')}
function spreadsheetXml(report){
  const rows=[[report.title],...report.rows,...(report.notes.length?[[],['Notes'],...report.notes.map(x=>[x])]:[])];
  const body=rows.map((r,ri)=>'<Row>'+r.map(v=>{const raw=String(v==null?'':v).trim(),numeric=ri>0&&raw!==''&&/^-?\d+(?:\.\d+)?$/.test(raw);return `<Cell><Data ss:Type="${numeric?'Number':'String'}">${xmlEscape(raw)}</Data></Cell>`}).join('')+'</Row>').join('');
  return '<?xml version="1.0"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Styles><Style ss:ID="Default"><Alignment ss:Vertical="Center"/></Style></Styles><Worksheet ss:Name="Financial Report"><Table>'+body+'</Table></Worksheet></Workbook>';
}
function printableHtml(report){
  const rows=report.rows.map((r,i)=>'<tr>'+r.map(c=>`<${i===0?'th':'td'}>${xmlEscape(c)}</${i===0?'th':'td'}>`).join('')+'</tr>').join('');
  return `<!doctype html><html><head><meta charset="utf-8"><title>${xmlEscape(report.title)}</title><style>body{font:12px Arial,sans-serif;color:#172033;margin:28px}h1{font-size:22px;margin-bottom:6px}.brand{color:#526078;margin-bottom:22px}table{border-collapse:collapse;width:100%;margin:16px 0}th{background:#e9eef5;text-align:left}td,th{border:1px solid #cbd5e1;padding:9px}tr:nth-child(even) td{background:#f8fafc}.notes{font-size:10px;color:#475569;margin-top:18px;line-height:1.5}@media print{body{margin:12mm}button{display:none}}</style></head><body><div class="brand">CashTracker · Financial report</div><h1>${xmlEscape(report.title)}</h1><table>${rows}</table>${report.notes.map(n=>`<p class="notes">${xmlEscape(n)}</p>`).join('')}<script>window.onload=()=>window.print();</script></body></html>`;
}
function exportCurrentExcel(){try{const r=exportRowsFromReport();Helpers.downloadFile(spreadsheetXml(r),`cashtracker-${r.title.toLowerCase().replace(/[^a-z0-9]+/g,'-')}.xls`,'application/vnd.ms-excel');}catch(e){if(typeof Toast!=='undefined')Toast.warning(e.message||'Could not export report')}}
function exportCurrentPdf(){try{const r=exportRowsFromReport(),w=window.open('','_blank');if(!w){if(typeof Toast!=='undefined')Toast.warning('Allow pop-ups to print or save this report as PDF');return;}w.document.open();w.document.write(printableHtml(r));w.document.close();}catch(e){if(typeof Toast!=='undefined')Toast.warning(e.message||'Could not prepare PDF')}}
function exportToolbar(){return '<div class="card" style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn-outline btn-sm" data-cashtracker-onclick="Statements.exportCurrentPdf()">Print / Save PDF</button><button class="btn btn-outline btn-sm" data-cashtracker-onclick="Statements.exportCurrentExcel()">Export Excel</button></div>'}

function periodProfitLoss(from,to){
  const journal=window.AccountingDoubleEntry;
  if(!journal||typeof journal.trialBalance!=='function')return {available:false,rows:[],totals:{revenue:0,returns:0,cogs:0,expenses:0,gross:0,net:0}};
  const tb=journal.trialBalance(from||'',to||'');
  const map=new Map((tb.rows||[]).map(x=>[String(x.code),x]));
  const net=(code,normal)=>{const x=map.get(code)||{};return normal==='credit'?n(x.credit)-n(x.debit):n(x.debit)-n(x.credit)};
  const revenue=net('4000','credit'),returns=net('4100','debit'),cogs=net('5000','debit'),expenses=net('6000','debit');
  return {available:true,rows:tb.rows||[],totals:{revenue,returns,cogs,expenses,gross:revenue-returns-cogs,net:revenue-returns-cogs-expenses},audit:journal.audit?.(from||'',to||'')||null};
}
function profitLoss(from,to){
  const r=periodProfitLoss(from,to),t=r.totals;
  if(!r.available)return '<div class="card">Accounting journal is unavailable. No profit-and-loss statement was generated.</div>';
  return `<div class="card"><div class="card-title">📈 Profit &amp; loss — ${esc(from||'all dates')} to ${esc(to||'today')}</div>
  ${r.audit&&!r.audit.ok?`<p style="color:var(--warning)">⚠️ ${r.audit.issues.length} journal issue(s) found in this period. Review before relying on the result.</p>`:''}
  ${table(['Statement','Amount'],[['Sales revenue',fmt(t.revenue)],['Less: sales returns',fmt(t.returns)],['Net revenue',`<b>${fmt(t.revenue-t.returns)}</b>`],['Cost of goods sold',fmt(t.cogs)],['Gross profit',`<b>${fmt(t.gross)}</b>`],['Operating expenses',fmt(t.expenses)],['Net profit / (loss)',`<b>${fmt(t.net)}</b>`]],null)}
  <small>Derived from the accounting journal for the selected dates. Results are read-only and depend on source transaction mappings and journal completeness.</small></div>`;
}
function comparePeriods(from,to){
  if(!from||!to||from>to)return '<div class="card">Choose a valid start and end date for the current period.</div>';
  const start=new Date(from+'T00:00:00Z'),end=new Date(to+'T00:00:00Z');
  const span=Math.round((end-start)/86400000)+1,prevEnd=new Date(start.getTime()-86400000),prevStart=new Date(prevEnd.getTime()-(span-1)*86400000);
  const iso=d=>d.toISOString().slice(0,10),pf=iso(prevStart),pt=iso(prevEnd),a=periodProfitLoss(from,to),b=periodProfitLoss(pf,pt);
  if(!a.available||!b.available)return '<div class="card">Accounting journal is unavailable. Period comparison cannot be generated.</div>';
  const keys=[['Revenue','revenue'],['Sales returns','returns'],['Cost of goods sold','cogs'],['Gross profit','gross'],['Operating expenses','expenses'],['Net profit / (loss)','net']];
  const rows=keys.map(([label,key])=>{const cur=a.totals[key],prev=b.totals[key],delta=cur-prev,pct=Math.abs(prev)>0.000001?delta/Math.abs(prev)*100:null;return [label,fmt(prev),fmt(cur),fmt(delta),pct===null?'—':pct.toFixed(1)+'%']});
  return `<div class="card"><div class="card-title">📊 Period comparison</div><small>Current: ${esc(from)} to ${esc(to)} · Previous equal-length period: ${esc(pf)} to ${esc(pt)}</small>
  ${table(['Metric','Previous','Current','Change','Change %'],rows,null)}
  <small>Percentage change is omitted when the previous period is zero. This comparison is read-only and uses journal entries only.</small></div>`;
}
function cashFlow(from,to){
  const m=(State.moneyTransactions||[]).filter(t=>live(t)&&t.type!=='opening'&&t.sourceType!=='transfer'&&!/^transfer_/.test(t.type)&&(!from||String(t.date||'').slice(0,10)>=from)&&(!to||String(t.date||'').slice(0,10)<=to));
  const LBL={sale:'Sales',payment:'Customer / supplier payments',purchase:'Purchases',expense:'Expenses',return:'Customer refunds',manual:'Manual entries',sms:'Bank SMS'};
  const g={};m.forEach(t=>{const k=LBL[t.sourceType]||t.sourceType||'Other';const o=g[k]||(g[k]={i:0,o:0});const a=n(t.amount);if(['in','income','adjustment_in'].includes(t.type))o.i+=a;else o.o+=a});
  const keys=Object.keys(g),ti=keys.reduce((a,k)=>a+g[k].i,0),to2=keys.reduce((a,k)=>a+g[k].o,0);
  return `<div class="card"><div class="card-title">💸 Cash flow ${esc(from||'start')} → ${esc(to||'today')}</div>
  ${keys.length?table(['Source','Money in','Money out','Net'],keys.map(k=>[esc(k),fmt(g[k].i),fmt(g[k].o),fmt(g[k].i-g[k].o)]),['Total',fmt(ti),fmt(to2),fmt(ti-to2)]):'<p>No money movements in this period.</p>'}
  <small>Transfers between your own accounts are left out.</small></div>`;
}
const Statements={
  show(kind){
    const el=out();if(!el)return;
    try{
      if(kind==='balance')el.innerHTML=balanceSheet();
      else if(kind==='ar')el.innerHTML=agingReport('customer');
      else if(kind==='ap')el.innerHTML=agingReport('supplier');
      else if(kind==='inventory')el.innerHTML=inventoryValue();
      else if(kind==='pnl'||kind==='profitloss'){const d=new Date(),f=new Date(d.getFullYear(),d.getMonth(),1),iso=x=>new Date(x.getTime()-x.getTimezoneOffset()*6e4).toISOString().slice(0,10);el.innerHTML=`<div class="card"><div style="display:flex;gap:6px;flex-wrap:wrap;align-items:end"><div><label>From</label><input type="date" class="form-control" id="plFrom" value="${iso(f)}"></div><div><label>To</label><input type="date" class="form-control" id="plTo" value="${iso(d)}"></div><button class="btn btn-primary btn-sm" data-cashtracker-onclick="Statements.runProfitLoss()">Show</button><button class="btn btn-outline btn-sm" data-cashtracker-onclick="Statements.exportProfitLoss()">Export CSV</button><button class="btn btn-outline btn-sm" data-cashtracker-onclick="Statements.exportCurrentPdf()">PDF</button><button class="btn btn-outline btn-sm" data-cashtracker-onclick="Statements.exportCurrentExcel()">Excel</button></div></div><div id="plOut">${profitLoss(iso(f),iso(d))}</div>`;}
      else if(kind==='compare'){const d=new Date(),f=new Date(d.getFullYear(),d.getMonth(),1),iso=x=>new Date(x.getTime()-x.getTimezoneOffset()*6e4).toISOString().slice(0,10);el.innerHTML=`<div class="card"><div style="display:flex;gap:6px;flex-wrap:wrap;align-items:end"><div><label>From</label><input type="date" class="form-control" id="cmpFrom" value="${iso(f)}"></div><div><label>To</label><input type="date" class="form-control" id="cmpTo" value="${iso(d)}"></div><button class="btn btn-primary btn-sm" data-cashtracker-onclick="Statements.runComparison()">Compare</button><button class="btn btn-outline btn-sm" data-cashtracker-onclick="Statements.exportComparison()">Export CSV</button><button class="btn btn-outline btn-sm" data-cashtracker-onclick="Statements.exportCurrentPdf()">PDF</button><button class="btn btn-outline btn-sm" data-cashtracker-onclick="Statements.exportCurrentExcel()">Excel</button></div></div><div id="cmpOut">${comparePeriods(iso(f),iso(d))}</div>`;}
      else if(kind==='cashflow'){
        const d=new Date(),f=new Date(d.getFullYear(),d.getMonth(),1);const iso=x=>new Date(x.getTime()-x.getTimezoneOffset()*6e4).toISOString().slice(0,10);
        el.innerHTML=`<div class="card"><div style="display:flex;gap:6px;flex-wrap:wrap;align-items:end"><div><label>From</label><input type="date" class="form-control" id="cfFrom" value="${iso(f)}"></div><div><label>To</label><input type="date" class="form-control" id="cfTo" value="${iso(d)}"></div><button class="btn btn-primary btn-sm" data-cashtracker-onclick="Statements.runCash()">Show</button></div></div><div id="cfOut">${cashFlow(iso(f),iso(d))}</div>`;
      }
      if(!['pnl','profitloss','compare'].includes(kind))el.innerHTML=exportToolbar()+el.innerHTML;
    }catch(e){el.innerHTML='<div class="card">Could not build this report: '+esc(e.message||e)+'</div>';console.error(e)}
  },
  runCash(){const o=document.getElementById('cfOut');if(o)o.innerHTML=cashFlow(document.getElementById('cfFrom')?.value,document.getElementById('cfTo')?.value)},
  runProfitLoss(){const o=document.getElementById('plOut');if(o)o.innerHTML=profitLoss(document.getElementById('plFrom')?.value,document.getElementById('plTo')?.value)},
  runComparison(){const o=document.getElementById('cmpOut');if(o)o.innerHTML=comparePeriods(document.getElementById('cmpFrom')?.value,document.getElementById('cmpTo')?.value)},
  exportCurrentPdf,exportCurrentExcel,_spreadsheetXml:spreadsheetXml,_printableHtml:printableHtml,_exportRowsFromReport:exportRowsFromReport,
  exportProfitLoss(){const from=document.getElementById('plFrom')?.value||'',to=document.getElementById('plTo')?.value||'',r=periodProfitLoss(from,to);if(!r.available){if(typeof Toast!=='undefined')Toast.warning('Accounting journal unavailable');return;}const t=r.totals,csv='CashTracker Profit and Loss\nFrom,'+from+'\nTo,'+to+'\nMetric,Amount\nRevenue,'+t.revenue+'\nSales returns,'+t.returns+'\nGross profit,'+t.gross+'\nOperating expenses,'+t.expenses+'\nNet profit,'+t.net+'\n';Helpers.downloadFile(csv,'cashtracker-profit-loss.csv');},
  exportComparison(){const from=document.getElementById('cmpFrom')?.value||'',to=document.getElementById('cmpTo')?.value||'';if(!from||!to||from>to){if(typeof Toast!=='undefined')Toast.warning('Choose a valid date range');return;}const start=new Date(from+'T00:00:00Z'),end=new Date(to+'T00:00:00Z'),span=Math.round((end-start)/86400000)+1,pe=new Date(start.getTime()-86400000),ps=new Date(pe.getTime()-(span-1)*86400000),iso=d=>d.toISOString().slice(0,10),a=periodProfitLoss(from,to),b=periodProfitLoss(iso(ps),iso(pe));if(!a.available||!b.available){if(typeof Toast!=='undefined')Toast.warning('Accounting journal unavailable');return;}const keys=[['Revenue','revenue'],['Sales returns','returns'],['Cost of goods sold','cogs'],['Gross profit','gross'],['Operating expenses','expenses'],['Net profit','net']];let csv='CashTracker Period Comparison\nPrevious from,'+iso(ps)+'\nPrevious to,'+iso(pe)+'\nCurrent from,'+from+'\nCurrent to,'+to+'\nMetric,Previous,Current,Change\n';keys.forEach(([label,key])=>csv+=label+','+b.totals[key]+','+a.totals[key]+','+(a.totals[key]-b.totals[key])+'\n');Helpers.downloadFile(csv,'cashtracker-period-comparison.csv');},
  _periodProfitLoss:periodProfitLoss,_comparePeriods:comparePeriods,_ageParty:ageParty,_bucketOf:bucketOf,_projection:projection
};
window.Statements=Statements;
})();
