/* Money math: runtime values stay numeric for compatibility; persistent monetary fields are integer minor units. */
(function(){'use strict';
const KEYS=new Set(['amount','total','grandTotal','cost','profit','buy','sell','price','paid','debit','credit','debitRemaining','paymentReceived','advanceUsed','excessPayment','excessPaid','openingBalance','balance','difference','expectedBalance','actualBalance','refundPerUnit','totalRefund','costAmount','customerAdvance','supplierAdvance']);
const SCALE=100;
function minor(v){
 const n=Number(v);if(!Number.isFinite(n))return 0;
 // Parse the shortest decimal representation so decimal half-cents are not lost to binary floats.
 const m=String(v).trim().match(/^([+-]?)(\d+)(?:\.(\d*))?(?:e([+-]?\d+))?$/i);
 if(!m)return Math.round((n+Math.sign(n)*Number.EPSILON)*SCALE);
 const sign=m[1]==='-'?-1n:1n, frac=m[3]||'', exp=Number(m[4]||0);
 let digits=BigInt((m[2]+frac).replace(/^0+(?=\d)/,'')), shift=2-frac.length+exp;
 if(shift>=0)digits*=10n**BigInt(shift);
 else {const den=10n**BigInt(-shift),q=digits/den,r=digits%den;digits=q+(r*2n>=den?1n:0n);}
 const result=Number(sign*digits);return Number.isSafeInteger(result)?result:Math.round((n+Math.sign(n)*Number.EPSILON)*SCALE);
}
function major(v){const n=Number(v);return Number.isFinite(n)?n/SCALE:0}
function encode(value){
 if(Array.isArray(value))return value.map(encode);
 if(value&&typeof value==='object'){const out={};for(const [k,v] of Object.entries(value)){if(KEYS.has(k)&&typeof v==='number'&&Number.isFinite(v)){out[k+'Minor']=minor(v);continue;}out[k]=encode(v);}out.__moneyMinorV1=true;return out;}
 return value;
}
function decode(value){
 if(Array.isArray(value))return value.map(decode);
 if(value&&typeof value==='object'){const out={};for(const [k,v] of Object.entries(value)){if(k==='__moneyMinorV1')continue;if(k.endsWith('Minor')&&KEYS.has(k.slice(0,-5))){out[k.slice(0,-5)]=major(v);continue;}out[k]=decode(v);}return out;}
 return value;
}
function add(...vs){return major(vs.reduce((a,v)=>a+minor(v),0))} function sub(a,b){return major(minor(a)-minor(b))} function mul(a,b){const x=minor(a)*Number(b||0);return major(Math.round(x+Math.sign(x)*Number.EPSILON))} function div(a,b){const x=Number(b)?minor(a)/Number(b):0;return Number(b)?major(Math.round(x+Math.sign(x)*Number.EPSILON)):0} function round(v){return major(minor(v))} window.Money={SCALE,minor,major,encode,decode,add,sub,mul,div,round,format(v){return 'ETB '+major(minor(v)).toFixed(2)}};
})();
