/* CashTracker V8.3 - read-only financial integrity audit.
 * This module never changes balances or source transactions. It reports differences only.
 */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.FinancialAudit=api;})(typeof window!=='undefined'?window:globalThis,function(){
 'use strict';
 const num=v=>{const n=Number(v);return Number.isFinite(n)?n:0;};
 const hasVal=v=>v!==null&&v!==undefined&&v!==''&&Number.isFinite(Number(v));
 const live=x=>!!x&&!['void','voided','cancelled','canceled','deleted'].includes(String(x.status||'').toLowerCase())&&x.voided!==true&&x.deleted!==true&&x.cancelled!==true&&x.deletedAt==null;
 const cents=n=>Math.round((num(n)+Number.EPSILON)*100);
 const sum=(a,f)=>a.reduce((s,x)=>s+f(x),0);
 function balanceAudit(data={}){
  const issues=[];const auditLogIncomplete=(data.auditLog||[]).length>=5000;const customers=data.customers||[],suppliers=data.suppliers||[],sales=(data.sales||[]).filter(live),purchases=(data.purchases||[]).filter(live),returns=(data.returns||[]).filter(live),payments=(data.paymentLedger||[]).filter(live);
  const adjustmentInfo=(type,id)=>{const list=(data.auditLog||[]).filter(a=>a&&a.action==='balance_adjustment'&&a.entityType===type&&a.details&&a.details.entityId===id);return {total:sum(list,a=>num(a.details.balanceApplied)),incomplete:list.some(a=>a.details.balanceApplied==null||a.details.balanceApplied==='')};};
  customers.forEach(c=>{
   if(!c.id||c.id==='walkin')return;
   const partyPayments=payments.filter(p=>p.entityType==='customer'&&p.entityId===c.id&&p.sourceType==='payment'&&p.kind==='settlement');
   const adj=adjustmentInfo('customer',c.id);if(auditLogIncomplete||partyPayments.some(p=>p.balanceApplied==null||p.balanceApplied==='')||adj.incomplete){issues.push({type:'legacy_balance_history_incomplete',entityType:'customer',entityId:c.id,name:c.name||'',explanation:'Older settlement or adjustment records do not distinguish debt applied from excess advance. Cached balance is retained; reconcile this party before migrating its balance.'});return;}
   const partySales=sales.filter(s=>s.customerId===c.id);const saleDebt=sum(partySales,s=>num(s.debitRemaining));
   const settlements=sum(partyPayments,p=>num(p.balanceApplied));
   const returnOffsets=sum(returns.filter(r=>r.customerId===c.id&&!(r.returnType==='supplier_return'||r.type==='purchase'||r.sourceType==='purchase')),r=>num(r.arOffset));
   if(!hasVal(c.openingBalance)&&partySales.length===0){issues.push({type:'legacy_balance_opening_missing',entityType:'customer',entityId:c.id,name:c.name||'',explanation:'No opening balance or source sales are available to reconstruct this party balance. Cached balance is retained.'});return;}
   const expected=Math.max(0,num(c.openingBalance)+saleDebt-settlements-returnOffsets+adj.total);
   const actual=num(c.balance);
   if(cents(expected)!==cents(actual))issues.push({type:'customer_balance',entityId:c.id,name:c.name||'',expected,actual,difference:actual-expected,explanation:'Opening balance + unpaid sale balances − applied settlements − credit-return offsets + recorded adjustments. Legacy records may require review.'});
  });
  suppliers.forEach(s=>{
   if(!s.id)return;
   const partyPayments=payments.filter(p=>p.entityType==='supplier'&&p.entityId===s.id&&p.sourceType==='payment'&&p.kind==='settlement');
   const adj=adjustmentInfo('supplier',s.id);if(auditLogIncomplete||partyPayments.some(p=>p.balanceApplied==null||p.balanceApplied==='')||adj.incomplete){issues.push({type:'legacy_balance_history_incomplete',entityType:'supplier',entityId:s.id,name:s.name||'',explanation:'Older settlement or adjustment records do not distinguish debt applied from excess advance. Cached balance is retained; reconcile this party before migrating its balance.'});return;}
   const partyPurchases=purchases.filter(p=>p.supplierId===s.id);const purchaseDebt=sum(partyPurchases,p=>num(p.debit));
   const settlements=sum(partyPayments,p=>num(p.balanceApplied));
   const supplierReturns=returns.filter(r=>(r.returnType==='supplier_return'||r.type==='purchase'||r.sourceType==='purchase')&&(r.partyId===s.id||r.supplierId===s.id));
   const returnOffsets=sum(supplierReturns,r=>{const total=num(r.totalRefund??r.total??r.amount);const cash=r.refundMethod==='cash'?Math.min(total,Math.max(0,num(r.cashRefundAmount??r.refundAmount??total))):0;return total-cash;});
   if(!hasVal(s.openingBalance)&&partyPurchases.length===0){issues.push({type:'legacy_balance_opening_missing',entityType:'supplier',entityId:s.id,name:s.name||'',explanation:'No opening balance or source purchases are available to reconstruct this party balance. Cached balance is retained.'});return;}
   const expected=Math.max(0,num(s.openingBalance)+purchaseDebt-settlements-returnOffsets+adj.total);
   const actual=num(s.balance);
   if(cents(expected)!==cents(actual))issues.push({type:'supplier_balance',entityId:s.id,name:s.name||'',expected,actual,difference:actual-expected,explanation:'Opening balance + unpaid purchase balances − applied settlements + recorded adjustments. Legacy records may require review.'});
  });
  return issues;
 }
 function paymentAudit(data={}){
  const issues=[];const ledger=(data.paymentLedger||[]).filter(p=>live(p)&&p.kind!=='advance_applied'&&num(p.amountNumber??p.amount)>0);const moves=(data.moneyTransactions||[]).filter(live);
  const attempts=new Map();(data.paymentLedger||[]).filter(p=>live(p)&&p.idempotencyKey).forEach(p=>{const k=String(p.idempotencyKey);attempts.set(k,(attempts.get(k)||0)+1);});attempts.forEach((count,key)=>{if(count>1)issues.push({type:'payment_duplicate_idempotency_key',id:key,count,explanation:'More than one posted payment uses the same idempotency key. Review before changing balances.'});});
  const accountIds=new Set((data.cashAccounts||[]).filter(a=>a&&a.active!==false).map(a=>a.id));
  const ledgerIds=new Set(ledger.map(p=>p.id).filter(Boolean));
  ledger.forEach(p=>{
   const amount=num(p.amountNumber??p.amount),direction=p.entityType==='customer'?'in':'out';
   if(!p.accountId){issues.push({type:'payment_missing_account',id:p.id||'',name:p.entityName||'',amount,repairable:false,explanation:'Posted payment has no linked cash/bank account. The original account cannot be inferred safely.'});return;}
   if(accountIds.size&&!accountIds.has(p.accountId)){issues.push({type:'payment_account_not_found',id:p.id||'',name:p.entityName||'',accountId:p.accountId,amount,repairable:false,explanation:'The payment references an account that is missing or inactive. Select the correct account only after checking the original receipt or statement.'});}
   const linked=moves.filter(m=>p.id&&m.paymentId===p.id);
   if(linked.length===0){
    const fallback=moves.filter(m=>m.accountId===p.accountId&&m.sourceId===p.sourceId&&m.sourceType=== (p.sourceType==='payment'?'payment':p.kind==='sale_payment'?'sale_payment':p.kind==='purchase_payment'?'purchase_payment':p.sourceType));
    if(fallback.length===0)issues.push({type:'payment_missing_movement',id:p.id||'',name:p.entityName||'',entityType:p.entityType||'',entityId:p.entityId||'',accountId:p.accountId,amount,direction,date:p.date||'',method:p.method||'',repairable:false,suggestedAction:'Compare the receipt, bank statement or wallet statement, then record a separately approved correction if confirmed.',explanation:'Payment ledger entry has no matching cash/bank movement. A repair is suggested for review only; legacy links may be incomplete.'});
    else if(fallback.length>1)issues.push({type:'payment_duplicate_movement',id:p.id||'',name:p.entityName||'',amount:num(p.amountNumber??p.amount),count:fallback.length,explanation:'Multiple cash/bank movements appear linked to one payment.'});
   } else if(linked.length>1)issues.push({type:'payment_duplicate_movement',id:p.id||'',name:p.entityName||'',amount:num(p.amountNumber??p.amount),count:linked.length,explanation:'Multiple cash/bank movements reference the same payment ID.'});
   else {
    const m=linked[0],expectedDirection=p.entityType==='customer'?'in':'out';
    if(m.accountId!==p.accountId||Math.abs(num(m.amount)-num(p.amountNumber??p.amount))>0.005||m.type!==expectedDirection)issues.push({type:'payment_movement_mismatch',id:p.id||'',name:p.entityName||'',amount:num(p.amountNumber??p.amount),movementAmount:num(m.amount),explanation:'Payment and linked account movement differ in account, amount or direction.'});
   }
  });
  moves.filter(m=>m&&m.paymentId&&live(m)&&!ledgerIds.has(m.paymentId)).forEach(m=>issues.push({type:'payment_orphan_movement',id:m.paymentId,accountId:m.accountId,amount:num(m.amount),repairable:false,explanation:'Cash/bank movement points to a payment ledger ID that is not present among active payments. Check voided records and history before changing either record.'}));
  moves.filter(m=>live(m)&&m.accountId&&accountIds.size&&!accountIds.has(m.accountId)).forEach(m=>issues.push({type:'movement_account_not_found',id:m.id||'',accountId:m.accountId,amount:num(m.amount),repairable:false,explanation:'Money movement references a missing or inactive cash/bank account.'}));
  return issues;
 }
 function advanceAudit(data={}){
  const issues=[],ledger=(data.paymentLedger||[]).filter(live),sales=(data.sales||[]).filter(live),purchases=(data.purchases||[]).filter(live),returns=(data.returns||[]).filter(live);
  const applied=(type,id)=>sum(ledger.filter(p=>p.kind==='advance_applied'&&p.entityType===type&&p.entityId===id),p=>num(p.amountNumber??p.amount));
  (data.customers||[]).forEach(c=>{if(c.openingAdvance==null)return;const incoming=sum(ledger.filter(p=>p.entityType==='customer'&&p.entityId===c.id&&p.sourceType==='payment'),p=>num(p.advanceAdded))+sum(sales.filter(s=>s.customerId===c.id),s=>num(s.excessPayment))+sum(returns.filter(r=>r.customerId===c.id&&!(r.returnType==='supplier_return'||r.type==='purchase'||r.sourceType==='purchase')),r=>num(r.advanceAdded));const expected=Math.max(0,num(c.openingAdvance)+incoming-applied('customer',c.id)),actual=num(c.customerAdvance);if(cents(expected)!==cents(actual))issues.push({type:'customer_advance_balance',entityType:'customer',entityId:c.id,name:c.name||'',expected,actual,difference:actual-expected,explanation:'Opening advance + recorded payment/sale/return advances − advance applications. Review edited or legacy transactions before correction.'});});
  (data.suppliers||[]).forEach(s=>{if(s.openingAdvance==null)return;const incoming=sum(ledger.filter(p=>p.entityType==='supplier'&&p.entityId===s.id&&p.sourceType==='payment'),p=>num(p.advanceAdded))+sum(purchases.filter(p=>p.supplierId===s.id),p=>num(p.excessPaid));const expected=Math.max(0,num(s.openingAdvance)+incoming-applied('supplier',s.id)),actual=num(s.supplierAdvance);if(cents(expected)!==cents(actual))issues.push({type:'supplier_advance_balance',entityType:'supplier',entityId:s.id,name:s.name||'',expected,actual,difference:actual-expected,explanation:'Opening advance + recorded payment/purchase advances − advance applications. Review edited or legacy transactions before correction.'});});
  return issues;
 }
 function sourceAudit(data={}){
  const issues=[],sales=(data.sales||[]).filter(live),purchases=(data.purchases||[]).filter(live),ledger=(data.paymentLedger||[]).filter(live);
  ledger.filter(p=>p.kind==='advance_applied'||p.kind==='sale_payment'||p.kind==='purchase_payment').forEach(p=>{
   const isSale=p.entityType==='customer',expectedType=isSale?'sale':'purchase',sourceId=p.sourceId;
   const list=isSale?sales:purchases,source=list.find(x=>x.id===sourceId),amount=num(p.amountNumber??p.amount);
   if(!sourceId){issues.push({type:'payment_source_missing_id',id:p.id||'',entityType:p.entityType||'',amount,repairable:false,explanation:'Payment or advance application has no source transaction ID. Check the original sale or purchase before editing history.'});return;}
   if(!source){issues.push({type:'payment_source_not_found',id:p.id||'',sourceType:expectedType,sourceId,amount,repairable:false,explanation:'The linked sale or purchase is not present among active transactions. It may be voided, archived or missing; do not recreate it automatically.'});return;}
   const partyId=isSale?source.customerId:source.supplierId;
   if(partyId&&partyId!==p.entityId)issues.push({type:'payment_source_party_mismatch',id:p.id||'',sourceId,entityId:p.entityId,sourcePartyId:partyId,amount,repairable:false,explanation:'The payment or advance application is linked to a transaction belonging to a different customer or supplier.'});
   if(!(amount>0))issues.push({type:'payment_source_invalid_amount',id:p.id||'',sourceId,amount,repairable:false,explanation:'The source-linked payment or advance application has a non-positive amount.'});
  });
  return issues;
 }
 function moneyMovementAudit(data={}){
  const issues=[],accounts=list(data.cashAccounts),moves=list(data.moneyTransactions).filter(live),ids=new Map();
  moves.forEach(m=>{
   if(m.id){ids.set(String(m.id),(ids.get(String(m.id))||0)+1);}
   const amount=num(m.amount),type=String(m.type||'');
   if(!(amount>0))issues.push({type:'money_movement_invalid_amount',id:m.id||'',accountId:m.accountId||'',amount,explanation:'Active cash/bank movement must have a positive amount.'});
   if(!m.accountId)issues.push({type:'money_movement_missing_account',id:m.id||'',amount,explanation:'Active money movement has no account assignment.'});
   if(!['opening','in','income','transfer_in','adjustment_in','out','expense','transfer_out','adjustment_out'].includes(type))issues.push({type:'money_movement_unknown_type',id:m.id||'',movementType:type,explanation:'Movement type is not recognized by the cash/bank balance engine.'});
  });
  ids.forEach((count,id)=>{if(count>1)issues.push({type:'money_movement_duplicate_id',id,count,explanation:'Multiple active cash/bank movements share the same record ID.'});});
  const accountIds=new Set(accounts.map(a=>String(a.id)));
  moves.forEach(m=>{if(m.accountId&&accountIds.size&&!accountIds.has(String(m.accountId)))issues.push({type:'money_movement_account_missing',id:m.id||'',accountId:m.accountId,amount:num(m.amount),explanation:'Movement points to an account that does not exist.'});});
  accounts.forEach(a=>{
   if(a.openingBalance!==undefined&&(!Number.isFinite(Number(a.openingBalance))||Number(a.openingBalance)<0))issues.push({type:'cash_account_invalid_opening',accountId:a.id||'',name:a.name||'',actual:a.openingBalance,explanation:'Cash/bank opening balance must be a finite non-negative amount.'});
   const expected=round2(num(a.openingBalance)+sum(moves.filter(m=>m.accountId===a.id&&m.type!=='opening'),m=>['in','income','transfer_in','adjustment_in'].includes(m.type)?num(m.amount):['out','expense','transfer_out','adjustment_out'].includes(m.type)?-num(m.amount):0));
   const cached=a.currentBalance??a.balance;
   if(cached!==undefined&&cached!==null&&cached!==''&&cents(expected)!==cents(cached))issues.push({type:'cash_account_balance_mismatch',accountId:a.id||'',name:a.name||'',expected,actual:num(cached),difference:num(cached)-expected,explanation:'Cached account balance differs from opening balance plus active cash/bank movements. The audit does not change either value.'});
  });
  return issues;
 }
 function transactionAudit(data={}){
  const issues=[];
  [['sale',data.sales],['purchase',data.purchases],['expense',data.directExpenses],['return',data.returns]].forEach(([kind,items])=>{
   const seen=new Map();list(items).filter(live).forEach(x=>{
    const id=String(x.id||x.transactionId||'');if(id){seen.set(id,(seen.get(id)||0)+1);}
    const amount=kind==='expense'?num(x.amount):num(x.total??x.totalRefund??x.amount);
    if(!Number.isFinite(Number(kind==='expense'?x.amount:(x.total??x.totalRefund??x.amount)))||amount<0)issues.push({type:'transaction_invalid_amount',transactionType:kind,id,name:x.partyName||x.customerName||x.supplierName||'',amount,explanation:'Active source transaction has a missing, non-finite or negative total.'});
   });
   seen.forEach((count,id)=>{if(count>1)issues.push({type:'transaction_duplicate_id',transactionType:kind,id,count,explanation:'More than one active source transaction has the same ID.'});});
  });
  return issues;
 }
 function inventoryAudit(data={}){
  const engine=globalThis.HistoricalCostEngine;
  if(!engine||typeof engine.summary!=='function')return [];
  const summary=engine.summary(data);
  return (summary.issues||[]).map(i=>({type:'inventory_'+String(i.code||'issue').toLowerCase(),productId:i.productId||'',name:i.productName||'',expected:i.expected,actual:i.actual,explanation:i.code==='STOCK_QUANTITY_MISMATCH'?'Historical source transactions and stock adjustments do not reconcile to the current product quantity. No stock was changed.':'Inventory valuation contains estimated or incomplete historical cost data; review the source movements before relying on stock value.'}));
 }
 function journalAudit(){
  const engine=globalThis.AccountingDoubleEntry;
  if(!engine||typeof engine.audit!=='function')return [];
  const result=engine.audit();
  const issues=(result.issues||[]).map(i=>({...i,type:'journal_'+i.type,explanation:'Derived double-entry journal check failed. Review the linked source transaction; this audit does not post or reverse entries.'}));
  if(engine.meta?.().postingLedgerEnabled===true&&engine.ledgerAudit){const saved=engine.ledgerAudit();(saved.issues||[]).forEach(i=>issues.push({...i,type:'posting_ledger_'+i.type,explanation:'Persistent posting ledger integrity check failed. Existing posted entries were not changed; review the source and use an explicit reversal where appropriate.'}));}
  return issues;
 }
 function round2(v){return Math.round((num(v)+Number.EPSILON)*100)/100;}
 function list(v){return Array.isArray(v)?v:[];}
 function run(data={}){
  const balance=balanceAudit(data),payment=paymentAudit(data),advance=advanceAudit(data),source=sourceAudit(data),money=moneyMovementAudit(data),transactions=transactionAudit(data),inventory=inventoryAudit(data),journal=journalAudit(),issues=balance.concat(payment,advance,source,money,transactions,inventory,journal);
  return Object.freeze({ok:issues.length===0,issueCount:issues.length,issues:Object.freeze(issues),counts:Object.freeze({customers:list(data.customers).length,suppliers:list(data.suppliers).length,sales:list(data.sales).filter(live).length,purchases:list(data.purchases).filter(live).length,payments:list(data.paymentLedger).filter(live).length,moneyMovements:list(data.moneyTransactions).filter(live).length,inventoryIssues:inventory.length,journalIssues:journal.length}),checkedAt:new Date().toISOString(),readOnly:true,scope:'party balances, payment links, advances, source links, cash/bank movements, transaction identity, historical inventory, derived journal and persistent posting ledger'});
 }
 return Object.freeze({run,balanceAudit,paymentAudit,advanceAudit,sourceAudit,moneyMovementAudit,transactionAudit,inventoryAudit,journalAudit});
});
