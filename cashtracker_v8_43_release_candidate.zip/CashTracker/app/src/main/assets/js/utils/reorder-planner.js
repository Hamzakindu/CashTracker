// V8.34: deterministic, read-only stock demand and reorder calculations.
(function(root){'use strict';
  const validDate = value => {
    if (!value) return null;
    const d = new Date(String(value).length === 10 ? String(value) + 'T12:00:00' : value);
    return Number.isNaN(d.getTime()) ? null : d;
  };
  const active = row => row && row.voided !== true && row.status !== 'void' && row.status !== 'deleted';
  function supplierLink(product, supplierId){
    return (Array.isArray(product?.supplierLinks) ? product.supplierLinks : []).find(x => String(x.supplierId) === String(supplierId)) || {};
  }
  function priceFor(product, supplierId, suppliers, purchases){
    const link = supplierLink(product, supplierId);
    const quote = Number(link.quotedPrice);
    if (Number.isFinite(quote) && quote > 0) return {price:quote, source:'quote'};
    const rows=[];
    (purchases||[]).filter(p=>active(p)&&String(p.supplierId)===String(supplierId)).forEach(p=>(p.items||[]).forEach(i=>{
      if(String(i.productId)===String(product.id)){const cost=Number(i.cost??i.unitCost??0);if(cost>0)rows.push({cost,date:String(p.date||p.createdAt||'')});}
    }));
    rows.sort((a,b)=>b.date.localeCompare(a.date));
    if(rows.length)return {price:rows[0].cost,source:'last purchase'};
    const buy=Number(product.buy||0);
    return {price:Number.isFinite(buy)&&buy>0?buy:0,source:buy>0?'product cost':'missing'};
  }
  function build(options={}){
    const products=options.products||[], sales=options.sales||[], suppliers=options.suppliers||[], purchases=options.purchases||[];
    const days=Math.max(7,Math.min(365,Number(options.windowDays)||30));
    const cover=Math.max(1,Math.min(180,Number(options.coverDays)||30));
    const now=validDate(options.asOf)||new Date();
    const start=new Date(now.getTime()-days*86400000);
    const branchId=options.branchId==null?'':String(options.branchId);
    const branchMode=!!branchId;
    const demand=new Map(); let unassignedSales=0, consideredSales=0;
    for(const sale of sales){
      if(!active(sale))continue;
      const date=validDate(sale.date||sale.createdAt);
      if(!date||date<start||date>now)continue;
      const sid=sale.branchId==null||sale.branchId===''?'':String(sale.branchId);
      if(branchMode&&sid!==branchId){if(!sid)unassignedSales++;continue;}
      consideredSales++;
      for(const item of sale.items||[]){const q=Number(item.quantity)||0;if(q>0&&item.productId!=null)demand.set(String(item.productId),(demand.get(String(item.productId))||0)+q);}
    }
    const rows=products.filter(p=>p&&!p.archived).map(product=>{
      const sold=Number(demand.get(String(product.id))||0), daily=sold/days, stock=Number(product.stock)||0;
      const min=Math.max(0,Number(product.minStock??5)||0);
      const links=Array.isArray(product.supplierLinks)?product.supplierLinks:[];
      const ids=(Array.isArray(product.supplierIds)&&product.supplierIds.length?product.supplierIds:links.map(x=>x.supplierId)).map(String).filter((id,i,a)=>a.indexOf(id)===i);
      const leadTimes=ids.map(id=>Number(supplierLink(product,id).leadTimeDays)||0).filter(n=>n>0);
      const lead=leadTimes.length?Math.min(...leadTimes):7;
      const safety=Math.max(min*2,daily*7);
      const target=Math.ceil(daily*(cover+lead)+safety);
      const reorderQty=Math.max(0,target-stock);
      const choices=ids.map(id=>{
        const supplier=suppliers.find(s=>String(s.id)===id); if(!supplier)return null;
        const link=supplierLink(product,id), pricing=priceFor(product,id,suppliers,purchases);
        const available=link.availability||'unknown';
        return {supplierId:id,supplierName:supplier.name||'Supplier',price:pricing.price,priceSource:pricing.source,availability:available,leadTimeDays:Number(link.leadTimeDays)||7,preferred:String(product.preferredSupplierId||'')===id,eligible:available!=='unavailable'};
      }).filter(Boolean).sort((a,b)=>(a.eligible===b.eligible?0:a.eligible?-1:1)||(a.price||Infinity)-(b.price||Infinity)||(a.leadTimeDays-b.leadTimeDays));
      const chosen=choices.find(x=>x.preferred&&x.eligible)||choices.find(x=>x.eligible)||null;
      const cost=chosen?.price||0, sell=Number(product.sell)||0;
      return {productId:String(product.id),name:product.name||'Unnamed product',category:product.category||'',stock,minStock:min,soldInPeriod:sold,averageDaily:daily,leadTimeDays:lead,coverDays:cover,targetStock:target,reorderQty,estimatedUnitCost:cost,estimatedPurchaseCost:reorderQty*cost,estimatedUnitProfit:sell-cost,estimatedGrossProfit:reorderQty*(sell-cost),marginPercent:sell>0?((sell-cost)/sell)*100:null,supplierOptions:choices,selectedSupplierId:chosen?.supplierId||'',selectedSupplierName:chosen?.supplierName||'No linked supplier',priceSource:chosen?.priceSource||'missing',status:reorderQty>0?'reorder':stock<=min?'low':'healthy',hasSupplier:ids.length>0};
    }).sort((a,b)=>{const rank={reorder:0,low:1,healthy:2};return rank[a.status]-rank[b.status]||b.estimatedPurchaseCost-a.estimatedPurchaseCost||a.name.localeCompare(b.name);});
    return {rows,windowDays:days,coverDays:cover,branchId,branchMode,unassignedSales,consideredSales,stockScope:'current workspace stock; not independently branch-allocated',summary:{products:rows.length,toReorder:rows.filter(x=>x.reorderQty>0).length,estimatedCost:rows.reduce((n,x)=>n+x.estimatedPurchaseCost,0),estimatedGrossProfit:rows.reduce((n,x)=>n+x.estimatedGrossProfit,0)}};
  }
  root.ReorderPlanner={build,priceFor};
})(typeof window!=='undefined'?window:globalThis);
