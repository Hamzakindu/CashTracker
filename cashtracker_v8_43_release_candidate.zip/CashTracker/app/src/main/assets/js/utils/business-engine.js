/* CashTracker V8.4 - centralized, read-only business projections.
 * Source records remain authoritative; this module never mutates them or persists derived values.
 */
(function(root,factory){const api=factory(root);if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.BusinessEngine=api;})(typeof window!=='undefined'?window:globalThis,function(root){
 'use strict';
 const n=v=>{const x=Number(v);return v!==null&&v!==undefined&&v!==''&&Number.isFinite(x)?x:0;};
 const has=v=>v!==null&&v!==undefined&&v!==''&&Number.isFinite(Number(v));
 const rows=v=>Array.isArray(v)?v:[];
 const live=x=>!!x&&!['void','voided','cancelled','canceled','deleted'].includes(String(x.status||'').toLowerCase())&&x.voided!==true&&x.deleted!==true&&x.cancelled!==true&&x.deletedAt==null;
 const sum=(list,fn)=>list.reduce((a,x)=>a+fn(x),0);
 const round2=v=>Math.round((v+Number.EPSILON)*100)/100;
 function itemAmount(i){return has(i.amount)?n(i.amount):n(i.price)*n(i.quantity);}
 function itemCost(i){if(has(i.costAmount))return n(i.costAmount);const unit=i.costPriceAtSale??i.cost;if(has(unit)&&has(i.quantity))return n(unit)*n(i.quantity);if(has(i.profit))return round2(itemAmount(i)-n(i.profit));return null;}
 function saleCost(s){if(has(s.cost))return n(s.cost);const items=rows(s.items);if(items.length){const costs=items.map(itemCost);if(costs.every(x=>x!==null))return sum(costs,x=>x);}if(has(s.profit)){const total=has(s.total)?n(s.total):sum(items,itemAmount);return round2(total-n(s.profit));}return null;}
 function saleExpense(s){return n(s.expenses&&typeof s.expenses==='object'?s.expenses.amount:0);}
 function adjustmentInfo(data,type,id){const list=rows(data.auditLog).filter(a=>a&&a.action==='balance_adjustment'&&a.entityType===type&&a.details&&a.details.entityId===id);return {total:sum(list,a=>n(a.details.balanceApplied)),incomplete:list.some(a=>!has(a.details.balanceApplied))};}
 function derivePartyBalances(data,kind){
  const isCustomer=kind==='customer', entities=rows(isCustomer?data.customers:data.suppliers), tx=rows(isCustomer?data.sales:data.purchases).filter(live), returns=rows(data.returns).filter(live), ledger=rows(data.paymentLedger).filter(live);
  const out=[];let total=0,legacyFallbackCount=0;
  for(const entity of entities){
   if(!entity||(isCustomer&&entity.id==='walkin'))continue;
   const related=entity.id?tx.filter(t=>(isCustomer?t.customerId:t.supplierId)===entity.id):[];
   const debt=sum(related,t=>n(isCustomer?t.debitRemaining:t.debit));
   const partyPayments=entity.id?ledger.filter(p=>p.entityType===kind&&p.entityId===entity.id&&p.sourceType==='payment'&&p.kind==='settlement'):[];
   const legacySettlementDataIncomplete=partyPayments.some(p=>!has(p.balanceApplied));
   const settlements=sum(partyPayments,p=>n(p.balanceApplied));
   const offsets=isCustomer?sum(returns.filter(r=>r.customerId===entity.id&&r.returnType!=='supplier_return'),r=>n(r.arOffset)):sum(returns.filter(r=>(r.returnType==='supplier_return'||r.type==='purchase'||r.sourceType==='purchase')&&(r.partyId===entity.id||r.supplierId===entity.id)),r=>{const total=n(r.totalRefund??r.total??r.amount);const cash=r.refundMethod==='cash'?Math.min(total,Math.max(0,n(r.cashRefundAmount??r.refundAmount??total))):0;return total-cash;});
   const opening=n(entity.openingBalance);
   const adjustment=entity.id?adjustmentInfo(data,kind,entity.id):{total:0,incomplete:false};
   const auditLogIncomplete=rows(data.auditLog).length>=5000;
   const hasSourceBase=!!entity.id&&(has(entity.openingBalance)||related.length>0);
   const hasEvidence=hasSourceBase||partyPayments.length>0||adjustment.total!==0||adjustment.incomplete||offsets!==0;
   const canDerive=hasSourceBase&&!legacySettlementDataIncomplete&&!adjustment.incomplete&&!auditLogIncomplete;
   // Legacy entities can have a manually carried balance without its opening-balance source.
   // Preserve that cached value rather than pretending the missing history is zero.
   const gross=round2(opening+debt-settlements-offsets+adjustment.total);
   const derived=canDerive?Math.max(0,gross):round2(n(entity.balance));
   if(!canDerive&&(Math.abs(n(entity.balance))>0.005||legacySettlementDataIncomplete))legacyFallbackCount++;
   total+=derived;out.push(Object.freeze({id:entity.id,name:entity.name||'',balance:derived,unappliedReturn:!isCustomer&&canDerive?Math.max(0,round2(-gross)):0,cachedBalance:round2(n(entity.balance)),difference:round2(n(entity.balance)-derived),basis:canDerive?'derived':'legacy_cached_fallback',hasEvidence,legacySettlementDataIncomplete,legacyAdjustmentDataIncomplete:adjustment.incomplete}));
  }
  return Object.freeze({total:round2(total),entities:Object.freeze(out),legacyFallbackCount});
 }
 // Allocate a party's reconciled outstanding balance to the newest unpaid source
 // documents. Settlements are assumed to clear oldest debt first. Any remainder
 // without a dated source (opening balance, adjustment, or legacy amount) is 90+.
 function allocateAging(balance,entries,amountOf,dateOf,asOf){
  const buckets=[0,0,0,0];let remaining=Math.max(0,round2(n(balance))),oldest=0;
  const today=asOf instanceof Date?new Date(asOf.getFullYear(),asOf.getMonth(),asOf.getDate()):new Date();
  const day=today.getTime();
  const dated=rows(entries).map((entry,index)=>{
   const raw=String(dateOf?dateOf(entry):entry&&entry.date||'').slice(0,10);
   const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(raw);
   const dt=m?new Date(Number(m[1]),Number(m[2])-1,Number(m[3])):null;
   const valid=!!dt&&!Number.isNaN(dt.getTime());
   const age=valid?Math.max(0,Math.floor((day-dt.getTime())/86400000)):91;
   return {entry,index,amount:Math.max(0,round2(n(amountOf?amountOf(entry):entry&&entry.amount))),age,valid};
  }).filter(x=>x.amount>0).sort((a,b)=>{
   if(a.valid!==b.valid)return a.valid? -1:1;
   if(!a.valid)return a.index-b.index;
   return String(dateOf?dateOf(b.entry):b.entry.date||'').localeCompare(String(dateOf?dateOf(a.entry):a.entry.date||''));
  });
  for(const x of dated){if(remaining<=0.005)break;const applied=Math.min(remaining,x.amount);remaining=round2(remaining-applied);const bucket=x.age<=30?0:x.age<=60?1:x.age<=90?2:3;buckets[bucket]=round2(buckets[bucket]+applied);oldest=Math.max(oldest,x.age);}
  if(remaining>0.005){buckets[3]=round2(buckets[3]+remaining);oldest=Math.max(oldest,91);}
  return Object.freeze({b:Object.freeze(buckets),oldest,unallocated:remaining,total:round2(buckets.reduce((a,x)=>a+x,0))});
 }
 function calculate(data={}){
  const products=rows(data.products).filter(live),sales=rows(data.sales).filter(live),purchases=rows(data.purchases).filter(live),expenses=rows(data.directExpenses).filter(live),returns=rows(data.returns).filter(live);
  const salesTotal=sum(sales,s=>n(s.total??sum(rows(s.items),i=>n(i.amount??n(i.price)*n(i.quantity)))));
  const purchaseTotal=sum(purchases,p=>n(p.total??sum(rows(p.items),i=>n(i.amount??n(i.cost??i.price)*n(i.quantity)))));
  const expenseTotal=sum(expenses,e=>n(e.amount??e.total));
  const saleExpenseTotal=sum(sales,s=>saleExpense(s));
  const costs=sales.map(saleCost),costKnown=costs.every(x=>x!==null),cogs=costKnown?sum(costs,x=>x):null;
  const legacyProfitCostInferences=sales.filter(s=>has(s.profit)&&!has(s.cost)&&rows(s.items).some(i=>!has(i.costAmount)&&!has(i.costPriceAtSale)&&!has(i.cost)&&!has(i.profit)) || (has(s.profit)&&!has(s.cost)&&!rows(s.items).length)).length;
  const customerReturns=returns.filter(r=>!(r.returnType==='supplier_return'||r.type==='purchase'||r.sourceType==='purchase'));
  const supplierReturns=returns.filter(r=>r.returnType==='supplier_return'||r.type==='purchase'||r.sourceType==='purchase');
  const returnsTotal=sum(customerReturns,r=>n(r.totalRefund??r.total??r.amount));
  const purchaseReturnsTotal=sum(supplierReturns,r=>n(r.totalRefund??r.total??r.amount));
  const returnedCost=sum(customerReturns,r=>n(r.costAmount));
  const returnCostComplete=customerReturns.every(r=>has(r.costAmount)&&r.costEstimated!==true);
  const netSales=round2(salesTotal-returnsTotal);
  const netCogs=(cogs===null||!returnCostComplete)?null:round2(cogs-returnedCost);
  const grossProfit=netCogs===null?null:round2(netSales-netCogs);
  const netProfit=netCogs===null?null:round2(grossProfit-expenseTotal-saleExpenseTotal);
  const customer=derivePartyBalances(data,'customer'),supplier=derivePartyBalances(data,'supplier');
  const received=sum(sales,s=>n(s.paymentReceived)),paid=sum(purchases,p=>n(p.paid));
  const stockQty=sum(products,p=>n(p.stock));
  const legacyStockValue=sum(products,p=>n(p.stock)*n(p.buy));
  const historicalStock= root&&root.HistoricalCostEngine&&typeof root.HistoricalCostEngine.summary==='function' ? root.HistoricalCostEngine.summary(data) : null;
  const stockValue=historicalStock&&historicalStock.totalStockValue!==null?historicalStock.totalStockValue:legacyStockValue;
  const stockValueBasis=historicalStock&&historicalStock.totalStockValue!==null ? (historicalStock.complete?'perpetual weighted-average from source transactions':'weighted-average projection with estimated legacy costs') : 'estimate using current product buy price; stock history does not reconcile';
  const issues=[];
  const supplierReturnExcess=supplier.entities.filter(x=>x.unappliedReturn>0.005);
  if(supplierReturnExcess.length)issues.push({code:'SUPPLIER_RETURN_EXCEEDS_PAYABLE',count:supplierReturnExcess.length,message:'One or more supplier returns exceed the derived payable. Confirm whether the supplier owes a refund or credit; the excess is not automatically posted as a supplier advance.'});
  if(!costKnown)issues.push({code:'SALE_COST_UNKNOWN',count:costs.filter(x=>x===null).length,message:'Profit is unavailable for one or more sales because historical cost is missing.'});
  if(!returnCostComplete)issues.push({code:'RETURN_COST_UNKNOWN',count:returns.filter(r=>!has(r.costAmount)||r.costEstimated===true).length,message:'Profit is unavailable because one or more returned items have missing or estimated historical cost.'});
  if(legacyProfitCostInferences)issues.push({code:'LEGACY_PROFIT_COST_INFERRED',count:legacyProfitCostInferences,message:'Historical cost was inferred from a stored legacy profit value for some sales; verify those older records if precision is important.'});
  if(products.some(p=>n(p.stock)<0))issues.push({code:'NEGATIVE_STOCK',count:products.filter(p=>n(p.stock)<0).length,message:'One or more products have negative stock.'});
  if(customer.legacyFallbackCount||supplier.legacyFallbackCount)issues.push({code:'LEGACY_BALANCE_FALLBACK',count:customer.legacyFallbackCount+supplier.legacyFallbackCount,message:'Some balances have incomplete legacy settlement/adjustment detail, truncated audit history or no source history; cached balances are shown for those parties.'});
  if(historicalStock&&historicalStock.unreconciledCount)issues.push({code:'STOCK_HISTORY_MISMATCH',count:historicalStock.unreconciledCount,message:'Historical stock movements do not reconcile to current product quantities for some products; historical valuation is unavailable for those products.'});
  if(historicalStock&&historicalStock.estimatedCount)issues.push({code:'STOCK_COST_ESTIMATED',count:historicalStock.estimatedCount,message:'Some inventory costs use estimated legacy opening or movement costs. Reconcile opening stock and source records before relying on the valuation.'});
  return Object.freeze({
   counts:Object.freeze({products:products.length,sales:sales.length,purchases:purchases.length,expenses:expenses.length,returns:returns.length}),
   salesTotal:round2(salesTotal),netSales,returnsTotal:round2(returnsTotal),purchaseReturnsTotal:round2(purchaseReturnsTotal),netPurchases:round2(purchaseTotal-purchaseReturnsTotal),purchaseTotal:round2(purchaseTotal),expenseTotal:round2(expenseTotal),saleExpenseTotal:round2(saleExpenseTotal),
   receivedFromSales:round2(received),paidForPurchases:round2(paid),cogs:cogs===null?null:round2(cogs),returnedCost:round2(returnedCost),netCogs,grossProfit,netProfit,
   stockQty,stockValue:round2(stockValue),stockValueBasis,
   customerBalances:customer.total,supplierBalances:supplier.total,customerBalanceDetails:customer.entities,supplierBalanceDetails:supplier.entities,
   dataQuality:Object.freeze({costComplete:costKnown&&returnCostComplete,unknownCostSales:costs.filter(x=>x===null).length,returnCostComplete,unknownCostReturns:customerReturns.filter(r=>!has(r.costAmount)||r.costEstimated===true).length,legacyProfitCostInferences,hasNegativeStock:products.some(p=>n(p.stock)<0),hasCancelledRecords:rows(data.sales).some(x=>x&&!live(x)),hasReturns:returns.length>0,stockValueIsEstimate:!historicalStock||!historicalStock.complete,stockValuationIssues:historicalStock?.issues||[],legacyBalanceFallbacks:customer.legacyFallbackCount+supplier.legacyFallbackCount,supplierReturnExcess:supplierReturnExcess.length,issues:Object.freeze(issues)})
  });
 }
 return Object.freeze({calculate,derivePartyBalances,allocateAging,isActive:live,itemCost,saleCost});
});
