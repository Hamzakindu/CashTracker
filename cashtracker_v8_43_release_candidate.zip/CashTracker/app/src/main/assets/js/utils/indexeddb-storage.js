/* CashTracker durable storage: localStorage is the authoritative synchronous store.
 * IndexedDB is maintained as a durable mirror and recovery cache when available.
 */
(function(){'use strict';
const DB='cashtracker_v3',VER=1,STORE='records';let dbPromise=null;let writeQueue=Promise.resolve();let lastWriteError=null;let idbUnavailable=false;const cache=new Map();
function open(){if(dbPromise)return dbPromise;dbPromise=new Promise((resolve,reject)=>{if(!window.indexedDB){idbUnavailable=true;return reject(new Error('IndexedDB unavailable'));}const r=indexedDB.open(DB,VER);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(STORE))r.result.createObjectStore(STORE,{keyPath:'key'});};r.onsuccess=()=>resolve(r.result);r.onerror=()=>{idbUnavailable=true;reject(r.error||new Error('IndexedDB open failed'));};r.onblocked=()=>{idbUnavailable=true;reject(new Error('IndexedDB open blocked'));};});return dbPromise}
async function put(key,value){cache.set(key,value);const job=writeQueue.then(async()=>{const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).put({key,value,updatedAt:Date.now()});tx.oncomplete=()=>resolve(true);tx.onerror=()=>reject(tx.error||new Error('IndexedDB write failed'));tx.onabort=()=>reject(tx.error||new Error('IndexedDB write aborted'));});}).catch(e=>{lastWriteError=e;throw e;});writeQueue=job.catch(()=>{});return job}
async function putMany(entries){
 const job=writeQueue.then(async()=>{const db=await open();return new Promise((resolve,reject)=>{
   const tx=db.transaction(STORE,'readwrite'),store=tx.objectStore(STORE),stamp=Date.now();
   entries.forEach(x=>store.put({key:x.key,value:x.value,updatedAt:stamp}));
   tx.oncomplete=()=>{entries.forEach(x=>cache.set(x.key,x.value));resolve(true)};tx.onerror=()=>reject(tx.error||new Error('IndexedDB batch write failed'));tx.onabort=()=>reject(tx.error||new Error('IndexedDB batch write aborted'));
 });}).catch(e=>{lastWriteError=e;throw e;});
 writeQueue=job.catch(()=>{});return job;
}
async function get(key){if(cache.has(key))return cache.get(key);const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readonly'),r=tx.objectStore(STORE).get(key);r.onsuccess=()=>{const v=r.result?.value;if(r.result)cache.set(key,v);resolve(v)};r.onerror=()=>reject(r.error||new Error('IndexedDB read failed'));})}
async function remove(key){cache.delete(key);const job=writeQueue.then(async()=>{const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).delete(key);tx.oncomplete=()=>resolve(true);tx.onerror=()=>reject(tx.error||new Error('IndexedDB delete failed'));tx.onabort=()=>reject(tx.error||new Error('IndexedDB delete aborted'));});}).catch(e=>{lastWriteError=e;throw e;});writeQueue=job.catch(()=>{});return job}
async function allForProfile(pid){const prefix='SMDB_'+pid+'_';const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readonly'),req=tx.objectStore(STORE).getAll();req.onsuccess=()=>{const out=req.result.filter(x=>String(x.key).startsWith(prefix));out.forEach(x=>cache.set(x.key,x.value));resolve(out)};req.onerror=()=>reject(req.error||new Error('IndexedDB read failed'));})}
async function quota(){if(!navigator.storage?.estimate)return null;try{return await navigator.storage.estimate()}catch(e){return null}}
async function bootstrap(){
 try{await open();const pid=localStorage.getItem('currentProfileId')||'default';const idbRows=await allForProfile(pid);const idbKeys=new Set(idbRows.map(x=>x.key));
   // localStorage is the authoritative recovery copy. When both stores contain a key, localStorage wins.
   for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.startsWith('SMDB_'+pid+'_')){try{await put(k,JSON.parse(localStorage.getItem(k)||'null'))}catch(e){console.warn('IDB local mirror refresh failed',k,e)}}}
   // Preserve IDB-only keys so older data is still available when localStorage has no copy.
   idbRows.forEach(x=>{if(!localStorage.getItem(x.key)) cache.set(x.key,x.value);});
   return true;
 }catch(e){console.warn('IndexedDB durable mirror unavailable; localStorage fallback active:',e.message);return false}
}
async function checkAndWarn(){const q=await quota();if(q?.quota&&q?.usage&&q.usage/q.quota>.9){Toast?.warning?.('Storage is over 90% full. Export a backup and free space soon.');return false}return true}
async function flush(){await writeQueue;const error=lastWriteError;lastWriteError=null;if(error&&!idbUnavailable)throw error;return {ok:!idbUnavailable,fallback:idbUnavailable,error:error?.message||null};}
window.StorageIDB={open,put,putMany,get,remove,quota,bootstrap,checkAndWarn,flush,cache,has:key=>cache.has(key)};
})();
