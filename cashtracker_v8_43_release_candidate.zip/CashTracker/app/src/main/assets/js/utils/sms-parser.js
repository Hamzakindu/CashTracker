// Shared bank SMS parser used by the Web/PWA path and Node tests.
(function(){'use strict';
const BANKS=[[/\bcommercial bank of ethiopia\b/i,'CBE'],[/\bcbe\b/i,'CBE'],[/\bawash\b/i,'Awash'],[/\bdashen\b/i,'Dashen'],[/\bbank of abyssinia\b/i,'BOA'],[/\bboa\b/i,'BOA'],[/\btelebirr\b/i,'Telebirr'],[/\bsafaricom\b/i,'Safaricom'],[/\bmpesa\b/i,'M-Pesa']];
const DEB=/\b(?:debited|debit|spent|purchase|withdrawn|withdrawal|paid|payment|sent|charged|deducted|transferred|transfer|bought|outgoing)\b/i;
const CRE=/\b(?:credited|credit|received|deposit|salary|refund|cashback|incoming)\b/i;
const ACTION=/(?:\b(?:debited|debit|spent|purchase|withdrawn|withdrawal|paid|payment|sent|charged|deducted|transferred|transfer|bought|outgoing|credited|credit|received|deposit|salary|refund|cashback|incoming)\b)/i;
const BAL=/\b(?:current\s+balance|available\s+balance|avl\.?\s*bal(?:ance)?|balance|bal)\s*(?:is|:)?\s*(?:etb|birr|br)?\s*([0-9][0-9,]*(?:\.[0-9]+)?)/i;
const REF=/\b(?:ref(?:erence)?|txn(?:\.?|\s*id)?|transaction\s*id|trx)\s*[:#-]?\s*([A-Za-z0-9-]{4,40})/i;
const AMOUNT_LABEL=/\b(?:amount|amt|transaction\s+amount|debit(?:ed)?|credit(?:ed)?|spent|paid|received|withdrawn|sent|transferred)\b\s*(?:is|:|=)?\s*(?:etb|birr|br)?\s*([0-9][0-9,]*(?:\.[0-9]+)?)/i;
const CURR=/(?:\b(?:etb|birr|br|rs\.?|inr|usd|egp|kes|ngn|sar|aed|eur|gbp)\b|[$€£₦₹])\s*([0-9][0-9,]*(?:\.[0-9]+)?)/i;
const CURR_AFTER=/([0-9][0-9,]*(?:\.[0-9]+)?)\s*(?:\b(?:etb|birr|br|rs|inr|usd|egp|kes|ngn|sar|aed|eur|gbp)\b|[$€£₦₹])/i;
function num(x){return Number(String(x).replace(/,/g,''))}
function detectBank(t){return BANKS.find(([re])=>re.test(t))?.[1]||''}
function parse(body){
 if(window.CashTrackerCore?.parseSms){const parsed=window.CashTrackerCore.parseSms(String(body||''));if(parsed)return parsed;}
 const t=String(body||'').trim();if(!t)return null;
 const bank=detectBank(t),bm=t.match(BAL),b=bm?t.replace(bm[0],' '):t;
 // Ignore date/reference numbers: prefer an explicitly labelled amount, then currency amount.
 const labelled=b.match(AMOUNT_LABEL),currency=b.match(CURR)||b.match(CURR_AFTER);
 const amount=labelled?num(labelled[1]):currency?num(currency[1]):null;
 if(!(amount>0)||!Number.isFinite(amount)||!ACTION.test(b))return null;
 const lower=b.toLowerCase();
 const sentToReceivedBy=/\bsent\b[\s\S]{0,80}\breceived\s+by\b/i.test(lower);
 const receivedBySent=/\breceived\s+by\b[\s\S]{0,80}\bsent\b/i.test(lower);
 let dir='out';
 if(sentToReceivedBy)dir='out';
 else if(receivedBySent)dir='in';
 else {const d=lower.search(DEB),c=lower.search(CRE);dir=c>=0&&(d<0||c<d)?'in':'out';}
 const wm=b.match(/(?:\bat\b|\bto\b|\bfrom\b|@|towards)\s+([A-Za-z0-9&.'\- ]{2,40}?)(?=\s+(?:on|using|via|ref|bal|a\/c|acct|card|dated|with|your|and|txn|transaction)\b|[.,;(]|$)/i);
 return {amount,dir,who:wm?wm[1].trim():'',bal:bm?num(bm[1]):null,reference:(t.match(REF)||[])[1]||'',bankName:bank};
}
window.BankSmsParser={parse,detectBank};
if(typeof globalThis!=='undefined')globalThis.BankSmsParser=globalThis.BankSmsParser||{parse,detectBank};
})();
