/* CashTracker V8.6 - Perpetual weighted-average inventory costing.
 * Read-only projection. It never rewrites historical sales, purchases or stock movements.
 * New stock movements should carry sourceId/unitCost metadata; legacy movements are
 * reconstructed from source transactions where possible and explicitly marked estimated.
 */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.HistoricalCostEngine=api;
})(typeof window!=='undefined'?window:globalThis,function(){
  'use strict';
  const list=x=>Array.isArray(x)?x:[];
  const num=x=>{const n=Number(x);return x!==null&&x!==undefined&&x!==''&&Number.isFinite(n)?n:0;};
  const has=x=>x!==null&&x!==undefined&&x!==''&&Number.isFinite(Number(x));
  const round=x=>Math.round((x+Number.EPSILON)*100)/100;
  const active=x=>!!x&&!['void','voided','cancelled','canceled','deleted'].includes(String(x.status||'').toLowerCase())&&x.voided!==true&&x.deleted!==true&&x.cancelled!==true&&x.deletedAt==null;
  const date=x=>String(x?.date||x?.createdAt||'0000-01-01').slice(0,10);
  const stamp=x=>String(x?.createdAt||x?.timestamp||'');
  function itemUnitCost(i){
    if(has(i.costPriceAtSale))return num(i.costPriceAtSale);
    if(has(i.cost))return num(i.cost);
    if(has(i.costAmount)&&num(i.quantity)>0)return num(i.costAmount)/num(i.quantity);
    if(has(i.price)&&i.sourceType==='purchase')return num(i.price);
    if(has(i.amount)&&num(i.quantity)>0)return num(i.amount)/num(i.quantity);
    return null;
  }
  function product(data,productId){
    const p=list(data.products).find(x=>x&&String(x.id)===String(productId));
    if(!p)return null;
    const events=[];let sequence=0;let estimated=false;const issues=[];
    const push=e=>events.push({...e,sequence:sequence++});
    let openingQty=has(p.initialStock)?num(p.initialStock):0;
    let openingCost=has(p.openingCost)?num(p.openingCost):(has(p.initialCost)?num(p.initialCost):num(p.buy));
    let openingEstimated=!has(p.openingCost)&&!has(p.initialCost)&&openingQty!==0;
    // Some older imports omitted initialStock. Infer the opening quantity from the earliest
    // recorded stock movement, but label the inferred opening cost/quantity as legacy-estimated.
    if(!has(p.initialStock)){
      const old=list(data.stockHistory).filter(h=>String(h.productId)===String(productId)).slice().sort((a,b)=>date(a).localeCompare(date(b))||stamp(a).localeCompare(stamp(b)));
      if(old.length&&has(old[0].previousStock)){openingQty=num(old[0].previousStock);openingEstimated=openingQty!==0;}
    }
    if(openingQty!==0)push({kind:'opening',date:'0000-01-01',timestamp:'',quantity:openingQty,unitCost:openingCost,estimated:openingEstimated,sourceId:'opening:'+productId});

    list(data.purchases).filter(active).forEach(tx=>list(tx.items).forEach((i,idx)=>{
      if(String(i.productId)!==String(productId))return;
      const q=num(i.quantity),c=itemUnitCost({...i,sourceType:'purchase'});
      if(q>0)push({kind:'purchase',date:date(tx),timestamp:stamp(tx),quantity:q,unitCost:c,estimated:c===null,sourceId:tx.id||tx.transactionId||'',sourceItemId:i.id||idx});
    }));
    list(data.sales).filter(active).forEach(tx=>list(tx.items).forEach((i,idx)=>{
      if(String(i.productId)!==String(productId))return;
      const q=num(i.quantity),c=itemUnitCost(i);
      if(q>0)push({kind:'sale',date:date(tx),timestamp:stamp(tx),quantity:-q,unitCost:c,estimated:c===null,sourceId:tx.id||tx.transactionId||'',sourceItemId:i.id||idx});
    }));
    list(data.returns).filter(active).forEach((r,idx)=>{
      if(String(r.productId)!==String(productId))return;
      const q=num(r.quantity),c=q>0&&has(r.costAmount)?num(r.costAmount)/q:null;
      if(q>0)push({kind:'return',date:date(r),timestamp:stamp(r),quantity:q,unitCost:c,estimated:c===null||r.costEstimated===true||String(r.costBasis||'').startsWith('estimated'),sourceId:r.id||r.transactionId||'',sourceItemId:idx});
    });
    // Source transactions above are authoritative for purchase/sale/return quantities.
    // Keep only independent adjustments and calculator stock operations from stockHistory.
    const transactionTypes=new Set(['purchase','purchase-reversal','purchase-void','purchase-restore','sale','sale-reversal','sale-void','sale-restore','return']);
    list(data.stockHistory).filter(h=>String(h.productId)===String(productId)).forEach(h=>{
      const type=String(h.type||'adjustment').toLowerCase();
      if(transactionTypes.has(type))return;
      const q=num(h.change);if(!q)return;
      push({kind:type==='customer-return'?'return':(type==='supplier-return'?'supplier-return':'adjustment'),date:date(h),timestamp:stamp(h),quantity:q,unitCost:has(h.unitCost)?num(h.unitCost):null,estimated:!has(h.unitCost),sourceId:h.sourceId||h.id||'',reason:h.reason||''});
    });
    events.sort((a,b)=>a.date.localeCompare(b.date)||a.timestamp.localeCompare(b.timestamp)||a.sequence-b.sequence);

    let qty=0,avg=0,value=0,known=true;const rows=[];let cogs=0,returnCost=0;
    for(const e of events){
      const beforeQty=qty,beforeAvg=avg;let unit=e.unitCost;
      if(e.estimated){estimated=true;issues.push({code:'MOVEMENT_COST_ESTIMATED',sourceId:e.sourceId,kind:e.kind});}
      if(e.kind==='opening'){
        qty=e.quantity;avg=unit??0;value=qty*avg;if(e.estimated){estimated=true;issues.push({code:'OPENING_COST_ESTIMATED',sourceId:e.sourceId});}
      } else if(e.quantity>0){
        if(unit===null){unit=avg>0?avg:null;known=false;estimated=true;issues.push({code:'MOVEMENT_COST_ESTIMATED',sourceId:e.sourceId,kind:e.kind});}
        if(unit===null)unit=0;
        if(e.kind==='purchase'){
          if(qty>0){avg=((qty*avg)+(e.quantity*unit))/(qty+e.quantity);}
          else if(qty+e.quantity>0){avg=unit;}
          qty+=e.quantity;value=qty*avg;
        } else {
          if(qty>0){avg=((qty*avg)+(e.quantity*unit))/(qty+e.quantity);}
          else if(qty+e.quantity>0){avg=unit;}
          qty+=e.quantity;value=qty*avg;
          if(e.kind==='return')returnCost+=e.quantity*unit;
        }
      } else if(e.quantity<0){
        const outQty=-e.quantity;
        if(unit===null){unit=avg>0?avg:null;known=false;estimated=true;issues.push({code:'SALE_COST_ESTIMATED',sourceId:e.sourceId});}
        // A backdated sale or a later backdated purchase can make the stored sale snapshot
        // differ from the reconstructed average at that date. Never rewrite the sale; disclose it.
        if(e.kind==='sale'&&unit!==null&&avg>0&&Math.abs(unit-avg)>0.010001){known=false;issues.push({code:'SALE_COST_SNAPSHOT_MISMATCH',sourceId:e.sourceId,stored:round(unit),projected:round(avg)});}
        // Use the moving average at the time of issue for inventory valuation. A saved sale-line
        // cost is compared, not used to rewrite the historical moving-average inventory value.
        const issueCost=avg>0?avg:(unit??0);
        if(e.kind==='sale')cogs+=outQty*(unit!==null?unit:issueCost);
        qty-=outQty;value=qty*issueCost; // retain last known average while stock is negative
        if(qty>0)value=qty*avg;
      }
      rows.push(Object.freeze({kind:e.kind,date:e.date,sourceId:e.sourceId,quantity:e.quantity,unitCost:unit===null?null:round(unit),averageBefore:round(beforeAvg),averageAfter:round(avg),stockBefore:round(beforeQty),stockAfter:round(qty),estimated:!!e.estimated}));
    }
    const current=num(p.stock),reconciled=Math.abs(qty-current)<0.000001;
    if(!reconciled)issues.push({code:'STOCK_QUANTITY_MISMATCH',expected:round(current),projected:round(qty)});
    const reliable=reconciled&&known&&!estimated;
    return Object.freeze({productId:p.id,name:p.name||'',stock:current,projectedStock:round(qty),averageCost:round(avg),stockValue:reconciled?round(current*avg):null,retailValue:round(current*num(p.sell)),potentialMargin:reconciled?round(current*(num(p.sell)-avg)):null,cogs:round(cogs),returnedCost:round(returnCost),reconciled,reliable,estimated:!reliable,issues:Object.freeze(issues),rows:Object.freeze(rows)});
  }
  function summary(data){
    const products=list(data.products).filter(active),items=products.map(p=>product(data,p.id)).filter(Boolean);
    const positive=items.filter(x=>x.stock>0),unreconciled=items.filter(x=>!x.reconciled),estimated=items.filter(x=>x.estimated);
    const total=items.every(x=>x.reconciled)?round(items.reduce((s,x)=>s+(x.stockValue||0),0)):null;
    return Object.freeze({totalStockValue:total,productCount:items.length,reconciledCount:items.length-unreconciled.length,unreconciledCount:unreconciled.length,estimatedCount:estimated.length,complete:unreconciled.length===0&&estimated.length===0,products:Object.freeze(items),issues:Object.freeze(items.flatMap(x=>x.issues.map(i=>({...i,productId:x.productId,productName:x.name}))))});
  }
  return Object.freeze({product,summary,isActive:active});
});
