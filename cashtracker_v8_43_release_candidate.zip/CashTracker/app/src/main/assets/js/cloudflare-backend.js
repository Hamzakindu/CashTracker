// CASH TRACKER CLOUD - CLOUDFLARE WORKERS + D1
// Offline-first. Telegram/BotSync remains completely independent.
(function(){
  'use strict';
  const STORE_NAMES = ['products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger','expenseTypes','directExpenses','returns','calculations','stockHistory','auditLog','accountingMeta','cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','periodClosures','branches','staffUsers','branchAccessMeta'];
  const TOKEN_KEY='stockpro_cloudflare_session';
  const EMAIL_KEY='stockpro_cloud_email';
  const URL_KEY='cashtracker_cloudflare_worker_url';
  const PASS_KEY='cashtracker_cloud_passphrase_session';
  const DEVICE_KEY='stockpro_cloud_device_id';
  const STATUS_ID='cloudSyncStatus';
  // Top-level records in these stores receive stable cross-device identities.
  // IDs are preserved through encrypted snapshots and legacy restore.
  const IDENTITY_STORES=new Set(['products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger','directExpenses','returns','stockHistory','auditLog','cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','periodClosures','branches','staffUsers']);
  let url=(window.CASH_TRACKER_CLOUDFLARE?.WORKER_URL||localStorage.getItem(URL_KEY)||'').replace(/\/+$/,'');
  const CloudSync={
    ready:false,busy:false,queue:new Set(),timer:null,initialized:false,passphrase:null,suppressQueue:false,changeSeq:0,cloudHead:null,
    init(){
      if(this.initialized)return; this.initialized=true;
      if(!localStorage.getItem(DEVICE_KEY)) localStorage.setItem(DEVICE_KEY,'dev_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,10));
      this.patchStorage(); this.updateHeader();
      if(url){this.setStatus('☁️ Cloudflare ready'); this.restoreSession();}
      else this.setStatus('☁️ Cloudflare not configured');
    },
    configure(workerUrl){
      try{const u=new URL(workerUrl.trim()); if(u.protocol!=='https:')throw new Error('Worker URL must use HTTPS'); url=u.origin; localStorage.setItem(URL_KEY,url); window.CASH_TRACKER_CLOUDFLARE.WORKER_URL=url; this.setStatus('☁️ Cloudflare ready'); this.updateHeader(); return true;}catch(e){Toast.error(e.message);return false;}
    },
    getUrl(){return url||localStorage.getItem(URL_KEY)||'';},
    token(){return sessionStorage.getItem(TOKEN_KEY)||'';},
    email(){return localStorage.getItem(EMAIL_KEY)||'';},
    setStatus(text){const el=document.getElementById(STATUS_ID);if(el)el.textContent=text;},
    updateHeader(){
      const el=document.getElementById(STATUS_ID); if(!el)return;
      if(!this.getUrl())el.textContent='☁️ Cloud: not configured';
      else if(this.ready)el.textContent='☁️ Cloudflare: signed in';
      else el.textContent='☁️ Cloudflare: not signed in';
    },
    async request(path,opts={}){
      const base=this.getUrl(); if(!base)throw new Error('Configure the Cloudflare Worker URL first.');
      const headers=Object.assign({'Content-Type':'application/json'},opts.headers||{});
      const token=this.token(); if(token)headers.Authorization='Bearer '+token;
      const r=await fetch(base+path,Object.assign({},opts,{headers}));
      let data=null; try{data=await r.json();}catch(e){data={};}
      if(!r.ok)throw new Error(data.error||('Cloudflare request failed ('+r.status+')'));
      return data;
    },
    async register(email,password){
      this.configure(this.getUrl());
      if(!email||!password)throw new Error('Email and password are required.');
      if(password.length<8)throw new Error('Cloud password must be at least 8 characters.');
      const data=await this.request('/api/register',{method:'POST',body:JSON.stringify({email,password})});
      sessionStorage.setItem(TOKEN_KEY,data.token); localStorage.setItem(EMAIL_KEY,email); this.passphrase=password; this.ready=true; this.syncBlocked=false; await this.refreshCloudRevision(); this.updateHeader();
      Toast.success('☁️ Cloudflare account created'); return data;
    },
    async signIn(email,password){
      if(!email||!password)throw new Error('Email and password are required.');
      if(password.length<8)throw new Error('Cloud password must be at least 8 characters.');
      const data=await this.request('/api/login',{method:'POST',body:JSON.stringify({email,password})});
      sessionStorage.setItem(TOKEN_KEY,data.token); localStorage.setItem(EMAIL_KEY,email); this.passphrase=password; this.ready=true; this.syncBlocked=false; await this.refreshCloudRevision(); this.updateHeader();
      if(!this.syncBlocked&&localStorage.getItem('cashtracker_cloud_sync_pending_'+(State.currentProfileId||'default'))==='1')this.queueStore('products');
      Toast.success('☁️ Signed in to CashTracker Cloud'); return data;
    },
    async restoreSession(){
      if(!this.token())return;
      try{const data=await this.request('/api/me');this.ready=!!data.ok;if(this.ready){await this.refreshCloudRevision();if(!this.syncBlocked&&localStorage.getItem('cashtracker_cloud_sync_pending_'+(State.currentProfileId||'default'))==='1')this.queueStore('products');}this.updateHeader();}
      catch(e){sessionStorage.removeItem(TOKEN_KEY);this.ready=false;this.updateHeader();}
    },
    async unlock(){
      if(this.passphrase&&this.passphrase.length>=8)return this.passphrase;
      const p=prompt('Enter your Cloudflare CashTracker password to unlock encrypted cloud data:');
      if(!p)throw new Error('Cloud password was cancelled.');
      if(p.length<8)throw new Error('Cloud password must be at least 8 characters.');
      this.passphrase=p; try{sessionStorage.setItem(PASS_KEY,'unlocked');}catch(e){} return p;
    },
    revisionKey(){return 'cashtracker_cloud_revision_'+(State.currentProfileId||'default')+'_'+(this.email()||'').toLowerCase();},
    getKnownRevision(){const v=Number(localStorage.getItem(this.revisionKey()));return Number.isSafeInteger(v)&&v>=0?v:0;},
    setKnownRevision(v){this.cloudRevision=Number(v)||0;localStorage.setItem(this.revisionKey(),String(this.cloudRevision));},
    async refreshCloudRevision(){
      const data=await this.request('/api/snapshots/'+encodeURIComponent(State.currentProfileId||'default'));
      const remote=Number(data.revision||0), knownRaw=localStorage.getItem(this.revisionKey());
      this.cloudHead={exists:!!data.exists,revision:remote,updatedAt:Number(data.updatedAt||0),deviceId:String(data.deviceId||''),appVersion:String(data.appVersion||''),legacyAvailable:!!data.legacyAvailable};
      this.cloudRevision=remote;
      this.legacyCloudAvailable=!!data.legacyAvailable;
      this.syncBlocked=this.legacyCloudAvailable||(remote>0&&(knownRaw===null||Number(knownRaw)!==remote));
      if(knownRaw===null&&remote===0)this.setKnownRevision(0);
      else if(!this.syncBlocked&&knownRaw!==null)this.setKnownRevision(remote);
      if(this.legacyCloudAvailable)this.setStatus('⚠️ Older cloud backup detected. Restore it once to migrate before syncing.');
      else if(this.syncBlocked)this.setStatus('⚠️ Cloud changed or not yet linked on this device. Restore or explicitly replace it.');
      return data;
    },
    patchStorage(){
      if(!window.Storage||Storage.__cloudflarePatched)return;
      const originalSave=Storage.save.bind(Storage), originalRemove=Storage.remove.bind(Storage);
      Storage.save=(name,data)=>{const ok=originalSave(name,data);if(ok&&CloudSync.ready&&!CloudSync.suppressQueue&&STORE_NAMES.includes(name))CloudSync.queueStore(name);return ok;};
      Storage.remove=(name)=>{const ok=originalRemove(name);if(ok&&CloudSync.ready&&!CloudSync.suppressQueue&&STORE_NAMES.includes(name))CloudSync.queueStore(name);return ok;};
      Storage.__cloudflarePatched=true;
    },
    queueStore(name){
      this.changeSeq++;
      this.queue.add(name);
      try{localStorage.setItem('cashtracker_cloud_sync_pending_'+(State.currentProfileId||'default'),'1');}catch(e){}
      clearTimeout(this.timer);this.timer=setTimeout(()=>this.flushQueue(),2500);
    },
    makeRecordId(){
      const device=String(localStorage.getItem(DEVICE_KEY)||'device').replace(/[^a-zA-Z0-9_-]/g,'').slice(0,32)||'device';
      let random='';
      try{random=window.crypto?.randomUUID?crypto.randomUUID().replace(/-/g,''):Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join('');}
      catch(e){random=Math.random().toString(36).slice(2)+Math.random().toString(36).slice(2);}
      return 'ct_'+device+'_'+Date.now().toString(36)+'_'+random;
    },
    ensureRecordIds(storeName,value){
      if(!IDENTITY_STORES.has(storeName)||!Array.isArray(value))return {value,added:0};
      let added=0;
      for(const record of value){
        if(!record||typeof record!=='object'||Array.isArray(record))continue;
        if(typeof record.ctRecordId==='string'&&record.ctRecordId.trim())continue;
        record.ctRecordId=this.makeRecordId();added++;
      }
      return {value,added};
    },
    captureProfile(){
      const stores={};
      for(const name of STORE_NAMES){
        const source=State[name]!==undefined?State[name]:Storage.load(name);
        const value=source===undefined?[]:JSON.parse(JSON.stringify(source));
        const identity=this.ensureRecordIds(name,value);
        stores[name]=identity.value;
        // Persist legacy IDs locally before publishing, so later edits retain identity.
        if(identity.added&&State[name]!==undefined){
          for(const record of State[name]){if(record&&typeof record==='object'&&!(typeof record.ctRecordId==='string'&&record.ctRecordId.trim()))record.ctRecordId=this.makeRecordId();}
          Storage.save(name,State[name]);
          // Keep the snapshot aligned with the IDs actually persisted locally.
          stores[name]=JSON.parse(JSON.stringify(State[name]));
        }
      }
      return {format:'cashtracker-cloud-snapshot-v1',profileId:State.currentProfileId||'default',createdAt:new Date().toISOString(),stores};
    },
    async uploadSnapshot(manual=false,expectedOverride=null){
      if(!this.ready)throw new Error('Sign in first.');
      const pass=await this.unlock();
      const bundle=this.captureProfile();
      // Capture after legacy-ID migration writes so this upload can clear its own queue.
      const sequenceAtCapture=this.changeSeq;
      const encrypted=await BackupCrypto.encryptJson(bundle,pass);
      const chunks=[];const size=250000;for(let i=0;i<encrypted.length;i+=size)chunks.push(encrypted.slice(i,i+size));
      if(!chunks.length||chunks.length>80)throw new Error('Cloud snapshot is too large (maximum 20 MB). Make a local backup and reduce large attachments.');
      let expected=expectedOverride===null?this.getKnownRevision():Number(expectedOverride);
      if(manual&&expectedOverride===null){const head=await this.request('/api/snapshots/'+encodeURIComponent(State.currentProfileId||'default'));expected=Number(head.revision||0);}
      const result=await this.request('/api/snapshots/'+encodeURIComponent(State.currentProfileId||'default'),{method:'PUT',body:JSON.stringify({chunks,expectedRevision:expected,deviceId:localStorage.getItem(DEVICE_KEY),appVersion:(window.CONFIG&&CONFIG.VERSION)||'unknown'})});
      this.setKnownRevision(result.revision);this.syncBlocked=false;
      // Do not clear a newer local change that arrived while encryption/upload was in flight.
      if(this.changeSeq===sequenceAtCapture){
        try{localStorage.removeItem('cashtracker_cloud_sync_pending_'+(State.currentProfileId||'default'));}catch(e){}
        this.queue.clear();
      }
      return result;
    },
    async flushQueue(){
      if(!this.ready||this.busy||!this.queue.size)return;
      if(this.syncBlocked){this.setStatus('⚠️ Cloud conflict: restore or explicitly replace cloud data first.');return;}
      this.busy=true;
      try{const result=await this.uploadSnapshot(false);this.setStatus('☁️ Full profile synced · revision '+result.revision);}
      catch(e){if(e.message&&/changed on another device|revision/i.test(e.message)){this.syncBlocked=true;this.setStatus('⚠️ Cloud conflict: another device has newer data.');}else this.setStatus('⚠️ Cloud sync pending');console.error('Cloud snapshot sync error',e);}
      finally{this.busy=false;}
    },
    async getWorkspaceAccess(){
      if(!this.ready)throw new Error('Sign in first.');
      return this.request('/api/workspaces/'+encodeURIComponent(State.currentProfileId||'default')+'/access');
    },
    currentBranchId(){const branch=window.BranchAccess?.currentBranch?.();return String(branch?.id||State.branchAccessMeta?.activeBranchId||'');},
    branchRevisionKey(branchId){return 'cashtracker_branch_revision_'+(State.currentProfileId||'default')+'_'+branchId+'_'+(this.email()||'').toLowerCase();},
    captureBranch(branchId){
      if(!window.BranchSnapshotPartition)throw new Error('Branch partition module is not loaded.');
      const stores={};for(const name of BranchSnapshotPartition.STORE_NAMES){const value=State[name]!==undefined?State[name]:Storage.load(name);stores[name]=value===undefined?[]:JSON.parse(JSON.stringify(value));}
      const partition=BranchSnapshotPartition.partition(stores,branchId);
      return {format:partition.format,profileId:State.currentProfileId||'default',branchId,createdAt:new Date().toISOString(),stores:partition.stores};
    },
    async uploadCurrentBranch(){
      if(!this.ready)throw new Error('Sign in first.');const branchId=this.currentBranchId();if(!branchId)throw new Error('Create or select a branch first.');
      const access=await this.getWorkspaceAccess();if(access.branchIds!=='*'&&!access.branchIds.includes(branchId))throw new Error('Your account is not assigned to the selected branch.');
      if(!['owner','manager'].includes(access.role))throw new Error('Only Owners and Managers can publish branch snapshots.');
      const bundle=this.captureBranch(branchId);if(!confirm('Upload encrypted records for branch '+branchId+' only? Other branches and unassigned records will not be included.'))return false;
      const pass=await this.unlock(),encrypted=await BackupCrypto.encryptJson(bundle,pass),chunks=[];for(let i=0;i<encrypted.length;i+=250000)chunks.push(encrypted.slice(i,i+250000));
      if(!chunks.length||chunks.length>80)throw new Error('Branch snapshot exceeds the 20 MB cloud safety limit.');
      const path='/api/branch-snapshots/'+encodeURIComponent(State.currentProfileId||'default')+'/'+encodeURIComponent(branchId),head=await this.request(path),expected=Number(head.revision||0);
      const result=await this.request(path,{method:'PUT',body:JSON.stringify({chunks,expectedRevision:expected,deviceId:localStorage.getItem(DEVICE_KEY),appVersion:(window.CONFIG&&CONFIG.VERSION)||'unknown'})});
      localStorage.setItem(this.branchRevisionKey(branchId),String(result.revision));const out=document.getElementById('cloudCompareResult');if(out)out.textContent='BRANCH SNAPSHOT UPLOADED\nBranch: '+branchId+'\nRevision: '+result.revision+'\nRecords: '+BranchSnapshotPartition.STORE_NAMES.reduce((n,k)=>n+(bundle.stores[k]?.length||0),0)+'\nOnly this branch was published.';
      Toast.success('Encrypted branch snapshot uploaded · revision '+result.revision);return result;
    },
    async downloadCurrentBranch(){
      if(!this.ready)throw new Error('Sign in first.');const branchId=this.currentBranchId();if(!branchId)throw new Error('Create or select a branch first.');
      const access=await this.getWorkspaceAccess();if(access.branchIds!=='*'&&!access.branchIds.includes(branchId))throw new Error('Your account is not assigned to the selected branch.');
      if(!['owner','manager','accountant'].includes(access.role))throw new Error('Your role cannot download branch financial data.');
      const path='/api/branch-snapshots/'+encodeURIComponent(State.currentProfileId||'default')+'/'+encodeURIComponent(branchId),head=await this.request(path);if(!head.exists)throw new Error('No cloud snapshot exists for this branch.');
      const pass=await this.unlock(),bundle=await BackupCrypto.decryptJson((head.chunks||[]).join(''),pass);if(bundle?.format!=='cashtracker-branch-snapshot-v1'||bundle.branchId!==branchId||bundle.profileId!==(State.currentProfileId||'default'))throw new Error('Cloud branch snapshot identity does not match this profile and branch.');
      const current={};for(const name of BranchSnapshotPartition.STORE_NAMES)current[name]=JSON.parse(JSON.stringify(State[name]||[]));
      const merged=BranchSnapshotPartition.merge(current,bundle,branchId);
      if(!confirm('Restore branch '+branchId+' from cloud revision '+head.revision+'? Existing records for this branch will be replaced. Other branches and unassigned records will be preserved.'))return false;
      const rollback=State.createSnapshot?State.createSnapshot():null;
      this.suppressQueue=true;
      try{for(const name of BranchSnapshotPartition.STORE_NAMES){State[name]=merged[name];if(!State.save(name))throw new Error('Could not save local store '+name+'.');}if(window.StorageIDB?.flush)await StorageIDB.flush();await State.loadAllData();}
      catch(e){if(rollback&&State.restoreSnapshot){try{State.restoreSnapshot(rollback);if(window.StorageIDB?.flush)await StorageIDB.flush();await State.loadAllData();}catch(re){console.error('Branch restore rollback failed',re);}}throw e;}
      finally{this.suppressQueue=false;}
      localStorage.setItem(this.branchRevisionKey(branchId),String(head.revision));this.refreshApp();const out=document.getElementById('cloudCompareResult');if(out)out.textContent='BRANCH SNAPSHOT RESTORED\nBranch: '+branchId+'\nRevision: '+head.revision+'\nOther branches and unassigned records were preserved.';
      Toast.success('Branch '+branchId+' restored from cloud revision '+head.revision);return true;
    },
    async previewCloudSafe(){try{return await this.previewCloud();}catch(e){const out=document.getElementById('cloudCompareResult');if(out)out.textContent='Comparison failed: '+(e?.message||String(e));return false;}},
    async previewCloud(){
      if(!this.ready)throw new Error('Sign in first.');
      const profile=State.currentProfileId||'default';
      const head=await this.request('/api/snapshots/'+encodeURIComponent(profile));
      if(!head.exists){
        const message=head.legacyAvailable?'An older cloud backup exists. Restore it once to migrate it before syncing.':'No cloud snapshot exists for this profile.';
        const out=document.getElementById('cloudCompareResult');if(out)out.textContent=message;
        return {exists:false,legacyAvailable:!!head.legacyAvailable};
      }
      const pass=await this.unlock();
      const encrypted=(head.chunks||[]).join('');
      const bundle=await BackupCrypto.decryptJson(encrypted,pass);
      if(bundle?.format!=='cashtracker-cloud-snapshot-v1'||!bundle.stores)throw new Error('Cloud snapshot is invalid or incomplete.');
      const count=value=>Array.isArray(value)?value.length:(value&&typeof value==='object'?Object.keys(value).length:0);
      const identitySummary=(localValue,cloudValue)=>{
        const index=value=>{const map=new Map(),duplicates=new Set();if(Array.isArray(value))for(const r of value){const id=r&&typeof r.ctRecordId==='string'?r.ctRecordId:'';if(!id)continue;if(map.has(id))duplicates.add(id);else map.set(id,JSON.stringify(r));}return {map,duplicates};};
        const l=index(localValue),c=index(cloudValue);let common=0,changed=0,localOnly=0,cloudOnly=0;
        for(const [id,raw] of l.map){if(c.map.has(id)){common++;if(c.map.get(id)!==raw)changed++;}else localOnly++;}
        for(const id of c.map.keys())if(!l.map.has(id))cloudOnly++;
        return {common,changed,localOnly,cloudOnly,duplicateIds:l.duplicates.size+c.duplicates.size};
      };
      const rows=STORE_NAMES.map(name=>{const localValue=State[name]!==undefined?State[name]:Storage.load(name),cloudValue=bundle.stores[name];return {name,local:count(localValue),cloud:count(cloudValue),identity:identitySummary(localValue,cloudValue)};});
      const changed=rows.filter(row=>row.local!==row.cloud);
      const identityRows=rows.filter(row=>row.identity.common||row.identity.changed||row.identity.localOnly||row.identity.cloudOnly||row.identity.duplicateIds);
      const identityTotals=identityRows.reduce((a,r)=>{for(const k of Object.keys(a))a[k]+=r.identity[k];return a;},{common:0,changed:0,localOnly:0,cloudOnly:0,duplicateIds:0});
      const date=head.updatedAt?new Date(head.updatedAt).toLocaleString():'Unknown';
      const lines=['CLOUD SNAPSHOT COMPARISON','Profile: '+profile,'Cloud revision: '+Number(head.revision||0),'Last updated: '+date,'Uploading device: '+(head.deviceId||'Not recorded'),'App version: '+(head.appVersion||'Not recorded'),'','Store counts (local / cloud):',...rows.filter(row=>row.local||row.cloud||changed.includes(row)).map(row=>row.name+': '+row.local+' / '+row.cloud),'','Stable record identity comparison:','Same IDs: '+identityTotals.common,'Same ID but different contents (review): '+identityTotals.changed,'Local-only IDs: '+identityTotals.localOnly,'Cloud-only IDs: '+identityTotals.cloudOnly,'Duplicate IDs: '+identityTotals.duplicateIds,'','This is a read-only comparison and review. No automatic merge or overwrite was performed. Matching IDs with different contents require manual review.'];
      const result={exists:true,revision:Number(head.revision||0),updatedAt:Number(head.updatedAt||0),deviceId:String(head.deviceId||''),appVersion:String(head.appVersion||''),rows,differentStores:changed.length,identityTotals};
      this.cloudHead=result;
      const out=document.getElementById('cloudCompareResult');if(out)out.textContent=lines.join('\n');
      return result;
    },
    buildSafeMerge(localBundle,cloudBundle){
      if(localBundle?.format!=='cashtracker-cloud-snapshot-v1'||cloudBundle?.format!=='cashtracker-cloud-snapshot-v1'||!localBundle.stores||!cloudBundle.stores)throw new Error('A complete local and cloud snapshot is required.');
      if(String(localBundle.profileId||'default')!==String(cloudBundle.profileId||'default'))throw new Error('Profile mismatch. Merging across profiles is blocked.');
      const stores={},summary={addedLocal:0,addedCloud:0,unchanged:0,blocked:[]};
      for(const name of STORE_NAMES){
        const local=localBundle.stores[name],cloud=cloudBundle.stores[name];
        if(!Array.isArray(local)||!Array.isArray(cloud)){
          if(JSON.stringify(local)!==JSON.stringify(cloud))summary.blocked.push(name+': non-record store differs');
          stores[name]=JSON.parse(JSON.stringify(local===undefined?cloud:local));continue;
        }
        if(!IDENTITY_STORES.has(name)){
          if(JSON.stringify(local)!==JSON.stringify(cloud))summary.blocked.push(name+': store has no stable record identity');
          stores[name]=JSON.parse(JSON.stringify(local));continue;
        }
        const index=(rows,side)=>{const map=new Map(),dupes=[];for(const row of rows){if(!row||typeof row!=='object'||Array.isArray(row)||typeof row.ctRecordId!=='string'||!row.ctRecordId.trim())throw new Error(name+' contains a record without a stable ID. Sync is blocked.');const id=row.ctRecordId;if(map.has(id))dupes.push(id);else map.set(id,row);}if(dupes.length)throw new Error(name+' contains duplicate '+side+' record IDs. Sync is blocked.');return map;};
        const lm=index(local,'local'),cm=index(cloud,'cloud'),merged=[];
        for(const [id,row] of lm){if(cm.has(id)){if(JSON.stringify(row)!==JSON.stringify(cm.get(id)))summary.blocked.push(name+': same ID has different contents ('+id+')');else summary.unchanged++;merged.push(row);}else{summary.addedLocal++;merged.push(row);}}
        for(const [id,row] of cm)if(!lm.has(id)){summary.addedCloud++;merged.push(row);}
        stores[name]=merged;
      }
      return {bundle:{format:'cashtracker-cloud-snapshot-v1',profileId:localBundle.profileId||cloudBundle.profileId||'default',createdAt:new Date().toISOString(),stores},summary,ok:summary.blocked.length===0};
    },
    async mergeCloudSafe(){
      if(!this.ready)throw new Error('Sign in first.');if(this.busy)throw new Error('Cloud operation already in progress.');
      this.busy=true;let before=null;
      try{
        const profile=State.currentProfileId||'default';
        const head=await this.request('/api/snapshots/'+encodeURIComponent(profile));
        if(!head.exists)throw new Error('There is no cloud snapshot to merge.');
        const pass=await this.unlock(),cloudBundle=await BackupCrypto.decryptJson((head.chunks||[]).join(''),pass);
        const localBundle=this.captureProfile(),plan=this.buildSafeMerge(localBundle,cloudBundle);
        const report=['SAFE MERGE REVIEW','Cloud revision: '+Number(head.revision||0),'Local-only records to retain: '+plan.summary.addedLocal,'Cloud-only records to add: '+plan.summary.addedCloud,'Identical records: '+plan.summary.unchanged,'Conflicts: '+plan.summary.blocked.length,...plan.summary.blocked.slice(0,12)];
        const out=document.getElementById('cloudCompareResult');if(out)out.textContent=report.join('\n');
        if(!plan.ok)throw new Error('Merge stopped: conflicting records or stores need manual review. Neither copy was changed.');
        if(!confirm('Merge '+(plan.summary.addedLocal+plan.summary.addedCloud)+' non-conflicting records and publish as a new cloud revision? A temporary in-app rollback snapshot will be created first.'))return false;
        if(!State.saveUndoState||!State.restoreSnapshot)throw new Error('Recovery snapshot support is unavailable. Merge stopped.');
        State.saveUndoState('Before V8.15 cloud merge');
        before=State.createSnapshot();
        if(!before)throw new Error('Could not create a local rollback snapshot. Merge stopped.');
        if(window.StorageIDB?.flush)await StorageIDB.flush();
        this.suppressQueue=true;
        for(const name of STORE_NAMES)if(!Storage.save(name,plan.bundle.stores[name]))throw new Error('Could not save merged store: '+name);
        if(window.StorageIDB?.flush)await StorageIDB.flush();
        await State.loadAllData();
        const uploaded=await this.uploadSnapshot(false,Number(head.revision||0));
        this.syncBlocked=false;this.legacyCloudAvailable=false;this.queue.clear();
        try{localStorage.removeItem('cashtracker_cloud_sync_pending_'+profile);}catch(e){}
        this.refreshApp();Toast.success('☁️ Safe merge completed · revision '+uploaded.revision);return uploaded;
      }catch(e){
        if(before&&State.restoreSnapshot){try{State.restoreSnapshot(before);if(window.StorageIDB?.flush)await StorageIDB.flush();await State.loadAllData();}catch(rollback){console.error('Cloud merge rollback failed',rollback);}}
        Toast.error('Cloud merge stopped: '+e.message);return false;
      }finally{this.suppressQueue=false;this.busy=false;}
    },
    async uploadStore(storeName){
      // Kept as a compatibility entry point; all uploads now publish one whole-profile snapshot.
      if(!STORE_NAMES.includes(storeName))throw new Error('Unknown CashTracker store.');
      return this.uploadSnapshot(false);
    },
    async downloadStore(storeName, apply=true){
      if(!STORE_NAMES.includes(storeName))throw new Error('Unknown CashTracker store.');
      const pass=await this.unlock();
      const data=await this.request('/api/snapshots/'+encodeURIComponent(State.currentProfileId||'default'));
      if(!data.exists)return apply?false:null;
      const encrypted=(data.chunks||[]).join('');
      const bundle=await BackupCrypto.decryptJson(encrypted,pass);
      if(bundle?.format!=='cashtracker-cloud-snapshot-v1'||!bundle.stores||!Object.prototype.hasOwnProperty.call(bundle.stores,storeName))throw new Error('Cloud snapshot format is invalid or incomplete.');
      if(apply){if(!Storage.save(storeName,bundle.stores[storeName]))throw new Error('Could not save restored store: '+storeName);this.setKnownRevision(data.revision);return true;}
      return {storeName,data:bundle.stores[storeName],revision:data.revision};
    },
    async uploadAll(){
      if(!this.ready){this.openAuth();return false;} if(this.busy)return false;
      if(!confirm('Replace the Cloudflare copy with a complete snapshot of this device?\n\nThis intentionally replaces the cloud version for this profile. Other devices may need to restore again.'))return false;
      this.busy=true;try{const result=await this.uploadSnapshot(true);Toast.success('☁️ Complete cloud snapshot uploaded · revision '+result.revision);this.setStatus('☁️ Cloud backup complete · revision '+result.revision);return true;}catch(e){Toast.error('Cloud upload failed: '+e.message);return false;}finally{this.busy=false;}
    },
    async downloadAll(){
      if(!this.ready){this.openAuth();return false;}if(this.busy)return false;
      if(!confirm('Restore the complete Cloudflare snapshot and replace this device profile?\n\nExport a local backup first.'))return false;
      this.busy=true;let snapshot=null;try{
        const pass=await this.unlock();
        const data=await this.request('/api/snapshots/'+encodeURIComponent(State.currentProfileId||'default'));
        let stores=null, revision=Number(data.revision||0), migratedLegacy=false;
        if(data.exists){
          const encrypted=(data.chunks||[]).join('');
          const bundle=await BackupCrypto.decryptJson(encrypted,pass);
          if(bundle?.format!=='cashtracker-cloud-snapshot-v1'||!bundle.stores)throw new Error('Cloud snapshot is invalid or incomplete.');
          stores=bundle.stores;
        } else if(data.legacyAvailable){
          // One-time migration path for cloud data uploaded by older CashTracker versions.
          stores={};
          for(const name of STORE_NAMES){
            const legacy=await this.request('/api/stores/'+encodeURIComponent(State.currentProfileId||'default')+'/'+encodeURIComponent(name));
            if(legacy.exists){const parsed=await BackupCrypto.decryptJson((legacy.chunks||[]).join(''),pass);stores[name]=parsed;}
            else stores[name]=[];
          }
          migratedLegacy=true;
        } else throw new Error('No cloud snapshot exists for this profile.');
        for(const name of STORE_NAMES)if(!Object.prototype.hasOwnProperty.call(stores,name))throw new Error('Cloud snapshot is missing required store: '+name);
        snapshot=State.createSnapshot?State.createSnapshot():null;
        if(State.saveUndoState)State.saveUndoState('Before Cloudflare snapshot restore');
        this.suppressQueue=true;
        for(const name of STORE_NAMES){if(!Storage.save(name,stores[name]))throw new Error('Could not persist restored store: '+name);}
        if(window.StorageIDB?.flush)await StorageIDB.flush();
        await State.loadAllData();
        if(migratedLegacy){const published=await this.uploadSnapshot(true,0);revision=published.revision;}
        this.setKnownRevision(revision);this.syncBlocked=false;this.legacyCloudAvailable=false;this.queue.clear();
        try{localStorage.removeItem('cashtracker_cloud_sync_pending_'+(State.currentProfileId||'default'));}catch(e){}
        this.refreshApp();Toast.success((migratedLegacy?'☁️ Older cloud backup migrated and restored':'☁️ Complete cloud snapshot restored')+' · revision '+revision);return true;
      }catch(e){
        if(snapshot&&State.restoreSnapshot){try{State.restoreSnapshot(snapshot);if(window.StorageIDB?.flush)await StorageIDB.flush();await State.loadAllData();}catch(rollback){console.error('Cloud restore rollback failed',rollback);}}
        Toast.error('Cloud restore failed: '+e.message);return false;
      }finally{this.suppressQueue=false;this.busy=false;}
    },
    async signOut(){try{if(this.token())await this.request('/api/logout',{method:'POST'});}catch(e){}sessionStorage.removeItem(TOKEN_KEY);this.passphrase=null;this.ready=false;this.updateHeader();this.setStatus('☁️ Cloudflare: not signed in');},
    openAuth(){
      let m=document.getElementById('cloudAuthModal');if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='cloudAuthModal';m.innerHTML='<div class="modal" style="max-width:460px"><button class="close-btn" data-cashtracker-onclick="Modals.close(\'cloudAuthModal\')">✕</button><h3>☁️ CashTracker Cloudflare</h3><p style="opacity:.75">Cloud data is encrypted in the app before it reaches Cloudflare. The server stores only encrypted data.</p><div class="form-group"><label>Worker address</label><input id="cloudWorkerUrl" class="form-control" type="url" placeholder="https://your-worker.yourname.workers.dev"></div><div id="cloudAuthMessage" style="margin:8px 0;font-size:.85rem"></div><div class="form-group"><label>Email</label><input id="cloudEmail" class="form-control" type="email" autocomplete="username"></div><div class="form-group"><label>Password</label><input id="cloudPassword" class="form-control" type="password" autocomplete="new-password"></div><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn-primary" data-cashtracker-onclick="CloudSync.loginFromModal()">Sign in</button><button class="btn btn-success" data-cashtracker-onclick="CloudSync.signupFromModal()">Create account</button></div><hr><small style="opacity:.7">Use at least 8 characters. This password also unlocks your client-side encrypted cloud data. Keep it safe.</small></div>';document.body.appendChild(m);}document.getElementById('cloudWorkerUrl').value=this.getUrl();document.getElementById('cloudEmail').value=this.email();document.getElementById('cloudPassword').value='';document.getElementById('cloudAuthMessage').textContent='';Modals.open('cloudAuthModal');
    },
    async loginFromModal(){try{if(!this.configure(document.getElementById('cloudWorkerUrl').value))return;await this.signIn(document.getElementById('cloudEmail').value.trim(),document.getElementById('cloudPassword').value);Modals.close('cloudAuthModal');}catch(e){document.getElementById('cloudAuthMessage').textContent='❌ '+e.message;}},
    async signupFromModal(){try{if(!this.configure(document.getElementById('cloudWorkerUrl').value))return;await this.register(document.getElementById('cloudEmail').value.trim(),document.getElementById('cloudPassword').value);Modals.close('cloudAuthModal');}catch(e){document.getElementById('cloudAuthMessage').textContent='❌ '+e.message;}},
    openPanel(){
      if(!this.ready){this.openAuth();return;}let m=document.getElementById('cloudPanelModal');if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='cloudPanelModal';m.innerHTML='<div class="modal" style="max-width:460px"><button class="close-btn" data-cashtracker-onclick="Modals.close(\'cloudPanelModal\')">✕</button><h3>☁️ CashTracker Cloudflare</h3><div id="cloudPanelUser" style="margin-bottom:12px"></div><div style="display:grid;gap:8px"><button class="btn btn-outline" data-cashtracker-onclick="CloudSync.previewCloudSafe()">🔍 Compare this device with cloud</button><button class="btn btn-warning" data-cashtracker-onclick="CloudSync.mergeCloudSafe()">🔀 Merge non-conflicting records</button><button class="btn btn-primary" data-cashtracker-onclick="CloudSync.uploadAll()">⬆️ Upload current data</button><button class="btn btn-success" data-cashtracker-onclick="CloudSync.downloadAll()">⬇️ Restore cloud data</button><button class="btn btn-outline" data-cashtracker-onclick="CloudSync.flushQueue()">🔄 Sync pending changes</button><button class="btn btn-primary" data-cashtracker-onclick="CloudSync.uploadCurrentBranch().catch(e=>Toast.error(e.message))">🏬 Upload selected branch only</button><button class="btn btn-success" data-cashtracker-onclick="CloudSync.downloadCurrentBranch().catch(e=>Toast.error(e.message))">⬇️ Restore selected branch only</button><button class="btn btn-outline" data-cashtracker-onclick="Tabs.switchTo(\'finance\');Modals.close(\'cloudPanelModal\');setTimeout(()=>BranchAccess.openHistoricalMigration(),250)">🧭 Assign historical records to branches</button><hr><button class="btn btn-outline" data-cashtracker-onclick="CloudSync.listWorkspaceMembers()">👥 View server-side members</button><button class="btn btn-outline" data-cashtracker-onclick="CloudSync.addWorkspaceMember()">➕ Add / update member</button><button class="btn btn-outline" data-cashtracker-onclick="CloudSync.changeWorkspaceMember()">🔐 Change / disable member</button><button class="btn btn-outline" data-cashtracker-onclick="CloudSync.viewWorkspaceSecurityAudit()">📋 View security audit</button><button class="btn btn-danger" data-cashtracker-onclick="CloudSync.signOut();Modals.close(\'cloudPanelModal\')">Sign out</button></div><pre id="cloudCompareResult" style="white-space:pre-wrap;overflow-wrap:anywhere;max-height:220px;overflow:auto;font-size:.75rem;background:var(--surface-2,#f4f4f4);padding:10px;border-radius:8px"></pre><p style="font-size:.75rem;opacity:.7;margin-top:12px">Cloudflare stores encrypted, versioned profile snapshots. Server-side workspace membership controls who may sync. Branch snapshots are stored separately. Only records explicitly tagged with the selected branchId are included; unassigned records block upload. Branch restore preserves other branches. Legacy whole-profile snapshots remain restricted. Telegram remains independent.</p></div>';document.body.appendChild(m);}document.getElementById('cloudPanelUser').textContent=this.email()+' · '+this.getUrl();Modals.open('cloudPanelModal');
    },
    async listWorkspaceMembers(){
      const profile=State.currentProfileId||'default';const data=await this.request('/api/workspaces/'+encodeURIComponent(profile)+'/members');
      const lines=['SERVER-SIDE WORKSPACE MEMBERS', 'Profile: '+profile, ...(data.members||[]).map(m=>m.email+' · id '+m.user_id+' · '+m.role+' · '+(m.active?'active':'disabled')+' · branches: '+(m.branchIds==='*'?'all':m.branchIds.join(', ')))];
      const out=document.getElementById('cloudCompareResult');if(out)out.textContent=lines.join('\n');return data.members||[];
    },
    async addWorkspaceMember(){
      if(!this.ready)throw new Error('Sign in first.');
      const email=prompt('Email of an existing CashTracker Cloud account:');if(!email)return;
      const role=(prompt('Role: manager, accountant, cashier, inventory or viewer','cashier')||'').trim().toLowerCase();if(!role)return;
      const branchText=(prompt('Branch scope: enter * for all branches, or comma-separated branch IDs. Branch-limited users cannot use whole-profile cloud sync.','*')||'').trim();if(!branchText)return;
      const branchIds=branchText==='*'?'*':branchText.split(',').map(x=>x.trim()).filter(Boolean);
      await this.request('/api/workspaces/'+encodeURIComponent(State.currentProfileId||'default')+'/members',{method:'POST',body:JSON.stringify({email:email.trim(),role,branchIds})});
      Toast.success('Server-side workspace access updated.');await this.listWorkspaceMembers();
    },
    async changeWorkspaceMember(){
      const userId=(prompt('Enter the target Cloud user ID (shown only in server member records):')||'').trim();if(!userId)return;
      const role=(prompt('New role: manager, accountant, cashier, inventory or viewer. Leave blank to keep current role:','')||'').trim().toLowerCase();
      const state=(prompt('Access status: active or disabled','active')||'').trim().toLowerCase();if(!['active','disabled'].includes(state))return;
      await this.request('/api/workspaces/'+encodeURIComponent(State.currentProfileId||'default')+'/members/'+encodeURIComponent(userId),{method:'PUT',body:JSON.stringify({role:role||undefined,active:state==='active'})});
      Toast.success('Workspace member access updated.');await this.listWorkspaceMembers();
    },
    async viewWorkspaceSecurityAudit(){
      const data=await this.request('/api/workspaces/'+encodeURIComponent(State.currentProfileId||'default')+'/security-audit');
      const lines=['SERVER-SIDE SECURITY AUDIT (latest 100)',...(data.events||[]).map(e=>new Date(Number(e.created_at)).toLocaleString()+' · '+e.action+' · actor '+e.actor_user_id+' · target '+(e.target_user_id||'—')+' · '+e.details)];
      const out=document.getElementById('cloudCompareResult');if(out)out.textContent=lines.join('\n');return data.events||[];
    },
    refreshApp(){try{if(window.Dashboard?.render)Dashboard.render();if(window.Tabs?.refreshCurrent)Tabs.refreshCurrent();else if(window.Tabs?.renderCurrent)Tabs.renderCurrent();}catch(e){console.warn('Cloud refresh UI',e);}},
    authError(e){return e?.message||String(e)}
  };
  window.CloudSync=CloudSync;
  document.addEventListener('DOMContentLoaded',()=>setTimeout(()=>CloudSync.init(),80));
  window.addEventListener('online',()=>{CloudSync.updateHeader();if(CloudSync.ready)CloudSync.flushQueue();});
  window.addEventListener('offline',()=>CloudSync.updateHeader());
})();
