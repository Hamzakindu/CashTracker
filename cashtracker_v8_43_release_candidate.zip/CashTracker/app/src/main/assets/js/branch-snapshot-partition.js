// CashTracker V5.10.76 — fail-closed branch snapshot partitioning.
(function(g){'use strict';
 const STORE_NAMES=['products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger','directExpenses','returns','stockHistory','branchStockOpening','auditLog','cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','periodClosures'];
 function partition(stores,branchId){
  if(!branchId||typeof branchId!=='string')throw new Error('Choose a valid branch first.');
  const result={},unassigned=[];
  for(const name of STORE_NAMES){const source=stores?.[name]??[];if(!Array.isArray(source))throw new Error('Cannot isolate branch data: '+name+' is not a record list.');const rows=[];let missing=0;
   for(const row of source){if(!row||typeof row!=='object'||Array.isArray(row)){missing++;continue;}if(typeof row.branchId!=='string'||!row.branchId.trim()){missing++;continue;}if(row.branchId===branchId)rows.push(row);}
   if(missing)unassigned.push({store:name,count:missing});result[name]=rows;
  }
  if(unassigned.length){const detail=unassigned.map(x=>x.store+': '+x.count).join(', ');throw new Error('Branch sync blocked: '+unassigned.reduce((n,x)=>n+x.count,0)+' records have no branchId ('+detail+'). Assign and verify historical records to branches before syncing. Nothing was uploaded or changed.');}
  return {format:'cashtracker-branch-snapshot-v1',branchId,stores:result};
 }
 function merge(current,bundle,branchId){
  if(bundle?.format!=='cashtracker-branch-snapshot-v1'||bundle.branchId!==branchId||!bundle.stores)throw new Error('Branch snapshot identity or format is invalid.');
  const result={};
  for(const name of STORE_NAMES){const local=Array.isArray(current?.[name])?current[name]:[],remote=bundle.stores[name];if(!Array.isArray(remote))throw new Error('Branch snapshot is missing store: '+name);
   for(const row of remote)if(!row||typeof row!=='object'||row.branchId!==branchId)throw new Error('Branch snapshot contains a record outside the selected branch ('+name+').');
   result[name]=local.filter(row=>!row||typeof row!=='object'||row.branchId!==branchId).concat(remote);
  }
  return result;
 }
 function previewUnassigned(stores){
  const rows=[];
  for(const name of STORE_NAMES){const source=stores?.[name]??[];if(!Array.isArray(source))throw new Error('Cannot preview '+name+': not a record list.');source.forEach((row,index)=>{if(row&&typeof row==='object'&&!Array.isArray(row)&&!(typeof row.branchId==='string'&&row.branchId.trim()))rows.push({store:name,index,id:row.id==null?'':String(row.id),label:String(row.name||row.partyName||row.description||row.reference||row.productName||row.supplier||row.customer||row.type||row.id||('Record '+(index+1))).slice(0,100),date:String(row.date||row.createdAt||'').slice(0,25)});});}
  return rows;
 }
 function applyAssignments(stores,assignments){
  if(!Array.isArray(assignments)||!assignments.length)throw new Error('Choose a branch for at least one record.');
  const result={};for(const name of STORE_NAMES){const source=stores?.[name]??[];if(!Array.isArray(source))throw new Error('Cannot migrate '+name+': not a record list.');result[name]=source.map(row=>row&&typeof row==='object'?{...row}:row);}
  const seen=new Set();
  for(const a of assignments){if(!a||!STORE_NAMES.includes(a.store)||!a.branchId||typeof a.branchId!=='string')throw new Error('Invalid branch assignment.');const key=a.store+':'+a.index;if(seen.has(key))throw new Error('Duplicate assignment for '+key);seen.add(key);const row=result[a.store][a.index];if(!row||typeof row!=='object'||Array.isArray(row)|| (a.id&&String(row.id)!==String(a.id)) || (typeof row.branchId==='string'&&row.branchId.trim()))throw new Error('Record changed or already assigned. Refresh the migration preview.');row.branchId=a.branchId;row.branchMigration={method:'manual_review',reviewedAt:new Date().toISOString()};}
  return {stores:result,updated:assignments.length};
 }
 g.BranchSnapshotPartition={STORE_NAMES,partition,merge,previewUnassigned,applyAssignments};
})(window);
