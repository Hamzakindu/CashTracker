export const MONEY_SCALE = 100;
export function toMinor(value) {
    if (!Number.isFinite(value))
        throw new Error('Invalid money');
    const m = String(value).trim().match(/^([+-]?)(\d+)(?:\.(\d*))?(?:e([+-]?\d+))?$/i);
    if (!m)
        return Math.round((value + Math.sign(value) * Number.EPSILON) * MONEY_SCALE);
    const sign = m[1] === '-' ? -1n : 1n, frac = m[3] || '', exp = Number(m[4] || 0);
    let digits = BigInt((m[2] + frac).replace(/^0+(?=\d)/, '')), shift = 2 - frac.length + exp;
    if (shift >= 0)
        digits *= 10n ** BigInt(shift);
    else {
        const den = 10n ** BigInt(-shift), q = digits / den, r = digits % den;
        digits = q + (r * 2n >= den ? 1n : 0n);
    }
    const result = Number(sign * digits);
    if (!Number.isSafeInteger(result))
        throw new Error('Money amount exceeds safe precision');
    return result;
}
export function fromMinor(value) { if (!Number.isFinite(value))
    throw new Error('Invalid minor amount'); return value / MONEY_SCALE; }
export function add(...values) { return fromMinor(values.reduce((sum, v) => sum + toMinor(v), 0)); }
export function subtract(a, b) { return fromMinor(toMinor(a) - toMinor(b)); }
export function multiply(a, b) { if (!Number.isFinite(b))
    throw new Error('Invalid multiplier'); return fromMinor(Math.round(toMinor(a) * b + Math.sign(toMinor(a) * b) * Number.EPSILON)); }
export function divide(a, b) { return b === 0 ? 0 : fromMinor(Math.round(toMinor(a) / b + Math.sign(toMinor(a) / b) * Number.EPSILON)); }
export function addMinor(a, b) { return toMinor(a / 100) + toMinor(b / 100); }
