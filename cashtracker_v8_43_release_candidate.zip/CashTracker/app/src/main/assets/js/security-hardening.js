// CashTracker V5.9 Security & Reliability Hardening
(function(){
'use strict';
const Security={
  VERSION:'5.9.0',
  _fails:0,_lockedUntil:0,_timer:null,
  async digest(text){
    const data=new TextEncoder().encode(text);
    const buf=await crypto.subtle.digest('SHA-256',data);
    return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
  },
  async derivePin(pin,salt){
    const base=await crypto.subtle.importKey('raw',new TextEncoder().encode(pin),'PBKDF2',false,['deriveBits']);
    const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:new TextEncoder().encode(salt),iterations:120000,hash:'SHA-256'},base,256);
    return Array.from(new Uint8Array(bits)).map(b=>b.toString(16).padStart(2,'0')).join('');
  },
  newSalt(){const a=new Uint8Array(16);crypto.getRandomValues(a);return Array.from(a).map(b=>b.toString(16).padStart(2,'0')).join('');},
  audit(action,entityType,entityId,details,actor){
    try{
      State.auditLog=Array.isArray(State.auditLog)?State.auditLog:[];
      const user=window.Roles&&typeof Roles.currentUser==='function'?Roles.currentUser():null;
      State.auditLog.unshift({id:Helpers.uid(),actor:actor||localStorage.getItem('stockpro_actor')||'system',actorId:user?.id||'',actorRole:user?.role||'unconfigured',branchId:State.branchAccessMeta?.activeBranchId||'',action,entityType,entityId:entityId||'',details:details||{},date:Helpers.getToday(),createdAt:new Date().toISOString(),securityVersion:this.VERSION});
      if(State.auditLog.length>5000)State.auditLog.length=5000;
      Storage.save('auditLog',State.auditLog);
    }catch(e){console.error('Audit failure',e)}
  },
  touch(){sessionStorage.setItem('stockpro_last_activity',String(Date.now()));},
  startInactivityLock(minutes=30){
    const ms=minutes*60000; this.touch();
    ['click','keydown','touchstart','pointerdown'].forEach(ev=>document.addEventListener(ev,()=>this.touch(),{passive:true}));
    clearInterval(this._timer); this._timer=setInterval(()=>{
      if(window.AppLock?.isEnabled() && window.AppLock?.isUnlocked() && Date.now()-Number(sessionStorage.getItem('stockpro_last_activity')||0)>ms){
        sessionStorage.removeItem('stockpro_unlocked'); AppLock.showOverlay();
      }
    },15000);
  },
  validate(){
    const problems=[]; const money=State.moneyTransactions||[];
    const ids=new Set();
    money.forEach(t=>{
      if(!t.id||ids.has(t.id)) problems.push({type:'money_duplicate_id',id:t.id}); else ids.add(t.id);
      if(t.status!=='void' && (!t.accountId || !State.cashAccounts?.some(a=>a.id===t.accountId))) problems.push({type:'money_missing_account',id:t.id});
      if(Number(t.amount||0)<0) problems.push({type:'money_negative',id:t.id});
    });
    (State.paymentLedger||[]).filter(p=>p.status!=='void').forEach(p=>{
      if(p.amount>0 && p.sourceType && ['sale','purchase'].includes(p.sourceType) && !State.moneyTransactions.some(t=>t.status!=='void'&&t.sourceId===p.sourceId&&t.paymentId===p.id)) problems.push({type:'payment_without_money',id:p.id,sourceId:p.sourceId});
    });
    return problems;
  },
  auditHealth(){const rows=Array.isArray(State.auditLog)?State.auditLog:[],seen=new Set(),issues=[];rows.forEach((r,i)=>{if(!r||!r.id)issues.push({type:'audit_missing_id',index:i});else if(seen.has(r.id))issues.push({type:'audit_duplicate_id',id:r.id,index:i});else seen.add(r.id);if(!r||!r.action)issues.push({type:'audit_missing_action',index:i});if(!r||!r.createdAt)issues.push({type:'audit_missing_timestamp',index:i});if(!r||!r.actor)issues.push({type:'audit_missing_actor',index:i});});return {ok:issues.length===0,entries:rows.length,issues,checkedAt:new Date().toISOString(),limitReached:rows.length>=5000};},
  report(){const p=this.validate();return {ok:p.length===0,problems:p,checkedAt:new Date().toISOString()};}
};
window.Security=Security;
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>Security.startInactivityLock(30));else Security.startInactivityLock(30);
})();
