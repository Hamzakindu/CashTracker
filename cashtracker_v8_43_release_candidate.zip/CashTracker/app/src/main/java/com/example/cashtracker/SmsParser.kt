package com.example.cashtracker

import org.json.JSONObject
import java.util.Locale

/** Kotlin-first bank SMS parser. Amount selection deliberately prefers labelled/currency values over dates. */
object SmsParser {
    private val balance = Regex("\\b(?:current\\s+balance|available\\s+balance|avl\\.?\\s*bal(?:ance)?|balance|bal)\\s*(?:is|:)?\\s*(?:etb|birr|br)?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE)
    private val reference = Regex("\\b(?:ref(?:erence)?|txn(?:\\.?|\\s*id)?|transaction\\s*id|trx)\\s*[:#-]?\\s*([A-Za-z0-9-]{4,40})", RegexOption.IGNORE_CASE)
    private val amountLabel = Regex("\\b(?:amount|amt|transaction\\s+amount|debit(?:ed)?|credit(?:ed)?|spent|paid|received|withdrawn|sent|transferred)\\b\\s*(?:is|:|=)?\\s*(?:etb|birr|br)?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE)
    private val currencyBefore = Regex("(?:\\b(?:etb|birr|br|rs\\.?|inr|usd|egp|kes|ngn|sar|aed|eur|gbp)\\b|[$€£₦₹])\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE)
    private val currencyAfter = Regex("([0-9][0-9,]*(?:\\.[0-9]+)?)\\s*(?:\\b(?:etb|birr|br|rs|inr|usd|egp|kes|ngn|sar|aed|eur|gbp)\\b|[$€£₦₹])", RegexOption.IGNORE_CASE)
    private val debit = Regex("\\b(?:debited|debit|spent|purchase|withdrawn|withdrawal|paid|payment|sent|charged|deducted|transferred|transfer|bought|outgoing)\\b", RegexOption.IGNORE_CASE)
    private val credit = Regex("\\b(?:credited|credit|received|deposit|salary|refund|cashback|incoming)\\b", RegexOption.IGNORE_CASE)
    private val action = Regex("\\b(?:debited|debit|spent|purchase|withdrawn|withdrawal|paid|payment|sent|charged|deducted|transferred|transfer|bought|outgoing|credited|credit|received|deposit|salary|refund|cashback|incoming)\\b", RegexOption.IGNORE_CASE)
    private val bankNames = listOf(
        Regex("\\bcommercial bank of ethiopia\\b", RegexOption.IGNORE_CASE) to "CBE",
        Regex("\\bcbe\\b", RegexOption.IGNORE_CASE) to "CBE",
        Regex("\\bawash\\b", RegexOption.IGNORE_CASE) to "Awash",
        Regex("\\bdashen\\b", RegexOption.IGNORE_CASE) to "Dashen",
        Regex("\\bbank of abyssinia\\b|\\bboa\\b", RegexOption.IGNORE_CASE) to "BOA",
        Regex("\\btelebirr\\b", RegexOption.IGNORE_CASE) to "Telebirr",
        Regex("\\bsafaricom\\b", RegexOption.IGNORE_CASE) to "Safaricom",
        Regex("\\bmpesa\\b", RegexOption.IGNORE_CASE) to "M-Pesa"
    )

    fun parse(body: String): JSONObject? {
        val text = body.trim()
        if (text.isEmpty()) return null
        val balanceMatch = balance.find(text)
        val withoutBalance = if (balanceMatch != null) text.replaceRange(balanceMatch.range, " ") else text
        val labelled = amountLabel.find(withoutBalance)
        val currency = currencyBefore.find(withoutBalance) ?: currencyAfter.find(withoutBalance)
        val amount = (labelled?.groupValues?.getOrNull(1) ?: currency?.groupValues?.getOrNull(1))
            ?.replace(",", "")?.toDoubleOrNull() ?: return null
        if (!amount.isFinite() || amount <= 0 || !action.containsMatchIn(withoutBalance)) return null

        val sentToReceivedBy = Regex("\\bsent\\b[\\s\\S]{0,80}\\breceived\\s+by\\b", RegexOption.IGNORE_CASE).containsMatchIn(withoutBalance)
        val receivedBySent = Regex("\\breceived\\s+by\\b[\\s\\S]{0,80}\\bsent\\b", RegexOption.IGNORE_CASE).containsMatchIn(withoutBalance)
        val lower = withoutBalance.lowercase(Locale.ROOT)
        val debitAt = debit.find(lower)?.range?.first ?: -1
        val creditAt = credit.find(lower)?.range?.first ?: -1
        val direction = when {
            sentToReceivedBy -> "out"
            receivedBySent -> "in"
            creditAt >= 0 && (debitAt < 0 || creditAt < debitAt) -> "in"
            else -> "out"
        }
        val who = Regex("(?:\\bat\\b|\\bto\\b|\\bfrom\\b|@|towards)\\s+([A-Za-z0-9&.'\\- ]{2,40}?)(?=\\s+(?:on|using|via|ref|bal|a/c|acct|card|dated|with|your|and|txn|transaction)\\b|[.,;(]|$)", RegexOption.IGNORE_CASE)
            .find(text)?.groupValues?.getOrNull(1)?.trim() ?: ""
        val bank = bankNames.firstOrNull { it.first.containsMatchIn(text) }?.second ?: ""
        val balanceValue = balanceMatch?.groupValues?.getOrNull(1)?.replace(",", "")?.toDoubleOrNull()
        return JSONObject()
            .put("amount", amount)
            .put("dir", direction)
            .put("who", who)
            .put("bal", balanceValue ?: JSONObject.NULL)
            .put("reference", reference.find(text)?.groupValues?.getOrNull(1) ?: "")
            .put("bankName", bank)
    }
}
