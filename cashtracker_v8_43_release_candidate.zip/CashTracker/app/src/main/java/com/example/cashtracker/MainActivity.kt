package com.example.cashtracker

import android.Manifest
import androidx.fragment.app.FragmentActivity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.Toast
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import org.json.JSONObject
import androidx.core.content.FileProvider
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.activity.OnBackPressedCallback
import java.util.concurrent.Executor
import org.json.JSONArray
import androidx.webkit.WebViewAssetLoader
import java.io.File
import java.io.ByteArrayOutputStream
import java.net.URLConnection

open class MainActivity : FragmentActivity() {
    protected open val startPage = "index.html"
    protected open val isMain = true
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var pendingSharedImages: List<String> = emptyList()
    private val host = "appassets.androidplatform.net"
    private fun trustedPage(url: String): Boolean { val u=Uri.parse(url); return u.scheme=="https" && u.host==host && (u.path?.startsWith("/assets/") == true) }

    inner class Bridge {
        @JavascriptInterface fun drain(): String = if (isMain) Queue.peek(this@MainActivity) else "[]"

        @JavascriptInterface fun ackSms(queueIdsJson: String): Int {
            if (!isMain) return 0
            return try {
                val a = JSONArray(queueIdsJson)
                val ids = mutableSetOf<String>()
                for (i in 0 until a.length()) ids.add(a.optString(i))
                Queue.ack(this@MainActivity, ids)
            } catch (_: Exception) { 0 }
        }

        @JavascriptInterface fun parseBankSms(body: String): String {
            if (!isMain) return ""
            return SmsParser.parse(body)?.toString() ?: ""
        }

        @JavascriptInterface fun authenticateBiometric() {
            runOnUiThread { authenticateBiometricInternal() }
        }

        @JavascriptInterface fun share2(channel: String, text: String, phone: String, imgB64: String, mode: String) {
            runOnUiThread {
                try { doShare(channel, text, phone, imgB64, mode) }
                catch (e: Exception) { Toast.makeText(this@MainActivity, "Share failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }

        @JavascriptInterface fun share(channel: String, text: String, phone: String, imgB64: String) {
            runOnUiThread {
                try { doShare(channel, text, phone, imgB64, "direct") }
                catch (e: Exception) { Toast.makeText(this@MainActivity, "Share failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }

        @JavascriptInterface fun scan() {
            runOnUiThread {
                try {
                    GmsBarcodeScanning.getClient(this@MainActivity).startScan()
                        .addOnSuccessListener { b ->
                            web.evaluateJavascript("window.__onScan&&window.__onScan(" + JSONObject.quote(b.rawValue ?: "") + ")", null)
                        }
                        .addOnFailureListener { e ->
                            if (e.message?.contains("cancel", true) != true)
                                Toast.makeText(this@MainActivity, "Scanner unavailable: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Scanner unavailable: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface fun shareMulti(channel: String, text: String, phone: String, imgsJson: String, mode: String) {
            runOnUiThread {
                try { doShareMulti(channel, text, phone, imgsJson, mode) }
                catch (e: Exception) { Toast.makeText(this@MainActivity, "Share failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }

        @JavascriptInterface fun setFullscreen(enabled: Boolean) {
            runOnUiThread { applyCalculatorFullscreen(enabled) }
        }

        @JavascriptInterface fun closeCalculator() {
            runOnUiThread {
                if (!isMain) finish()
                else web.evaluateJavascript("(typeof Tabs!=='undefined' && Tabs.currentTab==='calculator') ? (Tabs.exitCalculatorFullscreen(), true) : false") { }
            }
        }

        @JavascriptInterface fun openMain() {
            runOnUiThread {
                if (!isMain) finish() else if (::web.isInitialized) web.evaluateJavascript("typeof Tabs!=='undefined' && Tabs.exitCalculatorFullscreen ? (Tabs.exitCalculatorFullscreen(), true) : false", null)
            }
        }

        @JavascriptInterface fun saveFile(name: String, b64: String, callbackId: String) {
            val safeName: String
            val result = try {
                safeName = sanitizeFileName(name)
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                if (bytes.isEmpty()) throw IllegalArgumentException("The backup file is empty")
                val savedLocation = if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                        put(MediaStore.Downloads.MIME_TYPE, URLConnection.guessContentTypeFromName(safeName) ?: "application/octet-stream")
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("Android could not create a Downloads entry")
                    try {
                        val output = contentResolver.openOutputStream(uri, "w")
                            ?: throw IllegalStateException("Android could not open the Downloads file")
                        output.use { it.write(bytes); it.flush() }
                        val updated = contentResolver.update(uri,
                            ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
                        if (updated <= 0) throw IllegalStateException("Android could not finalize the Downloads file")
                        // Read the MediaStore entry back after finalization. A successful
                        // write call alone is not enough to tell the user the backup exists.
                        var verifiedSize = -1L
                        contentResolver.query(uri, arrayOf(MediaStore.Downloads.SIZE, MediaStore.Downloads.IS_PENDING), null, null, null)?.use { cursor ->
                            if (cursor.moveToFirst()) {
                                val sizeIndex = cursor.getColumnIndex(MediaStore.Downloads.SIZE)
                                val pendingIndex = cursor.getColumnIndex(MediaStore.Downloads.IS_PENDING)
                                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) verifiedSize = cursor.getLong(sizeIndex)
                                if (pendingIndex >= 0 && cursor.getInt(pendingIndex) != 0) throw IllegalStateException("Downloads file is still pending")
                            }
                        } ?: throw IllegalStateException("Android could not verify the Downloads entry")
                        if (verifiedSize != bytes.size.toLong()) throw IllegalStateException("Downloads verification failed: expected ${bytes.size} bytes, found $verifiedSize")
                        // Verify the actual saved content, not only the MediaStore size metadata.
                        val savedBytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                            ?: throw IllegalStateException("Android could not reopen the saved Downloads file")
                        if (!savedBytes.contentEquals(bytes)) throw IllegalStateException("Downloads read-back verification failed: saved content does not match the backup")
                        "Downloads/$safeName (${savedBytes.size} bytes; content verified)"
                    } catch (e: Exception) {
                        contentResolver.delete(uri, null, null)
                        throw e
                    }
                } else {
                    val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                        ?: throw IllegalStateException("App-specific Downloads directory is unavailable")
                    val f = File(dir, safeName).canonicalFile
                    if (!f.path.startsWith(dir.canonicalPath + File.separator)) throw SecurityException("Invalid file name")
                    f.writeBytes(bytes)
                    if (!f.exists() || f.length() != bytes.size.toLong()) throw IllegalStateException("Saved file verification failed")
                    val savedBytes = f.readBytes()
                    if (!savedBytes.contentEquals(bytes)) throw IllegalStateException("Saved file read-back verification failed")
                    f.absolutePath
                }
                "OK|$savedLocation"
            } catch (e: Exception) {
                "ERROR|${e.message ?: "Unknown file save error"}"
            }
            val ok = result.startsWith("OK|")
            val message = result.substringAfter('|')
            runOnUiThread {
                val js = "window.__cashTrackerDownloadResult && window.__cashTrackerDownloadResult(" +
                    JSONObject.quote(callbackId) + "," + ok + "," + JSONObject.quote(message) + ")"
                if (::web.isInitialized) web.evaluateJavascript(js, null)
            }
        }
    }

    private val apps = mapOf(
        "whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "telegram" to listOf("org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram"),
        "imo" to listOf("com.imo.android.imoim", "com.imo.android.imoimbeta", "com.imo.android.imoimhd")
    )

    private fun note(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun sanitizeFileName(input: String): String {
        val raw = input.trim().replace('\\', '/').substringAfterLast('/')
        val clean = raw.replace(Regex("[^A-Za-z0-9._-]"), "_").trim('.', ' ')
        if (clean.isEmpty() || clean == "." || clean == "..") throw SecurityException("Invalid file name")
        if (clean.length > 120) return clean.take(120)
        return clean
    }

    private fun tryStart(i: Intent): Boolean = try { startActivity(i); true } catch (e: Exception) { false }

    private fun doShare(channel: String, text: String, phone: String, img: String, mode: String) {
        val digits = phone.filter { it.isDigit() }
        if (channel == "sms") {
            if (!tryStart(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phone")).putExtra("sms_body", text))) note("No SMS app found")
            return
        }
        val label = mapOf("whatsapp" to "WhatsApp", "telegram" to "Telegram", "imo" to "imo")[channel]
        val pkg = apps[channel]?.firstOrNull { packageManager.getLaunchIntentForPackage(it) != null }
        val send = Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_TEXT, text)
        if (img.isNotEmpty()) {
            val dir = File(cacheDir, "share").apply { mkdirs() }
            val f = File(dir, "share_${System.currentTimeMillis()}.jpg")
            f.writeBytes(Base64.decode(img, Base64.DEFAULT))
            send.type = "image/*"
            send.putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(this, "$packageName.files", f))
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } else send.type = "text/plain"
        // Share sheet: the phone's normal app list (most reliable)
        if (channel == "more" || (mode == "sheet" && channel != "imo")) {
            if (!tryStart(Intent.createChooser(send, "Share"))) note("No app available to share")
            return
        }
        // Chat links: whatsapp:// and tg:// links, no package forcing
        if (mode == "deep" && img.isEmpty()) {
            val link = when (channel) {
                "whatsapp" -> if (digits.isNotEmpty()) "whatsapp://send?phone=$digits&text=" + Uri.encode(text) else "whatsapp://send?text=" + Uri.encode(text)
                "telegram" -> "tg://msg?text=" + Uri.encode(text)
                else -> null
            }
            if (link != null && tryStart(Intent(Intent.ACTION_VIEW, Uri.parse(link)))) { note("Opening $label…"); return }
        }
        // 1) WhatsApp: open the customer's chat directly when we know the number
        if (channel == "whatsapp" && pkg != null && img.isEmpty() && digits.isNotEmpty()) {
            val v = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=$digits&text=" + Uri.encode(text))).setPackage(pkg)
            if (tryStart(v)) { note("Opening WhatsApp…"); return }
        }
        // 2) Share straight to the chosen app
        if (pkg != null) {
            val s = Intent(send).setPackage(pkg)
            if (channel == "whatsapp" && digits.isNotEmpty()) s.putExtra("jid", "$digits@s.whatsapp.net")
            if (tryStart(s)) { note("Opening $label…"); return }
        }
        // 3) Never fail silently: show the normal share list
        note(if (label != null) "$label didn't open. Choose an app." else "Choose an app")
        if (!tryStart(Intent.createChooser(send, "Share"))) note("No app available to share")
    }

    private fun doShareMulti(channel: String, text: String, phone: String, json: String, mode: String) {
        val arr = JSONArray(json)
        val dir = File(cacheDir, "share").apply { mkdirs() }
        dir.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 86400000L }?.forEach { it.delete() }
        val uris = ArrayList<Uri>()
        val stamp = System.currentTimeMillis()
        for (i in 0 until arr.length()) {
            val f = File(dir, "card_${stamp}_$i.jpg")
            f.writeBytes(Base64.decode(arr.getString(i), Base64.DEFAULT))
            uris.add(FileProvider.getUriForFile(this, "$packageName.files", f))
        }
        if (uris.isEmpty()) { note("Nothing to send"); return }
        val send = Intent(Intent.ACTION_SEND_MULTIPLE).setType("image/*")
            .putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        if (text.isNotEmpty()) send.putExtra(Intent.EXTRA_TEXT, text)
        val digits = phone.filter { it.isDigit() }
        val label = mapOf("whatsapp" to "WhatsApp", "telegram" to "Telegram", "imo" to "imo")[channel]
        val pkg = apps[channel]?.firstOrNull { packageManager.getLaunchIntentForPackage(it) != null }
        val sheet = channel == "more" || (mode == "sheet" && channel != "imo")
        if (!sheet && pkg != null) {
            val s = Intent(send).setPackage(pkg)
            if (channel == "whatsapp" && digits.isNotEmpty()) s.putExtra("jid", "$digits@s.whatsapp.net")
            if (tryStart(s)) { note("Opening $label…"); return }
        }
        if (!tryStart(Intent.createChooser(send, "Share"))) note("No app available to share")
    }

    private fun applyCalculatorFullscreen(enabled: Boolean) {
        if (!isMain) {
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
            if (enabled) {
                window.addFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (
                    android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                    android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                )
            } else {
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            }
        }
    }

    private fun authenticateBiometricInternal() {
        val manager = BiometricManager.from(this)
        if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK) != BiometricManager.BIOMETRIC_SUCCESS) {
            web.evaluateJavascript("window.AppLock&&AppLock.onBiometricError&&AppLock.onBiometricError('Biometric unlock is not available on this device')", null)
            return
        }
        val executor: Executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                web.evaluateJavascript("window.AppLock&&AppLock.onBiometricSuccess&&AppLock.onBiometricSuccess()", null)
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                web.evaluateJavascript("window.AppLock&&AppLock.onBiometricError&&AppLock.onBiometricError(" + JSONObject.quote(errString.toString()) + ")", null)
            }
        })
        prompt.authenticate(BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock CashTracker")
            .setSubtitle("Use your biometric to unlock")
            .setNegativeButtonText("Use PIN")
            .build())
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (!isMain) applyCalculatorFullscreen(true)
        if (isMain && Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECEIVE_SMS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            AlertDialog.Builder(this).setTitle("Bank SMS access")
                .setMessage("CashTracker uses incoming SMS only to detect bank transaction messages. Messages stay on this device until you review and save them. You can continue without this permission.")
                .setNegativeButton("Not now", null)
                .setPositiveButton("Allow") { _, _ -> requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS), 1001) }.show()
        }
        val loader = WebViewAssetLoader.Builder()
            .setDomain(host)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            private fun trusted(url: Uri): Boolean = trustedPage(url.toString())
            override fun onPageStarted(v: WebView, url: String, favicon: android.graphics.Bitmap?) {
                if (trustedPage(url)) v.addJavascriptInterface(Bridge(), "Android") else v.removeJavascriptInterface("Android")
                super.onPageStarted(v, url, favicon)
            }
            override fun onPageFinished(v: WebView, url: String) {
                super.onPageFinished(v, url)
                if (isMain) deliverSharedImages()
            }
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                if (trusted(r.url)) loader.shouldInterceptRequest(r.url) else null
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (trusted(r.url)) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (_: Exception) { }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(v: WebView, url: String, m: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setOnCancelListener { r.confirm() }.show(); return true
            }
            override fun onJsConfirm(v: WebView, url: String, m: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m)
                    .setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }.show(); return true
            }
            override fun onJsPrompt(v: WebView, url: String, m: String, d: String?, r: JsPromptResult): Boolean {
                val input = EditText(this@MainActivity); input.setText(d ?: "")
                AlertDialog.Builder(this@MainActivity).setMessage(m).setView(input)
                    .setPositiveButton("OK") { _, _ -> r.confirm(input.text.toString()) }
                    .setNegativeButton("Cancel") { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }.show(); return true
            }
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                chooser?.onReceiveValue(null); chooser = cb
                return try { startActivityForResult(p.createIntent(), 42); true }
                catch (e: Exception) { chooser = null; false }
            }
        }
        setContentView(web)
        if (isMain) collectSharedImages(intent)
        web.loadUrl("https://$host/assets/$startPage")
        setupBackNavigation()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (isMain) {
            collectSharedImages(intent)
            if (::web.isInitialized) deliverSharedImages()
        }
    }

    private fun collectSharedImages(source: Intent?) {
        if (source == null || (source.action != Intent.ACTION_SEND && source.action != Intent.ACTION_SEND_MULTIPLE)) return
        val uris = mutableListOf<Uri>()
        try {
            source.clipData?.let { clip ->
                for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { uris.add(it) }
            }
            source.data?.let { uris.add(it) }
            if (source.action == Intent.ACTION_SEND_MULTIPLE) {
                @Suppress("DEPRECATION")
                val extras = source.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                extras?.forEach { uris.add(it) }
            } else {
                @Suppress("DEPRECATION")
                val single = source.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                single?.let { uris.add(it) }
            }
            val unique = uris.distinct().take(5)
            Thread {
                val encoded = unique.mapNotNull { uri -> compressSharedImage(uri) }
                runOnUiThread {
                    pendingSharedImages = encoded
                    if (encoded.isEmpty()) Toast.makeText(this, "Could not read the shared image. Try sharing it again.", Toast.LENGTH_LONG).show()
                    else deliverSharedImages()
                }
            }.start()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not read shared product photo: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun compressSharedImage(uri: Uri): String? {
        return try {
            val original = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return null
            val maxSide = 1600
            val scale = minOf(1.0, maxSide.toDouble() / maxOf(original.width, original.height))
            val bitmap = if (scale < 1.0) Bitmap.createScaledBitmap(original, (original.width * scale).toInt().coerceAtLeast(1), (original.height * scale).toInt().coerceAtLeast(1), true) else original
            val out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)
            if (bitmap !== original) bitmap.recycle()
            original.recycle()
            "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            android.util.Log.w("CashTracker", "Unable to import shared image", e)
            null
        }
    }

    private fun deliverSharedImages() {
        if (pendingSharedImages.isEmpty() || !::web.isInitialized) return
        val images = JSONArray()
        pendingSharedImages.forEach { images.put(it) }
        pendingSharedImages = emptyList()
        val payload = images.toString()
        web.evaluateJavascript("(function(){var n=0;function deliver(){if(window.Products&&typeof Products.receiveSharedImages==='function'){Products.receiveSharedImages($payload);return;}if(n++<30)setTimeout(deliver,300);}deliver();})();", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 42) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data)); chooser = null
        } else super.onActivityResult(req, res, data)
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (isMain && ::web.isInitialized) {
                    web.evaluateJavascript("(typeof Tabs!=='undefined' && Tabs.currentTab==='calculator') ? (Tabs.exitCalculatorFullscreen(), 'CALCULATOR') : ''") { value ->
                        if (value != "\"CALCULATOR\"") {
                            if (web.canGoBack()) web.goBack() else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                        }
                    }
                    return
                }
                if (::web.isInitialized && web.canGoBack()) web.goBack() else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        if (isMain && ::web.isInitialized) web.evaluateJavascript("window.BankSMS&&BankSMS.pull&&BankSMS.pull()", null)
    }
}
