package com.example.cashtracker

import org.junit.Assert.*
import org.junit.Test

class SmsParserTest {
    @Test fun dateBeforeCurrencyDoesNotBecomeAmount() {
        val parsed = SmsParser.parse("CBE debited on 12/03/2026 with ETB 500.00")!!
        assertEquals(500.0, parsed.getDouble("amount"), 0.001)
        assertEquals("out", parsed.getString("dir"))
    }

    @Test fun presentDoesNotMeanSentAndUnpaidDoesNotMeanPaid() {
        val incoming = SmsParser.parse("We present your statement. Account credited ETB 50")!!
        assertEquals(50.0, incoming.getDouble("amount"), 0.001)
        assertEquals("in", incoming.getString("dir"))
        assertNull(SmsParser.parse("unpaid bill of ETB 300"))
    }

    @Test fun boaDoesNotMatchBoard() {
        val parsed = SmsParser.parse("BOARD notice: payment credited ETB 50")!!
        assertEquals("", parsed.getString("bankName"))
    }
}
