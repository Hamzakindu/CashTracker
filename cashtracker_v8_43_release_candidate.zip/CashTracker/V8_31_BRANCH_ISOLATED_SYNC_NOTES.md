# CashTracker V8.31 — Branch-Isolated Cloud Synchronization

## Implemented
- Added D1 storage for independently versioned encrypted snapshots per `(workspace profile, branch ID)`.
- Added authenticated workspace-access lookup for the current Cloud account.
- Added server-side branch membership checks on every branch snapshot read/write.
- Owner/Manager may publish; Owner/Manager/Accountant may download. Cashier, Inventory and Viewer cannot download full branch financial snapshots through this endpoint.
- Branch writes use compare-and-swap revisions; concurrent stale uploads are rejected.
- Retains the latest five snapshots per branch and records branch snapshot publication in the server security audit.
- Added client-side branch partition/merge utility. Upload includes only records explicitly tagged with the selected `branchId`.
- Upload fails closed if any record in the branch-operational stores has no `branchId`; it does not guess which branch owns legacy data.
- Restore replaces only selected-branch records and preserves records from other branches and unassigned legacy records. It creates a local rollback snapshot first.
- Added manual upload/restore controls to the Cloudflare panel. Existing whole-profile sync remains separate and branch-scoped accounts remain blocked from it.

## Critical limits and migration requirement
- Existing transaction records in this project may not have `branchId`. The new uploader intentionally blocks while any operational record is unassigned. Do not bulk-assign historical records to one branch unless the business has verified their origin.
- The new branch snapshot transport is manual. It is not yet a per-transaction real-time/offline queue, and branch-scoped cashier/inventory write APIs are not implemented.
- Encrypted snapshot contents are opaque to the Worker. The server enforces the branch ID in the API path and membership scope, while the client partition utility validates the decrypted envelope and record tags. A compromised client with valid credentials can still upload a deliberately mislabeled encrypted payload; server-side record-level inspection would require a different data/encryption architecture.
- Branch snapshot APIs require the V8.31 D1 schema migration and Worker deployment. The ZIP alone does not update a deployed Cloudflare service.
- No Cloudflare deployment, Android Gradle APK build, or physical-device test was performed.

## Deployment
1. Export a local encrypted backup and back up the D1 database.
2. Apply the additive `cloudflare/worker/schema.sql` migration to the existing D1 database.
3. Deploy the Worker with `npm run cloudflare:deploy`.
4. Confirm server-side staff branch assignments.
5. Verify and tag historical records with their actual `branchId` before attempting branch uploads.
6. Select a branch and use **Upload selected branch only**. On another authorized device, select that branch and use **Restore selected branch only**.
