# CashTracker V8.30 — Cloudflare Server-Side Security

## Changes
- Added D1 workspace membership records separate from encrypted local staff labels.
- First authenticated account to access a new profile is provisioned as its Owner.
- Owner can add an existing Cloud account by email with manager, accountant, cashier, inventory or viewer role.
- Owner can change a member role, branch scope, or active status. Owner membership cannot be demoted or disabled through these APIs.
- Only Owner can list/manage members and read the server-side security audit.
- Whole-profile snapshot and legacy store reads require an active Owner, Manager or Accountant membership with all-branch (`*`) scope. Upload/write operations are restricted to Owner and Manager.
- Branch-scoped members are explicitly blocked from whole-profile snapshot sync, preventing an accidental bypass of branch restrictions through the current all-branch snapshot format.
- Membership changes are written to a separate D1 security audit table.
- Added client controls in the Cloudflare panel to list members, add/update a member, change/disable access and view security audit.
- Offline-first local operation remains unchanged; sync waits until online.

## Important limits
- A profile ID is a workspace identifier on the server; use a distinct profile ID for a separate business. The first authenticated account to claim an unused profile becomes its Owner.
- Branch-scoped data synchronization is not implemented. Branch-scoped members cannot use whole-profile cloud sync until a future branch-partitioned snapshot design exists.
- Existing local PIN staff roles are not automatically mapped to Cloud accounts. Each invited staff member needs their own Cloud account.
- Snapshot encryption remains client-side; the Worker cannot inspect or redact individual branch records inside encrypted snapshots.
- Server-side role enforcement applies only after this Worker version and the D1 schema migration are deployed. Existing deployed Worker/database instances are not updated by this source ZIP alone.
- This is not a substitute for a security review, account recovery policy, MFA, or device-level protection.

## Deployment
1. Back up the existing D1 database.
2. From `cloudflare/worker`, apply the additive schema: `npx wrangler d1 execute cashtracker --remote --file=./schema.sql`.
3. Deploy the Worker: `npx wrangler deploy`.
4. Sign in from the app. The first account to access each profile becomes its Owner.
5. Invite staff using their existing CashTracker Cloud account email. Use `*` only when they are trusted to sync the entire profile.

No Cloudflare deployment, Android Gradle APK build, or physical-device test was performed while preparing this source release.
