# CashTracker V8.26 — Payment History and Source Traceability

Version: 5.10.70 (Android versionCode 70)

## Changes
- Customer and supplier profile payment histories now include normal payments, advances received and advance applications in one chronological ledger view.
- History rows show payment method, cash/bank account, reference, debt-applied and excess-advance allocation where recorded.
- Sale payments and customer advance applications identify their source sale; purchase payments and supplier advance applications identify their source purchase.
- When the source transaction remains active, its history row provides a direct action to open that sale or purchase. Missing/voided source records remain visibly unavailable instead of being silently recreated.
- Added `FinancialAudit.sourceAudit()` to detect source-linked payment/application rows with missing source IDs, unavailable source transactions, party mismatches, or non-positive amounts.
- Full financial audit now includes source-link findings and a source-link issue count.
- All source-link checks are read-only. No historical transaction, balance, payment or movement is modified.

## Verification
- 172/172 automated tests passed.
- `npm run typecheck` passed.
- `npm run build:android-assets` passed.
- `node --check` passed for all JavaScript files under `app/src/main/assets/js`.
- Android manifest XML and `appmint.json` validation passed.
- ZIP integrity passed.

## Limitations
- This release adds traceability to existing source IDs; it does not invent source IDs for legacy rows.
- Historical records with missing source IDs or unavailable source transactions are flagged for manual investigation.
- Android Gradle APK compilation, physical-device UI testing, and verification against real business data remain outstanding.
