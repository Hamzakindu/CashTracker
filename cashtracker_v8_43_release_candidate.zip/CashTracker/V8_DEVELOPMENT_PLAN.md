# CashTracker V8 Development Roadmap

## Guiding rule
Preserve the V7 feature set and user data. V8 is a controlled migration, not a rewrite. Keep an untouched V7 archive and require a verified backup before any schema migration.

## Milestone 0 — Baseline and safety
- [x] Preserve V7 source as the V8 starting baseline.
- [x] Run current automated tests and TypeScript typecheck.
- [x] Record confirmed reporting and transaction-flow observations.
- [ ] Inventory all persisted stores, schemas, keys, and migration paths.
- [ ] Create a representative anonymized V7 fixture and restore test.

## Milestone 1 — Transaction integrity (P0)
- Define canonical transaction IDs and source references.
- Make posting atomic across source record, payment ledger, account movement, stock movement, and journal entry.
- Make posted transactions immutable; use linked reversal entries.
- Add idempotency keys for cloud synchronization.
- Reconcile cached balances against ledgers.
- Add crash/interruption, duplicate-save, and recovery tests.

## Milestone 2 — Cash movement reporting (P0)
- Build one normalized cash-movement query over account movements.
- Report all receipts and all payments, including sale/purchase collections, customer/supplier settlements, expenses, refunds, and other money movements.
- Show transfers separately and exclude them from business income/expense totals.
- Deduplicate using canonical movement IDs, not broad source-type exclusions.
- Reconcile report totals to each cash/bank account statement.

## Milestone 3 — Accounting integrity (P1)
- Validate balanced journal entries for every posted financial event.
- Add chart-of-accounts validation and period locking.
- Produce trial balance, general ledger, profit and loss, balance sheet, and cash flow statements.
- Reconcile customer receivables, supplier payables, and inventory valuation to control accounts.

## Milestone 4 — Cash and bank controls (P1)
- Daily cash count and closing with variance reasons.
- Bank statement import/matching and reconciliation.
- Account transfer workflow with paired movements.
- Approval permissions for adjustments and reversals.

## Milestone 5 — Inventory and operational improvements (P1/P2)
- Weighted-average cost validation and historical cost preservation.
- Stocktaking, damaged/lost stock, branch transfers, reorder levels.
- Barcode scanning and optional batch/expiry tracking.

## Milestone 6 — Management reporting and UX (P2)
- Reconciled management dashboard.
- Branch and period comparisons.
- PDF/Excel/CSV exports with totals matching on-screen filters.
- Calculator/navigation regression testing.

## Mandatory release gates
- Automated tests and typecheck pass.
- Android Gradle build succeeds.
- V7-to-V8 migration and restore tests pass on a copy of real-world-shaped data.
- Critical workflows pass on a physical Android device.
- No unresolved P0 data-integrity defects.
- Existing Telegram/Cloudflare, SMS, offline, and backup behavior is regression-tested.


## V8.1 reliability patch status

Completed in 5.10.44: SMS parser boundary/amount fixes, money rounding, business-engine cost/returns fixes, EntryMemory entry-kind persistence, explicit legacy plain-JSON restore opt-in, staged Cloudflare restore, Worker PBKDF2/rate-limit hardening and TypeScript asset compilation. Still open: transaction-wide atomic cloud snapshots, canonical per-record idempotency, complete derived balance integration, historical weighted-average costing, Android/device regression and deployed Worker verification.


## V8.2 cloud snapshot reliability status (5.10.46)
- Implemented whole-profile encrypted cloud snapshots with revisioned D1 metadata and a conditional profile-head update.
- Added stale-revision conflict blocking, explicit manual replacement, complete-snapshot restore validation, legacy per-store migration and five-version retention.
- Cloud snapshot maximum: 20 MB / 80 chunks.
- Remaining: deployed Worker race testing, local crash journal, per-record idempotency, multi-device merge, derived balances, weighted-average costing and Android device verification.


## V8.3 financial integrity pass (5.10.47)
- Added a read-only financial integrity audit for customer/supplier cached balances and payment-ledger-to-cash/bank movement links. It reports discrepancies and never auto-edits balances.
- Excludes void/cancelled records and non-cash advance applications from the relevant checks.
- Fixed the weighted-average cost hook so it awaits the asynchronous durable purchase submission before reading the newly saved purchase and recalculating product buy cost.
- Remaining: migrate all adjustments and returns into canonical ledgers, derive balances centrally, handle supplier returns, validate full historical stock valuation, and test all cases against anonymized real data.


## V8.4 central business engine integration (5.10.48)
- BusinessEngine now provides the dashboard's product count, stock quantity, purchase totals, profit and customer/supplier balance projections. The dashboard no longer presents a numeric profit when any active sale lacks reliable historical cost.
- Net profit includes both sale-level expenses and direct expenses, and deducts sales returns while reversing returned cost.
- Customer/supplier balance projections use opening balances, unpaid source transactions, settlement amounts actually applied to debt, customer credit-return offsets and recorded balance adjustments.
- New customer/supplier settlement records store `balanceApplied` and `advanceAdded`; excess payments are not incorrectly treated as debt repayment. Balance adjustments now record the portion actually applied to debt separately from any advance created.
- Legacy settlement/adjustment records without applied-amount detail fall back to the cached balance instead of guessing. The Finance Control audit reports incomplete legacy history. No legacy balance is automatically rewritten.
- Remaining: migrate and verify historical records, integrate BusinessEngine into every report/statement and accounting screen, supplier returns, full historical stock valuation, journal reconciliation and Android/device testing.


## V8.5 unified reports and statements (5.10.49)
- Balance sheet and AR/AP aging use BusinessEngine party projections where source history is complete.
- Reports share the engine sale-cost inference rules; filtered product reports calculate selected line costs.
- Inventory valuation remains explicitly labelled as current-buy-price estimate pending historical weighted-average valuation.
- Read-only reporting integration and regression tests added.


## V8.6 historical inventory costing (5.10.51)
- Added a read-only perpetual weighted-average cost projection using opening stock, posted purchase lines, sale-line historical cost snapshots, returns and independent stock adjustments.
- Purchase and sale stock-history rows now carry source IDs and unit-cost snapshots for new transactions; return stock entries retain the cost used for the return.
- Stock Ledger and Inventory Statement use the historical projection when quantities reconcile; missing costs and quantity gaps are explicitly flagged rather than silently valued at today's buy price.
- Legacy transactions are reconstructed from source records where possible. Existing historical records are not rewritten; opening costs without an explicit snapshot remain estimated.
- Remaining: physical-device regression, multi-branch costing, supplier-return workflow validation, and a verified migration fixture for legacy stock-history truncation.


## V8.7 accounting integrity guard (5.10.51)

Adds transaction-level journal balancing and metadata checks, prevents non-cash returns from posting a cash refund, and extends closed-period protection to return changes. Remaining full-ledger work is explicitly tracked in `V8_7_ACCOUNTING_INTEGRITY_NOTES.md`.

## V8.17 completed scope
Supplier-return settlement capture (payable offset or partial cash refund), selected cash/bank account tagging, proportional refund allocation across line items, and balance-sheet equity reconciliation display. Remaining work includes real-device transaction/persistence verification, complete retained-earnings period-close controls, full cash-flow reconciliation, and further journal mapping coverage.
