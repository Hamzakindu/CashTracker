# CashTracker V8.14 — Stable Record Identity and Conflict Review

Version: 5.10.58  
Version code: 58

## Changes
- Added stable `ctRecordId` identities to top-level records in transaction and operational stores when a full cloud snapshot is captured.
- Existing IDs are preserved; records from older releases receive an ID before the snapshot is published and the migrated IDs are persisted locally.
- IDs are device-prefixed and generated with cryptographically strong randomness where available.
- The cloud comparison now compares record identities in addition to store counts and reports shared IDs, local-only IDs, cloud-only IDs, same-ID content differences, and duplicate IDs.
- The comparison remains read-only. It does not merge, overwrite, or silently choose a winner for conflicting records.
- Whole-profile conditional revision protection remains unchanged; stale uploads are still rejected by the Worker.
- Telegram synchronization remains independent.

## Verification
- Automated tests, TypeScript checks, Android asset build, JavaScript syntax checks, metadata validation, and ZIP integrity are run for this release.
- Android Gradle compilation and physical-device tests are not performed in this environment.

## Limitations
- This release establishes record identity and conflict visibility; it does not implement automatic record-level merge. A same-ID/different-content record is flagged for manual review.
- Older records are assigned IDs when first included in a cloud snapshot. Local-only records that are never uploaded do not yet have IDs.
- Cross-store relationships and transaction dependencies still require a dependency-aware merge engine before safe automatic merging can be enabled.
