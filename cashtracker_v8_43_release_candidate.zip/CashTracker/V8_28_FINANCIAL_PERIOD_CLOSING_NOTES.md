# CashTracker V8.28 — Financial Period Closing and Locking

## Scope
- Replaced the single-date-only finance panel with date-range financial period closures.
- Pre-close preview counts active sales, purchases, expenses, returns and cash/bank movements in the selected range and reports the current financial audit issue count.
- Closing requires an explicit typed `CLOSE` confirmation.
- Closed periods block date-based create, update and delete/void operations for sales, purchases, expenses and returns through the existing guard hooks.
- Reopening requires a reason of at least five characters and a typed `REOPEN` confirmation; it changes the closure status rather than deleting the record.
- Close/reopen actions emit security audit events.
- Period closures are stored in the profile data store and included in normal backup, restore, safety snapshots and Cloudflare sync.
- Existing legacy `SP_lock_date` locks remain active and are not silently discarded.

## Safety boundaries
- This is an application-level guard, not cryptographic immutability. A user with direct storage/file access or a modified app can bypass it.
- Reopening a period is a controlled correction path; this release does not add a new adjustment-journal workflow.
- Pre-close audit issue count is the current whole-ledger audit count, not a period-filtered audit certification.
- Closing does not alter balances, post entries, or rewrite historical transactions.

## Verification
- Automated tests cover range validation, overlap rejection, persistence, date blocking, reasoned reopening, legacy lock compatibility and backup/cloud registry inclusion.
- Android Gradle APK build and physical-device UI testing are not claimed unless separately performed.
