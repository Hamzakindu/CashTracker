import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import '../app/src/main/assets/js/utils/financial-audit.js';
const Audit=globalThis.FinancialAudit;
const read=p=>readFileSync(new URL(`../${p}`,import.meta.url),'utf8');

test('source audit validates advance applications against the original sale and party',()=>{
 const data={sales:[{id:'sale-1',customerId:'c1',status:'posted'}],paymentLedger:[{id:'adv-1',entityType:'customer',entityId:'c1',kind:'advance_applied',sourceId:'sale-1',amount:25,status:'posted'}]};
 assert.equal(Audit.sourceAudit(data).length,0);
 data.paymentLedger[0].entityId='c2';
 assert.ok(Audit.sourceAudit(data).some(x=>x.type==='payment_source_party_mismatch'));
});

test('source audit reports missing and unavailable source records without mutating data',()=>{
 const data={sales:[],purchases:[],paymentLedger:[
  {id:'a',entityType:'customer',kind:'advance_applied',amount:10,status:'posted'},
  {id:'b',entityType:'supplier',kind:'advance_applied',sourceId:'gone',amount:12,status:'posted'}]};
 const before=JSON.stringify(data),issues=Audit.sourceAudit(data);
 assert.ok(issues.some(x=>x.type==='payment_source_missing_id'));
 assert.ok(issues.some(x=>x.type==='payment_source_not_found'));
 assert.equal(JSON.stringify(data),before);
});

test('sale and purchase source-linked payments must retain their source transaction',()=>{
 const issues=Audit.sourceAudit({sales:[{id:'s1',customerId:'c1'}],purchases:[{id:'p1',supplierId:'v1'}],paymentLedger:[
  {id:'sp',entityType:'customer',entityId:'c1',kind:'sale_payment',sourceId:'s1',amount:20,status:'posted'},
  {id:'pp',entityType:'supplier',entityId:'v1',kind:'purchase_payment',sourceId:'p1',amount:15,status:'posted'}]});
 assert.equal(issues.length,0);
});

test('party payment history exposes source trace, allocation split and cash account',()=>{
 const source=read('app/src/main/assets/js/modules/transaction-detail.js');
 assert.match(source,/getPaymentTrace\(p\)/);
 assert.match(source,/openPaymentSource\(sourceType, sourceId\)/);
 assert.match(source,/Debt: \$\{formatCurrency\(p\.balanceApplied\)\}/);
 assert.match(source,/cash\/bank account/i);
 assert.match(source,/Advance applications are non-cash entries/);
});
