import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const root=new URL('../',import.meta.url).pathname;
const cloud=fs.readFileSync(root+'app/src/main/assets/js/cloudflare-backend.js','utf8');
const worker=fs.readFileSync(root+'cloudflare/worker/src/index.js','utf8');
test('cloud snapshot assigns stable IDs to supported top-level records and preserves existing IDs',()=>{
  assert.match(cloud,/const IDENTITY_STORES=new Set\(/);
  assert.match(cloud,/ensureRecordIds\(storeName,value\)/);
  assert.match(cloud,/record\.ctRecordId=this\.makeRecordId\(\)/);
  assert.match(cloud,/if\(typeof record\.ctRecordId==='string'&&record\.ctRecordId\.trim\(\)\)continue/);
  assert.match(cloud,/Storage\.save\(name,State\[name\]\)/);
});
test('record identity comparison reports matching, missing, duplicate and changed records without writes',()=>{
  const start=cloud.indexOf('async previewCloud()');
  const end=cloud.indexOf('    buildSafeMerge(',start);
  const fn=cloud.slice(start,end);
  for(const token of ['common','changed','localOnly','cloudOnly','duplicateIds','JSON.stringify(r)','read-only comparison and review'])assert.ok(fn.includes(token),`missing ${token}`);
  assert.doesNotMatch(fn,/Storage\.save\(|Storage\.remove\(|State\.loadAllData/);
});
test('conditional cloud revision protection remains in place',()=>{
  assert.match(worker,/WHERE cloud_snapshot_heads\.revision=\?/);
  assert.match(worker,/status:409|},409\)/);
});
test('upload sequence is captured after migration writes',()=>{
  const start=cloud.indexOf('async uploadSnapshot(');
  const end=cloud.indexOf('async flushQueue(',start);
  const fn=cloud.slice(start,end);
  assert.ok(fn.indexOf('const bundle=this.captureProfile()')<fn.indexOf('const sequenceAtCapture=this.changeSeq'));
});
