import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const base=new URL('../app/src/main/assets/',import.meta.url);
const html=fs.readFileSync(new URL('index.html',base),'utf8');
const finance=fs.readFileSync(new URL('js/modules/finance-control.js',base),'utf8');
test('financial audit utility loads before Finance Control',()=>{
 assert.ok(html.indexOf('js/utils/financial-audit.js')>=0);
 assert.ok(html.indexOf('js/utils/financial-audit.js')<html.indexOf('js/modules/finance-control.js'));
});
test('Finance Control exposes a read-only integrity audit action',()=>{
 assert.match(finance,/FinanceControl\.runIntegrityAudit\(\)/);
 assert.match(finance,/FinancialAudit\.run\(/);
 assert.match(finance,/No records were changed/);
});
