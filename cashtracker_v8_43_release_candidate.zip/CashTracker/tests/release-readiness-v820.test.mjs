import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const read = (p) => readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');

test('release version is consistent across package metadata and Android Gradle defaults', () => {
  const pkg = JSON.parse(read('package.json'));
  const gradle = read('app/build.gradle.kts');
  assert.equal(pkg.version, '5.10.87');
  const gradleProperties = read('gradle.properties');
  const config = read('app/src/main/assets/js/config.js');
  const appmint = JSON.parse(read('app/src/main/assets/appmint.json'));
  assert.match(gradleProperties, /VERSION_NAME=5\.10\.87/);
  assert.match(gradleProperties, /VERSION_CODE=87/);
  assert.match(config, /VERSION: '5\.10\.87'/);
  assert.equal(appmint.version, '5.10.87');
  assert.equal(appmint.versionCode, 87);
  assert.match(gradle, /VERSION_CODE"\)\.orElse\("87"\)/);
  assert.match(gradle, /VERSION_NAME"\)\.orElse\("5\.10\.87"\)/);
});

test('critical browser modules load in dependency order', () => {
  const html = read('app/src/main/assets/index.html');
  const ordered = [
    'js/utils/storage.js',
    'js/utils/indexeddb-storage.js',
    'js/utils/backup-crypto.js',
    'js/module-loader.js',
    'js/state.js',
    'js/utils/historical-cost-engine.js',
    'js/utils/business-engine.js',
    'js/utils/financial-audit.js',
    'js/backup.js'
  ];
  const positions = ordered.map((s) => html.indexOf(s));
  assert.ok(positions.every((p) => p >= 0), 'all critical modules must be included');
  assert.deepEqual(positions, [...positions].sort((a, b) => a - b), 'critical modules must retain dependency order');
});

test('Android manifest remains valid XML and declares a launcher activity', () => {
  const manifest = read('app/src/main/AndroidManifest.xml');
  assert.match(manifest, /<manifest[\s>]/);
  assert.match(manifest, /<application[\s>]/);
  assert.match(manifest, /android\.intent\.action\.MAIN/);
  assert.match(manifest, /android\.intent\.category\.LAUNCHER/);
});

test('backup encryption, calculator, durable sales and safe cloud merge regression suites remain present', () => {
  const required = [
    'tests/backup-crypto.test.mjs',
    'tests/backup-encrypted-flow.test.mjs',
    'tests/calculator-v818.test.mjs',
    'tests/sales-regression.test.mjs',
    'tests/safe-record-merge.test.mjs',
    'tests/financial-audit-integration.test.mjs'
  ];
  for (const p of required) assert.ok(read(p).length > 100, `${p} must not be empty`);
});


test('release workflow discovers nested Gradle projects and derives version from release metadata', () => {
  const workflow = read('.github/workflows/build.yml');
  assert.match(workflow, /find \"?\$SRC_DIR\"? -maxdepth 8 -type f -name settings\.gradle\.kts/);
  assert.match(workflow, /app\/build\.gradle\.kts/);
  assert.match(workflow, /BASE_VERSION_NAME=.*gradle\.properties/);
  assert.match(workflow, /BASE_VERSION_CODE=.*gradle\.properties/);
  assert.doesNotMatch(workflow, /5\.10\.54-b/);
});
