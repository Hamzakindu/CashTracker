import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const root=new URL('../',import.meta.url).pathname;
const cloud=fs.readFileSync(root+'app/src/main/assets/js/cloudflare-backend.js','utf8');
test('safe merge unions records by stable ID and blocks conflicting stores',()=>{
  assert.match(cloud,/buildSafeMerge\(localBundle,cloudBundle\)/);
  assert.match(cloud,/typeof row\.ctRecordId!=='string'/);
  assert.match(cloud,/duplicate .*record IDs/);
  assert.match(cloud,/same ID has different contents/);
  assert.match(cloud,/store has no stable record identity/);
  assert.match(cloud,/summary\.blocked\.length===0/);
});
test('merge requires confirmation, local rollback snapshot and cloud revision compare-and-swap',()=>{
  const start=cloud.indexOf('async mergeCloudSafe()'),end=cloud.indexOf('async uploadStore(',start),fn=cloud.slice(start,end);
  assert.match(fn,/confirm\(/);
  assert.match(fn,/State\.createSnapshot\(\)/);
  assert.match(fn,/State\.restoreSnapshot\(before\)/);
  assert.match(fn,/uploadSnapshot\(false,Number\(head\.revision\|\|0\)\)/);
  assert.match(fn,/Neither copy was changed/);
});
test('merge action is visible in Cloudflare panel and conflict review stays available',()=>{
  assert.match(cloud,/Merge non-conflicting records/);
  assert.match(cloud,/previewCloudSafe\(\)/);
});
test('stable-ID cloud upload still uses server revision compare-and-swap',()=>{
  const worker=fs.readFileSync(root+'cloudflare/worker/src/index.js','utf8');
  assert.match(worker,/WHERE cloud_snapshot_heads\.revision=\?/);
  assert.match(worker,/status:409|},409\)/);
});
