import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

function loadStatements(journal){
  const window={AccountingDoubleEntry:journal};
  const context={window,State:{},Helpers:{esc:x=>String(x),formatCurrency:n=>Number(n||0).toFixed(2),getToday:()=> '2026-11-13'}};
  vm.runInNewContext(fs.readFileSync(new URL('../app/src/main/assets/js/modules/statements.js',import.meta.url),'utf8'),context);
  return window.Statements;
}

test('V8.39 profit and loss uses selected-period journal balances without mutating records',()=>{
  const state={sales:[{id:'s1',total:150}],directExpenses:[{id:'e1',amount:20}]};
  const before=JSON.stringify(state);
  const journal={trialBalance:(from,to)=>({rows:[
    {code:'4000',credit:150,debit:0},{code:'4100',debit:10,credit:0},
    {code:'5000',debit:50,credit:0},{code:'6000',debit:20,credit:0}
  ]}),audit:()=>({ok:true,issues:[]})};
  const r=loadStatements(journal)._periodProfitLoss('2026-11-01','2026-11-13');
  assert.equal(r.totals.revenue,150);
  assert.equal(r.totals.returns,10);
  assert.equal(r.totals.gross,90);
  assert.equal(r.totals.net,70);
  assert.equal(JSON.stringify(state),before);
});

test('V8.39 comparative statement compares equal-length adjacent periods',()=>{
  const ranges=[];
  const journal={trialBalance:(from,to)=>{ranges.push([from,to]);return {rows:[{code:'4000',credit:from==='2026-11-01'?200:100,debit:0}]};}};
  const r=loadStatements(journal)._comparePeriods('2026-11-01','2026-11-03');
  assert.deepEqual(ranges,[['2026-11-01','2026-11-03'],['2026-10-29','2026-10-31']]);
  assert.match(r,/Period comparison/);
  assert.match(r,/100\.0%/);
});

test('V8.39 reports safely decline when accounting journal is unavailable',()=>{
  const s=loadStatements(null);
  assert.equal(s._periodProfitLoss('2026-11-01','2026-11-13').available,false);
  assert.match(s._comparePeriods('2026-11-01','2026-11-13'),/unavailable/);
});
