import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const root=new URL('../',import.meta.url).pathname;
const worker=fs.readFileSync(root+'cloudflare/worker/src/index.js','utf8');
const schema=fs.readFileSync(root+'cloudflare/worker/schema.sql','utf8');
const cloud=fs.readFileSync(root+'app/src/main/assets/js/cloudflare-backend.js','utf8');
const html=fs.readFileSync(root+'app/src/main/assets/index.html','utf8');
test('Worker PBKDF2 stays within configured 100k iteration budget',()=>assert.match(worker,/PBKDF2_ITERATIONS\s*=\s*100000/));
test('Worker login and registration are rate limited',()=>{assert.match(worker,/rateLimited\(request,env,'login'\)/);assert.match(worker,/rateLimited\(request,env,'register'\)/);assert.match(schema,/CREATE TABLE IF NOT EXISTS auth_rate_limits/)});
test('cloud restore validates a complete encrypted profile snapshot before local writes',()=>{assert.match(cloud,/BackupCrypto\.decryptJson\(encrypted,pass\)/);assert.match(cloud,/cashtracker-cloud-snapshot-v1/);assert.match(cloud,/for\(const name of STORE_NAMES\)if\(!Object\.prototype\.hasOwnProperty\.call\(stores,name\)\)/);assert.match(cloud,/this\.suppressQueue=true/);assert.match(cloud,/this\.suppressQueue=false/);assert.match(cloud,/CloudSync\.ready&&!CloudSync\.suppressQueue/)});
test('cloud sync publishes one whole-profile snapshot and blocks stale revisions',()=>{assert.match(cloud,/uploadSnapshot\(false\)/);assert.match(cloud,/expectedRevision:expected/);assert.match(cloud,/this\.syncBlocked/);assert.match(cloud,/Cloud conflict/);assert.match(worker,/cloud_snapshot_heads/);assert.match(worker,/WHERE cloud_snapshot_heads\.revision=\?/);assert.match(worker,/currentRevision/)});
test('cloud snapshot schema is additive and stores encrypted chunks by snapshot id',()=>{assert.match(schema,/CREATE TABLE IF NOT EXISTS cloud_snapshots/);assert.match(schema,/CREATE TABLE IF NOT EXISTS cloud_snapshot_chunks/);assert.match(schema,/CREATE TABLE IF NOT EXISTS cloud_snapshot_heads/)});
test('custom HTTPS Worker origins are permitted without permitting remote scripts',()=>{assert.match(html,/connect-src[^;]*https:/);assert.match(html,/script-src 'self'/)});

test('legacy per-store cloud data is detected and has a one-time migration path',()=>{assert.match(worker,/legacyAvailable/);assert.match(cloud,/data\.legacyAvailable/);assert.match(cloud,/One-time migration path for cloud data uploaded by older CashTracker versions/);assert.match(cloud,/this\.uploadSnapshot\(true,0\)/)});

test('cloud sync does not clear pending changes created while a snapshot is uploading',()=>{assert.match(cloud,/changeSeq\+\+/);assert.match(cloud,/sequenceAtCapture=this\.changeSeq/);assert.match(cloud,/if\(this\.changeSeq===sequenceAtCapture\)/)});
