import test from 'node:test';
import assert from 'node:assert/strict';
import '../app/src/main/assets/js/utils/historical-cost-engine.js';
import '../app/src/main/assets/js/utils/financial-audit.js';
const Audit=globalThis.FinancialAudit;

test('V8.36 cash movement audit detects missing accounts, invalid amounts and duplicate IDs without mutation',()=>{
 const data={cashAccounts:[{id:'cash',openingBalance:100}],moneyTransactions:[
  {id:'m1',accountId:'cash',type:'in',amount:10,status:'posted'},
  {id:'m1',accountId:'cash',type:'out',amount:5,status:'posted'},
  {id:'m2',accountId:'missing',type:'in',amount:0,status:'posted'},
  {id:'m3',type:'in',amount:5,status:'posted'}
 ]};
 const before=JSON.stringify(data),issues=Audit.moneyMovementAudit(data);
 assert.ok(issues.some(x=>x.type==='money_movement_duplicate_id'));
 assert.ok(issues.some(x=>x.type==='money_movement_invalid_amount'));
 assert.ok(issues.some(x=>x.type==='money_movement_missing_account'));
 assert.ok(issues.some(x=>x.type==='money_movement_account_missing'));
 assert.equal(JSON.stringify(data),before);
});

test('V8.36 transaction audit identifies duplicate active source IDs and ignores void rows',()=>{
 const issues=Audit.transactionAudit({sales:[{id:'s1',total:10},{id:'s1',total:20},{id:'old',total:5,status:'void'}],purchases:[{id:'p1',total:-1}]});
 assert.ok(issues.some(x=>x.type==='transaction_duplicate_id'&&x.id==='s1'));
 assert.ok(issues.some(x=>x.type==='transaction_invalid_amount'&&x.id==='p1'));
 assert.equal(issues.some(x=>x.id==='old'),false);
});

test('V8.36 inventory audit surfaces source-to-current quantity mismatch and never repairs stock',()=>{
 const data={products:[{id:'p1',name:'Test product',stock:7,initialStock:2,initialCost:10,buy:10}],sales:[],purchases:[],returns:[],stockHistory:[]};
 const before=JSON.stringify(data),issues=Audit.inventoryAudit(data);
 assert.ok(issues.some(x=>x.type==='inventory_stock_quantity_mismatch'&&x.productId==='p1'));
 assert.equal(JSON.stringify(data),before);
});

test('V8.36 full audit reports expanded scope and remains explicitly read-only',()=>{
 const result=Audit.run({customers:[],suppliers:[],sales:[],purchases:[],returns:[],directExpenses:[],products:[],stockHistory:[],paymentLedger:[],moneyTransactions:[],cashAccounts:[],auditLog:[]});
 assert.equal(result.readOnly,true);
 assert.match(result.scope,/cash\/bank movements/);
 assert.equal(result.counts.moneyMovements,0);
 assert.equal(result.counts.inventoryIssues,0);
});

test('V8.36 journal audit reports transaction-level imbalance through the unified audit',()=>{
 const previous=globalThis.AccountingDoubleEntry;
 globalThis.AccountingDoubleEntry={audit:()=>({issues:[{type:'unbalanced_transaction',ref:'sale:s1',difference:4}]})};
 try { const issues=Audit.journalAudit();assert.equal(issues.length,1);assert.equal(issues[0].type,'journal_unbalanced_transaction');assert.match(issues[0].explanation,/does not post or reverse/); }
 finally { if(previous===undefined)delete globalThis.AccountingDoubleEntry;else globalThis.AccountingDoubleEntry=previous; }
});
