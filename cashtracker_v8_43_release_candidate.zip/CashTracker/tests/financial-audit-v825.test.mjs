import test from 'node:test';
import assert from 'node:assert/strict';
import '../app/src/main/assets/js/utils/financial-audit.js';
const Audit=globalThis.FinancialAudit;

test('advance audit reconciles opening, received and applied customer advances',()=>{
 const data={customers:[{id:'c1',name:'A',openingAdvance:100,customerAdvance:35}],paymentLedger:[
  {id:'p1',entityType:'customer',entityId:'c1',sourceType:'payment',kind:'advance',advanceAdded:50,amount:50,status:'posted'},
  {id:'a1',entityType:'customer',entityId:'c1',kind:'advance_applied',amount:115,status:'posted'}]};
 assert.equal(Audit.advanceAudit(data).length,0);
 data.customers[0].customerAdvance=40;
 const issue=Audit.advanceAudit(data)[0];assert.equal(issue.type,'customer_advance_balance');assert.equal(issue.expected,35);assert.equal(issue.actual,40);
});

test('advance audit checks supplier advances from payments and purchases',()=>{
 const data={suppliers:[{id:'s1',name:'S',openingAdvance:20,supplierAdvance:25}],paymentLedger:[
  {id:'p1',entityType:'supplier',entityId:'s1',sourceType:'payment',kind:'advance',advanceAdded:25,status:'posted'},
  {id:'a1',entityType:'supplier',entityId:'s1',kind:'advance_applied',amount:30,status:'posted'}],purchases:[{supplierId:'s1',excessPaid:10,status:'posted'}]};
 assert.equal(Audit.advanceAudit(data).length,0);
});

test('payment audit reports missing movement with review details and never marks it auto-repairable',()=>{
 const data={cashAccounts:[{id:'cash',active:true}],paymentLedger:[{id:'p1',entityType:'customer',entityId:'c1',entityName:'Customer',amount:12,accountId:'cash',date:'2026-11-12',method:'Cash',status:'posted'}],moneyTransactions:[]};
 const before=JSON.stringify(data),issue=Audit.paymentAudit(data).find(x=>x.type==='payment_missing_movement');
 assert.ok(issue);assert.equal(issue.direction,'in');assert.equal(issue.repairable,false);assert.ok(issue.suggestedAction);assert.equal(JSON.stringify(data),before);
});

test('payment audit detects orphan movements and invalid account references',()=>{
 const issues=Audit.paymentAudit({cashAccounts:[{id:'cash',active:true}],paymentLedger:[],moneyTransactions:[
  {id:'m1',paymentId:'missing-payment',accountId:'cash',amount:8,status:'posted'},
  {id:'m2',accountId:'deleted-account',amount:4,status:'posted'}]});
 assert.ok(issues.some(x=>x.type==='payment_orphan_movement'));
 assert.ok(issues.some(x=>x.type==='movement_account_not_found'));
});

test('full audit remains read-only and includes advance discrepancies',()=>{
 const data={customers:[{id:'c1',name:'C',openingAdvance:0,customerAdvance:9}],suppliers:[],sales:[],purchases:[],returns:[],paymentLedger:[],moneyTransactions:[],cashAccounts:[]};
 const before=JSON.stringify(data),r=Audit.run(data);
 assert.equal(r.readOnly,true);assert.ok(r.issues.some(x=>x.type==='customer_advance_balance'));assert.equal(JSON.stringify(data),before);
});
