import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import '../app/src/main/assets/js/utils/financial-audit.js';

const Audit = globalThis.FinancialAudit;
const read = (p) => readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');

test('payment form creates one attempt key and retains it across retries in the same modal', () => {
  const source = read('app/src/main/assets/js/modules/payments.js');
  assert.match(source, /id="paymentIdempotencyKey"/);
  assert.match(source, /paymentIdempotencyKey'\)\.value=Helpers\.uid\(\)/);
  assert.match(source, /idempotencyKey,kind:advance/);
  assert.match(source, /priorRows\.length===1&&movement\.length===1/);
});

test('cash-bank payment linking is idempotent by payment ID and rejects pre-existing duplicates', () => {
  const source = read('app/src/main/assets/js/modules/cash-banks.js');
  assert.match(source, /filter\(x=>x&&x\.paymentId===meta\.paymentId&&x\.status!=='void'\)/);
  assert.match(source, /linked\.length>1/);
  assert.match(source, /if\(linked\.length===1\)return linked\[0\]/);
});

test('payment audit flags repeated attempt keys as a read-only integrity issue', () => {
  const rows = [
    {id:'p1', idempotencyKey:'attempt-1', amount:25, accountId:'cash', entityType:'customer'},
    {id:'p2', idempotencyKey:'attempt-1', amount:25, accountId:'cash', entityType:'customer'}
  ];
  const before = JSON.stringify(rows);
  const issues = Audit.paymentAudit({paymentLedger:rows, moneyTransactions:[]});
  assert.ok(issues.some(x => x.type === 'payment_duplicate_idempotency_key' && x.count === 2));
  assert.equal(JSON.stringify(rows), before);
});
