import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const root=new URL('../app/src/main/assets/',import.meta.url);
const html=fs.readFileSync(new URL('index.html',root),'utf8');
const dashboard=fs.readFileSync(new URL('js/ui/dashboard.js',root),'utf8');
const payments=fs.readFileSync(new URL('js/modules/payments.js',root),'utf8');
test('BusinessEngine is loaded before app initialization and used by dashboard',()=>{
 const engineAt=html.indexOf('js/utils/business-engine.js');
 const appAt=html.lastIndexOf('js/app.js');
 assert.ok(engineAt>=0&&appAt>engineAt,'engine must load before app init');
 assert.match(dashboard,/BusinessEngine\.calculate\(/);
 assert.match(dashboard,/Cost unavailable/);
});
test('new customer and supplier settlement rows store applied debt and excess advance separately',()=>{
 assert.match(payments,/balanceApplied,advanceAdded/);
 assert.match(payments,/balanceApplied=Math\.min\(amount,e\.balance\)/);
 assert.match(payments,/advanceAdded=amount-balanceApplied/);
});
test('balance adjustment audit records applied portion and excess advance',()=>{
 assert.match(payments,/balanceApplied,advanceAdded/);
 assert.match(payments,/AccountingLedger\.audit\('user','balance_adjustment',type,\{entityId:id,amount:a,balanceApplied,advanceAdded\}\)/);
});
