import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const source = readFileSync(new URL('../app/src/main/assets/js/modules/export.js', import.meta.url), 'utf8');
function loadExport(overrides = {}) {
  let factory;
  const context = {
    console,
    window: { registerModule: (_name, fn) => { factory = fn; } },
    Backup: { exportBackup: async () => ({ ok: true, confirmed: true, encrypted: true }) },
    State: { products: [], customers: [], suppliers: [], sales: [], purchases: [], directExpenses: [], returns: [], paymentLedger: [], moneyTransactions: [], activeSales() { return this.sales; } },
    Helpers: { downloadFile: async (content, filename, type) => { context.lastDownload = { content, filename, type }; return { ok: true, confirmed: true }; } },
    Toast: { success() {}, info() {}, error() {} },
    ...overrides
  };
  vm.runInNewContext(source, context);
  return { Export: factory(), context };
}

test('full JSON export delegates to the complete encrypted backup pipeline', async () => {
  const { Export, context } = loadExport();
  const result = await Export.exportAllJSON();
  assert.equal(result.encrypted, true);
  assert.equal(result.confirmed, true);
  assert.equal(context.lastDownload, undefined);
});

test('CSV cells escape quotes and neutralize spreadsheet formula prefixes', () => {
  const { Export } = loadExport();
  assert.equal(Export.csvCell('A "quoted" name'), '"A ""quoted"" name"');
  assert.equal(Export.csvCell('=HYPERLINK("x")'), '"\'=HYPERLINK(""x"")"');
  assert.equal(Export.csvCell('  +SUM(A1:A2)'), '"\'  +SUM(A1:A2)"');
  assert.equal(Export.csvCell(125.5), '"125.5"');
});

test('CSV export includes financial ledgers and uses legacy/current sale paid fields', async () => {
  const { Export, context } = loadExport();
  context.State.sales = [{ id: 's1', date: '2026-11-13', total: 10, paid: 7 }, { id: 's2', paymentReceived: 3 }];
  context.State.paymentLedger = [{ id: 'p1', amount: 4 }];
  context.State.moneyTransactions = [{ id: 'm1', amount: 9 }];
  const result = await Export.exportCSV();
  assert.equal(result.confirmed, true);
  const csv = context.lastDownload.content;
  assert.match(csv, /PAYMENT LEDGER/);
  assert.match(csv, /CASH AND BANK MOVEMENTS/);
  assert.match(csv, /"s1"/);
  assert.match(csv, /"7"/);
  assert.match(csv, /"3"/);
  assert.match(context.lastDownload.filename, /^cashtracker-data-/);
});

test('CSV uses central derived party balances and labels legacy cached fallbacks', async () => {
  const { Export, context } = loadExport({
    BusinessEngine: { calculate: () => ({
      customerBalanceDetails: [{ id: 'c1', balance: 42, basis: 'derived' }],
      supplierBalanceDetails: [{ id: 'sp1', balance: 17, basis: 'legacy' }]
    }) }
  });
  context.State.customers = [{ id: 'c1', name: 'Customer', balance: 999 }];
  context.State.suppliers = [{ id: 'sp1', name: 'Supplier', balance: 17 }];
  await Export.exportCSV();
  const csv = context.lastDownload.content;
  assert.match(csv, /"42","derived from records"/);
  assert.match(csv, /"17","legacy cached"/);
});
