import test from 'node:test';
import assert from 'node:assert/strict';
globalThis.window = globalThis;
await import('../app/src/main/assets/js/utils/money.js');
const Money=globalThis.Money;
test('real money code uses integer minor units',()=>{assert.equal(Money.minor(12.345),1235);assert.equal(Money.major(1235),12.35)});
test('real money addition is integer-safe',()=>assert.equal(Money.add(0.1,0.2,0.3),0.6));
test('real money multiplication rounds to cents',()=>assert.equal(Money.mul(12.345,2),24.70));

test('decimal half-cents round correctly from decimal strings',()=>{assert.equal(Money.minor(1.005),101);assert.equal(Money.minor(8.325),833);assert.equal(Money.minor(-1.005),-101)});
test('multiplication and division round to cents',()=>{assert.equal(Money.mul(1.005,1),1.01);assert.equal(Money.div(1,8),0.13)});

test('persisted debit and credit ledger amounts use integer minor units',()=>{const encoded=Money.encode({debit:12.34,credit:5.67});assert.equal(encoded.debitMinor,1234);assert.equal(encoded.creditMinor,567);assert.deepEqual(Money.decode(encoded),{debit:12.34,credit:5.67});});
