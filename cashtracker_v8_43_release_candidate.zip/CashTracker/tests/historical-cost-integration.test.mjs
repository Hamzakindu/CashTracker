import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const root=new URL('../app/src/main/assets/',import.meta.url);
const html=fs.readFileSync(new URL('index.html',root),'utf8');
const purchase=fs.readFileSync(new URL('js/modules/purchases.js',root),'utf8');
const sale=fs.readFileSync(new URL('js/modules/sales.js',root),'utf8');
const stockHistory=fs.readFileSync(new URL('js/modules/stock-history.js',root),'utf8');
const statements=fs.readFileSync(new URL('js/modules/statements.js',root),'utf8');
const dashboard=fs.readFileSync(new URL('js/ui/dashboard.js',root),'utf8');
test('HistoricalCostEngine loads before BusinessEngine and application modules',()=>{
  assert.ok(html.indexOf('js/utils/historical-cost-engine.js')>=0);
  assert.ok(html.indexOf('js/utils/historical-cost-engine.js')<html.indexOf('js/utils/business-engine.js'));
});
test('new purchase and sale stock movements retain source and unit-cost snapshots',()=>{
  assert.match(purchase,/sourceId: purchaseId, sourceType: 'purchase'.*unitCost: Number\(item.cost\)/);
  assert.match(sale,/sourceId: saleId, sourceType: 'sale'.*unitCost: costPrice/);
  assert.match(stockHistory,/sourceItemId: metadata\.sourceItemId/);
});
test('dashboard and inventory statements receive stock history and use historical costing',()=>{
  assert.match(dashboard,/stockHistory: State\.stockHistory/);
  assert.match(statements,/HistoricalCostEngine\?\.product/);
  assert.match(statements,/perpetual weighted-average costing where source history reconciles/);
});
