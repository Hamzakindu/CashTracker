import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(process.cwd(), 'app/src/main/assets/js');
const sales = fs.readFileSync(path.join(root, 'modules/sales.js'), 'utf8');
const storage = fs.readFileSync(path.join(root, 'utils/storage.js'), 'utf8');
const idb = fs.readFileSync(path.join(root, 'utils/indexeddb-storage.js'), 'utf8');

 test('new sale starts fresh and carries only the previous sale date', () => {
  assert.match(sales, /EntryDrafts\.clear\('sellModal'\)/);
  assert.match(sales, /const previousSale = \(State\.sales \|\| \[\]\)/);
  assert.match(sales, /previousSale\?\.date/);
  assert.doesNotMatch(sales, /if\(!calcItems\?\.length && !bankContext && window\.EntryMemory\) EntryMemory\.apply\('sale'\)/);
  assert.doesNotMatch(sales, /Same as last time/);
  assert.match(sales, /freshSubmitBtn\.onclick = function\(\) \{ Sales\.submit\(\); \};/);
});

test('sale save waits for the durable mirror and verifies persistence', () => {
  assert.match(sales, /async submit\(\)/);
  assert.match(sales, /await State\.runAtomicDurable\('Create sale'/);
  assert.match(sales, /persistedSales\.some\(s => s && s\.id === saleId\)/);
});

test('localStorage is the authoritative synchronous recovery copy', () => {
  assert.match(storage, /localStorage\.setItem\(item\.key, item\.raw\)/);
  assert.match(storage, /const raw=localStorage\.getItem\(key\)/);
});

test('IndexedDB writes and deletes are serialized and can be flushed', () => {
  assert.match(idb, /let writeQueue=Promise\.resolve\(\)/);
  assert.match(idb, /writeQueue=job\.catch\(\(\)=>\{\}\)/);
  assert.match(idb, /async function flush\(\)/);
});

 test('State save propagates storage failure instead of silently reporting success', () => {
  const state = fs.readFileSync(path.join(root, 'state.js'), 'utf8');
  assert.match(state, /return Storage\.save\(storeName, this\[storeName\]\) === true/);
  assert.match(state, /Storage\.saveBatch\(batch\)/);
});

test('durable atomic helper commits localStorage then waits for the IndexedDB mirror', () => {
  const state = fs.readFileSync(path.join(root, 'state.js'), 'utf8');
  assert.match(state, /async runAtomicDurable\(action, fn, verify\)/);
  assert.match(state, /this\.saveAll\(\);\s*if \(window\.StorageIDB\?\.flush\) await StorageIDB\.flush\(\);/);
  assert.match(state, /Durable atomic operation failed/);
});


test('new sale has an integrity guard against voiding an existing active sale', () => {
  assert.match(sales, /const activeSaleStatusBefore = new Map/);
  assert.match(sales, /Sale integrity check failed: existing sale/);
  assert.match(sales, /State\.runAtomicDurable\('Create sale'/);
});


test('purchase save is durable, verified, and protected against duplicate taps', () => {
  const purchases = fs.readFileSync(path.join(root, 'modules/purchases.js'), 'utf8');
  assert.match(purchases, /async submit\(\)/);
  assert.match(purchases, /if \(this\._saving\) return Toast\.warning/);
  assert.match(purchases, /await State\.runAtomicDurable\('Create purchase'/);
  assert.match(purchases, /persistedPurchases\.some\(x => x && x\.id === purchaseId\)/);
});

test('direct expense save and quick expense save use durable verified commits', () => {
  const expenses = fs.readFileSync(path.join(root, 'modules/expenses.js'), 'utf8');
  assert.match(expenses, /async submitDirect\(\)/);
  assert.match(expenses, /await State\.runAtomicDurable\('Record expense'/);
  assert.match(expenses, /await State\.runAtomicDurable\('Record quick expense'/);
});

test('customer and supplier payments require an account and verify their linked movement', () => {
  const payments = fs.readFileSync(path.join(root, 'modules/payments.js'), 'utf8');
  assert.match(payments, /if\(!accountId\)return Toast\.warning\('Select the cash\/bank account for this payment'\)/);
  assert.match(payments, /await State\.runAtomicDurable\('Record payment'/);
  assert.match(payments, /moves\.some\(x=>x&&x\.paymentId===postedLedgerId/);
});

test('IndexedDB flush exposes queued mirror failures instead of silently swallowing them', () => {
  assert.match(idb, /let lastWriteError=null/);
  assert.match(idb, /lastWriteError=e;throw e/);
  assert.match(idb, /if\(error&&!idbUnavailable\)throw error/);
});
