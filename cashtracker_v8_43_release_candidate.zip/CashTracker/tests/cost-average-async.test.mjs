import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const source=fs.readFileSync(new URL('../app/src/main/assets/js/modules/cost-average.js',import.meta.url),'utf8');
test('weighted-average wrapper waits for asynchronous purchase commit before reading new purchase',()=>{
 assert.match(source,/const w=async function\(\.\.\.a\)/);
 assert.match(source,/const r=await orig\.apply\(this,a\)/);
 assert.doesNotMatch(source,/const r=orig\.apply\(this,a\)/);
});
