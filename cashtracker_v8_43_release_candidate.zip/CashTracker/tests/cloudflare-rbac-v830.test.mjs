import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const root=new URL('../',import.meta.url).pathname;
const worker=fs.readFileSync(root+'cloudflare/worker/src/index.js','utf8');
const schema=fs.readFileSync(root+'cloudflare/worker/schema.sql','utf8');
const client=fs.readFileSync(root+'app/src/main/assets/js/cloudflare-backend.js','utf8');
test('server workspace membership bootstraps the first account as owner and stores server roles',()=>{
 assert.match(worker,/INSERT OR IGNORE INTO workspace_members[\s\S]*?'owner'/);
 assert.match(schema,/CREATE TABLE IF NOT EXISTS workspace_members/);
 assert.match(schema,/PRIMARY KEY\(profile_id, user_id\)/);
});
test('whole-profile snapshots require server role and all-branch scope',()=>{
 assert.match(worker,/request\.method==='PUT'\?'snapshot_write':'snapshot_read'/);
 assert.match(worker,/Branch-scoped accounts cannot download or upload a whole-workspace snapshot/);
 assert.match(worker,/\['owner','manager'\]\.includes\(m\.role\)/);
 assert.match(worker,/\['owner','manager','accountant'\]\.includes\(m\.role\)/);
});
test('only owners can manage members and owners cannot be demoted',()=>{
 assert.match(worker,/action==='members' \? m\.role==='owner'/);
 assert.match(worker,/existingTarget\?\.role==='owner'/);
 assert.match(worker,/existing\.role==='owner'/);
});
test('member changes are recorded in server-side security audit',()=>{
 assert.match(schema,/CREATE TABLE IF NOT EXISTS workspace_security_audit/);
 assert.match(worker,/securityAudit\(env,profile,userId,target\.id,'member_added_or_updated'/);
 assert.match(worker,/securityAudit\(env,profile,userId,targetId,'member_access_changed'/);
});
test('client exposes server member and audit management controls',()=>{
 assert.match(client,/listWorkspaceMembers\(/);
 assert.match(client,/addWorkspaceMember\(/);
 assert.match(client,/changeWorkspaceMember\(/);
 assert.match(client,/viewWorkspaceSecurityAudit\(/);
});

test('invited members access the owner workspace snapshot rather than a separate personal copy',()=>{
 assert.match(schema,/workspace_owner_id TEXT NOT NULL/);
 assert.match(worker,/const workspaceUserId=access\.member\.workspace_owner_id\|\|userId/);
 assert.match(worker,/bind\(snapshotId,workspaceUserId,profile,revision/);
});
