import test from 'node:test';
import assert from 'node:assert/strict';
import '../app/src/main/assets/js/utils/business-engine.js';
import '../app/src/main/assets/js/utils/financial-audit.js';
const Audit=globalThis.FinancialAudit;

test('customer and supplier balances reconcile from opening balances and outstanding source transactions',()=>{
 const issues=Audit.balanceAudit({
  customers:[{id:'c1',name:'Customer',openingBalance:10,balance:43}],
  suppliers:[{id:'s1',name:'Supplier',openingBalance:3,balance:23}],
  sales:[{id:'sale1',customerId:'c1',debitRemaining:40}],
  purchases:[{id:'purchase1',supplierId:'s1',debit:30}],
  returns:[{id:'ret1',customerId:'c1',arOffset:2}],
  paymentLedger:[
   {id:'cp',entityType:'customer',entityId:'c1',sourceType:'payment',kind:'settlement',amount:5,balanceApplied:5},
   {id:'sp',entityType:'supplier',entityId:'s1',sourceType:'payment',kind:'settlement',amount:10,balanceApplied:10}
  ]
 });
 assert.equal(issues.length,0);
});

test('void and cancelled transactions do not contribute to derived balances',()=>{
 const issues=Audit.balanceAudit({customers:[{id:'c',openingBalance:0,balance:0}],sales:[{id:'v',customerId:'c',debitRemaining:100,status:'void'},{id:'x',customerId:'c',debitRemaining:50,status:'cancelled'}]});
 assert.equal(issues.length,0);
});

test('reports customer and supplier cached-balance discrepancies without mutating input',()=>{
 const data={customers:[{id:'c',name:'C',openingBalance:0,balance:99}],suppliers:[{id:'s',name:'S',openingBalance:0,balance:0}],sales:[{id:'sale',customerId:'c',debitRemaining:50}],purchases:[]};
 const before=JSON.stringify(data),issues=Audit.balanceAudit(data);
 assert.equal(issues.length,1);assert.equal(issues[0].type,'customer_balance');assert.equal(issues[0].expected,50);assert.equal(issues[0].actual,99);assert.equal(JSON.stringify(data),before);
});

test('detects missing payment movement',()=>{
 const issues=Audit.paymentAudit({paymentLedger:[{id:'p1',entityType:'customer',entityId:'c',accountId:'cash',amount:20,sourceType:'payment'}],moneyTransactions:[]});
 assert.equal(issues.length,1);assert.equal(issues[0].type,'payment_missing_movement');
});

test('detects duplicate and mismatched linked movements',()=>{
 const duplicate=Audit.paymentAudit({paymentLedger:[{id:'p1',entityType:'customer',accountId:'cash',amount:20}],moneyTransactions:[{paymentId:'p1',accountId:'cash',amount:20,type:'in'},{paymentId:'p1',accountId:'cash',amount:20,type:'in'}]});
 assert.equal(duplicate[0].type,'payment_duplicate_movement');
 const mismatch=Audit.paymentAudit({paymentLedger:[{id:'p2',entityType:'customer',accountId:'cash',amount:20}],moneyTransactions:[{paymentId:'p2',accountId:'cash',amount:25,type:'out'}]});
 assert.equal(mismatch[0].type,'payment_movement_mismatch');
});

test('ignores void payment records and recognizes legacy source-linked movement',()=>{
 const issues=Audit.paymentAudit({paymentLedger:[{id:'void',status:'void',accountId:'cash',amount:10},{id:'legacy',entityType:'supplier',accountId:'bank',amount:12,sourceId:'pur1',sourceType:'purchase',kind:'purchase_payment'}],moneyTransactions:[{accountId:'bank',amount:12,type:'out',sourceId:'pur1',sourceType:'purchase_payment'}]});
 assert.equal(issues.length,0);
});

test('audit explicitly declares read-only output',()=>{
 const r=Audit.run({});assert.equal(r.readOnly,true);assert.equal(r.ok,true);
});

test('non-cash advance application is not expected to have a bank movement',()=>{
 const issues=Audit.paymentAudit({paymentLedger:[{id:'a1',entityType:'customer',amount:30,kind:'advance_applied',sourceType:'sale'}],moneyTransactions:[]});
 assert.equal(issues.length,0);
});


test('balance audit includes recorded manual adjustments and only subtracts applied settlement amounts',()=>{
 const issues=Audit.balanceAudit({
  customers:[{id:'c',openingBalance:10,balance:32}],sales:[{id:'s',customerId:'c',debitRemaining:30}],
  paymentLedger:[{id:'p',entityType:'customer',entityId:'c',sourceType:'payment',kind:'settlement',amount:50,balanceApplied:8}],
  auditLog:[{action:'balance_adjustment',entityType:'customer',details:{entityId:'c',amount:0,balanceApplied:0}}]
 });
 assert.equal(issues.length,0);
});

test('legacy settlement without applied amount is flagged instead of guessed',()=>{
 const issues=Audit.balanceAudit({customers:[{id:'c',balance:40}],paymentLedger:[{id:'p',entityType:'customer',entityId:'c',sourceType:'payment',kind:'settlement',amount:10}]});
 assert.equal(issues.length,1);assert.equal(issues[0].type,'legacy_balance_history_incomplete');
});


test('audit uses applied portion of an overpayment adjustment, not excess advance',()=>{
 const issues=Audit.balanceAudit({customers:[{id:'c',openingBalance:50,balance:0}],auditLog:[{action:'balance_adjustment',entityType:'customer',details:{entityId:'c',amount:-100,balanceApplied:-50,advanceAdded:50}}]});
 assert.equal(issues.length,0);
});


test('audit does not invent a zero opening balance when a party has only settlements',()=>{
 const issues=Audit.balanceAudit({customers:[{id:'c',balance:75}],paymentLedger:[{id:'p',entityType:'customer',entityId:'c',sourceType:'payment',kind:'settlement',amount:25,balanceApplied:25}]});
 assert.equal(issues.length,1);assert.equal(issues[0].type,'legacy_balance_opening_missing');
});


test('supplier return offsets reduce expected payable in the balance audit',()=>{
 const issues=Audit.balanceAudit({
  suppliers:[{id:'s',name:'Supplier',openingBalance:100,balance:70}],
  returns:[{id:'r',returnType:'supplier_return',sourceType:'purchase',supplierId:'s',partyId:'s',totalRefund:30}]
 });
 assert.equal(issues.length,0);
});

test('partial supplier cash refund offsets only the non-cash portion of payable',()=>{
 const issues=Audit.balanceAudit({
  suppliers:[{id:'s',name:'Supplier',openingBalance:100,balance:65}],
  returns:[{id:'r',returnType:'supplier_return',sourceType:'purchase',supplierId:'s',partyId:'s',totalRefund:60,refundMethod:'cash',cashRefundAmount:25}]
 });
 assert.equal(issues.length,0);
});

test('supplier returns are not treated as customer receivable offsets',()=>{
 const issues=Audit.balanceAudit({
  customers:[{id:'c',openingBalance:100,balance:100}],
  returns:[{id:'r',customerId:'c',supplierId:'s',returnType:'supplier_return',totalRefund:40}]
 });
 assert.equal(issues.length,0);
});

test('soft-deleted transactions are excluded from financial balance audit',()=>{
 const issues=Audit.balanceAudit({
  customers:[{id:'c',openingBalance:0,balance:0}],
  sales:[{id:'s',customerId:'c',debitRemaining:50,deletedAt:'2026-11-01T00:00:00.000Z'}]
 });
 assert.equal(issues.length,0);
});

test('BusinessEngine and FinancialAudit agree on supplier balances after partial cash refunds',()=>{
 const data={
  suppliers:[{id:'s',name:'Supplier',openingBalance:100,balance:65}],
  returns:[{id:'r',returnType:'supplier_return',sourceType:'purchase',supplierId:'s',partyId:'s',totalRefund:60,refundMethod:'cash',cashRefundAmount:25}]
 };
 const projected=globalThis.BusinessEngine.calculate(data);
 const issues=Audit.balanceAudit(data);
 assert.equal(projected.supplierBalances,65);
 assert.equal(issues.length,0);
});


test('payment audit detects duplicate idempotency keys without mutating payment rows',()=>{
 const rows=[{id:'p1',idempotencyKey:'attempt-1',amount:10},{id:'p2',idempotencyKey:'attempt-1',amount:10}];
 const before=JSON.stringify(rows);const issues=Audit.paymentAudit({paymentLedger:rows,moneyTransactions:[]});
 assert.equal(issues.some(x=>x.type==='payment_duplicate_idempotency_key'&&x.count===2),true);assert.equal(JSON.stringify(rows),before);
});
