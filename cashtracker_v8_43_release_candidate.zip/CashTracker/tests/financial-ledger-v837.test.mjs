import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

function loadAccounting(state) {
  const context = {
    window: {}, State: state,
    Helpers: { esc: s => String(s), formatCurrency: n => Number(n).toFixed(2) },
    document: { getElementById: () => null }, console,
    confirm: () => true,
    Toast: { success(){}, error(){} }
  };
  vm.runInNewContext(fs.readFileSync(new URL('../app/src/main/assets/js/modules/accounting-double-entry.js', import.meta.url), 'utf8'), context);
  return context.window.AccountingDoubleEntry;
}

const balancedSale = (id, total=100) => ({id,transactionId:id,date:'2026-11-01',total,paymentReceived:total,debitRemaining:0,profit:30,status:'posted'});

test('V8.37 remains backward compatible until the owner explicitly enables persistent posting', () => {
  const state={accountingMeta:{version:6,migratedAt:'2026-01-01'},sales:[balancedSale('s1')],purchases:[],returns:[],directExpenses:[],paymentLedger:[],cashAccounts:[],customers:[],suppliers:[]};
  const D=loadAccounting(state);
  assert.equal(D.postingPreview().enabled,false);
  assert.equal(state.accountingMeta.postingLedger.length,0);
  assert.equal(D.postedLines().length,D.build().length);
});

test('V8.37 explicit initialization appends stable immutable lines and is idempotent', () => {
  const state={accountingMeta:{version:6,migratedAt:'2026-01-01'},sales:[balancedSale('s1')],purchases:[],returns:[],directExpenses:[],paymentLedger:[],cashAccounts:[],customers:[],suppliers:[],saveAll(){this.saved=true;return true;}};
  const D=loadAccounting(state);
  const result=D.capturePosting({initialize:true});
  assert.equal(result.ok,true);
  assert.equal(result.added,D.build().length);
  assert.equal(state.accountingMeta.postingLedgerEnabled,true);
  const ids=state.accountingMeta.postingLedger.map(x=>x.entryId);
  const again=D.capturePosting({initialize:true});
  assert.equal(again.ok,true);
  assert.equal(again.added,0);
  assert.deepEqual(state.accountingMeta.postingLedger.map(x=>x.entryId),ids);
  assert.equal(D.ledgerAudit().ok,true);
});

test('V8.37 automatic capture appends only newly-created groups and does not rewrite old rows', () => {
  const state={accountingMeta:{version:6,postingLedgerEnabled:true,postingLedger:[]},sales:[balancedSale('s1')],purchases:[],returns:[],directExpenses:[],paymentLedger:[],cashAccounts:[],customers:[],suppliers:[]};
  const D=loadAccounting(state);
  const first=D.autoCapturePosting();
  assert.equal(first.added,D.build().length);
  const before=JSON.stringify(state.accountingMeta.postingLedger);
  state.sales.push({...balancedSale('s2'),date:'2026-11-02'});
  const second=D.autoCapturePosting();
  assert.equal(second.ok,true);
  assert.equal(second.added, D.build().length - JSON.parse(before).length);
  assert.equal(JSON.stringify(state.accountingMeta.postingLedger.slice(0,JSON.parse(before).length)),before);
});

test('V8.37 changed posted source is blocked instead of overwritten', () => {
  const state={accountingMeta:{version:6,postingLedgerEnabled:true,postingLedger:[]},sales:[balancedSale('s1')],purchases:[],returns:[],directExpenses:[],paymentLedger:[],cashAccounts:[],customers:[],suppliers:[]};
  const D=loadAccounting(state);
  assert.equal(D.autoCapturePosting().ok,true);
  const count=state.accountingMeta.postingLedger.length;
  state.sales[0].total=120;state.sales[0].paymentReceived=120;
  const result=D.autoCapturePosting();
  assert.equal(result.ok,false);
  assert.ok(result.preview.issues.some(x=>x.type==='posted_source_changed'));
  assert.equal(state.accountingMeta.postingLedger.length,count);
});

test('V8.37 reversal is append-only, balanced and requires a reason', () => {
  const state={accountingMeta:{version:6,postingLedgerEnabled:true,postingLedger:[]},sales:[balancedSale('s1')],purchases:[],returns:[],directExpenses:[],paymentLedger:[],cashAccounts:[],customers:[],suppliers:[],auditLog:[],saveAll(){return true;}};
  const D=loadAccounting(state);
  D.autoCapturePosting();
  const group=state.accountingMeta.postingLedger[0].groupKey;
  assert.throws(()=>D.reversePostedGroup(group,''),/reason is required/);
  const original=state.accountingMeta.postingLedger.length;
  const reversal=D.reversePostedGroup(group,'Corrected by voiding the original sale');
  assert.equal(reversal.length>0,true);
  assert.equal(state.accountingMeta.postingLedger.length,original+reversal.length);
  assert.equal(reversal.reduce((n,x)=>n+x.debit-x.credit,0),0);
  assert.equal(state.auditLog[0].action,'accounting_journal_reversal');
  assert.equal(D.ledgerAudit().ok,true);
});

test('V8.37 state save hooks preserve existing source stores and capture into the existing accountingMeta batch', () => {
  const source=fs.readFileSync(new URL('../app/src/main/assets/js/state.js', import.meta.url),'utf8');
  assert.match(source,/autoCapturePosting\(\)/);
  assert.match(source,/accountingMeta:this\.accountingMeta/);
  assert.match(source,/previousAccountingMeta/);
});

test('V8.37 persisted ledger audit detects edited posted line content', () => {
  const state={accountingMeta:{version:6,postingLedgerEnabled:true,postingLedger:[]},sales:[balancedSale('s1')],purchases:[],returns:[],directExpenses:[],paymentLedger:[],cashAccounts:[],customers:[],suppliers:[]};
  const D=loadAccounting(state);
  D.autoCapturePosting();
  state.accountingMeta.postingLedger[0].memo='tampered';
  const audit=D.ledgerAudit();
  assert.equal(audit.ok,false);
  assert.ok(audit.issues.some(x=>x.type==='persisted_entry_fingerprint_mismatch'));
});
