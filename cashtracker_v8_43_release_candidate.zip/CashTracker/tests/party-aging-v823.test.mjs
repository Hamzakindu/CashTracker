import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import '../app/src/main/assets/js/utils/business-engine.js';
const Engine=globalThis.BusinessEngine;
test('receivables and payables both delegate aging allocation to BusinessEngine',()=>{
 const receivables=fs.readFileSync(new URL('../app/src/main/assets/js/modules/receivables.js',import.meta.url),'utf8');
 const payables=fs.readFileSync(new URL('../app/src/main/assets/js/modules/payables.js',import.meta.url),'utf8');
 assert.match(receivables,/BusinessEngine\.allocateAging\(outstanding,sales/);
 assert.match(payables,/BusinessEngine\.allocateAging\(outstanding,ps/);
});
test('aging allocates reconciled balance to newest source debts and keeps undated remainder in 90+',()=>{
 const asOf=new Date(2026,10,12);
 const x=Engine.allocateAging(65,[{date:'2026-09-01',amount:40},{date:'2026-11-01',amount:50}],r=>r.amount,r=>r.date,asOf);
 assert.deepEqual([...x.b],[50,0,15,0]);
 assert.equal(x.oldest,72);
 assert.equal(x.total,65);
});
test('aging never allocates more than the reconciled balance or source debt',()=>{
 const x=Engine.allocateAging(25,[{date:'2026-11-01',amount:10},{date:'2026-10-01',amount:30}],r=>r.amount,r=>r.date,new Date(2026,10,12));
 assert.deepEqual([...x.b],[10,15,0,0]);
 assert.equal(x.total,25);
});
