import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const read = p => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const periodSource = read('app/src/main/assets/js/modules/period-lock.js');

function periodHarness(role, allowed) {
  const state = {sales:[],purchases:[],directExpenses:[],returns:[],moneyTransactions:[],customers:[],suppliers:[],paymentLedger:[],cashAccounts:[],auditLog:[],periodClosures:[],save:()=>true};
  const audit=[];
  const user={id:'u-1',name:'Test User',role};
  const Roles={isStaffLoginEnabled:()=>true,currentUser:()=>user,requirePermission:p=>{if(!allowed.includes(p))throw new Error('denied '+p);return true;}};
  const window={State:state,Roles,Helpers:{esc:String},Toast:{success(){},warning(){},error(){}},Security:{audit:(...a)=>audit.push(a)},addEventListener(){}};
  const context={window,State:state,Roles,Toast:window.Toast,Security:window.Security,localStorage:{getItem:()=>null,setItem(){},removeItem(){}},document:{getElementById:()=>null},console,Date,Math};
  vm.runInNewContext(periodSource,context);
  return {P:window.PeriodLock,State:state,audit};
}

test('manager and accountant may close a period, but only owner may reopen it',()=>{
  const manager=periodHarness('manager',['close_period']);
  const closed=manager.P.close('2026-10-01','2026-10-31');
  assert.equal(closed.closedByRole,'manager');
  assert.throws(()=>manager.P.reopen(closed.id,'Correct a wrong date'),/denied|not authorized/);
  const accountant=periodHarness('accountant',['close_period']);
  assert.equal(accountant.P.close('2026-10-01','2026-10-31').closedByRole,'accountant');
  const owner=periodHarness('owner',['close_period','reopen_period']);
  const period=owner.P.close('2026-09-01','2026-09-30');
  owner.P.reopen(period.id,'Correct an incorrectly dated purchase');
  assert.equal(period.reopenedByRole,'owner');
  assert.equal(period.reopenReason,'Correct an incorrectly dated purchase');
});

test('period closure authorization failure does not create a closure',()=>{
  const h=periodHarness('cashier',[]);
  assert.throws(()=>h.P.close('2026-10-01','2026-10-31'),/denied|not authorized/);
  assert.equal(h.State.periodClosures.length,0);
});

test('audit entries include staff identity, role and branch context',()=>{
  const src=read('app/src/main/assets/js/security-hardening.js');
  assert.match(src,/actorId:user\?\.id/);
  assert.match(src,/actorRole:user\?\.role/);
  assert.match(src,/branchId:State\.branchAccessMeta\?\.activeBranchId/);
});

test('audit health detects missing and duplicate audit identifiers and incomplete records',()=>{
  const State={auditLog:[
    {id:'a1',actor:'Owner',action:'close',createdAt:'2026-10-01T10:00:00Z'},
    {id:'a1',actor:'Owner',action:'reopen',createdAt:'2026-10-02T10:00:00Z'},
    {actor:'?',createdAt:'2026-10-03T10:00:00Z'}
  ]};
  const window={State};
  const context={window,State,document:{readyState:'loading',addEventListener(){}},console};
  vm.runInNewContext(read('app/src/main/assets/js/security-hardening.js'),context);
  const result=window.Security.auditHealth();
  assert.equal(result.ok,false);
  assert.ok(result.issues.some(x=>x.type==='audit_duplicate_id'));
  assert.ok(result.issues.some(x=>x.type==='audit_missing_id'));
});

test('roles grant period permissions by role and restrict audit tab access',()=>{
  const src=read('app/src/main/assets/js/modules/roles.js');
  assert.match(src,/manager:\{label:'Manager',[\s\S]*?can:\[[^\]]*'close_period'/);
  assert.match(src,/accountant:\{label:'Accountant',[\s\S]*?can:\[[^\]]*'audit'[^\]]*'close_period'/);
  assert.match(src,/owner:\{label:'Owner',[\s\S]*?can:\[[^\]]*'reopen_period'/);
  assert.match(src,/t==='audit'\)\|\|can\('audit'\)/);
});
