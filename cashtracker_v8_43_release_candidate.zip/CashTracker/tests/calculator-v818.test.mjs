import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../app/src/main/assets/js/calculator-home.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../app/src/main/assets/calculator-home.html', import.meta.url), 'utf8');

test('embedded and standalone calculator use profile-scoped shared history storage', () => {
  assert.match(source, /CT_CALCULATOR_V2_HISTORY/);
  assert.match(source, /window\.addEventListener\('storage'/);
  assert.match(source, /if\(event\.key===HISTORY_KEY\)renderHistory\(\)/);
});

test('history writes merge by stable ID to avoid duplicate entries across calculator views', () => {
  assert.match(source, /function mergeHistoryEntries\(primary,secondary\)/);
  assert.match(source, /function writeHistoryMerged\(entries\)/);
  assert.match(source, /writeHistoryMerged\(\[item\]\)/);
});

test('swipe down opens history and swipe up opens saved operations', () => {
  assert.match(source, /gestureSurface\.addEventListener\('touchstart'/);
  assert.match(source, /gestureSurface\.addEventListener\('touchend'/);
  assert.match(source, /if\(dy>0\).*openDrawer\(historyDrawer\)/s);
  assert.match(source, /else if\(!saveDrawer\.classList\.contains\('open'\)\)openDrawer\(saveDrawer\)/);
});

test('share remains user-confirmed and uses the editable share header', () => {
  assert.match(source, /function shareHeader\(\)/);
  assert.match(source, /confirm\('Share this calculation\?/);
  assert.match(source, /settings\.shareHeader=e\.target\.value/);
});

test('clear history writes an empty shared list and offers an undo restore', () => {
  assert.match(source, /localStorage\.setItem\(HISTORY_KEY,'\[\]'\)/);
  assert.match(source, /writeHistoryMerged\(JSON\.parse\(backup\)\)/);
});

test('calculator keeps the history action menu aligned to the right', () => {
  assert.match(html, /#historyList \.hmore[\s\S]*?justify-self:end/);
  assert.match(html, /#historyList \.hmenu[\s\S]*?right:6px[\s\S]*?left:auto/);
});
