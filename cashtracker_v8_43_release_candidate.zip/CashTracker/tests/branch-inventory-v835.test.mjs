import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const source = readFileSync(new URL('../app/src/main/assets/js/modules/branch-inventory.js', import.meta.url), 'utf8');
function setup(){
  const State={branches:[{id:'a',name:'Branch A',active:true},{id:'b',name:'Branch B',active:true}],products:[{id:'p1',name:'Product 1',stock:15}],stockHistory:[],branchStockOpening:[{productId:'p1',branchId:'a',quantity:10,asOf:'2026-11-01T00:00:00.000Z'},{productId:'p1',branchId:'b',quantity:5,asOf:'2026-11-01T00:00:00.000Z'}],saveUndoState(){}};
  let values={bitProduct:'p1',bitFrom:'a',bitTo:'b',bitQty:'3',bitNote:'test'};
  const ctx={State,Storage:{saveBatch(){return true}},Helpers:{esc:String,getToday:()=> '2026-11-12'},Toast:{warning(){},error(){},success(){}},Modals:{close(){}},confirm:()=>true,document:{getElementById(id){return values[id]?{value:values[id]}:null}},console,Date,Math,Number,String,Array,Object,JSON};
  ctx.window=ctx;ctx.registerModule=(name,fn)=>{ctx.api=fn()};vm.runInNewContext(source,ctx);return {State,api:ctx.api,setValues:v=>values=v};
}
test('branch balances start from explicit per-branch opening allocations and reconcile to workspace stock',()=>{
 const {api}=setup();assert.equal(api.balance('p1','a'),10);assert.equal(api.balance('p1','b'),5);assert.equal(api.productStatus({id:'p1',stock:15}).ready,true);
});
test('unallocated product stock is not guessed or reported as a branch balance',()=>{
 const {State,api}=setup();State.branchStockOpening=[];assert.equal(api.balance('p1','a'),null);assert.equal(api.productStatus(State.products[0]).ready,false);
});
test('dispatch reduces sender stock only; receipt increases destination; workspace stock total is unchanged',()=>{
 const {State,api}=setup();api.dispatch();const out=State.stockHistory.find(x=>x.type==='branch-transfer-out');assert.ok(out);assert.equal(api.balance('p1','a'),7);assert.equal(api.balance('p1','b'),5);assert.equal(State.products[0].stock,15);api.receive(out.transferId);assert.equal(api.balance('p1','a'),7);assert.equal(api.balance('p1','b'),8);assert.equal(api.productStatus(State.products[0]).ready,true);assert.equal(State.products[0].stock,15);
});
test('cancelling an in-transit transfer restores sender quantity and does not credit destination',()=>{
 const {State,api}=setup();api.dispatch();const out=State.stockHistory.find(x=>x.type==='branch-transfer-out');api.cancel(out.transferId);assert.equal(api.balance('p1','a'),10);assert.equal(api.balance('p1','b'),5);assert.equal(out.transferStatus,'cancelled');assert.equal(State.products[0].stock,15);
});
test('insufficient branch stock and same-branch transfers are rejected',()=>{
 const {State,api,setValues}=setup();setValues({bitProduct:'p1',bitFrom:'a',bitTo:'b',bitQty:'99'});api.dispatch();assert.equal(State.stockHistory.length,0);setValues({bitProduct:'p1',bitFrom:'a',bitTo:'a',bitQty:'1'});api.dispatch();assert.equal(State.stockHistory.length,0);
});
test('destination branch can confirm its own isolated incoming transfer record',()=>{
 const {State,api}=setup();State.stockHistory=[{id:'pending',transferId:'remote-transfer',productId:'p1',productName:'Product 1',branchId:'b',originBranchId:'a',change:0,transferQuantity:2,previousStock:5,newStock:5,type:'branch-transfer-pending',transferStatus:'in_transit',timestamp:'2026-11-10T10:00:00.000Z',date:'2026-11-10'}];api.receive('remote-transfer');assert.equal(api.balance('p1','b'),7);assert.equal(State.stockHistory.find(x=>x.id==='pending').type,'branch-transfer-in');
});
test('branch inventory store is included in persistence, backups and branch snapshots',()=>{
 const state=readFileSync(new URL('../app/src/main/assets/js/state.js',import.meta.url),'utf8');
 const backup=readFileSync(new URL('../app/src/main/assets/js/backup.js',import.meta.url),'utf8');
 const storage=readFileSync(new URL('../app/src/main/assets/js/utils/storage.js',import.meta.url),'utf8');
 const partition=readFileSync(new URL('../app/src/main/assets/js/branch-snapshot-partition.js',import.meta.url),'utf8');
 const html=readFileSync(new URL('../app/src/main/assets/index.html',import.meta.url),'utf8');
 assert.match(state,/this\.branchStockOpening = Storage\.load\('branchStockOpening'\)/);assert.match(state,/branchStockOpening.*branchStockOpening/);
 assert.match(backup,/branchStockOpening/);assert.match(storage,/branchStockOpening/);assert.match(partition,/branchStockOpening/);assert.match(html,/js\/modules\/branch-inventory\.js/);
});
