import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
const source = readFileSync(new URL('../app/src/main/assets/js/branch-snapshot-partition.js', import.meta.url), 'utf8');
const window = {};
vm.runInNewContext(source, {window, Set, Array, String, Date, Error});
const api = window.BranchSnapshotPartition;

test('migration preview lists unassigned historical records without changing them', () => {
  const stores = {products:[{id:'p1',name:'Item'},{id:'p2',name:'Tagged',branchId:'b1'}]};
  const rows = api.previewUnassigned(stores);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].id, 'p1');
  assert.equal(stores.products[0].branchId, undefined);
});

test('manual assignments update only selected records and preserve other branches', () => {
  const stores = {products:[{id:'p1',name:'Item'},{id:'p2',name:'Other',branchId:'b2'}]};
  const result = api.applyAssignments(stores,[{store:'products',index:0,id:'p1',branchId:'b1'}]);
  assert.equal(result.updated,1);
  assert.equal(result.stores.products[0].branchId,'b1');
  assert.equal(result.stores.products[1].branchId,'b2');
  assert.equal(stores.products[0].branchId,undefined);
});

test('migration rejects stale, duplicate, already-assigned and invalid branch assignments', () => {
  const stores = {products:[{id:'p1',name:'Item'}]};
  assert.throws(()=>api.applyAssignments(stores,[{store:'products',index:0,id:'wrong',branchId:'b1'}]),/changed/);
  assert.throws(()=>api.applyAssignments(stores,[{store:'products',index:0,id:'p1',branchId:'b1'},{store:'products',index:0,id:'p1',branchId:'b1'}]),/Duplicate/);
  assert.throws(()=>api.applyAssignments(stores,[{store:'products',index:0,id:'p1',branchId:''}]),/Invalid/);
  assert.throws(()=>api.applyAssignments({products:[{id:'p1',branchId:'b2'}]},[{store:'products',index:0,id:'p1',branchId:'b1'}]),/already assigned/);
});
