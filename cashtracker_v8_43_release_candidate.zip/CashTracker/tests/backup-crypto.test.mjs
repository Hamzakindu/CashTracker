import test from 'node:test';
import assert from 'node:assert/strict';
globalThis.window = globalThis;
await import('../app/src/main/assets/js/utils/backup-crypto.js');
test('backup crypto uses passphrase envelope and restores JSON', async()=>{
 const original={products:[{name:'A',price:12.34}],n:7};
 const encrypted=await BackupCrypto.encryptJson(original,'correct horse battery staple');
 const env=JSON.parse(encrypted);
 assert.equal(env.v,2); assert.equal(env.kdf,'PBKDF2-SHA256'); assert.equal(env.salt.length>0,true);
 assert.deepEqual(await BackupCrypto.decryptJson(encrypted,'correct horse battery staple'),original);
});
test('plain JSON restore requires explicit legacy compatibility opt-in',async()=>{const x={products:[],sales:[]};assert.deepEqual(await BackupCrypto.decryptJson(JSON.stringify(x),'unused-passphrase',{allowLegacyPlainJson:true}),x)});

test('plain JSON is rejected by default to prevent encryption downgrade',async()=>{await assert.rejects(()=>BackupCrypto.decryptJson(JSON.stringify({sales:[]}), 'unused-passphrase'),/Unsupported backup format/)});

test('encrypted backup envelope rejects modified ciphertext', async()=>{
 const original={products:[{id:'p1'}],sales:[]};
 const encrypted=JSON.parse(await BackupCrypto.encryptJson(original,'another strong passphrase'));
 encrypted.ciphertext=encrypted.ciphertext.slice(0,-4)+'AAAA';
 await assert.rejects(()=>BackupCrypto.decryptJson(encrypted,'another strong passphrase'));
});

test('encrypted backup rejects a weakened PBKDF2 iteration declaration', async()=>{
 const encrypted=JSON.parse(await BackupCrypto.encryptJson({products:[]},'another strong passphrase'));
 encrypted.iterations=1000;
 assert.equal(BackupCrypto.isEncrypted(encrypted),false);
 await assert.rejects(()=>BackupCrypto.decryptJson(encrypted,'another strong passphrase'),/Unsupported backup format/);
});
