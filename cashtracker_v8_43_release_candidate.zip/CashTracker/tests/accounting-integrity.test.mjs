import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

function loadAccounting(state) {
  const context = { window: {}, State: state, Helpers: { esc: s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])), formatCurrency: n => Number(n).toFixed(2) }, document: { getElementById: () => null }, console };
  vm.runInNewContext(fs.readFileSync(new URL('../app/src/main/assets/js/modules/accounting-double-entry.js', import.meta.url), 'utf8'), context);
  return context.window.AccountingDoubleEntry;
}

test('double-entry audit accepts balanced sale, purchase, settlement, and customer-credit return groups', () => {
  const D = loadAccounting({
    sales:[{id:'s1',date:'2026-11-01',total:100,paymentReceived:60,debitRemaining:40,profit:30}],
    purchases:[{id:'p1',date:'2026-11-02',total:80,paid:50,debit:30}],
    returns:[{id:'r1',date:'2026-11-03',totalRefund:20,refundMethod:'credit',arOffset:15,advanceAdded:5,costAmount:8}],
    directExpenses:[], paymentLedger:[{id:'pay1',date:'2026-11-04',sourceType:'payment',entityType:'customer',kind:'settlement',amount:10}]
  });
  const audit = D.audit('2026-11-01','2026-11-30');
  assert.equal(audit.ok, true, JSON.stringify(audit.issues));
  assert.equal(audit.entries.length, 4);
  assert.equal(Math.round(audit.totalDebit*100), Math.round(audit.totalCredit*100));
});

test('double-entry audit flags an unbalanced transaction group instead of hiding it in aggregate totals', () => {
  const D = loadAccounting({ sales:[{id:'bad-sale',date:'2026-11-01',total:100,paymentReceived:20,debitRemaining:50,profit:10}], purchases:[], returns:[], directExpenses:[], paymentLedger:[] });
  const audit = D.audit();
  assert.equal(audit.ok, false);
  assert.ok(audit.issues.some(x => x.type === 'unbalanced_transaction' && x.ref === 'sale:bad-sale'));
});

test('return without a cash refund does not create an imaginary cash credit', () => {
  const D = loadAccounting({ sales:[], purchases:[], returns:[{id:'r-none',date:'2026-11-03',totalRefund:0,refundMethod:'none',costAmount:12}], directExpenses:[], paymentLedger:[] });
  const lines = D.build();
  assert.equal(lines.some(x => x.ref === 'r-none' && x.account === '1000'), false);
  const audit = D.audit();
  assert.equal(audit.ok, true, JSON.stringify(audit.issues));
});

test('period lock guards return submission, update, and deletion as well as sales and purchases', () => {
  const src = fs.readFileSync(new URL('../app/src/main/assets/js/modules/period-lock.js', import.meta.url), 'utf8');
  assert.match(src, /wrap\('Returns','submit'/);
  assert.match(src, /wrap\('Returns','update'/);
  assert.match(src, /wrap\('Returns','delete'/);
});

test('legacy non-cash return with a positive refund is flagged and never credited to cash', () => {
  const D = loadAccounting({ sales:[], purchases:[], returns:[{id:'legacy-r',date:'2026-11-03',totalRefund:20,refundMethod:'none',costAmount:10}], directExpenses:[], paymentLedger:[] });
  const lines = D.build();
  assert.equal(lines.some(x => x.ref === 'return:legacy-r' && x.account === '1000'), false);
  assert.ok(D.audit().issues.some(x => x.type === 'unbalanced_transaction' && x.ref === 'return:legacy-r'));
});

test('general ledger provides period opening, dated movements, and closing balance per account', () => {
  const D = loadAccounting({
    sales:[
      {id:'s-old',date:'2026-10-31',total:100,paymentReceived:100,debitRemaining:0,profit:30},
      {id:'s-new',date:'2026-11-05',total:50,paymentReceived:20,debitRemaining:30,profit:15}
    ], purchases:[], returns:[], directExpenses:[], paymentLedger:[]
  });
  const gl = D.accountLedger('1000','2026-11-01','2026-11-30');
  assert.equal(gl.opening,100);
  assert.equal(gl.rows.length,1);
  assert.equal(gl.rows[0].runningBalance,120);
  assert.equal(gl.closing,120);
  assert.equal(gl.totalDebit,20);
  assert.equal(gl.totalCredit,0);
});

test('calculator share header is user-editable, persisted, and applied to both share entry points', () => {
  const home = fs.readFileSync(new URL('../app/src/main/assets/js/calculator-home.js', import.meta.url), 'utf8');
  const html = fs.readFileSync(new URL('../app/src/main/assets/calculator-home.html', import.meta.url), 'utf8');
  const main = fs.readFileSync(new URL('../app/src/main/assets/js/modules/calculator.js', import.meta.url), 'utf8');
  assert.match(html, /id="shareHeaderSetting"/);
  assert.match(home, /settings\.shareHeader/);
  assert.match(home, /shareHeader\(\)/);
  assert.match(main, /CT_CALCULATOR_V2_SETTINGS_/);
  assert.match(main, /shareHeader/);
});

test('cash and bank opening balances create balanced equity-backed journal entries without counting audit snapshots twice', () => {
  const D = loadAccounting({
    cashAccounts:[{id:'cash-a',name:'Main Cash',openingBalance:250,openingDate:'2026-10-01'}],
    moneyTransactions:[{id:'opening-audit',accountId:'cash-a',type:'opening',amount:250,date:'2026-10-01',status:'posted'}],
    sales:[],purchases:[],returns:[],directExpenses:[],paymentLedger:[]
  });
  const lines=D.build();
  assert.equal(lines.filter(x=>x.ref==='opening-account:cash-a').length,2);
  assert.equal(lines.find(x=>x.account==='1000'&&x.accountId==='cash-a').debit,250);
  assert.equal(lines.find(x=>x.account==='3000').credit,250);
  assert.equal(D.audit().ok,true,JSON.stringify(D.audit().issues));
  assert.equal(D.accountLedger('1000|cash-a','2026-11-01','2026-11-30').opening,250);
});

test('individual cash account ledger isolates only movements assigned to that account', () => {
  const D=loadAccounting({
    cashAccounts:[{id:'cash-a',name:'Main Cash',openingBalance:100,openingDate:'2026-10-01'},{id:'bank-b',name:'CBE',openingBalance:500,openingDate:'2026-10-01'}],
    sales:[{id:'s1',date:'2026-11-02',total:100,paymentReceived:60,debitRemaining:40,profit:30}],
    purchases:[],returns:[],directExpenses:[],
    paymentLedger:[{id:'sale-pay',sourceId:'s1',kind:'sale_payment',date:'2026-11-02',amount:60,accountId:'cash-a',status:'posted'}]
  });
  const cash=D.accountLedger('1000|cash-a','2026-11-01','2026-11-30');
  const bank=D.accountLedger('1000|bank-b','2026-11-01','2026-11-30');
  assert.equal(cash.opening,100);
  assert.equal(cash.closing,160);
  assert.equal(bank.opening,500);
  assert.equal(bank.closing,500);
  assert.equal(cash.rows.length,1);
  assert.equal(bank.rows.length,0);
});

test('expense payment is tagged to its selected cash or bank account in the general ledger', () => {
  const D=loadAccounting({
    cashAccounts:[{id:'bank-cbe',name:'CBE',openingBalance:0,openingDate:'2026-11-01'}],
    sales:[],purchases:[],returns:[],paymentLedger:[],
    directExpenses:[{id:'e1',date:'2026-11-04',amount:25,accountId:'bank-cbe',status:'posted'}]
  });
  const ledger=D.accountLedger('1000|bank-cbe','2026-11-01','2026-11-30');
  assert.equal(ledger.closing,-25);
  assert.equal(ledger.rows[0].accountId,'bank-cbe');
  assert.equal(D.audit().ok,true,JSON.stringify(D.audit().issues));
});

test('customer and supplier opening debts and advances are journalized against opening equity', () => {
  const D=loadAccounting({
    cashAccounts:[],sales:[],purchases:[],returns:[],directExpenses:[],paymentLedger:[],moneyTransactions:[],
    customers:[{id:'c1',name:'Customer One',openingBalance:80,openingAdvance:10,openingDate:'2026-10-01'}],
    suppliers:[{id:'s1',name:'Supplier One',openingBalance:45,openingAdvance:5,openingDate:'2026-10-01'}]
  });
  const lines=D.build();
  assert.equal(lines.find(x=>x.account==='1100').debit,80);
  assert.equal(lines.find(x=>x.account==='2100').credit,10);
  assert.equal(lines.find(x=>x.account==='2000').credit,45);
  assert.equal(lines.find(x=>x.account==='2200').debit,5);
  assert.equal(D.audit().ok,true,JSON.stringify(D.audit().issues));
});

test('supplier return reduces supplier payable and inventory without being misclassified as a customer refund',()=>{
  const D=loadAccounting({sales:[],purchases:[],directExpenses:[],paymentLedger:[],returns:[{id:'sr1',date:'2026-11-08',returnType:'supplier_return',sourceType:'purchase',partyId:'sup1',partyName:'Supplier A',productId:'p1',quantity:2,totalRefund:40}]});
  const lines=D.build();
  assert.equal(lines.length,2);
  assert.ok(lines.some(x=>x.account==='2000'&&x.debit===40));
  assert.ok(lines.some(x=>x.account==='1200'&&x.credit===40));
  assert.equal(lines.some(x=>x.account==='4100'),false);
  assert.equal(D.audit().ok,true,JSON.stringify(D.audit().issues));
});

test('supplier return cash refund is posted to the selected cash account and only the remainder offsets payable',()=>{
  const D=loadAccounting({sales:[],purchases:[],directExpenses:[],paymentLedger:[],returns:[{id:'sr-cash',date:'2026-11-09',returnType:'supplier_return',sourceType:'purchase',partyId:'sup1',partyName:'Supplier A',totalRefund:100,refundMethod:'cash',cashRefundAmount:35,accountId:'bank-cbe'}]});
  const lines=D.build();
  assert.ok(lines.some(x=>x.account==='1000'&&x.accountId==='bank-cbe'&&x.debit===35));
  assert.ok(lines.some(x=>x.account==='2000'&&x.debit===65));
  assert.ok(lines.some(x=>x.account==='1200'&&x.credit===100));
  assert.equal(D.audit().ok,true,JSON.stringify(D.audit().issues));
});

test('supplier return cash refund is capped at the returned value and cannot create excess cash',()=>{
  const D=loadAccounting({sales:[],purchases:[],directExpenses:[],paymentLedger:[],returns:[{id:'sr-cap',date:'2026-11-09',returnType:'supplier_return',sourceType:'purchase',totalRefund:50,refundMethod:'cash',cashRefundAmount:90}]});
  const lines=D.build();
  assert.equal(lines.filter(x=>x.account==='1000').reduce((n,x)=>n+x.debit,0),50);
  assert.equal(D.audit().ok,true,JSON.stringify(D.audit().issues));
});

test('calculator supplier return captures settlement method, partial cash refund and selected account', () => {
  const src = fs.readFileSync(new URL('../app/src/main/assets/js/modules/calculator.js', import.meta.url), 'utf8');
  assert.match(src, /How will the supplier settle this return\?/);
  assert.match(src, /Reduce what you owe the supplier/);
  assert.match(src, /Supplier refunds money to my account/);
  assert.match(src, /cashRefundAmount: cashRefundForLine/);
  assert.match(src, /CashBanks\.link\(action\.accountId,[\s\S]{0,180}'in'/);
  assert.match(src, /Cash refund cannot exceed the return value/);
});

test('supplier return split across products allocates the cash refund proportionally, not once per item', () => {
  const src = fs.readFileSync(new URL('../app/src/main/assets/js/modules/calculator.js', import.meta.url), 'utf8');
  assert.match(src, /cashRefundForLine[\s\S]{0,260}action\.payment\*\(lineTotal\/action\.total\)/);
  assert.match(src, /cashRefundAmount: cashRefundForLine/);
  assert.match(src, /itemIndex===selectedItems\.length-1/);
});

test('balance sheet reports journal capital, retained earnings and unreconciled difference without auto-posting', () => {
  const src = fs.readFileSync(new URL('../app/src/main/assets/js/modules/statements.js', import.meta.url), 'utf8');
  assert.match(src, /Accumulated net profit \(journal estimate\)/);
  assert.match(src, /Unreconciled difference/);
  assert.match(src, /No automatic adjustment has been posted/);
  assert.match(src, /journal\?\.trialBalance\?\.\(\)/);
});
