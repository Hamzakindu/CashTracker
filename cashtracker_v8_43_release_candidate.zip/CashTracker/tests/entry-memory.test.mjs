import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
test('People Money entry kind is persisted for Same as last time',()=>{
 const store=new Map(),sandbox={localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)},window:{},document:{getElementById:()=>null},State:{customers:[],suppliers:[]},Event:function(){}};
 vm.runInNewContext(fs.readFileSync(new URL('../app/src/main/assets/js/utils/entry-memory.js',import.meta.url),'utf8'),sandbox);
 sandbox.window.EntryMemory.remember('peopleMoney',{personId:'p1',entryKind:'payment_from_person',accountId:'a1',date:'2026-11-11'});
 assert.equal(sandbox.window.EntryMemory.last('peopleMoney').entryKind,'payment_from_person');
});
