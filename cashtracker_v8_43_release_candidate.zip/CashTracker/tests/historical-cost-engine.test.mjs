import test from 'node:test';
import assert from 'node:assert/strict';
import '../app/src/main/assets/js/utils/historical-cost-engine.js';
const Engine=globalThis.HistoricalCostEngine;

test('perpetual weighted average preserves historical purchase cost and sale issue cost',()=>{
  const data={
    products:[{id:'p1',name:'Item',initialStock:10,initialCost:10,buy:99,sell:30,stock:15}],
    purchases:[{id:'buy1',date:'2026-01-02',createdAt:'2026-01-02T10:00:00Z',items:[{productId:'p1',quantity:10,cost:20}]}],
    sales:[{id:'sale1',date:'2026-01-03',createdAt:'2026-01-03T10:00:00Z',items:[{productId:'p1',quantity:5,price:30,costPriceAtSale:15,costAmount:75}]}],
    returns:[],stockHistory:[
      {id:'h1',productId:'p1',type:'purchase',change:10,date:'2026-01-02'},
      {id:'h2',productId:'p1',type:'sale',change:-5,date:'2026-01-03'}
    ]
  };
  const x=Engine.product(data,'p1');
  assert.equal(x.reconciled,true);
  assert.equal(x.averageCost,15);
  assert.equal(x.stockValue,225);
  assert.equal(x.reliable,true);
  assert.equal(x.rows.filter(r=>r.kind==='purchase').length,1,'source transactions must not double-count stockHistory rows');
});

test('return is reintroduced at its recorded historical cost',()=>{
  const data={products:[{id:'p1',initialStock:10,initialCost:10,buy:99,stock:16}],purchases:[{id:'b',date:'2026-01-02',items:[{productId:'p1',quantity:10,cost:20}]}],sales:[{id:'s',date:'2026-01-03',items:[{productId:'p1',quantity:5,costPriceAtSale:15,costAmount:75}]}],returns:[{id:'r',date:'2026-01-04',productId:'p1',quantity:1,costAmount:15}],stockHistory:[]};
  const x=Engine.product(data,'p1');
  assert.equal(x.reconciled,true);
  assert.equal(x.averageCost,15);
  assert.equal(x.stockValue,240);
  assert.equal(x.returnedCost,15);
});

test('missing opening cost is visibly estimated, never silently called reliable',()=>{
  const data={products:[{id:'p1',initialStock:5,buy:12,stock:5}],purchases:[],sales:[],returns:[],stockHistory:[]};
  const x=Engine.product(data,'p1');
  assert.equal(x.stockValue,60);
  assert.equal(x.reconciled,true);
  assert.equal(x.reliable,false);
  assert.equal(x.estimated,true);
});

test('quantity mismatch with current stock blocks historical stock valuation',()=>{
  const data={products:[{id:'p1',initialStock:5,initialCost:10,buy:10,stock:7}],purchases:[],sales:[],returns:[],stockHistory:[]};
  const x=Engine.product(data,'p1');
  assert.equal(x.reconciled,false);
  assert.equal(x.stockValue,null);
  assert.ok(x.issues.some(i=>i.code==='STOCK_QUANTITY_MISMATCH'));
});

test('BusinessEngine uses historical stock valuation when the engine is loaded',async()=>{
  await import('../app/src/main/assets/js/utils/business-engine.js');
  const B=globalThis.BusinessEngine;
  const x=B.calculate({
    products:[{id:'p1',initialStock:10,initialCost:10,buy:99,stock:15}],
    purchases:[{id:'b',date:'2026-01-02',items:[{productId:'p1',quantity:10,cost:20}]}],
    sales:[{id:'s',date:'2026-01-03',items:[{productId:'p1',quantity:5,costPriceAtSale:15,costAmount:75}]}],
    stockHistory:[],returns:[],directExpenses:[],customers:[],suppliers:[],paymentLedger:[],auditLog:[]
  });
  assert.equal(x.stockValue,225);
  assert.match(x.stockValueBasis,/perpetual weighted-average/);
});

test('BusinessEngine discloses stock-history gaps and estimated legacy costs',async()=>{
  await import('../app/src/main/assets/js/utils/business-engine.js');
  const x=globalThis.BusinessEngine.calculate({products:[{id:'p1',initialStock:5,buy:12,stock:7}],stockHistory:[],sales:[],purchases:[],returns:[],directExpenses:[],customers:[],suppliers:[],paymentLedger:[],auditLog:[]});
  assert.ok(x.dataQuality.issues.some(i=>i.code==='STOCK_HISTORY_MISMATCH'));
});

test('backdated purchase that conflicts with a stored sale cost is flagged, not silently rewritten',()=>{
  const data={products:[{id:'p1',initialStock:10,initialCost:10,buy:15,stock:15}],purchases:[{id:'b',date:'2026-01-02',items:[{productId:'p1',quantity:10,cost:30}]}],sales:[{id:'s',date:'2026-01-03',items:[{productId:'p1',quantity:5,costPriceAtSale:15,costAmount:75}]}],returns:[],stockHistory:[]};
  const x=Engine.product(data,'p1');
  assert.ok(x.issues.some(i=>i.code==='SALE_COST_SNAPSHOT_MISMATCH'));
  assert.equal(x.reliable,false);
});
