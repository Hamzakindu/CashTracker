import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const read = p => readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');
function loadProducts(stateOverrides = {}) {
  const state = { products: [], suppliers: [{id:'s1',name:'Supplier One'},{id:'s2',name:'Supplier Two'}], purchases: [], ...stateOverrides };
  const window = { registerModule(_name, factory) { factory(); } };
  const context = { window, State: state, document: {getElementById(){return null;},querySelectorAll(){return []; }}, Helpers: {esc:x=>String(x),formatCurrency:x=>`ETB ${x}`,uid:()=> 'x',debounce:fn=>fn}, console, Date, Set, Array, String, Number, Math };
  vm.runInNewContext(read('app/src/main/assets/js/modules/products.js'), context);
  return { Products: window.Products, state };
}

test('supplier purchase statistics are derived from active purchase history and exclude voided purchases', () => {
  const {Products} = loadProducts({ products:[{id:'p1',supplierIds:['s1']}], purchases:[
    {id:'a',supplierId:'s1',date:'2026-01-01',items:[{productId:'p1',quantity:2,cost:12}]},
    {id:'b',supplierId:'s1',date:'2026-02-01',items:[{productId:'p1',quantity:3,cost:15}]},
    {id:'c',supplierId:'s1',date:'2026-03-01',status:'void',items:[{productId:'p1',quantity:9,cost:99}]},
    {id:'d',supplierId:'s2',date:'2026-04-01',items:[{productId:'p1',quantity:1,cost:10}]}
  ]});
  const stats = Products.supplierPurchaseStats('p1','s1');
  assert.equal(stats.count,2);
  assert.equal(stats.last.cost,15);
  assert.equal(stats.history[0].date,'2026-02-01');
});

test('supplier price priority is quoted price, then last recorded purchase, then product base buy price', () => {
  const {Products} = loadProducts({ purchases:[{id:'a',supplierId:'s1',date:'2026-02-01',items:[{productId:'p1',quantity:1,cost:14}]}] });
  const product = {id:'p1',buy:20,supplierLinks:[{supplierId:'s1',quotedPrice:12}]};
  assert.equal(Products.getSupplierPrice(product,'s1'),12);
  product.supplierLinks[0].quotedPrice = null;
  assert.equal(Products.getSupplierPrice(product,'s1'),14);
  assert.equal(Products.getSupplierPrice(product,'s2'),20);
});

test('supplier profile collection preserves historical metadata and records preferred supplier and sourcing fields', () => {
  const {Products} = loadProducts();
  const fields = {
    'price:s1':{value:'18'}, 'code:s1':{value:'ABC-1'}, 'notes:s1':{value:'Call before delivery'},
    'availability:s1':{value:'limited'}, 'leadTime:s1':{value:'4'}
  };
  const box = {querySelector(selector) {
    if (selector === 'input[type=radio]:checked') return {value:'s1'};
    const m = selector.match(/data-supplier-profile="([^"]+)".*data-supplier-id="([^"]+)"/);
    return m ? fields[`${m[1]}:${m[2]}`] || null : null;
  }};
  const originalGet = globalThis.document;
  // Product module closes over its VM document; replace its lookup with the supplier profile test fixture.
  const result = Products.collectSupplierProfiles;
  assert.equal(typeof result,'function');
  // Exercise the actual collector through a minimal test VM context with the same selectors.
  const source = read('app/src/main/assets/js/modules/products.js');
  const state = {products:[],suppliers:[{id:'s1',name:'Supplier One'}]};
  const window = {registerModule(_n,f){f();}};
  const context = {window,State:state,document:{getElementById:id=>id==='profile'?box:null,querySelectorAll(){return[];}},Helpers:{esc:String,debounce:fn=>fn},console,Date,Set,Array,String,Number,Math};
  vm.runInNewContext(source,context);
  const collected = window.Products.collectSupplierProfiles('profile',['s1'],{supplierLinks:[{supplierId:'s1',lastPurchasePrice:16,purchaseCount:3}]});
  assert.equal(collected.preferredSupplierId,'s1');
  assert.equal(collected.links[0].quotedPrice,18);
  assert.equal(collected.links[0].supplierProductCode,'ABC-1');
  assert.equal(collected.links[0].availability,'limited');
  assert.equal(collected.links[0].leadTimeDays,4);
  assert.equal(collected.links[0].lastPurchasePrice,16);
  void originalGet;
});

test('product detail and purchase entry expose supplier comparison and supplier-aware price defaults', () => {
  const products = read('app/src/main/assets/js/modules/products.js');
  const purchases = read('app/src/main/assets/js/modules/purchases.js');
  assert.match(products,/Supplier comparison/);
  assert.match(products,/recent purchases/);
  assert.match(products,/preferredSupplierId/);
  assert.match(products,/supplierProductCode/);
  assert.match(products,/leadTimeDays/);
  assert.match(purchases,/Products\.getSupplierPrice\(p,supplierId\)/);
  assert.match(purchases,/refreshSupplierPrices\(\)/);
});
