import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const src=fs.readFileSync(new URL('../app/src/main/assets/js/modules/period-lock.js',import.meta.url),'utf8');
function harness(seed={}){
 const data={sales:[],purchases:[],directExpenses:[],returns:[],moneyTransactions:[],customers:[],suppliers:[],paymentLedger:[],cashAccounts:[],auditLog:[],periodClosures:[],...seed};
 const kv=new Map();const audits=[];const messages=[];
 const State={...data,save(name){if(name!=='periodClosures')return false;return true;}};
 const window={State,Helpers:{esc:String},Toast:{success:x=>messages.push(x),warning:x=>messages.push(x),error:x=>messages.push(x)},Security:{audit:(...a)=>audits.push(a)},addEventListener(){}};
 const context={window,State,localStorage:{getItem:k=>kv.get(k)||null,setItem:(k,v)=>kv.set(k,String(v)),removeItem:k=>kv.delete(k)},Toast:window.Toast,Security:window.Security,console,Date,Math,confirm:()=>true,prompt:()=>null,document:{getElementById:()=>null}};
 vm.runInNewContext(src,context);return {P:window.PeriodLock,State,kv,audits,messages,context};
}

test('period closing persists a bounded range and blocks dates inside only',()=>{
 const h=harness({sales:[{id:'s1',date:'2026-10-04'}],purchases:[{id:'p1',date:'2026-10-10'}]});
 const r=h.P.close('2026-10-01','2026-10-31');
 assert.equal(r.status,'closed');assert.equal(r.counts.sales,1);assert.equal(r.counts.purchases,1);
 assert.equal(h.P.isLocked('2026-10-01'),true);assert.equal(h.P.isLocked('2026-10-31'),true);assert.equal(h.P.isLocked('2026-11-01'),false);
 assert.equal(h.State.periodClosures.length,1);assert.ok(h.audits.some(a=>a[0]==='financial_period_closed'));
});

test('invalid ranges and overlapping closures are rejected without adding a second closure',()=>{
 const h=harness();assert.throws(()=>h.P.close('2026-02-30','2026-03-01'),/valid date range/);
 h.P.close('2026-01-01','2026-01-31');assert.throws(()=>h.P.close('2026-01-15','2026-02-15'),/overlaps/);assert.equal(h.State.periodClosures.length,1);
});

test('reopening requires a meaningful reason and is recorded instead of deleting the closure',()=>{
 const h=harness();const r=h.P.close('2026-09-01','2026-09-30');assert.throws(()=>h.P.reopen(r.id,'no'),/at least 5/);
 h.P.reopen(r.id,'Correct a wrong purchase date');assert.equal(h.State.periodClosures.length,1);assert.equal(r.status,'reopened');assert.equal(h.P.isLocked('2026-09-10'),false);assert.ok(h.audits.some(a=>a[0]==='financial_period_reopened'));
});

test('legacy lock remains active and does not get silently removed by new period features',()=>{
 const h=harness();h.kv.set('SP_lock_date','2026-08-31');assert.equal(h.P.isLocked('2026-08-31'),true);assert.equal(h.P.isLocked('2026-09-01'),false);
});

test('period closures are included in profile state, backup, safety storage and cloud sync registries',()=>{
 const read=p=>fs.readFileSync(new URL('../'+p,import.meta.url),'utf8');
 for(const [p,needle] of [['app/src/main/assets/js/state.js','periodClosures'],['app/src/main/assets/js/backup.js','periodClosures'],['app/src/main/assets/js/utils/storage.js','periodClosures'],['app/src/main/assets/js/cloudflare-backend.js','periodClosures']])assert.ok(read(p).includes(needle),p+' must persist period closures');
 assert.equal((read('app/src/main/assets/js/backup.js').match(/periodClosures: State\.periodClosures \|\| \[\]/g)||[]).length,2,'local and exported backups both include closures');
});

test('finance control displays the new period closing panel instead of the legacy single-date control',()=>{
 const s=fs.readFileSync(new URL('../app/src/main/assets/js/modules/finance-control.js',import.meta.url),'utf8');
 const p=fs.readFileSync(new URL('../app/src/main/assets/js/modules/period-lock.js',import.meta.url),'utf8');
 assert.match(s,/PeriodLock\.renderPanel\(\)/);assert.match(p,/PeriodLock\.closeFromForm/);
});

test('closed periods block sales, payments, manual bank movements and People Money submissions at the action boundary',()=>{
 const calls=[];const values={sellDate:'2026-10-05',paymentDate:'2026-10-06',cmDate:'2026-10-07',pmDate:'2026-10-08',directExpenseDate:'2026-10-09',returnDate:'2026-10-10',purchaseDate:'2026-10-11'};
 const data={sales:[],purchases:[],directExpenses:[],returns:[],moneyTransactions:[],customers:[],suppliers:[],paymentLedger:[],cashAccounts:[],auditLog:[],periodClosures:[]};
 const State={...data,save:()=>true};const Toast={error:m=>calls.push('blocked:'+m),success(){},warning(){}};
 const mk=name=>({submit(){calls.push(name)},update(){calls.push(name)},delete(){calls.push(name)},submitDirect(){calls.push(name)},movement(){calls.push(name)},addEntry(){calls.push(name)},voidDirect(){calls.push(name)},recordExclusive(){calls.push(name)},submitAdjust(){calls.push(name)},addAccount(){calls.push(name)}});
 const window={State,Helpers:{getToday:()=> '2026-10-12'},Toast,Sales:mk('sales'),Purchases:mk('purchases'),Expenses:mk('expenses'),Returns:mk('returns'),Payments:mk('payments'),CashBanks:mk('cashbanks'),PeopleMoney:mk('people'),addEventListener(){}};
 const context={window,State,Toast,Helpers:window.Helpers,localStorage:{getItem:()=>null,setItem(){},removeItem(){}},document:{getElementById:id=>({value:values[id]||''})},console,Date,Math};
 vm.runInNewContext(src,context);window.PeriodLock.close('2026-10-01','2026-10-31');
 window.Sales.submit();window.Payments.submit();window.CashBanks.movement();window.PeopleMoney.addEntry();window.Expenses.submitDirect();window.Returns.submit();window.Purchases.submit();
 assert.deepEqual(calls.filter(x=>!String(x).startsWith('blocked:')),[]);assert.equal(calls.filter(x=>String(x).startsWith('blocked:')).length,7);
});
