import test from 'node:test';
import assert from 'node:assert/strict';
globalThis.window = globalThis;
await import('../app/src/main/assets/js/utils/sms-parser.js');
const {parse} = globalThis.BankSmsParser;
test('real parser detects outgoing CBE sent/received wording',()=>{const p=parse('CBE: Amount debited 1,250 ETB. Sent to ABEBE, received by ABEBE');assert.equal(p.amount,1250);assert.equal(p.dir,'out');assert.equal(p.bankName,'CBE')});
test('real parser detects incoming credit',()=>assert.equal(parse('Amount credited: 850 ETB received from ABEBE').dir,'in'));
test('real parser uses labelled amount before balance',()=>assert.equal(parse('CBE Amount debited 1250 ETB. Current balance 99,999 ETB').amount,1250));
test('real parser identifies bank template',()=>assert.equal(parse('Telebirr: Amount received 500 ETB').bankName,'Telebirr'));

test('Kotlin regression sample: date is not mistaken for transaction amount in JS fallback',()=>{const p=parse('CBE debited on 12/03/2026 with ETB 500.00');assert.equal(p.amount,500);assert.equal(p.dir,'out')});
test('word boundaries prevent present and unpaid false positives',()=>{assert.equal(parse('We present your statement. Account credited ETB 50').dir,'in');assert.equal(parse('unpaid bill of ETB 300'),null)});
test('BOA alias does not match BOARD',()=>{assert.equal(parse('BOARD notice: payment credited ETB 50').bankName,'')});
test('currency amount is selected when action is separated from amount by date words',()=>{assert.equal(parse('Telebirr: sent on 12/03/2026, amount ETB 500').amount,500)});

test('compiled TypeScript parser has the same amount and false-positive protections',async()=>{await import('../app/src/main/assets/js/ts-runtime/index.js');const p=globalThis.CashTrackerCore.parseSms('CBE debited on 12/03/2026 with ETB 500.00');assert.equal(p.amount,500);assert.equal(globalThis.CashTrackerCore.parseSms('unpaid bill of ETB 300'),null);assert.equal(globalThis.CashTrackerCore.parseSms('We present your statement. Account credited ETB 50').dir,'in')});

test('transfer wording is recognised as an outgoing transaction',()=>{const p=parse('CBE transfer of ETB 250.00 completed');assert.equal(p.amount,250);assert.equal(p.dir,'out')});
