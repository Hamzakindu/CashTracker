import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

function loadStatements(state) {
  const output = { innerHTML: '' };
  const context = {
    window: {},
    State: state,
    Helpers: {
      esc: value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),
      formatCurrency: value => `ETB ${Number(value).toFixed(2)}`,
      getToday: () => '2026-11-11'
    },
    CashBanks: { totals: () => ({cash:100,bank:200,wallet:0,total:300}) },
    document: { getElementById: id => id === 'statementsOutput' ? output : null },
    Date, console
  };
  vm.runInNewContext(fs.readFileSync(new URL('../app/src/main/assets/js/utils/business-engine.js', import.meta.url), 'utf8'), context);
  context.BusinessEngine = context.window.BusinessEngine;
  vm.runInNewContext(fs.readFileSync(new URL('../app/src/main/assets/js/modules/statements.js', import.meta.url), 'utf8'), context);
  return { Statements: context.window.Statements, output };
}

test('balance sheet and aging use BusinessEngine-derived party balances, not stale cached balances', () => {
  const state = {
    products: [{id:'p1',stock:2,buy:10,sell:20}],
    sales: [{id:'s1',customerId:'c1',date:'2026-11-01',total:100,debitRemaining:100,items:[{quantity:1,price:100,cost:50}]}],
    purchases: [{id:'p1',supplierId:'s1',date:'2026-11-02',total:80,debit:80,items:[{quantity:1,cost:80}]}],
    customers: [{id:'c1',name:'Customer A',openingBalance:0,balance:999}],
    suppliers: [{id:'s1',name:'Supplier A',openingBalance:0,balance:888}],
    paymentLedger: [], returns: [], directExpenses: [], auditLog: [], moneyTransactions: []
  };
  const {Statements, output} = loadStatements(state);
  Statements.show('balance');
  assert.match(output.innerHTML, /ETB 100\.00/);
  assert.match(output.innerHTML, /ETB 80\.00/);
  assert.doesNotMatch(output.innerHTML, /ETB 999\.00/);
  assert.doesNotMatch(output.innerHTML, /ETB 888\.00/);
  Statements.show('ar');
  assert.match(output.innerHTML, /ETB 100\.00/);
  assert.doesNotMatch(output.innerHTML, /ETB 999\.00/);
  Statements.show('ap');
  assert.match(output.innerHTML, /ETB 80\.00/);
  assert.doesNotMatch(output.innerHTML, /ETB 888\.00/);
});

test('statements use historical weighted-average valuation where reconciled and flag legacy estimates', () => {
  const {Statements, output} = loadStatements({products:[{id:'p',name:'Item',stock:3,buy:12,sell:20}],sales:[],purchases:[],customers:[],suppliers:[],returns:[],directExpenses:[],paymentLedger:[],auditLog:[],moneyTransactions:[]});
  Statements.show('inventory');
  assert.match(output.innerHTML, /perpetual weighted-average costing where source history reconciles/i);
  assert.match(output.innerHTML, /estimated\/incomplete historical cost/i);
  assert.match(output.innerHTML, /Estimated margin if everything sells/);
});

test('reports use the same BusinessEngine sale-cost rules and do not override item cost with stale sale.profit', () => {
  const reports = fs.readFileSync(new URL('../app/src/main/assets/js/modules/reports.js', import.meta.url), 'utf8');
  assert.match(reports, /BusinessEngine\.saleCost\(sale\)/);
  assert.match(reports, /BusinessEngine\.itemCost\(i\)/);
  assert.doesNotMatch(reports, /profit = this\.number\(sale\.profit\)/);
});
