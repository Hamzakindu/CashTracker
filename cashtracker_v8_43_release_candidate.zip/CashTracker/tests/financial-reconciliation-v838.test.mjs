import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

function loadLedger(state, audit) {
  const window = audit ? { FinancialAudit: audit } : {};
  window.registerModule=(name,factory)=>factory();
  const context = { window, FinancialAudit: audit, State: state, Helpers: { uid: () => 'uid', getToday: () => '2026-11-13', formatCurrency: n => Number(n).toFixed(2), esc: x => String(x) }, Modals: { open(){} }, Toast: { error(){} }, document: { getElementById: () => null } };
  vm.runInNewContext(fs.readFileSync(new URL('../app/src/main/assets/js/modules/accounting-ledger.js', import.meta.url), 'utf8'), context);
  return window.AccountingLedger;
}

test('V8.38 delegates party reconciliation to shared read-only balance and advance audits', () => {
  const calls=[];
  const audit={balanceAudit(data){calls.push(['balance',data]);return [{type:'customer_balance',entityId:'c1',expected:80,actual:100,difference:20}];},advanceAudit(data){calls.push(['advance',data]);return [{type:'customer_advance_balance',entityId:'c1',expected:5,actual:10,difference:5}];}};
  const state={customers:[{id:'c1',name:'A',balance:100}],suppliers:[],sales:[],purchases:[],returns:[],paymentLedger:[],auditLog:[],cashAccounts:[],directExpenses:[]};
  const before=JSON.stringify(state);
  const ledger=loadLedger(state,audit);
  const result=ledger.reconcile();
  assert.equal(result.ok,false);
  assert.equal(result.source,'FinancialAudit');
  assert.equal(result.issues.length,2);
  assert.equal(calls.length,2);
  assert.equal(JSON.stringify(state),before,'reconciliation must not mutate business records');
});

test('V8.38 keeps a legacy fallback when the shared audit is not available', () => {
  const state={customers:[],suppliers:[],sales:[],purchases:[],paymentLedger:[],cashAccounts:[],directExpenses:[],returns:[],auditLog:[],activeSales:()=>[]};
  const ledger=loadLedger(state);
  const result=ledger.reconcile();
  assert.equal(result.ok,true);
  assert.equal(result.source,'legacy_fallback');
  assert.equal(result.readOnly,true);
});

test('V8.38 reconciliation view safely renders incomplete-history findings without formatting missing amounts', () => {
  const state={customers:[],suppliers:[],sales:[],purchases:[],paymentLedger:[],cashAccounts:[],directExpenses:[],returns:[],auditLog:[]};
  const window={FinancialAudit:{balanceAudit:()=>[{type:'legacy_balance_history_incomplete',entityId:'c1',name:'Legacy customer',explanation:'History incomplete.'}],advanceAudit:()=>[]}};
  const elements={detailModalContent:{},detailModalTitle:{}};
  window.registerModule=(name,factory)=>factory();
  const context={window,FinancialAudit:window.FinancialAudit,State:state,Helpers:{uid:()=>'',getToday:()=>'',formatCurrency:n=>Number(n).toFixed(2),esc:x=>String(x)},Modals:{open(){}},Toast:{error(){}},document:{getElementById:id=>elements[id]||null}};
  vm.runInNewContext(fs.readFileSync(new URL('../app/src/main/assets/js/modules/accounting-ledger.js',import.meta.url),'utf8'),context);
  window.AccountingLedger.showReconciliation();
  assert.match(elements.detailModalContent.innerHTML,/Legacy customer/);
  assert.match(elements.detailModalContent.innerHTML,/—/);
  assert.match(elements.detailModalContent.innerHTML,/History incomplete/);
});
