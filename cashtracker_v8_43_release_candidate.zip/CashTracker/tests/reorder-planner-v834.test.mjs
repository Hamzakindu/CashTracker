import test from 'node:test';
import assert from 'node:assert/strict';
import '../app/src/main/assets/js/utils/reorder-planner.js';
const Planner=globalThis.ReorderPlanner;
const asOf='2026-11-12T12:00:00';
const base={asOf,windowDays:30,coverDays:30,products:[{id:'p1',name:'Rice',stock:5,minStock:5,buy:40,sell:60,supplierIds:['s1','s2'],preferredSupplierId:'s2',supplierLinks:[{supplierId:'s1',quotedPrice:35,leadTimeDays:4,availability:'available'},{supplierId:'s2',quotedPrice:38,leadTimeDays:6,availability:'available'}]}],suppliers:[{id:'s1',name:'Supplier A'},{id:'s2',name:'Supplier B'}],sales:[{id:'sale1',date:'2026-11-10',branchId:'b1',items:[{productId:'p1',quantity:10}]},{id:'sale2',date:'2026-11-08',branchId:'b2',items:[{productId:'p1',quantity:100}]}],purchases:[]};
test('planner uses selected branch sales only and reports unassigned historical rows',()=>{
 const d=Planner.build({...base,branchId:'b1',sales:[...base.sales,{id:'old',date:'2026-11-09',items:[{productId:'p1',quantity:7}]}]});
 assert.equal(d.rows[0].soldInPeriod,10);assert.equal(d.unassignedSales,1);assert.equal(d.branchMode,true);
});
test('planner ignores voided sales and sales outside the selected demand window',()=>{
 const d=Planner.build({...base,sales:[...base.sales,{id:'void',date:'2026-11-11',voided:true,items:[{productId:'p1',quantity:500}]},{id:'old',date:'2026-01-01',items:[{productId:'p1',quantity:500}]}]});
 assert.equal(d.rows[0].soldInPeriod,110);
});
test('preferred eligible supplier is selected and quote price drives estimate',()=>{
 const d=Planner.build(base),r=d.rows[0];assert.equal(r.selectedSupplierId,'s2');assert.equal(r.estimatedUnitCost,38);assert.equal(r.priceSource,'quote');
});
test('unavailable supplier is not selected when an eligible linked supplier exists',()=>{
 const input=structuredClone(base);input.products[0].preferredSupplierId='s2';input.products[0].supplierLinks[1].availability='unavailable';
 const r=Planner.build(input).rows[0];assert.equal(r.selectedSupplierId,'s1');
});
test('suggested quantity never goes below zero and purchase cost is derived only',()=>{
 const input=structuredClone(base);input.products[0].stock=9999;const before=JSON.stringify(input);const r=Planner.build(input).rows[0];assert.equal(r.reorderQty,0);assert.equal(r.estimatedPurchaseCost,0);assert.equal(JSON.stringify(input),before);
});
test('planner reports missing supplier and missing price without inventing either',()=>{
 const input=structuredClone(base);input.products[0].supplierIds=[];input.products[0].supplierLinks=[];input.products[0].preferredSupplierId='';input.products[0].buy=0;
 const r=Planner.build(input).rows[0];assert.equal(r.hasSupplier,false);assert.equal(r.selectedSupplierId,'');assert.equal(r.estimatedUnitCost,0);assert.equal(r.priceSource,'missing');
});
test('supplier price falls back to latest active purchase when no quote exists',()=>{
 const input=structuredClone(base);input.products[0].supplierLinks[1].quotedPrice=null;const d=Planner.build({...input,purchases:[{id:'pur1',supplierId:'s2',date:'2026-11-09',items:[{productId:'p1',cost:42}]},{id:'pur2',supplierId:'s2',date:'2026-11-10',status:'void',items:[{productId:'p1',cost:1}]}]});
 assert.equal(d.rows[0].estimatedUnitCost,42);assert.equal(d.rows[0].priceSource,'last purchase');
});
test('branch ID is stamped on newly saved sale and purchase records',async()=>{
 const {readFileSync}=await import('node:fs');const sale=readFileSync(new URL('../app/src/main/assets/js/modules/sales.js',import.meta.url),'utf8');const purchase=readFileSync(new URL('../app/src/main/assets/js/modules/purchases.js',import.meta.url),'utf8');
 assert.match(sale,/branchId: saleBranchId/);assert.match(sale,/const saleBranchId = State\.branchAccessMeta\?\.activeBranchId/);assert.match(purchase,/branchId: purchaseBranchId/);assert.match(purchase,/const purchaseBranchId = State\.branchAccessMeta\?\.activeBranchId/);
});
test('planner module is loaded before StockAlerts UI',async()=>{
 const {readFileSync}=await import('node:fs');const html=readFileSync(new URL('../app/src/main/assets/index.html',import.meta.url),'utf8');assert.ok(html.indexOf('js/utils/reorder-planner.js')<html.indexOf('js/modules/stock-alerts.js'));
});

test('zero-sales fallback still replenishes stock to twice the configured minimum',()=>{
 const input=structuredClone(base);input.sales=[];input.products[0].stock=5;const r=Planner.build(input).rows[0];assert.equal(r.reorderQty,5);
});
test('planner does not select a supplier marked unavailable when all linked suppliers are unavailable',()=>{
 const input=structuredClone(base);input.products[0].supplierLinks.forEach(x=>x.availability='unavailable');const r=Planner.build(input).rows[0];assert.equal(r.selectedSupplierId,'');assert.equal(r.estimatedUnitCost,0);
});
test('unassigned historical sale count is limited to the selected sales window',()=>{
 const input=structuredClone(base);input.sales=[{id:'old',date:'2025-01-01',items:[]},{id:'recent',date:'2026-11-10',items:[]}];assert.equal(Planner.build({...input,branchId:'b1'}).unassignedSales,1);
});
