import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const read = (p) => readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');

function loadProducts() {
  const elements = Object.fromEntries(['name','category','barcode','buy','sell','stock','minStock','productNotes'].map(id => [id, { value: ({name:'New item',sell:'10',minStock:'5'}[id] || ''), click(){}, textContent:'' }]));
  const supplierChecks = [];
  const state = { products: [], suppliers: [{id:'sup-1',name:'Main Supplier'}], saveUndoState(){} };
  const warnings = [];
  const window = { registerModule(_name, factory) { factory(); } };
  const context = {
    window, State: state,
    document: { getElementById(id){return elements[id] || null;}, querySelectorAll(){return supplierChecks;} },
    Helpers: { uid:()=> 'prod-1', debounce:fn=>fn, esc:x=>String(x), formatCurrency:x=>String(x) },
    Storage: { save(){} }, Toast: { warning:m=>warnings.push(m), success(){}, info(){} },
    Dashboard:{update(){}}, App:{populateDropdowns(){}}, Tabs:{switchTo(){}},
    console, Date, Set, Array, String, Number, Math
  };
  vm.runInNewContext(read('app/src/main/assets/js/modules/products.js'), context);
  const Products = window.Products;
  Products.render = ()=>{};
  return {Products, state, elements, supplierChecks, warnings};
}

test('new product cannot be saved without at least one supplier', () => {
  const {Products,state,warnings} = loadProducts();
  Products.add();
  assert.equal(state.products.length, 0);
  assert.match(warnings.at(-1), /supplier/i);
});

test('new product stores selected supplier IDs and supplier link metadata', () => {
  const {Products,state,supplierChecks} = loadProducts();
  supplierChecks.push({value:'sup-1'});
  Products._addImages = ['data:image/jpeg;base64,AAAA'];
  Products.add();
  assert.equal(state.products.length, 1);
  assert.deepEqual(Array.from(state.products[0].supplierIds), ['sup-1']);
  assert.equal(state.products[0].supplierId, 'sup-1');
  assert.equal(state.products[0].supplierLinks[0].supplierName, 'Main Supplier');
  assert.equal(state.products[0].images.length, 1);
});

test('shared Gallery images are accepted only as supported image data URLs and open Add Product', async () => {
  const {Products} = loadProducts();
  // The test context supplies a Tabs stub; accepted image data is retained for the Add Product form.
  Products.receiveSharedImages(['data:image/jpeg;base64,AAAA','javascript:alert(1)','data:text/plain;base64,AAAA']);
  assert.equal(Products._addImages.length, 1);
});

test('Android manifest declares image share targets for single and multiple photos', () => {
  const manifest = read('app/src/main/AndroidManifest.xml');
  assert.match(manifest, /android\.intent\.action\.SEND[\s\S]*?android:mimeType="image\/\*"/);
  assert.match(manifest, /android\.intent\.action\.SEND_MULTIPLE[\s\S]*?android:mimeType="image\/\*"/);
  const kotlin = read('app/src/main/java/com/example/cashtracker/MainActivity.kt');
  assert.match(kotlin, /override fun onNewIntent/);
  assert.match(kotlin, /compressSharedImage/);
  assert.match(kotlin, /Products\.receiveSharedImages/);
});

test('purchase creation and editing require the selected supplier to be linked to every product', () => {
  const purchases = read('app/src/main/assets/js/modules/purchases.js');
  assert.equal((purchases.match(/const supplierMismatch = items\.find/g) || []).length, 2);
  assert.match(purchases, /not linked to/);
  assert.match(purchases, /Assign at least one supplier/);
});

test('supplier cannot be deleted while linked to a product', () => {
  const suppliers = read('app/src/main/assets/js/modules/suppliers.js');
  assert.match(suppliers, /linkedProducts[\s\S]*?Cannot delete/);
});
