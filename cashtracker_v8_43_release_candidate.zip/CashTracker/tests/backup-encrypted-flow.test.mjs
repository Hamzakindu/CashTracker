import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const source = readFileSync(new URL('../app/src/main/assets/js/backup.js', import.meta.url), 'utf8');
test('file export encrypts the integrity-sealed backup before download',()=>{
 const seal = source.indexOf('data.backupIntegrity = await this.createIntegritySeal(data)');
 const encrypt = source.indexOf('BackupCrypto.encryptJson(data, passphrase)');
 const download = source.indexOf('Helpers.downloadFile(json, filename, \'application/json\')');
 assert.ok(seal >= 0 && encrypt > seal && download > encrypt);
});
test('file restore decrypts encrypted backups and warns before legacy plaintext import',()=>{
 assert.match(source,/BackupCrypto\.isEncrypted\(data\)/);
 assert.match(source,/BackupCrypto\.decryptJson\(data, passphrase\)/);
 assert.match(source,/older UNENCRYPTED backup/);
});
test('export reports success only after the download helper returns an affirmative result',()=>{
 assert.match(source,/if \(!result \|\| result\.ok !== true\) throw new Error/);
});
