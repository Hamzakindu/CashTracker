import test from 'node:test';
import assert from 'node:assert/strict';
import '../app/src/main/assets/js/utils/business-engine.js';
const Engine=globalThis.BusinessEngine;
test('derives key business totals without mutating source records',()=>{
 const data={products:[{id:'p',stock:8,buy:10}],sales:[{id:'s',total:100,cost:40,paymentReceived:60}],purchases:[{id:'b',total:50,paid:30}],directExpenses:[{amount:5}],customers:[{balance:40}],suppliers:[{balance:20}]};
 const before=JSON.stringify(data),x=Engine.calculate(data);
 assert.equal(x.salesTotal,100);assert.equal(x.purchaseTotal,50);assert.equal(x.expenseTotal,5);assert.equal(x.receivedFromSales,60);assert.equal(x.paidForPurchases,30);assert.equal(x.grossProfit,60);assert.equal(x.netProfit,55);assert.equal(x.stockValue,80);assert.equal(x.customerBalances,40);assert.equal(x.supplierBalances,20);assert.equal(JSON.stringify(data),before);
});
test('excludes void records and flags missing historical cost',()=>{
 const x=Engine.calculate({products:[{stock:2,buy:5}],sales:[{status:'void',total:99},{total:20,items:[{quantity:2,price:10}]}]});
 assert.equal(x.salesTotal,20);assert.equal(x.cogs,null);assert.equal(x.grossProfit,null);assert.equal(x.dataQuality.costComplete,false);
});
test('empty data is safe',()=>{const x=Engine.calculate();assert.equal(x.salesTotal,0);assert.equal(x.stockQty,0);assert.equal(x.netProfit,0);});

test('missing cost on an empty sale is unknown, not zero',()=>{const x=Engine.calculate({sales:[{id:'s',total:100,items:[]}]});assert.equal(x.cogs,null);assert.equal(x.grossProfit,null);assert.equal(x.dataQuality.costComplete,false)});
test('sales returns reduce net sales and reverse returned cost',()=>{const x=Engine.calculate({sales:[{id:'s',total:100,cost:40}],returns:[{id:'r',totalRefund:20,costAmount:8}]});assert.equal(x.salesTotal,100);assert.equal(x.netSales,80);assert.equal(x.returnsTotal,20);assert.equal(x.netCogs,32);assert.equal(x.grossProfit,48)});
test('cancelled records are excluded',()=>{const x=Engine.calculate({sales:[{status:'cancelled',total:100,cost:40},{status:'canceled',total:20,cost:5}]});assert.equal(x.salesTotal,0);assert.equal(x.counts.sales,0)});
test('item costAmount is treated as line total, not multiplied twice',()=>{const x=Engine.calculate({sales:[{items:[{quantity:3,costAmount:12,total:30}]}]});assert.equal(x.cogs,12)});

test('return cost reversal is not silently clamped when it relates to a prior period',()=>{const x=Engine.calculate({sales:[{total:10,cost:4}],returns:[{totalRefund:20,costAmount:8}]});assert.equal(x.netCogs,-4);assert.equal(x.grossProfit,-6)});


test('central engine includes sale-level expenses and returns in net profit',()=>{
 const x=Engine.calculate({sales:[{total:100,cost:40,expenses:{amount:5}}],returns:[{totalRefund:10,costAmount:4}],directExpenses:[{amount:3}]});
 assert.equal(x.grossProfit,54);assert.equal(x.netProfit,46);assert.equal(x.saleExpenseTotal,5);
});

test('derives customer and supplier balances using applied settlement portions and adjustments',()=>{
 const x=Engine.calculate({
  customers:[{id:'c',openingBalance:10,balance:20}],sales:[{customerId:'c',debitRemaining:30}],
  suppliers:[{id:'s',openingBalance:5,balance:15}],purchases:[{supplierId:'s',debit:20}],
  paymentLedger:[{entityType:'customer',entityId:'c',sourceType:'payment',kind:'settlement',amount:50,balanceApplied:8},{entityType:'supplier',entityId:'s',sourceType:'payment',kind:'settlement',amount:10,balanceApplied:10}],
  auditLog:[{action:'balance_adjustment',entityType:'customer',details:{entityId:'c',amount:-12,balanceApplied:-12}}]
 });
 assert.equal(x.customerBalances,20);assert.equal(x.supplierBalances,15);
});

test('uses cached balances rather than guessing when legacy settlements lack applied amounts',()=>{
 const x=Engine.calculate({customers:[{id:'c',balance:75}],paymentLedger:[{entityType:'customer',entityId:'c',sourceType:'payment',kind:'settlement',amount:25}]});
 assert.equal(x.customerBalances,75);assert.equal(x.dataQuality.legacyBalanceFallbacks,1);
});


test('does not derive a party balance from settlements alone when opening history is missing',()=>{
 const x=Engine.calculate({customers:[{id:'c',balance:75}],paymentLedger:[{entityType:'customer',entityId:'c',sourceType:'payment',kind:'settlement',amount:25,balanceApplied:25}]});
 assert.equal(x.customerBalances,75);assert.equal(x.dataQuality.legacyBalanceFallbacks,1);
});

test('legacy stored sale profit is converted into an explicit inferred cost consistently',()=>{
 const x=Engine.calculate({sales:[{total:100,profit:30,items:[]}]});
 assert.equal(x.cogs,70);assert.equal(x.grossProfit,30);assert.equal(x.dataQuality.costComplete,true);
});
test('line-level stored profit can supply missing historical line cost',()=>{
 const x=Engine.calculate({sales:[{items:[{quantity:2,price:50,amount:100,profit:35}]}]});
 assert.equal(x.cogs,65);assert.equal(x.grossProfit,35);
});

test('legacy profit-based cost inference is disclosed as a data-quality warning',()=>{
 const x=Engine.calculate({sales:[{total:100,profit:30,items:[]}]});
 assert.equal(x.dataQuality.legacyProfitCostInferences,1);
 assert.ok(x.dataQuality.issues.some(i=>i.code==='LEGACY_PROFIT_COST_INFERRED'));
});

test('profit is unavailable when a return has estimated historical cost',()=>{
 const x=Engine.calculate({sales:[{id:'s',total:100,cost:50}],returns:[{id:'r',totalRefund:20,costAmount:10,costEstimated:true}],products:[],purchases:[],directExpenses:[]});
 assert.equal(x.netCogs,null);
 assert.equal(x.netProfit,null);
 assert.ok(x.dataQuality.issues.some(i=>i.code==='RETURN_COST_UNKNOWN'));
});

test('supplier returns reduce only the linked supplier payable and flag excess returns for review',()=>{
 const x=Engine.calculate({suppliers:[{id:'sup1',name:'Supplier',openingBalance:80,balance:80}],purchases:[],returns:[{id:'sr1',returnType:'supplier_return',sourceType:'purchase',partyId:'sup1',supplierId:'sup1',totalRefund:30}]});
 assert.equal(x.supplierBalances,50);
 assert.equal(x.supplierBalanceDetails[0].balance,50);
 assert.equal(x.dataQuality.supplierReturnExcess,0);
 const excess=Engine.calculate({suppliers:[{id:'sup1',openingBalance:20,balance:20}],returns:[{returnType:'supplier_return',partyId:'sup1',totalRefund:35}]});
 assert.equal(excess.supplierBalances,0);
 assert.equal(excess.dataQuality.supplierReturnExcess,1);
 assert.ok(excess.dataQuality.issues.some(i=>i.code==='SUPPLIER_RETURN_EXCEEDS_PAYABLE'));
});

test('supplier returns reduce purchases but do not reduce sales revenue or reverse COGS',()=>{
 const x=Engine.calculate({sales:[{id:'s1',total:100,cost:40}],purchases:[{id:'p1',total:90}],returns:[{id:'sr1',returnType:'supplier_return',sourceType:'purchase',partyId:'sup1',totalRefund:25}]});
 assert.equal(x.netSales,100);
 assert.equal(x.returnsTotal,0);
 assert.equal(x.netCogs,40);
 assert.equal(x.purchaseReturnsTotal,25);
 assert.equal(x.netPurchases,65);
});

test('supplier cash refund only offsets the non-cash portion of the supplier payable',()=>{
 const x=Engine.calculate({
  suppliers:[{id:'s',openingBalance:100,balance:100}],
  returns:[{id:'sr',returnType:'supplier_return',sourceType:'purchase',supplierId:'s',partyId:'s',totalRefund:80,refundMethod:'cash',cashRefundAmount:30}]
 });
 assert.equal(x.supplierBalances,50);
 assert.equal(x.supplierBalanceDetails[0].balance,50);
});


test('allocates reconciled receivable aging to newest unpaid sales after oldest-first settlements',()=>{
 const asOf=new Date(2026,10,12);
 const x=Engine.allocateAging(70,[{date:'2026-08-01',debitRemaining:40},{date:'2026-11-01',debitRemaining:50}],r=>r.debitRemaining,r=>r.date,asOf);
 assert.deepEqual([...x.b],[50,0,0,20]);
 assert.equal(x.oldest,103);
 assert.equal(x.total,70);
});

test('allocates supplier aging consistently and flags undated opening balance as 90+',()=>{
 const asOf=new Date(2026,10,12);
 const x=Engine.allocateAging(65,[{date:'2026-10-20',amount:25},{date:'2026-09-01',amount:20}],r=>r.amount,r=>r.date,asOf);
 assert.deepEqual([...x.b],[25,0,20,20]);
 assert.equal(x.unallocated,20);
 assert.equal(x.oldest,91);
});

test('aging handles future dates, invalid dates, and zero balances safely',()=>{
 const asOf=new Date(2026,10,12);
 const future=Engine.allocateAging(10,[{date:'2026-12-01',amount:10}],r=>r.amount,r=>r.date,asOf);
 assert.deepEqual([...future.b],[10,0,0,0]);assert.equal(future.oldest,0);
 const invalid=Engine.allocateAging(5,[{date:'not-a-date',amount:5}],r=>r.amount,r=>r.date,asOf);
 assert.deepEqual([...invalid.b],[0,0,0,5]);assert.equal(invalid.oldest,91);
 const zero=Engine.allocateAging(0,[],r=>r.amount,r=>r.date,asOf);
 assert.deepEqual([...zero.b],[0,0,0,0]);assert.equal(zero.oldest,0);
});
