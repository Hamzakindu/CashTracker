import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

function createModule(state={}) {
  let instance;
  const context={
    State:Object.assign({cashAccounts:[{id:'bank1',name:'CBE',type:'bank',active:true}],moneyTransactions:[],cashReconciliations:[],paymentLedger:[],saveUndoState(){},save(){},runAtomic(fn){fn();}},state),
    Helpers:{uid:()=>`id-${Math.random()}`,getToday:()=> '2026-11-12',formatDate:x=>x,formatCurrency:x=>String(x),esc:x=>String(x??'')},
    Toast:{warning(){},success(){},info(){},error(){}},
    Security:{audit(){}},
    document:{getElementById(){return null}},
    window:{registerModule(name,factory){instance=factory();}}
  };
  context.window.window=context.window;
  vm.runInNewContext(readFileSync(new URL('../app/src/main/assets/js/modules/cash-banks.js',import.meta.url),'utf8'),context);
  return {api:instance,state:context.State};
}

test('CSV parser handles quoted commas and maps signed amounts',()=>{
  const {api}=createModule();
  const result=api.parseStatementCSV('Date,Description,Amount,Reference\n2026-11-01,"Shop, Main",-125.50,TX1\n2026-11-02,Customer deposit,300,TX2');
  assert.equal(result.ok,true);assert.equal(result.rows.length,2);
  assert.equal(result.rows[0].description,'Shop, Main');assert.equal(result.rows[0].direction,'out');assert.equal(result.rows[0].amount,125.5);
  assert.equal(result.rows[1].direction,'in');
});

test('CSV parser accepts debit and credit statement columns',()=>{
  const {api}=createModule();
  const result=api.parseStatementCSV('Posting Date,Details,Debit,Credit\n2026-11-01,Transfer out,50,\n2026-11-02,Deposit,,75');
  assert.equal(result.ok,true);assert.equal(JSON.stringify(result.rows.map(x=>[x.direction,x.amount])),JSON.stringify([['out',50],['in',75]]));
});

test('CSV parser rejects files without required transaction columns',()=>{
  const {api}=createModule();
  assert.equal(api.parseStatementCSV('Name,Note\nA,B').ok,false);
  assert.equal(api.parseStatementCSV('').ok,false);
});

test('match suggestions require same account, amount, direction and date within three days',()=>{
  const {api}=createModule({moneyTransactions:[
    {id:'good',accountId:'bank1',type:'in',amount:100,date:'2026-11-10',status:'posted'},
    {id:'wrong-direction',accountId:'bank1',type:'out',amount:100,date:'2026-11-10',status:'posted'},
    {id:'wrong-account',accountId:'other',type:'in',amount:100,date:'2026-11-10',status:'posted'},
    {id:'wrong-date',accountId:'bank1',type:'in',amount:100,date:'2026-11-01',status:'posted'}
  ]});
  const matches=api.suggestStatementMatches({date:'2026-11-11',amount:100,direction:'in'},'bank1');
  assert.deepEqual(matches.map(x=>x.id),['good']);
});

test('statement match suggestions exclude already matched app movements',()=>{
  const {api}=createModule({moneyTransactions:[{id:'used',accountId:'bank1',type:'in',amount:20,date:'2026-11-10',status:'posted'},{id:'free',accountId:'bank1',type:'in',amount:20,date:'2026-11-10',status:'posted'}],cashReconciliations:[{recordType:'statement_import',rows:[{status:'matched',matchedTransactionId:'used'}]}]});
  const matches=api.suggestStatementMatches({date:'2026-11-10',amount:20,direction:'in'},'bank1');
  assert.deepEqual(matches.map(x=>x.id),['free']);
});

test('semicolon CSV accepts decimal comma amounts without losing cents',()=>{
  const {api}=createModule();
  const result=api.parseStatementCSV('Date;Description;Amount;Type\n2026-11-01;Purchase;1.234,56;debit');
  assert.equal(result.ok,true);assert.equal(result.rows[0].amount,1234.56);assert.equal(result.rows[0].direction,'out');
});

test('confirming a match only annotates the statement row and never edits the money movement',()=>{
  const original={id:'tx1',accountId:'bank1',type:'in',amount:90,date:'2026-11-10',note:'Customer receipt',status:'posted'};
  const imp={id:'imp1',recordType:'statement_import',accountId:'bank1',rows:[{id:'row1',date:'2026-11-10',amount:90,direction:'in',status:'unmatched'}]};
  const {api,state}=createModule({moneyTransactions:[{...original}],cashReconciliations:[imp]});
  api.confirmStatementMatch('imp1','row1','tx1');
  assert.deepEqual(state.moneyTransactions[0],original);
  assert.equal(imp.rows[0].status,'matched');assert.equal(imp.rows[0].matchedTransactionId,'tx1');
});

test('confirming a statement match refuses a transaction with a different amount',()=>{
  const tx={id:'tx1',accountId:'bank1',type:'in',amount:91,date:'2026-11-10',status:'posted'};
  const imp={id:'imp1',recordType:'statement_import',accountId:'bank1',rows:[{id:'row1',date:'2026-11-10',amount:90,direction:'in',status:'unmatched'}]};
  const {api}=createModule({moneyTransactions:[tx],cashReconciliations:[imp]});
  api.confirmStatementMatch('imp1','row1','tx1');
  assert.equal(imp.rows[0].status,'unmatched');
});

test('ambiguous slash dates use day-first order for Ethiopian bank statement exports',()=>{
  const {api}=createModule();
  assert.equal(api.normalizeStatementDate('12/11/2026'),'2026-11-12');
  assert.equal(api.normalizeStatementDate('11/12/2026'),'2026-12-11');
  assert.equal(api.normalizeStatementDate('11/23/2026'),'2026-11-23');
});

test('exact statement reference ranks an otherwise valid candidate first',()=>{
  const {api}=createModule({moneyTransactions:[
    {id:'near-date',accountId:'bank1',type:'in',amount:45,date:'2026-11-10',reference:'OTHER',status:'posted'},
    {id:'same-ref',accountId:'bank1',type:'in',amount:45,date:'2026-11-12',reference:'REF-45',status:'posted'}
  ]});
  const matches=api.suggestStatementMatches({date:'2026-11-11',amount:45,direction:'in',reference:'REF-45'},'bank1');
  assert.equal(matches[0].id,'same-ref');
});
