import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const source = readFileSync(new URL('../app/src/main/assets/js/backup.js', import.meta.url), 'utf8');
function makeBackup(state) {
  const context = {
    console,
    State: state,
    Storage: { getSetting() { return 'disabled'; } },
    window: { addEventListener() {} },
    setTimeout() {}
  };
  vm.runInNewContext(source + '\n;globalThis.__BackupForTest = Backup;', context);
  return context.__BackupForTest;
}

test('restore preview reports collection counts and detects newer current activity', () => {
  const backup = makeBackup({
    currentProfileId: 'shop-a',
    sales: [{ id: 'old-sale', createdAt: '2026-01-01T10:00:00Z' }],
    purchases: [], directExpenses: [], returns: [], paymentLedger: [], moneyTransactions: [], peopleMoneyTx: [], stockHistory: []
  });
  const preview = backup.getBackupPreview({
    profileId: 'shop-a', exportedAt: '2026-01-02T00:00:00Z',
    products: [{ id: 'p1' }], sales: [], purchases: [], customers: [], suppliers: [],
    directExpenses: [], returns: [], paymentLedger: [], moneyTransactions: [], peopleMoneyTx: [], stockHistory: []
  });
  assert.equal(preview.counts.products, 1);
  assert.equal(preview.counts.sales, 0);
  assert.equal(preview.isOlderThanCurrent, true);
  assert.equal(preview.profileMismatch, false);
});

test('restore preview flags a backup belonging to a different profile', () => {
  const backup = makeBackup({ currentProfileId: 'shop-b', sales: [], purchases: [], directExpenses: [], returns: [], paymentLedger: [], moneyTransactions: [], peopleMoneyTx: [], stockHistory: [] });
  const preview = backup.getBackupPreview({ profileId: 'shop-a', products: [], sales: [], purchases: [], customers: [], suppliers: [] });
  assert.equal(preview.profileMismatch, true);
});

test('file restore requires preview confirmation and creates a recovery snapshot before writes', () => {
  assert.match(source, /BACKUP PREVIEW — REVIEW BEFORE RESTORE/);
  assert.match(source, /FINAL SAFETY CHECK/);
  assert.match(source, /Storage\.createSafetySnapshot\('pre-restore-'/);
  assert.ok(source.indexOf('Storage.createSafetySnapshot(\'pre-restore-\'') < source.indexOf('for (const store of Object.keys(prepared))'));
});
