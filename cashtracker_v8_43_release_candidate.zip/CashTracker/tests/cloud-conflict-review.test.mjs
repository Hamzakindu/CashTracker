import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const root=new URL('../',import.meta.url).pathname;
const cloud=fs.readFileSync(root+'app/src/main/assets/js/cloudflare-backend.js','utf8');
const worker=fs.readFileSync(root+'cloudflare/worker/src/index.js','utf8');
test('cloud conflict review decrypts a complete snapshot without writing local stores',()=>{
  const start=cloud.indexOf('async previewCloud()');
  const end=cloud.indexOf('    buildSafeMerge(',start);
  assert.ok(start>=0&&end>start);
  const fn=cloud.slice(start,end);
  assert.match(fn,/BackupCrypto\.decryptJson\(encrypted,pass\)/);
  assert.match(fn,/local:\s*count\(/);
  assert.match(fn,/cloud:\s*count\(/);
  assert.match(fn,/This is a read-only comparison/);
  assert.doesNotMatch(fn,/Storage\.save\(|Storage\.remove\(|State\.loadAllData/);
});
test('cloud comparison displays revision, timestamp and originating device metadata',()=>{
  assert.match(cloud,/head\.updatedAt/);
  assert.match(cloud,/head\.deviceId/);
  assert.match(cloud,/head\.appVersion/);
  assert.match(cloud,/cloudCompareResult/);
  assert.match(worker,/deviceId:head\.device_id/);
  assert.match(worker,/appVersion:head\.app_version/);
});
test('cloud compare is available in the Cloudflare panel and remains explicit',()=>{
  assert.match(cloud,/Compare this device with cloud/);
  assert.match(cloud,/uploadAll\(\)/);
  assert.match(cloud,/downloadAll\(\)/);
});
