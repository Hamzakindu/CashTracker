import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const src=fs.readFileSync(new URL('../app/src/main/assets/js/branch-snapshot-partition.js',import.meta.url),'utf8');
function helper(){const window={};vm.runInNewContext(src,{window});return window.BranchSnapshotPartition;}

test('branch partition includes only explicitly tagged records for the selected branch',()=>{
 const P=helper();const input={products:[{id:'p1',branchId:'east'},{id:'p2',branchId:'west'}],sales:[{id:'s1',branchId:'east'}]};
 const out=P.partition(input,'east');assert.equal(out.stores.products.length,1);assert.equal(out.stores.products[0].id,'p1');assert.equal(out.stores.sales[0].id,'s1');assert.equal(out.stores.purchases.length,0);
});

test('branch partition fails closed when any operational record has no branch ID',()=>{
 const P=helper();assert.throws(()=>P.partition({sales:[{id:'old-sale'}]},'east'),/Branch sync blocked/);
});

test('branch restore replaces only selected-branch rows and preserves other and unassigned rows',()=>{
 const P=helper(),names=P.STORE_NAMES;const current={};for(const n of names)current[n]=[];current.sales=[{id:'old-east',branchId:'east'},{id:'west',branchId:'west'},{id:'legacy'}];
 const stores={};for(const n of names)stores[n]=[];stores.sales=[{id:'new-east',branchId:'east'}];
 const merged=P.merge(current,{format:'cashtracker-branch-snapshot-v1',branchId:'east',stores},'east');
 assert.deepEqual(merged.sales.map(x=>x.id),['west','legacy','new-east']);
});

test('branch restore rejects snapshots containing another branch record or mismatched identity',()=>{
 const P=helper(),stores={};for(const n of P.STORE_NAMES)stores[n]=[];stores.sales=[{id:'x',branchId:'west'}];
 assert.throws(()=>P.merge({}, {format:'cashtracker-branch-snapshot-v1',branchId:'east',stores},'east'),/outside the selected branch/);
 assert.throws(()=>P.merge({}, {format:'cashtracker-branch-snapshot-v1',branchId:'west',stores},'east'),/identity or format/);
});

test('worker exposes separate branch snapshot tables and enforces branch scope and role checks',()=>{
 const schema=fs.readFileSync(new URL('../cloudflare/worker/schema.sql',import.meta.url),'utf8');
 const worker=fs.readFileSync(new URL('../cloudflare/worker/src/index.js',import.meta.url),'utf8');
 assert.match(schema,/cloud_branch_snapshot_heads/);assert.match(schema,/cloud_branch_snapshot_chunks/);
 assert.match(worker,/branch-snapshots/);assert.match(worker,/Your account is not authorized for this branch/);
 assert.match(worker,/Only Owners and Managers can publish branch snapshots/);assert.match(worker,/Your role cannot download branch financial data/);
});

test('branch cloud controls are loaded after the strict partition helper and remain separate from whole-profile sync',()=>{
 const html=fs.readFileSync(new URL('../app/src/main/assets/index.html',import.meta.url),'utf8');
 const backend=fs.readFileSync(new URL('../app/src/main/assets/js/cloudflare-backend.js',import.meta.url),'utf8');
 assert.ok(html.indexOf('js/branch-snapshot-partition.js')<html.indexOf('js/cloudflare-backend.js'));
 assert.match(backend,/uploadCurrentBranch/);assert.match(backend,/downloadCurrentBranch/);assert.match(backend,/BranchSnapshotPartition\.partition/);assert.match(backend,/this\.suppressQueue=true/);
});
