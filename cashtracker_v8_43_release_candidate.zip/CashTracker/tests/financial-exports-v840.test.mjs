import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

function loadStatements(host=null){
  const window={};
  const context={window,document:{getElementById:()=>host},Helpers:{esc:x=>String(x),formatCurrency:x=>String(x),getToday:()=> '2026-11-13'},State:{}};
  vm.runInNewContext(fs.readFileSync(new URL('../app/src/main/assets/js/modules/statements.js',import.meta.url),'utf8'),context);
  return window.Statements;
}

test('V8.40 Excel export is valid SpreadsheetML and preserves text and numeric cells',()=>{
  const s=loadStatements();
  const xml=s._spreadsheetXml({title:'Profit & Loss',rows:[['Metric','Amount'],['Net <profit>', '1250.50']],notes:['Read-only & unaudited']});
  assert.match(xml,/urn:schemas-microsoft-com:office:spreadsheet/);
  assert.match(xml,/Profit &amp; Loss/);
  assert.match(xml,/ss:Type="Number">1250\.50/);
  assert.match(xml,/Net &lt;profit&gt;/);
  assert.match(xml,/Read-only &amp; unaudited/);
});

test('V8.40 PDF print document escapes report content and includes print layout',()=>{
  const s=loadStatements();
  const html=s._printableHtml({title:'Balance <sheet>',rows:[['Account','Amount'],['Cash','10']],notes:['Read only']});
  assert.match(html,/Balance &lt;sheet&gt;/);
  assert.match(html,/window\.print\(\)/);
  assert.match(html,/@media print/);
  assert.match(html,/Read only/);
});

test('V8.40 export includes the selected date range in the exported report metadata',()=>{
  const row={querySelectorAll:()=>[{textContent:'Net profit'},{textContent:'125.00'}]};
  const table={querySelectorAll:()=>[row]};
  const card={querySelector:()=>({textContent:'Profit & Loss'}),querySelectorAll:(sel)=>sel==='table'?[table]:[]};
  const host={querySelectorAll:(sel)=>sel==='.card'?[card]:[{id:'plFrom',value:'2026-11-01'},{id:'plTo',value:'2026-11-13'}]};
  const s=loadStatements(host);
  const report=s._exportRowsFromReport();
  assert.ok(report.notes.some(x=>x.includes('plFrom: 2026-11-01')&&x.includes('plTo: 2026-11-13')));
});

test('V8.40 report export rejects a missing report table instead of creating an empty file',()=>{
  const s=loadStatements();
  assert.throws(()=>s._exportRowsFromReport(),/No financial report is currently displayed/);
});

test('V8.40 exposes PDF and Excel export actions for legacy and V8.39 reports',()=>{
  const source=fs.readFileSync(new URL('../app/src/main/assets/js/modules/statements.js',import.meta.url),'utf8');
  for(const kind of ['balance','ar','ap','inventory','cashflow','pnl','compare'])assert.ok(source.includes(`kind==='${kind}'`),`missing ${kind} report`);
  assert.match(source,/Statements\.exportCurrentPdf\(\)/);
  assert.match(source,/Statements\.exportCurrentExcel\(\)/);
  assert.match(source,/function comparePeriods\(from,to\)/);
  assert.match(source,/function periodProfitLoss\(from,to\)/);
});
