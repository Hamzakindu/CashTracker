# CashTracker V8.4 — Central Business Engine Integration

Version: 5.10.48 (versionCode 48)

## Implemented

1. Connected the read-only BusinessEngine to dashboard metrics for product count, stock quantity, purchase total, net profit and customer/supplier balance projections.
2. Net profit now includes sale-level expenses and direct expenses, sales returns, and returned cost.
3. Dashboard shows `Cost unavailable` when at least one active sale has no reliable historical cost. It does not substitute zero cost or stale stored profit.
4. New standalone customer/supplier settlement records preserve `balanceApplied` and `advanceAdded`, distinguishing debt repayment from excess prepayment.
5. Balance adjustments preserve the signed portion applied to debt and any excess converted into an advance.
6. Balance projections use source records and adjustment audit data where complete. Old settlement/adjustment rows without applied-amount detail, parties with no opening balance or source transaction history, or truncated audit history use cached balances instead of a guessed reconstruction.
7. The Finance Control balance audit includes applied adjustment portions and flags incomplete legacy settlement/adjustment history.
8. All projections are read-only; no migration rewrites existing balances.

## Important limitations

- BusinessEngine is integrated with dashboard metrics only. Reports, statements, cash/bank screens and accounting screens still have legacy calculations.
- Legacy cached balances are intentionally retained when their history cannot be reconstructed safely.
- Supplier returns are not yet fully represented in payable derivation.
- Stock value is still an estimate using current product buy price, not historical weighted-average costing.
- No Android Gradle build, deployed Cloudflare test or physical-device workflow test is claimed.

## Required regression checks

- Verify ordinary settlement less than debt: `balanceApplied` equals amount and `advanceAdded` is zero.
- Verify settlement greater than debt: `balanceApplied` equals debt and `advanceAdded` equals excess.
- Verify advance payment: `balanceApplied` is zero and `advanceAdded` equals amount.
- Verify negative balance adjustment larger than debt: only the existing debt is applied; excess becomes advance.
- Verify dashboard profit is unavailable if any active sale has missing historical cost.
- Verify void/cancelled records do not affect dashboard totals.
- Run Finance Control audit before and after each scenario; it must never silently change stored balances.


## Verification

- Automated Node tests: 76/76 passed.
- TypeScript strict typecheck: passed.
- TypeScript-to-Android-assets compilation: passed.
- Changed JavaScript syntax checks: passed.
- Project JSON validation: passed.
- ZIP integrity: passed.
- Android Gradle build and physical-device testing: not run; Gradle and a Gradle wrapper are unavailable in this environment.
