# CashTracker V8.40 — Professional Financial Exports

## Included
- Adds print-ready PDF output for the currently displayed financial report. The print dialog lets the user print or save the report as PDF; the app does not claim to create a PDF file silently.
- Adds Excel-compatible SpreadsheetML workbook exports (`.xls`) without adding a third-party runtime dependency.
- Export actions are available for balance sheet, receivable aging, payable aging, inventory valuation, cash flow, V8.39 Profit & Loss and V8.39 period comparison.
- Exported reports include displayed table contents, report notes and selected date inputs where applicable.
- Export encoding escapes XML-sensitive characters and preserves numeric cells as numbers.
- Existing V8.39 CSV exports remain available.

## Data safety and compatibility
- Export paths read the currently rendered report; they do not write to application state, journal entries, transaction records, balances or persistent posting ledger.
- No database/storage keys, record schemas or migrations were changed.
- No external PDF or spreadsheet library was added. PDF output uses the platform/browser print flow; Excel output uses Excel-compatible XML Spreadsheet format.
- Existing reports and their CSV entry points are retained.

## Verification
- `npm test`: 262 passed, 0 failed.
- `npm run typecheck`: passed.
- `npm run build:android-assets`: passed.
- `node --check` across JavaScript assets: passed.
- `package.json` and `appmint.json` JSON validation: passed.
- AndroidManifest XML parse: passed.
- ZIP integrity check: passed.
- Vite web build was not run; Vite is not installed in the supplied environment.
- Android APK/Gradle compilation and physical-device print/download behavior were not verified.

## Limitations
- PDF uses the Android WebView/browser print dialog. Availability of “Save as PDF” depends on the host print service.
- Excel output is SpreadsheetML XML in an `.xls`-named file for Excel compatibility, not a native OOXML `.xlsx` workbook.
- Reports inherit the completeness and accuracy of existing source data and journal mappings. They are management reports, not certified statements or tax advice.
