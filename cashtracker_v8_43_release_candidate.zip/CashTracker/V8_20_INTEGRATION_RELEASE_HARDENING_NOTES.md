# CashTracker V8.20 — Integration and Release Hardening

Version: 5.10.64 (Android versionCode 64)

## Scope

This is an integration/release-hardening update. It does not claim that every outstanding architectural item is complete. It preserves the V8.19 encrypted portable backup and restore flow, V8.18 calculator changes, V8.17 supplier refund and equity changes, safe record merge, durable sale/purchase/expense saves, and historical-cost warnings.

## Changes

- Bumped package and Android Gradle default version metadata to 5.10.64 / 64.
- Added release-readiness regression checks for version consistency, critical script dependency order, launcher manifest declarations, and presence of the major regression suites.
- Kept the existing detailed tests for encrypted backup/restore, download confirmation semantics, calculator history/share, supplier refunds, financial audit, safe cloud merge, and transaction persistence in the release gate.
- No automatic financial balancing, silent conflict resolution, or downgrade from encrypted backup to plaintext was introduced.

## Automated verification

Run from the project root:

```sh
npm test
npm run typecheck
npm run build:android-assets
```

The release-readiness tests are included in `npm test`.

## Not verified in this environment

- Android Gradle APK build/signing and installation on a physical phone.
- Actual Downloads-folder presence after export on Android 10+ and Android 16.
- Restore from an exported encrypted backup on a second device.
- Two-device Cloudflare concurrency, conflict review, merge, rollback and network interruption.
- Embedded/standalone calculator touch gestures, share sheet and return navigation on WebView.
- Real bank SMS ingestion and permission behavior.
- Financial correctness against the user's real historical records and opening balances.

## Required phone acceptance test before production use

1. Make a fresh encrypted backup and confirm the file is visible in the phone's Downloads app/file manager, with a non-zero size.
2. Copy that backup elsewhere before testing restore. Restore it into a test profile and compare products, stock, sales, purchases, expenses, parties, cash/bank accounts and reports.
3. Restore a legacy plaintext backup only after the explicit warning; verify the preview and recovery snapshot.
4. Create, close and reopen a sale; verify it remains active and no prior sale lines are copied into the next sale.
5. Save a purchase and expense; restart the app and verify all records and linked stock/cash movements.
6. Test a supplier return with full credit, partial cash refund and full cash refund; verify supplier payable and selected cash/bank balances.
7. Test calculator history, clear/undo, gestures, editable share header, confirmation, share sheet and return navigation.
8. On two phones, make separate non-conflicting changes and sync; then create a same-record conflict and verify it is blocked for review, not silently overwritten.
9. Review Finance Control and balance-sheet differences. Do not force a balancing adjustment merely to make the report show zero.
10. Keep the prior APK and a verified backup until all checks pass.

## Release status

**Test candidate only. Not certified production-ready.** Passing automated tests does not establish Android storage, native bridge, cloud deployment, multi-device or real-data correctness.
