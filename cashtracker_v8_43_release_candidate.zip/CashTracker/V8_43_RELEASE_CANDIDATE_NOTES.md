# CashTracker V8.43 — Release-candidate hardening

**App version:** 5.10.87  
**Android baseline versionCode:** 87

## Changes
- Corrected the GitHub Actions version override: CI now derives the base app version and version code from `gradle.properties`, then adds the workflow run number. This removes the stale hard-coded `5.10.54` label.
- Android project discovery now searches nested ZIP directories, validates the app Gradle file and manifest, and fails safely if multiple Android projects are found.
- Aligned package, Gradle, app metadata and JavaScript version values at 5.10.87.
- Added a regression test for CI project discovery and version derivation.

## Data safety
No database schema, transaction, financial calculation, encryption, backup or restore behavior was intentionally changed in this release-candidate hardening pass.

## Release gate status
- Node automated tests: **267 passed, 0 failed**.
- TypeScript typecheck and Android TypeScript asset compilation passed. Vite production build was not run because dependency installation timed out.
- GitHub Actions workflow YAML parsed successfully; Android Gradle release APK was not built because this environment has no Android SDK/Gradle installation.
- Signed APK and physical-device regression: pending GitHub Actions and device verification.

This is a release candidate, not a claim of a fully device-certified final release. Back up business data before installing.
