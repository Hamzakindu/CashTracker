import { copyFile, mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';
const source=resolve('dist-ts/cashtracker-core.js');
const targetDir=resolve('app/src/main/assets/js/utils');
const target=resolve(targetDir,'cashtracker-core.js');
await mkdir(targetDir,{recursive:true});
await copyFile(source,target);
console.log(`Copied TypeScript runtime bundle to ${target}`);
