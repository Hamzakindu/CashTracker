# V8.29 — Audit Trail and User Permissions

Release version: `5.10.73` (Android versionCode `73`).

## Changes
- Added explicit role permissions for audit viewing, period closing and period reopening.
- Managers and Accountants may close periods; only Owners may reopen periods or remove the legacy period lock. Cashiers and Inventory Clerks cannot close or reopen periods.
- Period close/reopen APIs enforce permissions directly, not only through hidden buttons or tab navigation. When staff login is enabled, an absent/expired staff session is denied. When staff login has never been configured, existing single-user operation remains compatible.
- Period closure records now retain the actor ID, display name and role for close/reopen actions.
- Audit events now capture actor ID, role and active branch context when staff login is active.
- Audit view is available to Owners, Managers, Accountants and Viewers, and checks for missing/duplicate IDs and missing action/timestamp/actor fields.

## Security boundaries
- Role checks run in the app on the device. They are not server-enforced authorization and cannot protect data from someone who can modify local app storage or code.
- Audit completeness checks detect malformed records; they do not cryptographically prove that audit records were not altered.
- The audit log retains a maximum of 5,000 records in the existing implementation. Reaching this limit is surfaced in the audit view; long-term immutable retention is not implemented.
- Multi-device authorization and immutable audit retention require server-side identity, access policies and append-only audit storage before this can be treated as a high-assurance control.

## Verification
- Automated tests: 194 passed, 0 failed.
- TypeScript typecheck and Android TypeScript asset compilation: to be recorded after release validation.
- JavaScript syntax, Android manifest XML, metadata JSON and ZIP integrity: to be recorded after release validation.
- Android Gradle APK compilation and physical-device testing are not claimed.
