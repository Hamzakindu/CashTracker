# CashTracker V8.2 – Cloud snapshot and conflict protection

## Changes
- Replaced independent per-store uploads in the current client with a single encrypted whole-profile snapshot.
- Added versioned snapshot metadata, chunk storage, and a profile head in D1.
- Added optimistic revision checks. A stale device receives HTTP 409 instead of silently replacing newer cloud data.
- Restore validates and decrypts the complete snapshot before writing any local store.
- Automatic sync records pending work locally and does not run while a known cloud conflict exists.
- Manual upload clearly asks before replacing the current cloud snapshot.
- Kept legacy `/api/stores` endpoints for older app versions.

## Deployment order
1. Make a verified local JSON backup on every device.
2. Apply the full updated `cloudflare/worker/schema.sql` to the existing D1 database. This is additive and does not delete the old `stores` table.
3. Deploy `cloudflare/worker` with Wrangler.
4. Update CashTracker on devices.
5. On a device with the authoritative current data, use Cloud → Upload current data and confirm replacement.
6. On other devices, use Cloud → Restore cloud data. Do not upload stale local data from those devices.

## Limits and caveats
- Encrypted whole-profile snapshots are capped at 20 MB and 80 chunks to stay within conservative request and D1 batch limits.
- D1 snapshot publication uses a conditional head update. Failed concurrent publications are not made visible and return HTTP 409.
- Existing legacy per-store data is detected; restore can decrypt it and publish a new versioned snapshot as a one-time migration.
- The Worker retains the latest five complete snapshots for recovery.
- This is cloud snapshot atomicity, not a distributed multi-device merge. Conflicting edits are blocked; users must choose the authoritative copy.
- Local multi-store writes are still not a crash-atomic database transaction. A local write-ahead recovery journal remains future work.
- Real Cloudflare deployment and multi-device race tests are still required.


## Verification in this environment
- Node tests: 54/54 passed.
- Cloudflare Worker and cloud client syntax checks: passed.
- TypeScript strict typecheck: passed.
- TypeScript Android runtime asset compilation: passed.
- Full Vite build and Android Gradle build: not verified here.
