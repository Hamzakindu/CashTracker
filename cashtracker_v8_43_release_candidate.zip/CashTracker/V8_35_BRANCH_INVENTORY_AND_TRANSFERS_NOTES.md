# V8.35 — Branch Inventory and Controlled Stock Transfers

Version: 5.10.79 (versionCode 79)

## Implemented
- Added a branch stock sub-ledger based on explicit opening allocations plus branch-tagged stock history.
- Added a branch inventory view under Branch Directory & Staff Role Setup.
- Added opening stock allocation wizard. Every product's allocations must sum exactly to its current workspace-wide `product.stock`; no branch is guessed.
- Added stock transfer workflow: dispatch decreases the sending branch; receiving confirmation increases the destination branch; cancellation before receipt returns quantity to the sender.
- Transfer movements are stored in `stockHistory` with branch IDs so the existing branch snapshot partitioner can keep sender and receiver movement records in their respective branch snapshots.
- Added `branchStockOpening` to application state, undo snapshots, atomic saves, safety snapshots, regular backup/restore, and branch snapshot partitioning.
- New sales and purchases record their branch ID on stock history movements; the sale product picker displays the selected branch quantity when a reconciled allocation exists, otherwise it clearly falls back to workspace total. Older sale/purchase correction movements derive the original transaction branch where source IDs are available; otherwise existing fallback behavior is retained and flagged by reconciliation.
- Opening allocation reset is blocked while transfers remain in transit.

## Safety model and limitations
- The legacy product `stock` field remains the workspace-wide control total; this release introduces branch balances as a reconciled sub-ledger rather than destructively replacing the existing stock field.
- Opening allocations are manual and require the sum to equal the current product stock. Historical stock movement rows are not silently assigned to branches.
- Product branch balances are marked not ready if no baseline exists, if post-baseline movements are unassigned, or if branch totals differ from the workspace-wide stock total.
- Transfers are not financial transactions and do not change cash, bank, sales, purchases, or product workspace-wide stock totals.
- This is an application-level workflow. The receiving branch has its own pending-transfer row so it can confirm receipt from a branch-scoped snapshot; sender/receiver transfer status coordination across separate Cloudflare devices still needs server-side integration and live testing.

## Verification
- Automated tests cover opening allocations, unassigned stock, dispatch, receipt, cancellation, insufficient quantity, and same-branch rejection.
- Android Gradle APK compilation, physical-device testing, Cloudflare deployment, and live multi-device testing are not claimed by this source release.
