# CashTracker V8.13 — Cloud Conflict Review

Version: 5.10.57  
Version code: 57

## Changes
- Added a read-only Cloudflare snapshot comparison in the Cloud panel.
- The comparison decrypts the remote snapshot on-device and compares record counts for each known store against the current local profile.
- Displays cloud revision, update time, originating device ID, app version, and local/cloud store counts.
- Does not write, merge, or overwrite local records. A count match is not proof that record contents are identical.
- Retains the existing conditional revision update on the Worker. Concurrent stale uploads remain rejected with HTTP 409.
- Preserves explicit user confirmation for full cloud upload replacement and full cloud restore.
- Corrected AppMint versionCode metadata to 57 to match the Gradle version code.

## Verification
- `npm test`: 116/116 passed.
- `npm run typecheck`: passed.
- `npm run build:android-assets`: passed.
- `node --check` on all JavaScript assets: passed.
- AppMint JSON validation: passed.
- Android Gradle compilation and physical-device testing: not performed.

## Limitations
- This release provides comparison and conflict visibility, not automatic record-level merge. Automatic merging of sales, purchases, payments, stock movements, and accounting entries would risk duplicate or inconsistent transactions without stable cross-device IDs and a transaction-aware merge protocol.
- Store counts can reveal differences but cannot prove that records are identical when counts match.
- Cloud preview requires a working Worker connection and the correct cloud password to decrypt the snapshot.
