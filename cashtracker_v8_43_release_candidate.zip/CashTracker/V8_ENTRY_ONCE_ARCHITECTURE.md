# CashTracker V8 — Enter Once, Derive Everywhere

## Required daily entry
The normal daily workflow is limited to:
1. Products
2. Purchases
3. Sales
4. Expenses

The app must derive inventory movements, cost of goods sold, profit, customer/supplier balances, cash/bank movements, accounting entries, statements and reports from those source transactions.

## Necessary transaction details are still captured at source
A sale or purchase may require a customer/supplier, date, payment amount, payment method and account. These are attributes of the sale/purchase and must not be entered again in a separate payment screen. Later settlement of an existing debt is a genuine new transaction and may be recorded as a receipt/payment against that customer/supplier.

Opening balances, opening stock, stock counts, returns, transfers, corrections and reconciliation differences are controlled setup/exception workflows, not routine duplicate entry.

## V8 code added in this build
`app/src/main/assets/js/utils/business-engine.js` is a read-only derived projection service. It calculates core business totals from existing source records and excludes void/deleted records. It does not rewrite source data or persist duplicate derived records. Historical profit is reported as unknown (`null`) when cost data is incomplete rather than inventing a value.

The service is loaded by `index.html` and exposed as `BusinessEngine.calculate(data)` / `window.BusinessEngine.calculate(data)`.

## Important implementation boundary
This is the first implementation increment, not the complete V8 accounting conversion. Existing operational modules still contain legacy balance/payment logic. They must be migrated in later steps so all screens consume the same derived projections and all posted transactions create validated accounting effects exactly once. Do not remove the legacy payment/adjustment workflows until that migration and its reconciliation tests are complete.

## Tests
`tests/business-engine.test.mjs` verifies core derivations, void filtering, missing-cost handling and source immutability.
