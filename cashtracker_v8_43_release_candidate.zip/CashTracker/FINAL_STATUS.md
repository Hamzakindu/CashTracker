# CashTracker V8.43 — Release Candidate Status

**Version:** 5.10.87  
**Android baseline version code:** 87

## Delivered
- V8.41 backup/export reliability and V8.42 complete financial export changes retained.
- GitHub Actions now finds a valid Android Gradle project inside nested ZIP folders and rejects ambiguous multi-project archives.
- CI release version derives from `gradle.properties`; stale hard-coded 5.10.54 version override removed.
- Package, Gradle, app metadata and JavaScript version aligned.

## Verification
- Node automated regression tests: **267 passed, 0 failed**.
- TypeScript typecheck: **passed**; TypeScript Android asset compilation: **passed**; JavaScript syntax checks: **passed**. Vite production bundle: not run because Vite dependency installation timed out.
- Workflow YAML syntax: **passed**. Android Gradle APK build: not run; Android SDK/Gradle environment is unavailable here.
- Signed APK install, backup/restore, calculator and transaction workflows: require GitHub Actions and physical Android verification.

**Release decision:** release candidate only. Do not treat as production-certified until the pending build and device gates pass.
