# CashTracker V8.39 — Advanced Financial Statements

## Included
- Adds a date-range Profit & Loss statement sourced from the existing double-entry accounting journal.
- Adds a comparative report for the selected period versus the immediately preceding period of equal length.
- Adds CSV export for both new reports.
- Retains the existing balance sheet, receivable aging, payable aging, inventory valuation and cash-flow reports.
- Uses journal account mappings for revenue (4000), sales returns (4100), cost of goods sold (5000) and operating expenses (6000).
- Displays journal-audit warnings and declines to fabricate report totals when the accounting journal is unavailable.

## Data safety and compatibility
- Reports are read-only. They do not edit sales, purchases, expenses, payments, balances, journal entries or the persistent posting ledger.
- No storage keys, business record schemas, migrations or existing report entry points were removed.
- Existing V8.38 reconciliation and V8.37 posting-ledger features are retained.
- Comparative period is calculated as the same number of calendar days immediately before the selected current period.
- CSV files contain numeric values and period labels; they are exports for analysis, not signed or certified financial statements.

## Verification
- `npm test`: 257 passed, 0 failed.
- `npm run typecheck`: passed.
- `npm run build:android-assets`: passed.
- `node --check` on all JavaScript files: passed.
- JSON manifests and AndroidManifest XML: valid.
- Android APK/Gradle build, Vite web build, physical-device testing, backup/restore against live user data, cloud deployment and multi-device synchronization were not verified in this environment.

## Accounting limitations
The reports inherit the completeness and accuracy of the existing journal mappings and source transaction history. Legacy or incomplete history may cause differences. Review the integrity audit and journal audit before using figures for tax, lending, statutory filings or a formal accounting close. No balancing adjustment is automatically posted.
