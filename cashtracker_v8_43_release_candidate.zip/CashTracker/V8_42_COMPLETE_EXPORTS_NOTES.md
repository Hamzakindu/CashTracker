# CashTracker V8.42 — Complete and Safe Exports

**App version:** 5.10.86  
**Android version code:** 86

## Changes
- Full JSON export now delegates to the dedicated encrypted, integrity-sealed backup pipeline. This removes the weaker duplicate plaintext/incomplete export path.
- CSV export now includes products, customers, suppliers, active sales, purchases, expenses, returns, payment ledger entries, and cash/bank movements.
- CSV cells use quote escaping compatible with common spreadsheet importers, UTF-8 BOM, and CRLF row endings.
- Text that could be interpreted as spreadsheet formulas is prefixed defensively.
- Sale paid amounts support both current `paid` and legacy `paymentReceived` fields.
- Export completion messaging distinguishes confirmed Android saves from unconfirmed browser download requests.

## Safety
- No transaction records, balances, accounting calculations, backup schema, encryption format, or restore behavior were changed.
- Full JSON backup continues to use the established encrypted backup format.

## Verification
- Run `npm test`, `npm run typecheck`, and `npm run build:ts`.
- Physical Android testing is still required to confirm exported files appear in Downloads on the target device.
