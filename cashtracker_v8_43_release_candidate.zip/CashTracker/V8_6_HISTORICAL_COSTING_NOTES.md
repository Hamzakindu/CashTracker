# CashTracker V8.6 — Historical Inventory Costing

Version: 5.10.50 (version code 50)

## Changes
- Introduces `HistoricalCostEngine`, a read-only perpetual weighted-average inventory projection.
- Reconstructs purchase receipts from purchase line costs, issues from stored sale-line cost snapshots, returns from recorded returned cost, and non-transaction stock adjustments from stock history.
- Purchase/sale/return stock-history rows created by this version carry source references and unit-cost snapshots.
- Inventory statements and Stock Ledger use the projection only when projected quantities reconcile to current product stock.
- Legacy opening stock with no explicit opening cost and transactions with missing historical cost are marked estimated. Missing or inconsistent history is never silently presented as a verified historical valuation.

## Compatibility and safety
- No existing sales, purchases, products, returns or stock-history rows are rewritten.
- Old stock-history purchase/sale rows are not guessed by matching only the calendar date; source transaction records are used instead.
- If source history and current stock disagree, the historical value is unavailable for that product and a reconciliation warning is exposed.
- The engine is a read-only projection, not an accounting-period close and not a replacement for a full stocktaking/reconciliation workflow.

## Validation
- Includes regression tests for weighted average, sale cost snapshots, returns, legacy estimates and stock quantity mismatches.
- Android Gradle build and physical-device testing remain release gates.

## Automated test result
93/93 Node regression tests passed in this workspace. TypeScript type checking and Android TypeScript asset compilation passed. Vite's separate bundle build could not run because the `vite` package is not installed in this archive environment. No Gradle wrapper is present, so Android APK build and physical-device verification were not performed.
- The projection also flags sale-line cost snapshots that differ from the reconstructed moving average (for example, after a backdated purchase). It does not rewrite the posted sale; investigate the discrepancy before relying on the affected historical margin.
