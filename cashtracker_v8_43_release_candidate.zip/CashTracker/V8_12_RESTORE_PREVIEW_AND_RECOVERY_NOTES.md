# CashTracker V8.12 — Restore Preview and Recovery Protection

Release: 5.10.56 (versionCode 56)

## Changes

- File restore now shows a review preview before overwriting records: primary collection counts, backup timestamp, and latest dated activity found in the backup and current profile.
- Restore detects when the current profile has newer activity than the selected backup and requires a separate final confirmation.
- Restore detects a profile ID mismatch and requires a separate final confirmation rather than silently treating the file as belonging to the active profile.
- A pre-restore Storage safety snapshot is created and confirmed before any store writes. If a snapshot cannot be confirmed, restore is stopped before changing data. Empty profiles are allowed to restore without a non-empty snapshot.
- Existing integrity-seal validation, legacy backup compatibility, write rollback, and current file export verification remain in place.

## Verification

- Automated tests: 113 passed.
- TypeScript typecheck: passed.
- Android TypeScript asset build: passed.
- JavaScript syntax checks: passed.
- appmint.json parse: passed.
- ZIP integrity: checked after packaging.

## Limitations

- Latest-activity comparison uses available transaction timestamps (`createdAt`, `timestamp`, or `date`). Legacy records without dates cannot be included in the freshness comparison.
- Restore still requires a real Android device test, including intentionally selecting an older backup and recovering the pre-restore snapshot.
- Android Gradle compilation and physical-device testing were not performed in this environment.
- This release does not claim that a backup is recoverable from a separate device unless the user has copied the exported file or cloud backup to that device.
