# CashTracker V8.38 — Party Balance Reconciliation

Release: 5.10.82 / Android versionCode 82

## Objective
Improve customer and supplier balance reconciliation without changing existing data structures, transaction formats, backups, or financial history.

## Changes
- `AccountingLedger.reconcile()` now delegates to the shared read-only `FinancialAudit` balance and advance audits when available.
- The shared audit accounts for applied settlement amounts, sales/purchase debt, return offsets, balance adjustments and advance balances, and flags incomplete legacy history for manual review.
- The legacy calculation remains as a fallback for unusual script load order or environments where the shared audit utility is unavailable.
- Reconciliation detail now displays the issue explanation and safely renders unavailable expected/actual amounts as a dash instead of a misleading numeric value.
- No automatic balance correction, transaction rewrite, schema migration, or ledger initialization is performed.

## Compatibility and data safety
- Existing stores and record structures are unchanged.
- All reconciliation checks are read-only.
- Incomplete or ambiguous history is reported, not guessed or repaired automatically.
- V8.37 persistent posting ledger behavior remains unchanged.

## Verification
- V8.38-specific tests cover shared audit delegation, read-only behavior, fallback behavior and safe rendering of legacy-history findings.
- Full automated suite and static checks are run for this release candidate.

## Release status
Source-level candidate. Android APK compilation, physical-device tests, real backup/restore and cloud multi-device validation remain external release gates.
