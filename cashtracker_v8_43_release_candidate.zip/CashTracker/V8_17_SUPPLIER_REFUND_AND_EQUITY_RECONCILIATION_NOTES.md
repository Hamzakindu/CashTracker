# CashTracker V8.17 — Supplier refund workflow and equity reconciliation

Version: 5.10.61 (versionCode 61)

## Implemented
- Calculator-originated supplier returns now ask how the supplier settles the return: reduce the payable, or refund money into a selected cash/bank account.
- A cash refund can be partial. The cash portion is allocated proportionally across returned product lines, recorded against the selected account, and capped at the total return value.
- The remaining return value offsets Accounts Payable in the generated double-entry journal. No imaginary cash is created for credit settlement.
- Balance sheet now shows journal-derived owner capital, accumulated net profit, recorded equity subtotal, net assets, and the unreconciled difference.
- Differences are flagged for review; no automatic balancing or retained-earnings adjustment is posted.
- Tests cover supplier refund UI wiring, partial refund allocation, and equity reconciliation reporting.

## Validation limits
- This is not a certified accounting close. Legacy transactions, opening balances, stock valuation gaps, and incomplete journal mappings can cause differences.
- Supplier-return workflow was updated in the calculator quick-return path. The separate customer-return screen is unchanged.
- No Android Gradle APK build or physical-device test was performed in this environment.
- Actual cash/bank balance updates and persistence must still be verified on an Android device using a test supplier return.
- Supplier payable projection now offsets only the non-cash portion of a supplier return when an explicit cash refund is recorded, keeping the party balance consistent with the double-entry journal.
