# CashTracker V8.41 — Backup Read-back Reliability

**App version:** 5.10.85  
**Android version code:** 85

## Changes
- Android backup writes now reopen the completed Downloads item and compare its complete bytes with the original encrypted backup before reporting confirmed success.
- The app-specific file fallback also performs a byte-for-byte read-back check.
- Backup reminder history is updated only when the save bridge reports `confirmed: true`; a browser download request without filesystem confirmation no longer counts as a completed backup.
- Failed or mismatched read-back verification returns an error instead of a success message.

## Safety
- No transaction data, accounting calculations, backup schema, encryption format, or restore behavior was changed.
- Existing encrypted and legacy backup compatibility is retained.

## Verification limits
- Automated source tests can verify the safeguards, but only an APK run on a physical Android device can verify actual Downloads visibility on that device.
