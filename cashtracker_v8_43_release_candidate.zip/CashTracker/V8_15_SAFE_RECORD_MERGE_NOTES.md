# CashTracker V8.15 — Safe Cross-Device Record Merge

Version: 5.10.59  
Version code: 59

## Changes
- Added an explicit **Merge non-conflicting records** action to the Cloudflare panel.
- Merges stable-ID record arrays by `ctRecordId`, retaining records unique to either device and including identical records once.
- Blocks duplicate IDs, missing IDs, same-ID content differences, profile mismatches, and changed stores that do not have stable record identities.
- Requires user confirmation and creates an in-memory State rollback snapshot plus the existing undo entry before applying the merge.
- Persists merged stores, flushes IndexedDB when available, and publishes against the exact cloud revision read at the start. Server compare-and-swap rejects a cloud revision that changed during the merge.
- Restores the local snapshot if applying or publishing the merge fails.
- Read-only comparison remains read-only; the merge is a separate explicit action.

## Safety boundary
This is conservative union-only merging, not a general-purpose conflict resolver. Records with the same stable ID but different contents are not auto-resolved. Stores without stable identities must be byte-for-byte JSON-equal. The current scheme does not yet prove every business-level foreign-key relationship across all historical schemas; use a local backup before merging real business data and test with two disposable profiles/devices first.

## Verification
- Automated tests, TypeScript typecheck, Android asset generation, JS syntax, manifest JSON and ZIP integrity are checked for this release.
- Android Gradle compilation, two-physical-device synchronization, and real Cloudflare end-to-end merge tests are not performed in this environment.
