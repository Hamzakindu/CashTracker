# V8.32 — Historical Branch Migration and Product Supplier / Gallery Intake

Version: `5.10.76` (Android versionCode `76`)

## Historical branch migration

- Added a preview of every top-level record in the branch snapshot stores that has no `branchId`.
- Each row is shown with its store, available record label/date and an explicit branch selector.
- Records may be left unassigned; there is no bulk default branch and no inferred branch ownership.
- Applying selected assignments validates the record identity and that it is still unassigned, rejects duplicate/stale assignments, and writes only the affected stores through `Storage.saveBatch`.
- Other branch records remain unchanged. Each assigned record receives `branchMigration.method=manual_review` and a review timestamp.
- The branch upload remains fail-closed until all required operational records have a branch ID.

## Product supplier directory

- New products require at least one existing supplier; multiple suppliers can be selected.
- Product records store `supplierIds`, the legacy-compatible primary `supplierId`, and `supplierLinks` name snapshots.
- Product details show linked suppliers.
- Product edit requires at least one linked supplier. Existing products without suppliers are flagged and can be reviewed one at a time.
- CSV import requires the operator to enter the exact name of an existing supplier and links that supplier to every imported row; no supplier is guessed.
- A supplier linked to any product cannot be deleted.
- Purchase creation and purchase editing validate that the selected supplier is linked to every product in the purchase.

## Gallery share intake

- Android MainActivity declares `ACTION_SEND` and `ACTION_SEND_MULTIPLE` image share targets.
- Incoming content URIs are read through ContentResolver, limited to five images, downscaled to a maximum 1600-pixel edge, converted to JPEG and passed to the Add Product form as data URLs.
- The native import runs off the UI thread. Images are then processed by the existing product-image storage flow and saved with the product when the user submits it.
- This feature is available only in the Android app; browser preview does not receive Android share intents.

## Safety / limitations

- Historical supplier migration does not invent or auto-assign suppliers. Products missing suppliers remain visible for review and cannot be used in a new purchase until linked.
- Supplier list membership is enforced in the product and purchase UI. It is not a server-side policy and does not prevent direct database edits.
- Gallery share intent handling and Android Kotlin source have static regression coverage, but this release has not been compiled into an APK or tested with the Android share sheet on a physical phone.
- Branch migration is a manual per-record assignment workflow. It does not infer branch from dates, staff, old purchase supplier, or transaction sequence.
- No Cloudflare Worker deployment was performed.

## Verification

- 215/215 automated Node tests passed.
- TypeScript typecheck passed.
- Android TypeScript asset build passed.
- JavaScript syntax checks passed for all 91 JavaScript files under `app/src/main/assets/js`.
- Android manifest XML and app/package JSON metadata parsed successfully.
- ZIP integrity checked after packaging.
- Android Gradle APK compilation and physical-device testing remain outstanding.
