# CashTracker V8.7 — Accounting Integrity Guard

Version: 5.10.51 (versionCode 51)

## Changes
- Adds a transaction-level audit to the read-only double-entry journal. Each generated journal group is checked independently for debit/credit equality, valid account codes, and valid ISO dates; an aggregate trial-balance total can no longer hide a broken individual transaction.
- The accounting statement screen displays the transaction-group audit result and a concise list of detected exceptions.
- Prevents a return marked “No money / exchange / stock correction” from being posted with a positive refund amount. This avoids recording a non-cash return as though cash had been paid.
- Extends the existing closed-period guard to return submit, update, and delete operations where those methods exist.
- No existing source transactions are rewritten; the audit is read-only. Legacy non-cash returns carrying a positive refund are flagged as unbalanced rather than being falsely represented as cash refunds.

## Important accounting limits retained
- This is an integrity guard around the existing derived journal, not yet a complete general ledger. Expense account/payment mapping, account-specific cash/bank mapping, supplier-return workflows, opening-balance journalization, and retained-earnings closing still need dedicated work.
- Legacy records with incomplete fields can produce flagged journal exceptions. Do not edit balances just to make the audit green.
- Period lock remains a local protection and is not a tamper-proof, server-enforced accounting close.

## Validation
- 98/98 Node regression tests passed, including balanced/unbalanced transaction groups, customer-credit returns, legacy non-cash return handling, and return period-lock guards.
- TypeScript type checking passed.
- Android TypeScript asset compilation passed.
- All JavaScript assets passed `node --check`; archive JSON and ZIP integrity checks passed.
- Vite bundle build was not run because the Vite package is not installed in this archive environment. No Gradle wrapper is present, so Android Gradle build and physical-device testing remain release gates.
