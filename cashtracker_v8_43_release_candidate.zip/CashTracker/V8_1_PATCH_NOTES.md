# CashTracker V8.1 Reliability Patch — 5.10.44

This patch addresses confirmed defects from the repository audit. It is a test candidate; see `FINAL_STATUS.md` for verification and release blockers.

## Defects corrected

1. Kotlin and JS/TS bank SMS parsers no longer select a date fragment as the transaction amount when the message has a currency-labelled amount later in the text.
2. Direction keywords use word boundaries, so `present` is not `sent` and `unpaid` is not `paid`. Messages without a recognised transaction action are rejected by the parser.
3. BOA matching uses word boundaries and no longer matches `BOARD`. Recognised bank names in SMS bodies can support legitimate short-code sender IDs.
4. Decimal minor-unit conversion now parses decimal strings, correctly rounding values such as 1.005 and 8.325.
5. BusinessEngine treats an empty item list with no sale cost as unknown cost, treats `costAmount` as a line total, excludes cancelled records and accounts for returns in net sales and COGS.
6. People Money EntryMemory now stores `entryKind`.
7. Plain JSON is no longer silently accepted by the decryption function; legacy import requires an explicit `allowLegacyPlainJson` option.
8. Cloud restore stages/decrypts stores before writing, attempts local rollback on failure and suppresses immediate re-upload of restored records.
9. Worker PBKDF2 configuration is set to 100,000 iterations. Login and registration have a D1-backed IP rate limit (10 attempts per 15-minute window).
10. TypeScript runtime compilation writes browser-compatible ES modules into Android assets; GitHub Actions now runs this pipeline before tests and APK build.

## Required Cloudflare deployment step

Before deploying the updated Worker, apply the new D1 schema: `cloudflare/worker/schema.sql`. This creates the `auth_rate_limits` table required by login and registration. Do not deploy the Worker first or authentication requests will fail until the migration is applied.

## Important remaining limitations

- Cloud uploads are still independent per-store writes. A versioned, atomic profile snapshot and idempotent per-record sync are not yet implemented.
- BusinessEngine is not yet integrated as the sole calculation source across every screen. Customer/supplier balances still need full transaction-ledger derivation.
- Cloud account password and encryption passphrase remain coupled. Local device data is not encrypted at rest by the PIN lock.
- Real SMS sender IDs/templates, Android Gradle tests/build, and deployed Cloudflare login/sync must be verified on actual services/devices.


## Follow-up: verified Android backup downloads

- Android WebView downloads now use a callback-based native bridge. JavaScript waits for the Android file writer to confirm the write and MediaStore finalization before showing a success message.
- Native saving rejects empty payloads, checks output stream creation, verifies the MediaStore pending row was finalized, and removes incomplete MediaStore entries on failure. On Android versions before API 29, the file is written to the app-specific Downloads directory and its actual path is returned.
- The backup reminder records a successful backup date only after the export reports success. Failed or unconfirmed exports do not reset the reminder.
- Local safety backup messaging now clearly distinguishes an internal app copy from a downloadable file.
- JSON and CSV export screens use the same download pipeline and no longer announce completion before the save request finishes.
- Added download reliability regression tests.


## Follow-up 5.10.45 — durable financial posting

- Extended `State.runAtomicDurable` with a post-write verification callback inside its rollback boundary.
- New sales and purchases now wait for durable commit completion and verify the source record plus associated payment/account movement before closing their forms.
- Direct expenses and quick expenses now use durable commits and verify their expense/money-movement pair.
- Customer and supplier payments now require a selected account, use durable commits, and verify the payment-ledger/account-movement link.
- Duplicate taps are blocked while a sale or purchase is being saved.
- IndexedDB flush now reports queued mirror-write failures rather than silently treating a swallowed promise rejection as a successful flush; environments without IndexedDB retain the localStorage fallback.
- Updated app/package/workflow version to 5.10.45 / versionCode 45.

This is not a claim of full ACID/crash atomicity. The existing persistence model still writes multiple localStorage keys separately and mirrors them asynchronously to IndexedDB. Full write-ahead recovery and versioned cloud snapshots remain outstanding.
