# CashTracker V8.27 — Cash and Bank Statement Reconciliation

## Added
- CSV statement import for cash, bank and mobile-wallet accounts.
- Supports common headers for transaction date, description/details, amount, debit/credit, direction/type and reference.
- Quoted CSV fields and comma/semicolon delimiters are supported. Slash-formatted dates use day-first interpretation for ambiguous dates, with unambiguous month/day values detected.
- Imported statement rows are stored as review records inside the existing `cashReconciliations` store and are included in backup/sync through the existing store registration.
- Exact amount + direction + account + date-window matching suggestions (up to three days); multiple candidates remain explicitly ambiguous.
- Possible repeat imports are flagged using account/date/amount/direction/reference fingerprints.
- User-confirmed matches retain the imported row and matched app transaction ID, timestamp and audit event.

## Safety
- Statement imports do not create `moneyTransactions` and do not affect cash, bank, wallet, profit, or accounting balances.
- No app transaction is edited, posted, voided or deleted by importing or matching.
- A match requires the user to confirm a suggested app movement. Amount, account, direction and duplicate-match checks run again at confirmation.
- Rows with invalid/missing dates or amounts are skipped and counted. CSV is the supported import format in this release; bank-specific PDF/Excel parsing and direct bank APIs are not included.

## Verification
- Automated tests cover CSV parsing, debit/credit mapping, invalid files, match criteria and duplicate match exclusion.
- Full project checks are recorded in the release handoff. Android Gradle APK compilation and physical-device testing are not claimed.
