# CashTracker V8.21 — Transaction Store Reliability

Version: 5.10.65 (Android versionCode 65)

## Changes

- Added a synchronous multi-store `Storage.saveBatch()` path. All values are serialized and size-checked before any write is attempted.
- LocalStorage writes are treated as one logical batch: if a later key write fails, earlier writes in that batch are restored to their prior values. A rollback failure is surfaced in the error rather than silently ignored.
- IndexedDB mirrors receive the same batch through one read-write transaction (`putMany`), instead of a sequence of independent transactions.
- `State.saveAll()` now uses the batch path, so sale, purchase and other `runAtomicDurable()` operations persist their related stores together before the IndexedDB flush and post-save verification.
- Single-store `Storage.save()` uses the same batch implementation.
- Existing storage keys and encoded record formats are unchanged; this is a backward-compatible storage-layer change.

## Verification

Run `npm test`, `npm run typecheck`, and `npm run build:android-assets` from the project root. All 148 automated tests passed in this build. The new storage tests simulate a quota/write failure and verify rollback, preflight rejection and successful multi-store commits.

## Important limitations

- WebView localStorage does not provide native database transactions. The synchronous batch uses compensating rollback if a write fails; sudden process termination or device power loss between individual localStorage writes cannot be made fully atomic by this technique.
- IndexedDB `putMany` is genuinely transactional within its object store, but it remains a mirror, not the only authoritative store.
- No real Android quota exhaustion, process-kill, device restart, or two-device concurrency test was performed here.
- This update does not yet migrate every non-transaction preference/log key into a unified database. The app remains a test candidate until phone acceptance tests pass.
