# CashTracker V8.10 — Supplier Returns and Reconciliation

Version: 5.10.54 (versionCode 54)

## Changes

- Calculator-history supplier returns now retain supplier/customer party references, transaction identifiers, return type, and purchase/sale source classification.
- Supplier returns reduce the linked supplier's derived payable balance. Returns exceeding the derived payable are capped at zero and explicitly flagged for review; the excess is not silently invented as a supplier advance or cash refund.
- Supplier returns are journalized as debit Accounts Payable / credit Inventory. They are no longer misclassified as customer sales returns or cash refunds.
- Business projections separate customer sales returns from supplier purchase returns. Supplier returns reduce net purchases, not net sales or cost of goods sold.
- The balance-sheet report displays double-entry journal warnings and supplier-return excess warnings when applicable.
- Version incremented to 5.10.54 / code 54.

## Important accounting limitation

The calculator-history supplier-return workflow currently records the returned value but does not collect a separate cash refund/payment settlement from the supplier. Therefore the journal treats the value as a reduction of supplier payable. If the supplier owes a cash refund or a credit beyond the payable, the app flags the excess for manual review rather than guessing its treatment. Supplier return valuation follows the entered return line value; it does not prove that the original purchase cost or supplier invoice was matched.

## Verification

- Automated tests: 107 passed.
- TypeScript typecheck: passed.
- Android TypeScript asset build: passed.
- JavaScript syntax checks and archive integrity are run for the release ZIP.
- No Android Gradle build or physical-device test was performed in this environment.
