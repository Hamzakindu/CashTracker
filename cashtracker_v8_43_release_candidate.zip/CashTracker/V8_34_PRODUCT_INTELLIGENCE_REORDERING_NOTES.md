# V8.34 — Product Intelligence and Reordering

Version: 5.10.78 (Android versionCode 78)

## Delivered

- Added a read-only `ReorderPlanner` engine for product demand and supplier-aware reorder calculations.
- Replaced the basic low-stock view with Product Intelligence & Reordering.
- Demand windows are configurable to 30, 60 or 90 days; target stock cover is configurable to 14, 30 or 60 days. Preferences are stored locally.
- Uses active, non-voided sales only and derives quantities from sale line items.
- Excludes sales outside the selected demand window. Branch selection filters sales by explicit `branchId`; unassigned historical sales are counted and disclosed rather than assigned by guess.
- New sales and purchases record the active branch ID (or the existing main fallback) at creation. Historical records are not rewritten.
- Suggested stock target uses average daily demand × (cover days + supplier lead time) plus safety stock. Safety stock is at least twice the configured minimum or seven days of average demand. With no recent sales, minimum-stock fallback is used.
- Supplier selection prefers the configured preferred supplier if it is not marked unavailable; otherwise selects an eligible linked supplier. If all suppliers are unavailable or no supplier is linked, no supplier is fabricated or selected.
- Estimated supplier unit cost uses the supplier quote, then latest active purchase from that supplier, then product buy price. Missing prices remain zero and are labeled missing.
- Shows estimated purchase cost and estimated gross profit if all suggested units sell at the current sell price. This is a planning estimate, not a profit posting or guarantee; it excludes operating expenses, tax, discounts and price changes.
- Purchase-plan sharing supports per-product supplier and quantity review. It only creates a message; it does not create a purchase, reserve stock, alter balances or post accounting entries.

## Important scope limitations

- Current stock is still a workspace-level product stock value, not a separate per-branch stock ledger. Branch selection filters sales demand only; the UI explicitly warns that stock is not independently allocated by branch. True branch-level reorder quantities require branch-specific stock balances and inventory movement migration.
- Historical sales/purchases without branch IDs remain unassigned. No historical branch assignment is guessed.
- Supplier quotes and supplier link metadata remain product-level; this release does not create branch-specific supplier contracts.
- No automatic purchase orders, supplier API calls, or purchase posting are performed.

## Verification

- 231/231 automated tests passed.
- `npm run typecheck` passed.
- `npm run build:android-assets` passed.
- `node --check` passed for every JavaScript file under `app/src/main/assets/js`.
- `appmint.json` parsed as valid JSON.
- `AndroidManifest.xml` parsed as valid XML.
- Android Gradle APK compilation, physical-device testing, and Cloudflare deployment were not performed.
