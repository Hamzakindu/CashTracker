CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  password_salt TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);

CREATE TABLE IF NOT EXISTS stores (
  user_id TEXT NOT NULL,
  profile_id TEXT NOT NULL,
  store_name TEXT NOT NULL,
  chunk_index INTEGER NOT NULL,
  chunk_data TEXT NOT NULL,
  chunk_count INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT,
  app_version TEXT,
  PRIMARY KEY(user_id, profile_id, store_name, chunk_index)
);
CREATE INDEX IF NOT EXISTS idx_stores_profile ON stores(user_id, profile_id, store_name);


-- Per-IP authentication throttling. Keys are SHA-256 hashes; raw IPs are not stored.
CREATE TABLE IF NOT EXISTS auth_rate_limits (
  rate_key TEXT PRIMARY KEY,
  window_start INTEGER NOT NULL,
  attempts INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_auth_rate_limits_window ON auth_rate_limits(window_start);


-- Versioned whole-profile snapshots. A head points to one complete encrypted snapshot.
-- Readers never observe a mixture of stores from different upload times.
CREATE TABLE IF NOT EXISTS cloud_snapshots (
  snapshot_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  profile_id TEXT NOT NULL,
  revision INTEGER NOT NULL,
  device_id TEXT,
  app_version TEXT,
  created_at INTEGER NOT NULL,
  chunk_count INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cloud_snapshots_profile ON cloud_snapshots(user_id, profile_id, revision);

CREATE TABLE IF NOT EXISTS cloud_snapshot_chunks (
  snapshot_id TEXT NOT NULL,
  chunk_index INTEGER NOT NULL,
  chunk_data TEXT NOT NULL,
  PRIMARY KEY(snapshot_id, chunk_index)
);
CREATE INDEX IF NOT EXISTS idx_cloud_snapshot_chunks_id ON cloud_snapshot_chunks(snapshot_id);

CREATE TABLE IF NOT EXISTS cloud_snapshot_heads (
  user_id TEXT NOT NULL,
  profile_id TEXT NOT NULL,
  revision INTEGER NOT NULL,
  snapshot_id TEXT NOT NULL,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY(user_id, profile_id)
);


-- Server-owned workspace memberships. These are separate from encrypted local staff labels.
CREATE TABLE IF NOT EXISTS workspace_members (
  profile_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  workspace_owner_id TEXT NOT NULL,
  role TEXT NOT NULL,
  branch_ids TEXT NOT NULL DEFAULT '*',
  active INTEGER NOT NULL DEFAULT 1,
  created_by TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY(profile_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_workspace_members_user ON workspace_members(user_id, profile_id);

-- Server-side audit events for access-control changes.
CREATE TABLE IF NOT EXISTS workspace_security_audit (
  id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL,
  actor_user_id TEXT NOT NULL,
  target_user_id TEXT,
  action TEXT NOT NULL,
  details TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_workspace_security_audit_profile ON workspace_security_audit(profile_id, created_at);


-- Branch-isolated encrypted snapshots. Each branch has an independent revision head.
CREATE TABLE IF NOT EXISTS cloud_branch_snapshots (
  snapshot_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  profile_id TEXT NOT NULL,
  branch_id TEXT NOT NULL,
  revision INTEGER NOT NULL,
  device_id TEXT,
  app_version TEXT,
  created_at INTEGER NOT NULL,
  chunk_count INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cloud_branch_snapshots_scope ON cloud_branch_snapshots(user_id, profile_id, branch_id, revision);
CREATE TABLE IF NOT EXISTS cloud_branch_snapshot_chunks (
  snapshot_id TEXT NOT NULL,
  chunk_index INTEGER NOT NULL,
  chunk_data TEXT NOT NULL,
  PRIMARY KEY(snapshot_id, chunk_index)
);
CREATE INDEX IF NOT EXISTS idx_cloud_branch_snapshot_chunks_id ON cloud_branch_snapshot_chunks(snapshot_id);
CREATE TABLE IF NOT EXISTS cloud_branch_snapshot_heads (
  user_id TEXT NOT NULL,
  profile_id TEXT NOT NULL,
  branch_id TEXT NOT NULL,
  revision INTEGER NOT NULL,
  snapshot_id TEXT NOT NULL,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY(user_id, profile_id, branch_id)
);
