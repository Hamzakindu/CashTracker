const ALLOWED_STORES = new Set([
  'products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger','expenseTypes','directExpenses','returns','calculations','stockHistory','auditLog','accountingMeta','cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','periodClosures','branches','staffUsers','branchAccessMeta'
]);
const MAX_CHUNK = 700000;
const SESSION_MS = 30 * 24 * 60 * 60 * 1000;
const PBKDF2_ITERATIONS = 100000;
const AUTH_WINDOW_MS = 15 * 60 * 1000;
const AUTH_MAX_ATTEMPTS = 10;

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, OPTIONS',
    'Cache-Control': 'no-store'
  };
}
function json(data, status=200) {
  return new Response(JSON.stringify(data), { status, headers: { ...corsHeaders(), 'Content-Type':'application/json; charset=utf-8' } });
}
function bad(message, status=400){ return json({error:message},status); }
function b64(bytes){ let s=''; const a=new Uint8Array(bytes); for(let i=0;i<a.length;i+=0x8000)s+=String.fromCharCode(...a.subarray(i,i+0x8000)); return btoa(s); }
function unb64(s){ const raw=atob(s); const a=new Uint8Array(raw.length); for(let i=0;i<raw.length;i++)a[i]=raw.charCodeAt(i); return a; }
function randomId(bytes=32){ return b64(crypto.getRandomValues(new Uint8Array(bytes))).replace(/[^A-Za-z0-9_-]/g,''); }
async function digestHex(bytes){ const d=await crypto.subtle.digest('SHA-256',bytes); return [...new Uint8Array(d)].map(x=>x.toString(16).padStart(2,'0')).join(''); }
async function hashToken(token){ return digestHex(new TextEncoder().encode(token)); }
async function passwordHash(password,salt){
  const base=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),{name:'PBKDF2'},false,['deriveBits']);
  const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations:PBKDF2_ITERATIONS,hash:'SHA-256'},base,256);
  return new Uint8Array(bits);
}
async function verifyPassword(password,saltB64,hashB64){
  const actual=await passwordHash(password,unb64(saltB64));
  const expected=unb64(hashB64);
  if(actual.length!==expected.length)return false;
  let diff=0; for(let i=0;i<actual.length;i++)diff|=actual[i]^expected[i]; return diff===0;
}

async function rateLimited(request, env, endpoint) {
  const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
  const key = await digestHex(new TextEncoder().encode(endpoint + ':' + ip));
  const now = Date.now(), windowStart = Math.floor(now / AUTH_WINDOW_MS) * AUTH_WINDOW_MS;
  await env.DB.prepare('INSERT INTO auth_rate_limits(rate_key,window_start,attempts) VALUES(?,?,1) ON CONFLICT(rate_key) DO UPDATE SET window_start=excluded.window_start, attempts=CASE WHEN auth_rate_limits.window_start=excluded.window_start THEN auth_rate_limits.attempts+1 ELSE 1 END').bind(key,windowStart).run();
  const row = await env.DB.prepare('SELECT attempts FROM auth_rate_limits WHERE rate_key=? AND window_start=?').bind(key,windowStart).first();
  return Number(row?.attempts || 0) > AUTH_MAX_ATTEMPTS;
}

function emailOf(v){ return String(v||'').trim().toLowerCase(); }
function profileOf(v){ const p=String(v||'default'); return p.length<=100 && /^[A-Za-z0-9._:-]+$/.test(p) ? p : null; }
function storeOf(v){ const s=String(v||''); return ALLOWED_STORES.has(s)?s:null; }
async function body(request){ try{return await request.json();}catch(e){throw new Error('Invalid JSON body.');} }
async function auth(request,env){
  const h=request.headers.get('Authorization')||''; if(!h.startsWith('Bearer '))return null;
  const token=h.slice(7).trim(); if(!token)return null;
  const hash=await hashToken(token); const now=Date.now();
  const row=await env.DB.prepare('SELECT user_id, expires_at FROM sessions WHERE token_hash=?').bind(hash).first();
  if(!row||Number(row.expires_at)<now)return null;
  return row.user_id;
}

const WORKSPACE_ROLES = new Set(['owner','manager','accountant','cashier','inventory','viewer']);
function safeBranchIds(value){
  if(value==='*')return '*';
  if(!Array.isArray(value)||!value.length||value.length>100)return null;
  const ids=[...new Set(value.map(x=>String(x||'').trim()).filter(x=>/^[A-Za-z0-9._:-]{1,100}$/.test(x)))];
  return ids.length===value.length?JSON.stringify(ids):null;
}
async function workspaceMember(env,userId,profile){
  let row=await env.DB.prepare('SELECT user_id,workspace_owner_id,role,branch_ids,active FROM workspace_members WHERE profile_id=? AND user_id=?').bind(profile,userId).first();
  if(row)return row;
  const count=await env.DB.prepare('SELECT COUNT(*) AS n FROM workspace_members WHERE profile_id=?').bind(profile).first();
  if(Number(count?.n||0)===0){const now=Date.now();await env.DB.prepare("INSERT OR IGNORE INTO workspace_members(profile_id,user_id,workspace_owner_id,role,branch_ids,active,created_by,created_at,updated_at) VALUES(?,?,?,'owner','*',1,?,?,?)").bind(profile,userId,userId,userId,now,now).run();row=await env.DB.prepare('SELECT user_id,workspace_owner_id,role,branch_ids,active FROM workspace_members WHERE profile_id=? AND user_id=?').bind(profile,userId).first();}
  return row||null;
}
async function authorizeWorkspace(env,userId,profile,action){
  const m=await workspaceMember(env,userId,profile);
  if(!m||Number(m.active)!==1)return {ok:false,status:403,error:'You do not have active access to this workspace.'};
  const branches=String(m.branch_ids||'*');
  if(action.startsWith('snapshot_') && branches!=='*')return {ok:false,status:403,error:'Branch-scoped accounts cannot download or upload a whole-workspace snapshot. Use an owner or all-branches manager account.'};
  const allowed=action==='members' ? m.role==='owner' : action==='snapshot_write' ? ['owner','manager'].includes(m.role) : action==='snapshot_read' ? ['owner','manager','accountant'].includes(m.role) : true;
  if(!allowed)return {ok:false,status:403,error:'Your server-side workspace role does not permit this action.'};
  return {ok:true,member:m};
}
async function securityAudit(env,profile,actor,target,action,details={}){
  await env.DB.prepare('INSERT INTO workspace_security_audit(id,profile_id,actor_user_id,target_user_id,action,details,created_at) VALUES(?,?,?,?,?,?,?)').bind(randomId(16),profile,actor,target||null,action,JSON.stringify(details),Date.now()).run();
}

async function newSession(env,userId){
  const token=randomId(32), hash=await hashToken(token), now=Date.now();
  await env.DB.prepare('INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)').bind(hash,userId,now+SESSION_MS,now).run();
  return token;
}

export default {
  async fetch(request, env) {
    if(request.method==='OPTIONS')return new Response(null,{status:204,headers:corsHeaders()});
    const u=new URL(request.url);
    try {
      if(u.pathname==='/api/health'&&request.method==='GET')return json({ok:true,service:'cashtracker-sync',time:new Date().toISOString()});
      if(u.pathname==='/api/register'&&request.method==='POST'){
        if(await rateLimited(request,env,'register'))return bad('Too many attempts. Please wait and try again.',429);
        const b=await body(request), email=emailOf(b.email), password=String(b.password||'');
        if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email))return bad('Invalid email address.');
        if(password.length<8)return bad('Password must be at least 8 characters.');
        const exists=await env.DB.prepare('SELECT id FROM users WHERE email=?').bind(email).first();
        if(exists)return bad('Unable to create account with these details.',400);
        const id=randomId(16), salt=crypto.getRandomValues(new Uint8Array(16));
        const hash=await passwordHash(password,salt); const now=Date.now();
        await env.DB.prepare('INSERT INTO users(id,email,password_salt,password_hash,created_at) VALUES(?,?,?,?,?)').bind(id,email,b64(salt),b64(hash),now).run();
        const token=await newSession(env,id); return json({ok:true,token,email});
      }
      if(u.pathname==='/api/login'&&request.method==='POST'){
        if(await rateLimited(request,env,'login'))return bad('Too many attempts. Please wait and try again.',429);
        const b=await body(request), email=emailOf(b.email), password=String(b.password||'');
        const row=await env.DB.prepare('SELECT id,email,password_salt,password_hash FROM users WHERE email=?').bind(email).first();
        if(!row||!(await verifyPassword(password,row.password_salt,row.password_hash)))return bad('Email or password is incorrect.',401);
        const token=await newSession(env,row.id); return json({ok:true,token,email:row.email});
      }
      const userId=await auth(request,env);
      if(u.pathname==='/api/me'&&request.method==='GET')return userId?json({ok:true}):bad('Not signed in.',401);
      if(!userId)return bad('Not signed in.',401);
      if(u.pathname==='/api/logout'&&request.method==='POST'){
        const h=request.headers.get('Authorization')||'', token=h.slice(7).trim();
        if(token)await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await hashToken(token)).run();
        return json({ok:true});
      }
      const wa=u.pathname.match(/^\/api\/workspaces\/([^/]+)\/access$/);
      if(wa&&request.method==='GET'){
        const profile=profileOf(decodeURIComponent(wa[1]));if(!profile)return bad('Invalid profile.');
        const member=await workspaceMember(env,userId,profile);
        if(!member||Number(member.active)!==1)return bad('You do not have active access to this workspace.',403);
        return json({ok:true,profile,userId,role:member.role,branchIds:member.branch_ids==='*'?'*':JSON.parse(member.branch_ids||'[]'),active:true});
      }
      const bm=u.pathname.match(/^\/api\/branch-snapshots\/([^/]+)\/([^/]+)$/);
      if(bm){
        const profile=profileOf(decodeURIComponent(bm[1])),branchId=decodeURIComponent(bm[2]);
        if(!profile||!/^[A-Za-z0-9._:-]{1,100}$/.test(branchId))return bad('Invalid profile or branch ID.');
        const member=await workspaceMember(env,userId,profile);
        if(!member||Number(member.active)!==1)return bad('You do not have active access to this workspace.',403);
        const scope=String(member.branch_ids||'*');
        let allowedBranches=[];try{allowedBranches=scope==='*'?['*']:JSON.parse(scope);}catch(e){return bad('Workspace branch permissions are invalid.',403);}
        if(!allowedBranches.includes('*')&&!allowedBranches.includes(branchId))return bad('Your account is not authorized for this branch.',403);
        const write=request.method==='PUT';
        if(write&&!['owner','manager'].includes(member.role))return bad('Only Owners and Managers can publish branch snapshots.',403);
        if(!write&&!['owner','manager','accountant'].includes(member.role))return bad('Your role cannot download branch financial data.',403);
        const workspaceUserId=member.workspace_owner_id||userId;
        if(request.method==='GET'){
          const head=await env.DB.prepare('SELECT h.revision,h.snapshot_id,h.updated_at,s.chunk_count,s.device_id,s.app_version FROM cloud_branch_snapshot_heads h JOIN cloud_branch_snapshots s ON s.snapshot_id=h.snapshot_id WHERE h.user_id=? AND h.profile_id=? AND h.branch_id=?').bind(workspaceUserId,profile,branchId).first();
          if(!head)return json({exists:false,revision:0,branchId});
          const rows=await env.DB.prepare('SELECT chunk_index,chunk_data FROM cloud_branch_snapshot_chunks WHERE snapshot_id=? ORDER BY chunk_index').bind(head.snapshot_id).all();
          const chunks=(rows.results||[]).map(r=>r.chunk_data);
          if(chunks.length!==Number(head.chunk_count))return bad('Branch snapshot is incomplete. Do not restore it.',503);
          return json({exists:true,revision:Number(head.revision),updatedAt:Number(head.updated_at),branchId,chunks,chunkCount:chunks.length,deviceId:head.device_id||'',appVersion:head.app_version||''});
        }
        if(request.method==='PUT'){
          const b=await body(request),chunks=Array.isArray(b.chunks)?b.chunks:[],expected=Number(b.expectedRevision);
          if(!Number.isSafeInteger(expected)||expected<0)return bad('A valid expected branch revision is required.');
          if(!chunks.length||chunks.length>80)return bad('Branch snapshot must contain between 1 and 80 chunks.');
          let total=0;for(const c of chunks){if(typeof c!=='string'||!c.length||c.length>250000)return bad('Invalid branch snapshot chunk.');total+=c.length;}
          if(total>20000000)return bad('Encrypted branch snapshot exceeds the 20 MB safety limit.');
          const now=Date.now(),revision=expected+1,snapshotId=randomId(18);
          const statements=[env.DB.prepare('INSERT INTO cloud_branch_snapshots(snapshot_id,user_id,profile_id,branch_id,revision,device_id,app_version,created_at,chunk_count) VALUES(?,?,?,?,?,?,?,?,?)').bind(snapshotId,workspaceUserId,profile,branchId,revision,String(b.deviceId||''),String(b.appVersion||''),now,chunks.length)];
          chunks.forEach((chunk,i)=>statements.push(env.DB.prepare('INSERT INTO cloud_branch_snapshot_chunks(snapshot_id,chunk_index,chunk_data) VALUES(?,?,?)').bind(snapshotId,i,chunk)));
          statements.push(env.DB.prepare('INSERT INTO cloud_branch_snapshot_heads(user_id,profile_id,branch_id,revision,snapshot_id,updated_at) VALUES(?,?,?,?,?,?) ON CONFLICT(user_id,profile_id,branch_id) DO UPDATE SET revision=excluded.revision,snapshot_id=excluded.snapshot_id,updated_at=excluded.updated_at WHERE cloud_branch_snapshot_heads.revision=?').bind(workspaceUserId,profile,branchId,revision,snapshotId,now,expected));
          const results=await env.DB.batch(statements),changed=Number(results[results.length-1]?.meta?.changes||0)>0;
          if(!changed){await env.DB.batch([env.DB.prepare('DELETE FROM cloud_branch_snapshot_chunks WHERE snapshot_id=?').bind(snapshotId),env.DB.prepare('DELETE FROM cloud_branch_snapshots WHERE snapshot_id=?').bind(snapshotId)]);const current=await env.DB.prepare('SELECT revision FROM cloud_branch_snapshot_heads WHERE user_id=? AND profile_id=? AND branch_id=?').bind(workspaceUserId,profile,branchId).first();return json({error:'This branch changed on another device. Download and review the newer branch snapshot first.',conflict:true,currentRevision:Number(current?.revision||0)},409);}
          const old=await env.DB.prepare('SELECT snapshot_id FROM cloud_branch_snapshots WHERE user_id=? AND profile_id=? AND branch_id=? ORDER BY revision DESC LIMIT -1 OFFSET 5').bind(workspaceUserId,profile,branchId).all();
          for(const row of(old.results||[]))await env.DB.batch([env.DB.prepare('DELETE FROM cloud_branch_snapshot_chunks WHERE snapshot_id=?').bind(row.snapshot_id),env.DB.prepare('DELETE FROM cloud_branch_snapshots WHERE snapshot_id=?').bind(row.snapshot_id)]);
          await securityAudit(env,profile,userId,null,'branch_snapshot_published',{branchId,revision,chunkCount:chunks.length});
          return json({ok:true,branchId,revision,snapshotId,updatedAt:now,chunkCount:chunks.length});
        }
        return bad('Method not allowed.',405);
      }
      const wm=u.pathname.match(/^\/api\/workspaces\/([^/]+)\/members(?:\/([^/]+))?$/);
      if(wm){
        const profile=profileOf(decodeURIComponent(wm[1]));if(!profile)return bad('Invalid profile.');
        const permission=await authorizeWorkspace(env,userId,profile,'members');if(!permission.ok)return bad(permission.error,permission.status);
        if(request.method==='GET'&&!wm[2]){
          const rows=await env.DB.prepare('SELECT m.user_id,u.email,m.role,m.branch_ids,m.active,m.created_at,m.updated_at FROM workspace_members m JOIN users u ON u.id=m.user_id WHERE m.profile_id=? ORDER BY m.created_at').bind(profile).all();
          return json({ok:true,profile,members:(rows.results||[]).map(r=>({...r,active:Number(r.active)===1,branchIds:r.branch_ids==='*'?'*':JSON.parse(r.branch_ids||'[]')}))});
        }
        if(request.method==='POST'&&!wm[2]){
          const b=await body(request),email=emailOf(b.email),role=String(b.role||'viewer');
          if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email))return bad('A valid existing CashTracker Cloud account email is required.');
          if(!WORKSPACE_ROLES.has(role)||role==='owner')return bad('Choose manager, accountant, cashier, inventory or viewer.');
          const target=await env.DB.prepare('SELECT id FROM users WHERE email=?').bind(email).first();if(!target)return bad('That email must create a CashTracker Cloud account before being added.');
          const existingTarget=await env.DB.prepare('SELECT role FROM workspace_members WHERE profile_id=? AND user_id=?').bind(profile,target.id).first();if(existingTarget?.role==='owner')return bad('The workspace Owner cannot be demoted or replaced.');
          const branchIds=safeBranchIds(b.branchIds===undefined?'*':b.branchIds);if(!branchIds)return bad('Branch scope must be * or a non-empty list of valid branch IDs.');
          const now=Date.now();await env.DB.prepare('INSERT INTO workspace_members(profile_id,user_id,workspace_owner_id,role,branch_ids,active,created_by,created_at,updated_at) VALUES(?,?,?,?,?,1,?,?,?) ON CONFLICT(profile_id,user_id) DO UPDATE SET role=excluded.role,branch_ids=excluded.branch_ids,active=1,updated_at=excluded.updated_at').bind(profile,target.id,permission.member.workspace_owner_id||userId,role,branchIds,userId,now,now).run();
          await securityAudit(env,profile,userId,target.id,'member_added_or_updated',{email,role,branchIds:branchIds==='*'?'*':JSON.parse(branchIds)});
          return json({ok:true});
        }
        if(request.method==='PUT'&&wm[2]){
          const targetId=decodeURIComponent(wm[2]),b=await body(request),role=String(b.role||''),active=b.active===undefined?true:!!b.active;
          if(role&&!WORKSPACE_ROLES.has(role))return bad('Unknown role.');
          const existing=await env.DB.prepare('SELECT role FROM workspace_members WHERE profile_id=? AND user_id=?').bind(profile,targetId).first();if(!existing)return bad('Workspace member not found.',404);
          if(existing.role==='owner')return bad('Owner membership cannot be changed or disabled through this endpoint.');
          const branchIds=b.branchIds===undefined?null:safeBranchIds(b.branchIds);if(b.branchIds!==undefined&&!branchIds)return bad('Invalid branch scope.');
          await env.DB.prepare('UPDATE workspace_members SET role=COALESCE(?,role),branch_ids=COALESCE(?,branch_ids),active=?,updated_at=? WHERE profile_id=? AND user_id=?').bind(role||null,branchIds,active?1:0,Date.now(),profile,targetId).run();
          await securityAudit(env,profile,userId,targetId,'member_access_changed',{role:role||existing.role,active,branchIds:branchIds||'unchanged'});
          return json({ok:true});
        }
        return bad('Method not allowed.',405);
      }
      const auditMatch=u.pathname.match(/^\/api\/workspaces\/([^/]+)\/security-audit$/);
      if(auditMatch&&request.method==='GET'){
        const profile=profileOf(decodeURIComponent(auditMatch[1]));if(!profile)return bad('Invalid profile.');
        const permission=await authorizeWorkspace(env,userId,profile,'members');if(!permission.ok)return bad(permission.error,permission.status);
        const rows=await env.DB.prepare('SELECT id,actor_user_id,target_user_id,action,details,created_at FROM workspace_security_audit WHERE profile_id=? ORDER BY created_at DESC LIMIT 100').bind(profile).all();
        return json({ok:true,events:rows.results||[]});
      }
      // Versioned whole-profile snapshots. The head is advanced conditionally so
      // concurrent devices cannot silently overwrite a newer cloud revision.
      const sm=u.pathname.match(/^\/api\/snapshots\/([^/]+)$/);
      if(sm){
        const profile=profileOf(decodeURIComponent(sm[1]));
        if(!profile)return bad('Invalid profile.');
        const access=await authorizeWorkspace(env,userId,profile,request.method==='PUT'?'snapshot_write':'snapshot_read');if(!access.ok)return bad(access.error,access.status);const workspaceUserId=access.member.workspace_owner_id||userId;
        if(request.method==='GET'){
          const head=await env.DB.prepare('SELECT h.revision,h.snapshot_id,h.updated_at,s.chunk_count,s.device_id,s.app_version FROM cloud_snapshot_heads h JOIN cloud_snapshots s ON s.snapshot_id=h.snapshot_id WHERE h.user_id=? AND h.profile_id=?').bind(workspaceUserId,profile).first();
          if(!head){const legacy=await env.DB.prepare('SELECT COUNT(*) AS n FROM stores WHERE user_id=? AND profile_id=?').bind(workspaceUserId,profile).first();return json({exists:false,revision:0,legacyAvailable:Number(legacy?.n||0)>0});}
          const rows=await env.DB.prepare('SELECT chunk_index,chunk_data FROM cloud_snapshot_chunks WHERE snapshot_id=? ORDER BY chunk_index').bind(head.snapshot_id).all();
          const chunks=(rows.results||[]).map(r=>r.chunk_data);
          if(chunks.length!==Number(head.chunk_count))return bad('Cloud snapshot is incomplete. Do not restore it.',503);
          return json({exists:true,revision:Number(head.revision),updatedAt:Number(head.updated_at),chunks,chunkCount:chunks.length,deviceId:head.device_id||'',appVersion:head.app_version||''});
        }
        if(request.method==='PUT'){
          const b=await body(request), chunks=Array.isArray(b.chunks)?b.chunks:[];
          const expected=Number(b.expectedRevision);
          if(!Number.isSafeInteger(expected)||expected<0)return bad('A valid expected cloud revision is required.');
          if(!chunks.length||chunks.length>80)return bad('Snapshot must contain between 1 and 80 chunks.');
          let total=0;
          for(const c of chunks){if(typeof c!=='string'||!c.length||c.length>250000)return bad('Invalid snapshot chunk.');total+=c.length;}
          if(total>20000000)return bad('Encrypted snapshot exceeds the 20 MB safety limit. Export a local backup and reduce stored attachments.');
          const now=Date.now(), revision=expected+1, snapshotId=randomId(18);
          const statements=[env.DB.prepare('INSERT INTO cloud_snapshots(snapshot_id,user_id,profile_id,revision,device_id,app_version,created_at,chunk_count) VALUES(?,?,?,?,?,?,?,?)').bind(snapshotId,workspaceUserId,profile,revision,String(b.deviceId||''),String(b.appVersion||''),now,chunks.length)];
          chunks.forEach((chunk,i)=>statements.push(env.DB.prepare('INSERT INTO cloud_snapshot_chunks(snapshot_id,chunk_index,chunk_data) VALUES(?,?,?)').bind(snapshotId,i,chunk)));
          statements.push(env.DB.prepare('INSERT INTO cloud_snapshot_heads(user_id,profile_id,revision,snapshot_id,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(user_id,profile_id) DO UPDATE SET revision=excluded.revision,snapshot_id=excluded.snapshot_id,updated_at=excluded.updated_at WHERE cloud_snapshot_heads.revision=?').bind(workspaceUserId,profile,revision,snapshotId,now,expected));
          const results=await env.DB.batch(statements);
          const headResult=results[results.length-1];
          const changed=Number(headResult?.meta?.changes||0)>0;
          if(!changed){
            await env.DB.batch([
              env.DB.prepare('DELETE FROM cloud_snapshot_chunks WHERE snapshot_id=?').bind(snapshotId),
              env.DB.prepare('DELETE FROM cloud_snapshots WHERE snapshot_id=?').bind(snapshotId)
            ]);
            const current=await env.DB.prepare('SELECT revision FROM cloud_snapshot_heads WHERE user_id=? AND profile_id=?').bind(workspaceUserId,profile).first();
            return json({error:'Cloud data changed on another device. Download or explicitly replace the newer cloud copy.',conflict:true,currentRevision:Number(current?.revision||0)},409);
          }
          // Retain the latest five complete snapshots for recovery; remove older encrypted versions.
          const old=await env.DB.prepare('SELECT snapshot_id FROM cloud_snapshots WHERE user_id=? AND profile_id=? ORDER BY revision DESC LIMIT -1 OFFSET 5').bind(workspaceUserId,profile).all();
          for(const row of (old.results||[])){
            await env.DB.batch([
              env.DB.prepare('DELETE FROM cloud_snapshot_chunks WHERE snapshot_id=?').bind(row.snapshot_id),
              env.DB.prepare('DELETE FROM cloud_snapshots WHERE snapshot_id=?').bind(row.snapshot_id)
            ]);
          }
          return json({ok:true,revision,snapshotId,updatedAt:now,chunkCount:chunks.length});
        }
      }
      const m=u.pathname.match(/^\/api\/stores\/([^/]+)\/([^/]+)$/);
      if(m){
        const profile=profileOf(decodeURIComponent(m[1])), store=storeOf(decodeURIComponent(m[2]));
        if(!profile||!store)return bad('Invalid profile or store.');
        const access=await authorizeWorkspace(env,userId,profile,request.method==='PUT'?'snapshot_write':'snapshot_read');if(!access.ok)return bad(access.error,access.status);const workspaceUserId=access.member.workspace_owner_id||userId;
        if(request.method==='GET'){
          const rows=await env.DB.prepare('SELECT chunk_index,chunk_data,chunk_count,updated_at FROM stores WHERE user_id=? AND profile_id=? AND store_name=? ORDER BY chunk_index').bind(workspaceUserId,profile,store).all();
          const result=rows.results||[]; if(!result.length)return json({exists:false});
          return json({exists:true,chunks:result.map(r=>r.chunk_data),chunkCount:Number(result[0].chunk_count||result.length),updatedAt:Number(result[0].updated_at||0)});
        }
        if(request.method==='PUT'){
          const b=await body(request), chunks=Array.isArray(b.chunks)?b.chunks:[];
          if(!chunks.length)return bad('No encrypted data supplied.');
          if(chunks.length>100)return bad('Encrypted store is too large. Export a local backup or split the store.');
          for(const c of chunks){if(typeof c!=='string'||c.length>MAX_CHUNK)return bad('Invalid encrypted chunk.');}
          const now=Date.now();
          const statements=[env.DB.prepare('DELETE FROM stores WHERE user_id=? AND profile_id=? AND store_name=?').bind(workspaceUserId,profile,store)];
          chunks.forEach((chunk,i)=>statements.push(env.DB.prepare('INSERT INTO stores(user_id,profile_id,store_name,chunk_index,chunk_data,chunk_count,updated_at,device_id,app_version) VALUES(?,?,?,?,?,?,?,?,?)').bind(workspaceUserId,profile,store,i,chunk,chunks.length,now,String(b.deviceId||''),String(b.appVersion||''))));
          await env.DB.batch(statements);
          return json({ok:true,store,chunkCount:chunks.length,updatedAt:now});
        }
      }
      return bad('Not found.',404);
    } catch(e){ console.error(e); return json({error:'Server error.'},500); }
  }
};
