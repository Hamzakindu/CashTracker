# CashTracker Cloudflare Sync

This Worker is a **separate backend from the existing Telegram bot Worker**. Do not replace the Telegram Worker with this one.

## 1. Create D1

```bash
npx wrangler d1 create cashtracker
```

Copy the returned `database_id` into `wrangler.toml`.

## 2. Apply schema

```bash
npx wrangler d1 execute cashtracker --remote --file=./schema.sql
```

## 3. Versioned whole-profile synchronization

The current app uses `/api/snapshots/:profile` rather than uploading each store independently. The Worker stores encrypted chunks under a snapshot ID and advances a profile head only when the caller supplies the expected revision. The head is the only visible version, so readers do not combine stores from different uploads. A stale device receives HTTP 409 and must restore the latest snapshot or explicitly choose to replace it.

Apply the complete schema before deploying the Worker. Existing per-store endpoints remain for backward compatibility, but the current app no longer uses them for normal synchronization. Whole-profile snapshots are limited to 20 MB / 80 chunks; large attachments should remain in local backup or be reduced before cloud sync.

## 4. Deploy

From `cloudflare/worker`:

```bash
npx wrangler deploy
```

The resulting `https://...workers.dev` URL is entered in CashTracker → Cloud.

## 5. Security model

- HTTPS is required by the app.
- Account passwords are verified using PBKDF2-SHA256 on the Worker.
- Sessions are random bearer tokens stored only for the active app session.
- CashTracker business data is encrypted in the app with AES-GCM before upload.
- Cloudflare D1 stores only encrypted store payloads, not readable business records.
- The Cloudflare Worker never needs the CashTracker encryption passphrase after login.

## 6. Telegram compatibility

The existing `BotSync` Telegram integration uses its own Worker URL and `X-Push-Key`. **Keep that Worker and its configuration unchanged.** This sync Worker is only for CashTracker multi-device cloud synchronization.
