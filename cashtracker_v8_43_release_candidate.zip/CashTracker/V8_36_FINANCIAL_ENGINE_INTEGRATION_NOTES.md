# CashTracker V8.36 — Financial Engine Integration and Transaction Consistency

Release: 5.10.80 / Android versionCode 80

## Changes
- Expanded the unified read-only Financial Integrity Audit to include active cash/bank movements, account references, movement amounts/types, duplicate movement IDs, and optional cached account-balance checks.
- Added duplicate active source transaction ID and invalid/missing/negative transaction-total checks for sales, purchases, expenses and returns.
- Integrated the historical weighted-average inventory engine into the audit so product quantity mismatches and estimated/incomplete historical valuation are surfaced instead of silently accepted.
- Integrated the derived double-entry journal audit into the same result when the accounting module is available. Unbalanced journal groups, invalid dates and unknown account codes are reported.
- Finance Control now supplies products, stock history and expenses to the expanded audit and describes the broader audit scope.
- Preserved V8.35 branch inventory, stock transfers, calculator share-header settings, backup and cloud modules.

## Safety boundaries
- The audit is intentionally read-only. It does not rewrite cached balances, recreate missing payments, change inventory quantities, post automatic correcting entries, or rewrite transaction history.
- The current double-entry journal remains a derived report, not a separately persisted posting ledger. Explicit reversal journals and automatic correction workflows are not introduced in this release; they require verified source edit/void lifecycle semantics and must not be guessed from legacy records.
- A clean result means only that the included checks found no discrepancy. It is not an accounting certification and does not replace bank statement review.
- Cash account cached-balance comparison runs only when a cached `balance` or `currentBalance` field exists; otherwise the audit does not invent one.

## Verification
- Automated tests: 243 passed, 0 failed.
- TypeScript typecheck and Android TypeScript asset build: pending release run.
- JavaScript syntax, Android manifest XML, app metadata JSON and ZIP integrity: pending release run.
- Android Gradle APK compilation, physical-device testing, Cloudflare deployment and multi-device testing: not performed.
