# CashTracker V8.25 — Payment and Advance Reconciliation

Version: 5.10.69 (Android versionCode 69)

## Changes
- Extended the read-only financial audit to reconcile customer and supplier advance balances when an opening-advance baseline is available.
- Customer advance checks account for opening advance, customer payment advances, excess sale payments, customer return credit and recorded advance applications.
- Supplier advance checks account for opening advance, supplier payment advances, excess purchase payments and recorded advance applications.
- Payment audit now identifies missing/inactive cash or bank accounts, missing cash/bank movements, orphan movements and movement references to missing/inactive accounts.
- Missing movement issues include the party, account, amount, direction, date, method and a suggested review action.
- Finance Control now includes cash-account data in the audit and displays suggested review actions.
- All findings are advisory and read-only. No repair, balance rewrite, or historical transaction mutation is performed.

## Important limitations
- Advance reconciliation is skipped for parties without an `openingAdvance` baseline; legacy data is not guessed.
- Edited or legacy transactions may produce differences requiring manual review. Do not change balances solely to make the audit clear.
- Suggested review actions are not automatic repairs. Confirm against receipts, bank statements or wallet statements before making any correction.
- Automated checks do not prove correctness on a physical Android device or certify accounting compliance.
