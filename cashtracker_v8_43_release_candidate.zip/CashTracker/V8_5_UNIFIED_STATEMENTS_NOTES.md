# CashTracker V8.5 — Unified Reports and Statements

Version: 5.10.49 (versionCode 49)

## Changes

- Balance sheet and receivable/payable aging statements now request party balances from `BusinessEngine` when it is available. Cached legacy balances remain the explicit fallback when source history is incomplete.
- Statement screens show data-quality warnings from the central engine rather than silently treating incomplete history as complete.
- Inventory statements explicitly identify current product buy-price valuation as an estimate, not historical weighted-average inventory valuation or realized profit.
- Cash-flow filtering uses the shared active-record rules, including cancelled/deleted records and date-only comparisons.
- Sales reports now use the same central sale-cost inference as the BusinessEngine for complete sales; product-filtered reports calculate only selected line costs. Stale stored sale profit no longer overrides available item-level cost.
- Legacy stored sale profit can be used as a documented fallback to infer cost only when a sale has no complete item-level cost.

## Safety boundaries

- This is read-only reporting integration; it does not rewrite balances or transactions.
- Balance sheet equity remains a balancing estimate, not a verified capital/retained-earnings ledger.
- Inventory value remains based on current product buy prices. Historical weighted-average valuation is still outstanding.
- Receivable/payable aging allocates the projected open balance to outstanding documents using the report's stated settlement assumption; it is not a payment-allocation subledger.
- Android Gradle build and physical-device verification are still required before production use.

## Tests added

- Derived balances override stale cached customer/supplier balances only when the engine has adequate source history.
- Aging reports use projected balances.
- Inventory valuation limitations are visible.
- Sales report cost rules match the central engine.
- Legacy sale-profit fallback and line-profit cost inference are covered.
