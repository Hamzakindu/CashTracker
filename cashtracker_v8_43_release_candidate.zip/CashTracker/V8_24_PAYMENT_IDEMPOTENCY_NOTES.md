# CashTracker V8.24 — Payment Idempotency and Reconciliation

Version: 5.10.68 (Android versionCode 68)

## Changes
- Payment form creates an idempotency key for each newly opened payment attempt.
- A retry in the same open form checks the payment ledger before applying any balance changes.
- If the ledger and exactly one linked cash/bank movement already exist, the retry is treated as already completed rather than posting again.
- If the ledger exists but its movement is missing or duplicated, the UI blocks another post and directs the operator to audit the payment.
- CashBanks.link now returns an existing single movement for a paymentId instead of creating another; it throws if multiple active movements already exist.
- FinancialAudit reports repeated idempotency keys without modifying source data.
- Existing legacy payment records without idempotency keys remain supported.

## Verification
Automated tests, TypeScript checks, Android asset build, JS syntax, manifest/metadata parsing, and ZIP integrity are run for this release. Android Gradle compilation and physical-device payment retry testing are not claimed.

## Limitation
The idempotency key is scoped to one open payment form attempt. Opening a new payment form creates a new attempt key; operators must still avoid deliberately entering the same real-world payment twice as separate new attempts. This is not a bank-side unique reference or server-enforced global idempotency guarantee.
