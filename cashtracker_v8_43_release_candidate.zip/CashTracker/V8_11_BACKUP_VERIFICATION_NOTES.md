# CashTracker V8.11 — Backup Verification

Version: 5.10.55 (versionCode 55)

## Changes
- Backup JSON exports include an optional SHA-256 integrity seal over the full payload (excluding the seal itself).
- Restore verifies the seal before validation, confirmation, undo snapshot creation, or data writes. A damaged or modified sealed backup is rejected without changing app data.
- Older unsealed JSON backups remain supported for compatibility.
- Android MediaStore Downloads writes are now read back after finalization. The native bridge checks the saved byte count and confirms the row is no longer pending before returning success.
- Android export success therefore requires both successful write/finalization and a matching read-back size; timeout or failure remains an error, not success.
- Version metadata aligned to 5.10.55 / code 55. Previous package/Gradle metadata had inconsistent version values; this release corrects the defaults and gradle.properties.

## Verification limits
Automated tests can inspect the bridge and validate app logic, but cannot prove a real phone's Downloads UI displays the file. Physical-device testing remains required, especially Android scoped-storage behavior and restoring a deliberately damaged backup.
