# CashTracker V8.19 — Encrypted backup and restore

Version: 5.10.63 (versionCode 63)

## Changes
- Portable file exports are encrypted with AES-256-GCM using a fresh random salt and IV for every backup.
- Passphrase key derivation uses PBKDF2-SHA256 with 210,000 iterations. The passphrase is not embedded in the backup.
- The integrity seal is calculated before encryption; AES-GCM authentication protects the complete sealed payload during transport/storage.
- Restore recognizes encrypted V2 envelopes, asks for the passphrase, decrypts, and then continues through the existing integrity validation, preview, profile/staleness warnings, pre-restore snapshot, and rollback-protected restore flow.
- Legacy plaintext JSON remains importable only after a clear warning and explicit confirmation.
- Encrypted exports still use the existing native Android MediaStore save callback. Android success is reported only after the native layer verifies the saved file size and finalized MediaStore row. Browser-only download remains explicitly unconfirmed.
- Encryption envelope validation rejects altered KDF metadata rather than accepting a reduced iteration count.

## Important operating guidance
- Keep the passphrase separate from the backup file. Losing it means the encrypted backup cannot be decrypted.
- Existing local safety copies in app storage are not changed by this update and are not automatically converted to portable encrypted files.
- The Android MediaStore path is covered by source review and static checks only; this update has not been installed and exercised on a physical phone.

## Validation
- Automated crypto tests cover round-trip, plaintext opt-in, tampered ciphertext, and weakened KDF metadata rejection.
- Restore-flow tests verify decryption precedes preview/restore and that plaintext legacy files require confirmation.
