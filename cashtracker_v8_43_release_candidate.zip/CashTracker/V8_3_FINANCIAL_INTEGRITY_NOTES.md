# CashTracker V8.3 — Financial Integrity Pass

Version: 5.10.47

## Changes

1. Added a read-only Financial Integrity Audit in Finance Control.
2. Compares cached customer balances with opening balances, unpaid sale balances, standalone settlements and recorded customer-credit return offsets.
3. Compares cached supplier balances with opening balances, unpaid purchase balances and standalone supplier settlements.
4. Checks posted cash-bearing payment ledger records against linked cash/bank movements by payment ID; validates account, amount and direction; reports missing or duplicate movements.
5. Supports legacy source-linked movement matching when an old movement has no `paymentId`.
6. Excludes void/cancelled records and excludes non-cash `advance_applied` ledger rows from payment-to-cash checks.
7. The audit is strictly read-only. It does not change customer balances, supplier balances, payments, cash accounts or source transactions.
8. Fixed the weighted-average cost wrapper to await the asynchronous durable purchase submission before reading the new purchase and recalculating product buy cost.

## Important interpretation notes

- An audit warning is a discrepancy to investigate, not permission to overwrite a balance.
- Old manual balance adjustments, missing opening-balance migration data, legacy imports, or incomplete return metadata can produce warnings.
- The current audit does not yet derive every balance from a canonical immutable ledger. It uses existing `debitRemaining`, `debit`, opening-balance and settlement fields that the current app already maintains.
- Supplier returns, full stock valuation reconciliation, journal completeness, branch consolidation and cash-count reconciliation are not yet included in this audit.

## Verification in this environment

- Node automated tests: 63/63 passed.
- TypeScript strict typecheck: passed.
- TypeScript-to-Android-assets compilation: passed.
- Syntax checks for changed JavaScript modules: passed.
- Android Gradle build and physical-device testing: not run.
