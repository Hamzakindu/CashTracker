# CashTracker V8 — V7 Baseline Audit

Audit date: 2026-11-09
Baseline: CashTracker V7 payment-reports ZIP (package version 5.10.43)

## Scope and evidence

Reviewed the V7 project structure and the report/payment/sales/purchase source paths. Ran the repository's automated Node tests and TypeScript typecheck.

## Verification results

- `npm test`: PASS — 19 tests, 0 failures.
- `npm run typecheck`: PASS.
- ZIP integrity: PASS.
- Android Gradle build: NOT RUN in this audit environment.
- Real-device UI, offline/online sync, two-device conflict, backup/restore against real user data: NOT VERIFIED.

Passing automated tests are useful regression evidence, but do not prove the entire Android application is release-ready.

## Confirmed implementation observations

1. Sales and purchases create payment-ledger entries with `sourceType: 'sale'` and `sourceType: 'purchase'` when paid amounts are recorded.
2. Customer/supplier settlement and advance payments created through the Payments module use `sourceType: 'payment'`.
3. The current Payments and Received Payments report filters only `sourceType === 'payment'`. Therefore the two reports intentionally omit cash movements made as part of sales and purchases. This is not a complete all-in/all-out cash report.
4. Expenses and returns create cash-account movements through `CashBanks.link`; these must be included in a complete cash movement report without double-counting the linked ledger entries.
5. The current report UI should distinguish operational activity (sales/purchases/expenses) from cash movements (receipts/payments/transfers). These are different measures and must not be added together as if they were independent income/expense totals.
6. Payment entry updates customer/supplier balances and links a cash-account movement. Any future refactor must preserve this behavior and maintain a single source of truth for each movement.

## P0 risks to resolve before financial expansion

- Establish a canonical transaction/movement ID shared by source transaction, payment ledger, account movement and journal entry.
- Ensure posting is atomic: either all required records are committed, or none are.
- Make posted transactions immutable; corrections should use linked reversals, not silent deletion or destructive edits.
- Define how legacy transactions without linked movement IDs are migrated and reconciled.
- Verify account balances from the movement ledger rather than trusting separately edited cached balances.
- Add recovery and backup-restore tests using representative V7 data, including interrupted writes and duplicate sync delivery.

## Required acceptance tests

1. Fully paid sale: sale report shows sale value; cash-in report shows only the amount actually collected; receivable is zero.
2. Partially paid sale: cash-in shows the paid portion; receivable shows the unpaid portion.
3. Customer debt settlement: cash-in increases and receivable decreases by the same amount.
4. Fully/partially paid purchase: cash-out shows amount paid; payable reflects unpaid amount.
5. Supplier settlement: cash-out increases and payable decreases by the same amount.
6. Expense: cash-out and expense report both show the expense, but consolidated cash movement counts it once.
7. Transfer: source account decreases and destination account increases; it is not business income or expense.
8. Return/refund: stock and cash effects are linked and reported once.
9. Reversal: original record remains visible; reversal offsets its accounting and account movements exactly once.
10. Duplicate sync delivery: same transaction ID is idempotent and cannot post twice.
11. Backup/restore: all source, payment, account-movement and journal links remain intact.
12. Offline write followed by reconnect: no missing or duplicate posting.

## Release gate

Do not label V8 financially verified until all P0 acceptance tests pass, the Android build succeeds, and the critical workflows are exercised on at least one physical Android device. Two-device synchronization should be tested before enabling multi-device production use.


## V8.1 follow-up correction log (5.10.44)

The reliability patch corrects the reproduced Kotlin SMS amount-selection and keyword-boundary defects, JavaScript/TypeScript SMS parity, decimal half-cent rounding, business-engine missing-cost and return calculations, cancelled-record filtering, People Money EntryMemory persistence, backup plain-JSON downgrade acceptance, Cloudflare restore staging/rollback, Worker PBKDF2 configuration and auth throttling. It also adds a TypeScript-to-Android-assets compilation step. See `FINAL_STATUS.md` for verification results and remaining release blockers.


## V8.6 update — historical inventory costing
A read-only perpetual weighted-average projection now reconstructs purchase receipts, sales issues, returns and independent stock adjustments. Legacy opening-cost gaps and stock quantity mismatches are surfaced. New stock movements carry source IDs and unit costs. No historical transaction is rewritten. Physical-device validation remains outstanding.
