export type SmsDirection = 'in' | 'out';
export interface ParsedSms { amount:number; dir:SmsDirection; who:string; reference:string; bankName:string; bal:number|null; }
const banks:[RegExp,string][]=[[/\bcommercial bank of ethiopia\b/i,'CBE'],[/\bcbe\b/i,'CBE'],[/\bawash\b/i,'Awash'],[/\bdashen\b/i,'Dashen'],[/\bbank of abyssinia\b|\bboa\b/i,'BOA'],[/\btelebirr\b/i,'Telebirr'],[/\bsafaricom\b/i,'Safaricom'],[/\bmpesa\b/i,'M-Pesa']];
const amountLabel=/\b(?:amount|amt|transaction\s+amount|debit(?:ed)?|credit(?:ed)?|spent|paid|received|withdrawn|sent|transferred)\b\s*(?:is|:|=)?\s*(?:etb|birr|br)?\s*([0-9][0-9,]*(?:\.\d+)?)/i;
const balance=/\b(?:current\s+balance|available\s+balance|avl\.?\s*bal(?:ance)?|balance|bal)\s*(?:is|:)?\s*(?:etb|birr|br)?\s*([0-9][0-9,]*(?:\.\d+)?)/i;
const currency=/(?:\b(?:etb|birr|br|rs\.?|inr|usd|egp|kes|ngn|sar|aed|eur|gbp)\b|[$€£₦₹])\s*([0-9][0-9,]*(?:\.\d+)?)/i;
const currencyAfter=/([0-9][0-9,]*(?:\.\d+)?)\s*(?:\b(?:etb|birr|br|rs|inr|usd|egp|kes|ngn|sar|aed|eur|gbp)\b|[$€£₦₹])/i;
const debit=/\b(?:debited|debit|spent|purchase|withdrawn|withdrawal|paid|payment|sent|charged|deducted|transferred|transfer|bought|outgoing)\b/i;
const credit=/\b(?:credited|credit|received|deposit|salary|refund|cashback|incoming)\b/i;
const action=/\b(?:debited|debit|spent|purchase|withdrawn|withdrawal|paid|payment|sent|charged|deducted|transferred|transfer|bought|outgoing|credited|credit|received|deposit|salary|refund|cashback|incoming)\b/i;
export function detectBank(body:string){return banks.find(([re])=>re.test(body))?.[1]||''}
export function parseSms(body:string):ParsedSms|null{
 const t=body.trim();if(!t)return null;const bm=t.match(balance),b=bm?t.replace(bm[0],' '):t;
 const labelled=b.match(amountLabel),cm=b.match(currency)||b.match(currencyAfter),m=labelled||cm;if(!m||!action.test(b))return null;
 const amount=Number(m[1].replace(/,/g,''));if(!(amount>0)||!Number.isFinite(amount))return null;
 const sentToReceivedBy=/\bsent\b[\s\S]{0,80}\breceived\s+by\b/i.test(b),receivedBySent=/\breceived\s+by\b[\s\S]{0,80}\bsent\b/i.test(b);
 const d=b.search(debit),c=b.search(credit);const dir:SmsDirection=sentToReceivedBy?'out':receivedBySent?'in':c>=0&&(d<0||c<d)?'in':'out';
 const ref=t.match(/\b(?:ref(?:erence)?|txn(?:\.?|\s*id)?|transaction\s*id|trx)\s*[:#-]?\s*([A-Za-z0-9-]{4,40})/i);
 const who=b.match(/(?:\bat\b|\bto\b|\bfrom\b|@|towards)\s+([A-Za-z0-9&.'\- ]{2,40}?)(?=\s+(?:on|using|via|ref|bal|a\/c|acct|card|dated|with|your|and|txn|transaction)\b|[.,;(]|$)/i);
 return {amount,dir,who:who?.[1]?.trim()||'',reference:ref?.[1]||'',bankName:detectBank(t),bal:bm?Number(bm[1].replace(/,/g,'')):null};
}
