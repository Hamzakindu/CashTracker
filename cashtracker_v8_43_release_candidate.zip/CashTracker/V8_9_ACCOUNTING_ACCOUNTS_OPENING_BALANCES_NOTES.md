# CashTracker V8.9 — Account-level cash/bank ledger and opening balances

Version: 5.10.53 (versionCode 53)

## Implemented

- Cash/bank opening balances now produce a dated, balanced opening journal entry: debit the selected cash/bank account and credit opening equity.
- Customer opening receivables and customer advances are journalized against opening equity and the customer-advance liability account.
- Supplier opening payables and supplier advances are journalized against opening equity and the supplier-advance asset account.
- Opening `moneyTransactions` rows remain audit snapshots and are not added again to the opening account balance.
- General Ledger can display an individual cash/bank account, not only the combined Cash and bank control account.
- Sale and purchase payments use their linked payment-ledger account IDs where available. Unlinked historical amounts remain visible in the combined control account and are explicitly labelled as unlinked.
- Direct expense payments retain their selected cash/bank account in the derived ledger.
- All changes are read-only derivations; source business transactions are not rewritten.

## Important limitations

- Account-specific ledgers depend on a valid `accountId` being present on the source payment/expense record. Older unlinked transactions remain in the combined account and cannot be safely assigned retrospectively.
- Opening balances without a reliable opening date or creation date are not silently assigned a guessed date; the audit can flag them as invalid/missing-date entries.
- The journal still needs a fully verified supplier-return posting model, complete account classification for all legacy transactions, and retained-earnings closing logic before it can be treated as a complete statutory ledger.
- A balanced journal does not by itself prove that a transaction was classified to the correct account.
- Android Gradle compilation and physical-device testing were not performed in this environment.

## Verification

- `npm test`: 104/104 passing.
- `npm run typecheck`: passing.
- `npm run build:android-assets`: passing.
- JavaScript syntax checks: passing for the accounting module; full asset sweep is performed before packaging.
- Backup/restore regression tests remain included. Actual Android Downloads-folder behavior still requires on-device verification, especially the previously reported case where the app claimed success but no file appeared.
