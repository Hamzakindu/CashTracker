# V8.33 — Advanced Product-Supplier Management

## Added
- Each linked product supplier now has optional supplier-specific quoted price, supplier product code/SKU, notes, availability state, and lead-time days.
- Products support a preferred supplier; if none is explicitly selected, the first linked supplier is used as the default preference for compatibility.
- Product detail presents a supplier comparison and up to five most recent purchases per supplier.
- Purchase history is derived from active purchase records and excludes voided purchases; it is not separately incremented, so editing/voiding transactions does not leave a stale counter.
- Purchase entry pre-fills a product's cost using the selected supplier's quoted price, then the latest active purchase price from that supplier, then the product's general buy price. Changing the purchase supplier refreshes row defaults. The user can still edit the purchase cost.
- Supplier profile fields are preserved while the user checks/unchecks other suppliers in the product editor.

## Data and accounting safety
- Existing `supplierLinks` metadata is retained when a product is edited; removing a supplier removes only that product's link, not the supplier record or historical purchases.
- Quoted price is supplier reference information, not an accounting posting. Only the actual cost entered and saved in a purchase affects inventory/accounting.
- Last purchase price and count are calculated from purchase history rather than written into balances.
- Existing product-level `buy` remains the fallback when there is no supplier quote or matching supplier purchase history.
- Supplier availability is manually maintained descriptive information; it is not verified against a live supplier system.

## Version
- App version: 5.10.77
- Android versionCode: 77

## Verification scope
- Automated tests: 219 passed.
- TypeScript typecheck passed.
- Android TypeScript asset build passed.
- 91 JavaScript files passed `node --check`.
- Android manifest XML and app metadata JSON parsed successfully.
- No Android Gradle APK compilation, physical Android device test, or Cloudflare deployment was performed.
