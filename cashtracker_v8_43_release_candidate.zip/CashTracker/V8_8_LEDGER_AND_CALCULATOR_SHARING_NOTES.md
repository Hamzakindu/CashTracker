# CashTracker V8.8 — General Ledger & Calculator Share Header

Version: 5.10.52 (versionCode 52)

## New in V8.8

### General ledger
- Adds an account-by-account general-ledger view to the existing read-only double-entry accounting report.
- Select an account to inspect dated journal lines, debit, credit, running balance, period opening balance, and closing balance.
- Opening balance is derived from journal lines dated before the selected report start date; period totals use the selected date range.
- The report is read-only and does not alter transactions, cached balances, or account mappings.

### Calculator share header
- Adds an editable **Default share header** field in Calculator → Menu (⋮) → Calculator settings.
- Default remains `CashTracker Calculation` until changed.
- User can enter a custom header (up to 80 characters) or leave it blank to share without a header.
- Header is saved in the calculator's profile-specific settings and is used for both current-calculation sharing and history-entry sharing, including the main calculator module.
- The calculation expression and result remain included below the header; sharing still requires the existing confirmation for the current calculation.

## Accounting limitations retained
- This general ledger is a view of the existing derived journal, not a fully configurable posting engine.
- Expense account/payment mapping, individual cash/bank account mapping, supplier-return posting, opening-balance journalization, and retained-earnings closing still require dedicated verified work.
- Legacy records and incomplete source fields can cause audit exceptions. No automatic balance repair is performed.
- A balanced journal does not certify that every transaction has been classified to the correct account.

## Validation
- Node regression tests include period opening/running/closing balance checks and calculator header persistence/share-path checks.
- JavaScript syntax checks, TypeScript checking, and Android TypeScript asset compilation are required release checks.
- Android Gradle compilation and physical-device testing are not claimed unless performed in a compatible Android build environment.
