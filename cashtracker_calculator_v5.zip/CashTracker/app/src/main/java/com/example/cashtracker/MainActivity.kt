package com.example.cashtracker

import android.Manifest
import androidx.fragment.app.FragmentActivity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.Toast
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import org.json.JSONObject
import androidx.core.content.FileProvider
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.activity.OnBackPressedCallback
import java.util.concurrent.Executor
import org.json.JSONArray
import androidx.webkit.WebViewAssetLoader
import java.io.File
import java.net.URLConnection

open class MainActivity : FragmentActivity() {
    protected open val startPage = "index.html"
    protected open val isMain = true
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private val host = "appassets.androidplatform.net"
    private fun trustedPage(url: String): Boolean { val u=Uri.parse(url); return u.scheme=="https" && u.host==host && (u.path?.startsWith("/assets/") == true) }

    inner class Bridge {
        @JavascriptInterface fun drain(): String = if (isMain) Queue.peek(this@MainActivity) else "[]"

        @JavascriptInterface fun ackSms(queueIdsJson: String): Int {
            if (!isMain) return 0
            return try {
                val a = JSONArray(queueIdsJson)
                val ids = mutableSetOf<String>()
                for (i in 0 until a.length()) ids.add(a.optString(i))
                Queue.ack(this@MainActivity, ids)
            } catch (_: Exception) { 0 }
        }

        @JavascriptInterface fun parseBankSms(body: String): String {
            if (!isMain) return ""
            return SmsParser.parse(body)?.toString() ?: ""
        }

        @JavascriptInterface fun authenticateBiometric() {
            runOnUiThread { authenticateBiometricInternal() }
        }

        @JavascriptInterface fun share2(channel: String, text: String, phone: String, imgB64: String, mode: String) {
            runOnUiThread {
                try { doShare(channel, text, phone, imgB64, mode) }
                catch (e: Exception) { Toast.makeText(this@MainActivity, "Share failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }

        @JavascriptInterface fun share(channel: String, text: String, phone: String, imgB64: String) {
            runOnUiThread {
                try { doShare(channel, text, phone, imgB64, "direct") }
                catch (e: Exception) { Toast.makeText(this@MainActivity, "Share failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }

        @JavascriptInterface fun scan() {
            runOnUiThread {
                try {
                    GmsBarcodeScanning.getClient(this@MainActivity).startScan()
                        .addOnSuccessListener { b ->
                            web.evaluateJavascript("window.__onScan&&window.__onScan(" + JSONObject.quote(b.rawValue ?: "") + ")", null)
                        }
                        .addOnFailureListener { e ->
                            if (e.message?.contains("cancel", true) != true)
                                Toast.makeText(this@MainActivity, "Scanner unavailable: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Scanner unavailable: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface fun shareMulti(channel: String, text: String, phone: String, imgsJson: String, mode: String) {
            runOnUiThread {
                try { doShareMulti(channel, text, phone, imgsJson, mode) }
                catch (e: Exception) { Toast.makeText(this@MainActivity, "Share failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }

        @JavascriptInterface fun setFullscreen(enabled: Boolean) {
            runOnUiThread { applyCalculatorFullscreen(enabled) }
        }

        @JavascriptInterface fun closeCalculator() {
            runOnUiThread {
                if (!isMain) finish()
                else web.evaluateJavascript("(typeof Tabs!=='undefined' && Tabs.currentTab==='calculator') ? (Tabs.exitCalculatorFullscreen(), true) : false") { }
            }
        }

        @JavascriptInterface fun openMain() {
            runOnUiThread {
                if (!isMain) finish() else if (::web.isInitialized) web.evaluateJavascript("typeof Tabs!=='undefined' && Tabs.exitCalculatorFullscreen ? (Tabs.exitCalculatorFullscreen(), true) : false", null)
            }
        }

        @JavascriptInterface fun saveFile(name: String, b64: String) {
            val safeName = sanitizeFileName(name)
            val msg = try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                if (Build.VERSION.SDK_INT >= 29) {
                    val v = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                        put(MediaStore.Downloads.MIME_TYPE, URLConnection.guessContentTypeFromName(safeName) ?: "application/octet-stream")
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                        ?: throw IllegalStateException("Could not create Downloads file")
                    try {
                        contentResolver.openOutputStream(uri, "w")!!.use { it.write(bytes) }
                        contentResolver.update(
                            uri,
                            ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) },
                            null, null
                        )
                    } catch (e: Exception) {
                        contentResolver.delete(uri, null, null)
                        throw e
                    }
                    "Saved to Downloads: $safeName (${bytes.size} bytes)"
                } else {
                    val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)!!
                    val f = File(dir, safeName).canonicalFile
                    if (!f.path.startsWith(dir.canonicalPath + File.separator)) throw SecurityException("Invalid file name")
                    f.writeBytes(bytes)
                    "Saved: ${f.absolutePath}"
                }
            } catch (e: Exception) { "Could not save file: ${e.message}" }
            runOnUiThread { Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show() }
        }
    }

    private val apps = mapOf(
        "whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "telegram" to listOf("org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram"),
        "imo" to listOf("com.imo.android.imoim", "com.imo.android.imoimbeta", "com.imo.android.imoimhd")
    )

    private fun note(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun sanitizeFileName(input: String): String {
        val raw = input.trim().replace('\\', '/').substringAfterLast('/')
        val clean = raw.replace(Regex("[^A-Za-z0-9._-]"), "_").trim('.', ' ')
        if (clean.isEmpty() || clean == "." || clean == "..") throw SecurityException("Invalid file name")
        if (clean.length > 120) return clean.take(120)
        return clean
    }

    private fun tryStart(i: Intent): Boolean = try { startActivity(i); true } catch (e: Exception) { false }

    private fun doShare(channel: String, text: String, phone: String, img: String, mode: String) {
        val digits = phone.filter { it.isDigit() }
        if (channel == "sms") {
            if (!tryStart(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phone")).putExtra("sms_body", text))) note("No SMS app found")
            return
        }
        val label = mapOf("whatsapp" to "WhatsApp", "telegram" to "Telegram", "imo" to "imo")[channel]
        val pkg = apps[channel]?.firstOrNull { packageManager.getLaunchIntentForPackage(it) != null }
        val send = Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_TEXT, text)
        if (img.isNotEmpty()) {
            val dir = File(cacheDir, "share").apply { mkdirs() }
            val f = File(dir, "share_${System.currentTimeMillis()}.jpg")
            f.writeBytes(Base64.decode(img, Base64.DEFAULT))
            send.type = "image/*"
            send.putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(this, "$packageName.files", f))
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } else send.type = "text/plain"
        // Share sheet: the phone's normal app list (most reliable)
        if (channel == "more" || (mode == "sheet" && channel != "imo")) {
            if (!tryStart(Intent.createChooser(send, "Share"))) note("No app available to share")
            return
        }
        // Chat links: whatsapp:// and tg:// links, no package forcing
        if (mode == "deep" && img.isEmpty()) {
            val link = when (channel) {
                "whatsapp" -> if (digits.isNotEmpty()) "whatsapp://send?phone=$digits&text=" + Uri.encode(text) else "whatsapp://send?text=" + Uri.encode(text)
                "telegram" -> "tg://msg?text=" + Uri.encode(text)
                else -> null
            }
            if (link != null && tryStart(Intent(Intent.ACTION_VIEW, Uri.parse(link)))) { note("Opening $label…"); return }
        }
        // 1) WhatsApp: open the customer's chat directly when we know the number
        if (channel == "whatsapp" && pkg != null && img.isEmpty() && digits.isNotEmpty()) {
            val v = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=$digits&text=" + Uri.encode(text))).setPackage(pkg)
            if (tryStart(v)) { note("Opening WhatsApp…"); return }
        }
        // 2) Share straight to the chosen app
        if (pkg != null) {
            val s = Intent(send).setPackage(pkg)
            if (channel == "whatsapp" && digits.isNotEmpty()) s.putExtra("jid", "$digits@s.whatsapp.net")
            if (tryStart(s)) { note("Opening $label…"); return }
        }
        // 3) Never fail silently: show the normal share list
        note(if (label != null) "$label didn't open. Choose an app." else "Choose an app")
        if (!tryStart(Intent.createChooser(send, "Share"))) note("No app available to share")
    }

    private fun doShareMulti(channel: String, text: String, phone: String, json: String, mode: String) {
        val arr = JSONArray(json)
        val dir = File(cacheDir, "share").apply { mkdirs() }
        dir.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 86400000L }?.forEach { it.delete() }
        val uris = ArrayList<Uri>()
        val stamp = System.currentTimeMillis()
        for (i in 0 until arr.length()) {
            val f = File(dir, "card_${stamp}_$i.jpg")
            f.writeBytes(Base64.decode(arr.getString(i), Base64.DEFAULT))
            uris.add(FileProvider.getUriForFile(this, "$packageName.files", f))
        }
        if (uris.isEmpty()) { note("Nothing to send"); return }
        val send = Intent(Intent.ACTION_SEND_MULTIPLE).setType("image/*")
            .putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        if (text.isNotEmpty()) send.putExtra(Intent.EXTRA_TEXT, text)
        val digits = phone.filter { it.isDigit() }
        val label = mapOf("whatsapp" to "WhatsApp", "telegram" to "Telegram", "imo" to "imo")[channel]
        val pkg = apps[channel]?.firstOrNull { packageManager.getLaunchIntentForPackage(it) != null }
        val sheet = channel == "more" || (mode == "sheet" && channel != "imo")
        if (!sheet && pkg != null) {
            val s = Intent(send).setPackage(pkg)
            if (channel == "whatsapp" && digits.isNotEmpty()) s.putExtra("jid", "$digits@s.whatsapp.net")
            if (tryStart(s)) { note("Opening $label…"); return }
        }
        if (!tryStart(Intent.createChooser(send, "Share"))) note("No app available to share")
    }

    private fun applyCalculatorFullscreen(enabled: Boolean) {
        if (!isMain) {
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
            if (enabled) {
                window.addFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (
                    android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                    android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                )
            } else {
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            }
        }
    }

    private fun authenticateBiometricInternal() {
        val manager = BiometricManager.from(this)
        if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK) != BiometricManager.BIOMETRIC_SUCCESS) {
            web.evaluateJavascript("window.AppLock&&AppLock.onBiometricError&&AppLock.onBiometricError('Biometric unlock is not available on this device')", null)
            return
        }
        val executor: Executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                web.evaluateJavascript("window.AppLock&&AppLock.onBiometricSuccess&&AppLock.onBiometricSuccess()", null)
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                web.evaluateJavascript("window.AppLock&&AppLock.onBiometricError&&AppLock.onBiometricError(" + JSONObject.quote(errString.toString()) + ")", null)
            }
        })
        prompt.authenticate(BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock CashTracker")
            .setSubtitle("Use your biometric to unlock")
            .setNegativeButtonText("Use PIN")
            .build())
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (!isMain) applyCalculatorFullscreen(true)
        if (isMain && Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECEIVE_SMS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            AlertDialog.Builder(this).setTitle("Bank SMS access")
                .setMessage("CashTracker uses incoming SMS only to detect bank transaction messages. Messages stay on this device until you review and save them. You can continue without this permission.")
                .setNegativeButton("Not now", null)
                .setPositiveButton("Allow") { _, _ -> requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS), 1001) }.show()
        }
        val loader = WebViewAssetLoader.Builder()
            .setDomain(host)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            private fun trusted(url: Uri): Boolean = trustedPage(url.toString())
            override fun onPageStarted(v: WebView, url: String, favicon: android.graphics.Bitmap?) {
                if (trustedPage(url)) v.addJavascriptInterface(Bridge(), "Android") else v.removeJavascriptInterface("Android")
                super.onPageStarted(v, url, favicon)
            }
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                if (trusted(r.url)) loader.shouldInterceptRequest(r.url) else null
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (trusted(r.url)) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (_: Exception) { }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(v: WebView, url: String, m: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setOnCancelListener { r.confirm() }.show(); return true
            }
            override fun onJsConfirm(v: WebView, url: String, m: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m)
                    .setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }.show(); return true
            }
            override fun onJsPrompt(v: WebView, url: String, m: String, d: String?, r: JsPromptResult): Boolean {
                val input = EditText(this@MainActivity); input.setText(d ?: "")
                AlertDialog.Builder(this@MainActivity).setMessage(m).setView(input)
                    .setPositiveButton("OK") { _, _ -> r.confirm(input.text.toString()) }
                    .setNegativeButton("Cancel") { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }.show(); return true
            }
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                chooser?.onReceiveValue(null); chooser = cb
                return try { startActivityForResult(p.createIntent(), 42); true }
                catch (e: Exception) { chooser = null; false }
            }
        }
        setContentView(web)
        web.loadUrl("https://$host/assets/$startPage")
        setupBackNavigation()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 42) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data)); chooser = null
        } else super.onActivityResult(req, res, data)
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (isMain && ::web.isInitialized) {
                    web.evaluateJavascript("(typeof Tabs!=='undefined' && Tabs.currentTab==='calculator') ? (Tabs.exitCalculatorFullscreen(), 'CALCULATOR') : ''") { value ->
                        if (value != "\"CALCULATOR\"") {
                            if (web.canGoBack()) web.goBack() else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                        }
                    }
                    return
                }
                if (::web.isInitialized && web.canGoBack()) web.goBack() else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        if (isMain && ::web.isInitialized) web.evaluateJavascript("window.BankSMS&&BankSMS.pull&&BankSMS.pull()", null)
    }
}
