// Android shell shim: route WebView blob downloads to the native Downloads writer.
(function(){
  if(!window.Android || typeof Android.saveFile !== 'function') return;

  const blobs = new Map();
  const nativeCreate = URL.createObjectURL.bind(URL);
  const nativeRevoke = URL.revokeObjectURL.bind(URL);

  URL.createObjectURL = function(blob){
    const url = nativeCreate(blob);
    blobs.set(url, blob);
    return url;
  };

  HTMLAnchorElement.prototype.click = new Proxy(HTMLAnchorElement.prototype.click, {
    apply(target, self, args){
      const url = self && self.href;
      const blob = url ? blobs.get(url) : null;
      if(self && self.download && blob){
        const name = self.download || 'download';
        const reader = new FileReader();
        reader.onload = function(){
          try {
            const dataUrl = String(reader.result || '');
            const comma = dataUrl.indexOf(',');
            if(comma < 0) throw new Error('Could not encode download');
            Android.saveFile(name, dataUrl.slice(comma + 1));
          } catch(e) {
            console.error('Android download bridge failed:', e);
          } finally {
            blobs.delete(url);
            nativeRevoke(url);
          }
        };
        reader.onerror = function(){
          blobs.delete(url);
          nativeRevoke(url);
          console.error('Could not read download blob');
        };
        reader.readAsDataURL(blob);
        return;
      }
      return Reflect.apply(target, self, args);
    }
  });

  // Delay URL revocation until the FileReader has finished.
  URL.revokeObjectURL = function(url){
    if(blobs.has(url)) return;
    nativeRevoke(url);
  };
})();
