(function(){
'use strict';
const exprEl=document.getElementById('expr'),resultEl=document.getElementById('result'),historyDrawer=document.getElementById('historyDrawer'),saveDrawer=document.getElementById('saveDrawer');
const PROFILE_ID=()=>{try{return localStorage.getItem('currentProfileId')||'default'}catch(e){return 'default'}};
const PK=base=>base+'_'+PROFILE_ID();
// ONE source of truth for both the in-app and standalone calculator.
const HISTORY_KEY=PK('CT_CALCULATOR_V2_HISTORY'),INBOX_KEY=PK('CT_CALCULATOR_V2_SAVED'),CLIP_KEY=PK('CT_CALCULATOR_V2_CLIPBOARD'),SETTINGS_KEY=PK('CT_CALCULATOR_V2_SETTINGS');
const LEGACY_HISTORY_KEYS=['SP_calculations_history',PK('SP_calculations_history')];
const LEGACY_INBOX_KEYS=['SP_calc_inbox',PK('SP_calc_inbox')];
(function migrateLegacy(){
  try{
    const merge=(target,keys)=>{
      let current=[]; try{current=JSON.parse(localStorage.getItem(target)||'[]')}catch(e){}
      const seen=new Set(current.map(x=>x.id||((x.timestamp||'')+'|'+(x.originalExpression||x.expression||'')+'|'+(x.result??''))));
      for(const k of keys){if(k===target)continue;let a=[];try{a=JSON.parse(localStorage.getItem(k)||'[]')}catch(e){};if(!Array.isArray(a))continue;for(const x of a){const id=x.id||((x.timestamp||'')+'|'+(x.originalExpression||x.expression||'')+'|'+(x.result??''));if(!seen.has(id)){seen.add(id);current.push(x)}}}
      current.sort((a,b)=>String(b.timestamp||'').localeCompare(String(a.timestamp||'')));
      if(current.length)localStorage.setItem(target,JSON.stringify(current));
    };
    merge(HISTORY_KEY,LEGACY_HISTORY_KEYS);
    merge(INBOX_KEY,LEGACY_INBOX_KEYS);
    // Preserve old daily history as part of the unified history before release.
    const dailyKeys=Object.keys(localStorage).filter(k=>k.indexOf('SP_calc_daily_')===0);
    if(dailyKeys.length){let h=[];try{h=JSON.parse(localStorage.getItem(HISTORY_KEY)||'[]')}catch(e){};const seen=new Set(h.map(x=>x.id));for(const k of dailyKeys){let a=[];try{a=JSON.parse(localStorage.getItem(k)||'[]')}catch(e){};if(Array.isArray(a))for(const x of a)if(x&&x.id&&!seen.has(x.id)){seen.add(x.id);h.push(x)}}h.sort((a,b)=>String(b.timestamp||'').localeCompare(String(a.timestamp||'')));localStorage.setItem(HISTORY_KEY,JSON.stringify(h));}
  }catch(e){console.warn('Calculator history migration failed',e)}
})();
let lastResult=null,lastExpression='',caret=0,settings=loadSettings(),touchStartY=null;
function loadSettings(){const d={historyGesture:'down',savedGesture:'up',fullscreen:true,autoHistory:true,haptic:true,theme:'system'};try{return Object.assign(d,JSON.parse(localStorage.getItem(SETTINGS_KEY)||'{}'))}catch(e){return d}}
function persistSettings(){localStorage.setItem(SETTINGS_KEY,JSON.stringify(settings));try{if(window.Android&&Android.setFullscreen)Android.setFullscreen(!!settings.fullscreen)}catch(e){}}
function toast(m){const t=document.getElementById('toast');t.textContent=m;t.style.display='block';clearTimeout(toast._t);toast._t=setTimeout(()=>t.style.display='none',2100)}
function haptic(){if(!settings.haptic)return;try{if(navigator.vibrate)navigator.vibrate(8)}catch(e){}}
function normalize(s){return String(s||'').replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-').replace(/,/g,'').replace(/\s+/g,'')}
function normalizeBusiness(s){let x=normalize(s).replace(/√/g,'sqrt');x=x.replace(/P([+-]?)(\d+(?:\.\d+)?)/gi,(m,sg,n)=>(sg==='-'?'-':'+')+n);return x}
function tokenize(s){const a=[];let i=0;while(i<s.length){const c=s[i];if(/[0-9.]/.test(c)){let j=i,d=0;while(j<s.length&&/[0-9.]/.test(s[j])){if(s[j]==='.')d++;j++}const raw=s.slice(i,j);if(raw==='.'||d>1)throw Error('Invalid number');a.push({t:'num',v:Number(raw)});i=j;continue}if(c==='π'){a.push({t:'num',v:Math.PI});i++;continue}if(c==='e'){a.push({t:'num',v:Math.E});i++;continue}if('+-*/%^!()'.includes(c)){a.push({t:c,v:c});i++;continue}let matched=false;for(const name of ['sqrt','sin','cos','tan','ln','log','rad','inv']){if(s.startsWith(name,i)){a.push({t:'fn',v:name});i+=name.length;matched=true;break}}if(!matched)throw Error('Invalid character')}return a}
function evaluate(s){const t=tokenize(normalizeBusiness(s));let p=0;const peek=()=>t[p];const take=x=>{if(peek()&&peek().t===x){p++;return true}return false};function primary(){if(take('+'))return primary();if(take('-'))return -primary();if(peek()&&peek().t==='fn'){const fn=peek().v;p++;if(!take('('))throw Error('Missing (');const v=add();if(!take(')'))throw Error('Missing )');if(fn==='sqrt')return Math.sqrt(v);if(fn==='sin')return settingsDeg()?Math.sin(v*Math.PI/180):Math.sin(v);if(fn==='cos')return settingsDeg()?Math.cos(v*Math.PI/180):Math.cos(v);if(fn==='tan')return settingsDeg()?Math.tan(v*Math.PI/180):Math.tan(v);if(fn==='ln')return Math.log(v);if(fn==='log')return Math.log10(v);if(fn==='rad')return v*Math.PI/180;if(fn==='inv')return 1/v}if(take('(')){const v=add();if(!take(')'))throw Error('Missing )');return v}if(!peek()||peek().t!=='num')throw Error('Number expected');const v=peek().v;p++;return v}function postfix(){let v=primary();while(true){if(take('%'))v/=100;else if(take('!')){if(v<0||v>170||Math.floor(v)!==v)throw Error('Invalid factorial');let f=1;for(let i=2;i<=v;i++)f*=i;v=f}else break}return v}function power(){let v=postfix();if(take('^'))v=Math.pow(v,power());return v}function mul(){let v=power();while(peek()&&('*'===peek().t||'/'===peek().t)){const op=peek().t;p++;const r=power();v=op==='*'?v*r:v/r}return v}function add(){let v=mul();while(peek()&&('+'===peek().t||'-'===peek().t)){const op=peek().t;p++;const r=mul();v=op==='+'?v+r:v-r}return v}if(!t.length)throw Error('Empty');const r=add();if(p!==t.length)throw Error('Unexpected input');if(Number.isNaN(r))throw Error('Math error');return r}
function settingsDeg(){return localStorage.getItem('SP_calc_angle')!=='rad'}
function format(n){if(n===Infinity)return '∞';if(n===-Infinity)return '−∞';if(Object.is(n,-0))n=0;if(Number.isNaN(n))return 'Error';if(!Number.isFinite(n))return n>0?'∞':'−∞';const s=String(n);return s.length>22?n.toExponential(14):n.toLocaleString('en-US',{maximumFractionDigits:14,useGrouping:true})}
function setResult(v,err){resultEl.textContent=err?'Error':format(v);resultEl.className='result'+(err?' err':'')}
function rememberCaret(){if(document.activeElement===exprEl){caret=exprEl.selectionStart==null?exprEl.value.length:exprEl.selectionStart}}
function live(){rememberCaret();const s=exprEl.value;if(!s){setResult(lastResult===null?0:lastResult,false);return}let candidate=s.replace(/[+*/%]+$/,'').replace(/-$/,'');if(!candidate||candidate==='-'){setResult(0,false);return}try{setResult(evaluate(candidate),false)}catch(e){setResult(0,false)}}
function insert(text){let pos=caret;if(document.activeElement===exprEl&&exprEl.selectionStart!=null)pos=exprEl.selectionStart;pos=Math.max(0,Math.min(pos,exprEl.value.length));let end=pos;if(document.activeElement===exprEl&&exprEl.selectionEnd!=null)end=exprEl.selectionEnd;exprEl.value=exprEl.value.slice(0,pos)+text+exprEl.value.slice(end);caret=pos+text.length;if(document.activeElement===exprEl){exprEl.setSelectionRange(caret,caret)}live()}
function isOp(c){return '+-*/'.includes(c)}
function addOperator(op){let s=exprEl.value;if(!s){if(op==='-')insert('-');return}let pos=caret;if(pos!==s.length){insert(op);return}let last=s.slice(-1);if(isOp(last)){if(last==='-'&&s.length>1&&isOp(s[s.length-2])){exprEl.value=s.slice(0,-2)+op;caret=exprEl.value.length}else{exprEl.value=s.slice(0,-1)+op;caret=exprEl.value.length}live();return}if(last==='('&&op!=='-')return;insert(op)}
function key(k){hideKeyboard();haptic();if(k==='AC'){exprEl.value='';caret=0;lastResult=null;lastExpression='';setResult(0,false);return}if(k==='DEL'){let s=exprEl.value;if(document.activeElement===exprEl&&exprEl.selectionStart!==exprEl.selectionEnd){const a=exprEl.selectionStart,b=exprEl.selectionEnd;exprEl.setRangeText('',a,b,'start');caret=a}else if(caret>0){exprEl.value=s.slice(0,caret-1)+s.slice(caret);caret--;if(document.activeElement===exprEl)exprEl.setSelectionRange(caret,caret)}live();return}if(k==='='){equals();return}if(k==='()'){insert('()');caret=Math.max(0,caret-1);return}if(k==='sqrt'){insert('sqrt(');return}if(k==='sin'||k==='cos'||k==='tan'||k==='ln'||k==='log'||k==='inv'){insert(k+'(');return}if(k==='pi'){insert('π');return}if(k==='e'){insert('e');return}if(k==='rad'){const next=settingsDeg()?'rad':'deg';localStorage.setItem('SP_calc_angle',next);const b=document.querySelector('[data-k="rad"]');if(b)b.textContent=next==='rad'?'Rad':'Deg';toast(next==='rad'?'Radians':'Degrees');return}if('+-*/^'.includes(k)){addOperator(k);return}insert(k)}
function equals(){let s=exprEl.value.trim();if(!s)return;if(/[+*/.]$/.test(s)||/\($/.test(s)){toast('Complete the expression first');return}try{const r=evaluate(s);lastResult=r;lastExpression=s;if(settings.autoHistory)saveHistory(s,r);exprEl.value='';caret=0;setResult(r,false);haptic()}catch(e){setResult(0,true);toast('Invalid expression') }}
function uid(){return 'calc_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,9)}
function saveHistory(q,r){const item={id:uid(),originalExpression:q,displayExpression:q,expression:q+' = '+format(r),result:r,displayResult:format(r),formattedResult:format(r),fullDisplay:q+' = '+format(r),type:'calculation',timestamp:new Date().toISOString(),date:new Date().toLocaleString(),imported:false};try{const h=JSON.parse(localStorage.getItem(HISTORY_KEY)||'[]');h.unshift(item);localStorage.setItem(HISTORY_KEY,JSON.stringify(h));renderHistory()}catch(e){toast('History storage is full')}}
function getHistory(){try{return JSON.parse(localStorage.getItem(HISTORY_KEY)||'[]')}catch(e){return []}}
function queryItems(q){
  let source=normalize(String(q||'')); if(!source)return [];
  const people=[];
  source=source.replace(/(^|[+-])P([+-]?)(\d+(?:\.\d+)?)/gi,(m,pre,sg,n)=>{const sign=sg? (sg==='-'?-1:1) : (pre==='-'?-1:1);const amount=sign*Number(n);people.push({kind:'peopleMoney',quantity:1,price:Math.abs(amount),amount,operation:sign<0?'subtract':'add'});return ''});
  source=source.replace(/^\+/,'');
  const parts=[]; let start=0,depth=0;
  for(let i=0;i<source.length;i++){const c=source[i]; if(c==='(')depth++; else if(c===')')depth=Math.max(0,depth-1); else if((c==='+'||c==='-')&&i>0&&depth===0&&/[0-9.)]/.test(source[i-1])&&/[0-9.(]/.test(source[i+1]||'')){parts.push(source.slice(start,i));start=i}}
  parts.push(source.slice(start));
  const items=[];
  for(const raw of parts){if(!raw)continue; const sign=raw[0]==='-'?-1:1; const body=raw[0]==='-'||raw[0]==='+'?raw.slice(1):raw;
    const nums=body.split('*').filter(Boolean);
    if(nums.length===2 && /^\d*\.?\d+$/.test(nums[0]) && /^\d*\.?\d+$/.test(nums[1])){
      const quantity=Number(nums[0]),price=Number(nums[1]); items.push({kind:'item',quantity,price,amount:sign*quantity*price,operation:sign<0?'subtract':'add'});
    } else if(nums.length===1 && /^\d*\.?\d+$/.test(nums[0])){
      const amount=sign*Number(nums[0]); if(amount!==0)items.push({kind:'adjustment',quantity:1,price:Math.abs(amount),amount,operation:sign<0?'subtract':'add',adjustment:true});
    }
  }
  return items.concat(people);
}
window.__calcQueryItems=queryItems;
function saveHistoryAs(type,index){
  const x=getHistory()[index]; if(!x)return; const q=x.originalExpression||x.expression||''; const r=Number(x.result);
  const items=queryItems(q); if(!items.length)return toast('No item lines found in this calculation');
  try{const a=JSON.parse(localStorage.getItem(INBOX_KEY)||'[]'); a.unshift({id:uid(),expr:q,result:r,note:'From calculator history',type,items,ts:new Date().toISOString(),status:'new',source:'calculator-history'}); localStorage.setItem(INBOX_KEY,JSON.stringify(a)); renderSaved(); toast(type==='sale'?'Saved as Sale':'Saved as Purchase'); openDrawer(saveDrawer);}catch(e){toast('Could not save operation')}}
function shareCalculation(x){
  if(!x)return;
  const q=x.originalExpression||x.displayExpression||x.expression||'';
  const r=x.displayResult||format(Number(x.result));
  const text='CashTracker Calculation\n\n'+q+'\n= '+r;
  if(!confirm('Share this calculation?\n\n'+q+'\n= '+r))return;
  try{
    if(window.Android&&Android.share2){Android.share2('more',text,'','','sheet');toast('Share opened');return;}if(window.Android&&Android.share){Android.share('more',text,'','');toast('Share opened');return;}
    if(navigator.share){navigator.share({title:'CashTracker Calculation',text}).then(()=>toast('Shared')).catch(()=>{});return;}
    copyText(text);
  }catch(e){copyText(text)}
}
function shareCurrent(){
  let q=lastExpression||exprEl.value.trim(),r=lastResult;
  if(r===null&&q){try{r=evaluate(q)}catch(e){}}
  if(r===null||Number.isNaN(r))return toast('Calculate a value first');
  shareCalculation({originalExpression:q,displayResult:format(Number(r)),result:r});
}

function renderHistory(){const h=getHistory(),c=document.getElementById('historyList');if(!h.length){c.innerHTML='<div class="empty">No calculations yet</div>';return}c.innerHTML=h.map((x,i)=>`<div class="hrow" data-hi="${i}"><div class="hmain"><div class="hq">${esc(x.originalExpression||x.expression||'')}</div><div class="hr">${esc(x.displayResult||format(Number(x.result)))}</div><div class="hts">${esc(x.date||'')}</div></div><button class="hmore" type="button" data-hmore="${i}" aria-label="History options" aria-expanded="false">⋮</button><div class="hmenu" data-hmenu="${i}"><button type="button" data-rq="${i}">Expression</button><button type="button" data-rr="${i}">Result</button><button type="button" data-rb="${i}">Both</button><button type="button" data-hsale="${i}">Sale</button><button type="button" data-hpurchase="${i}">Purchase</button><button type="button" data-hpeople="${i}">People Money</button><button type="button" data-hshare="${i}">Share</button></div></div>`).join('');syncCalculatorLayout()}
function recall(i,m){const x=getHistory()[i];if(!x)return;const q=x.originalExpression||'';const r=x.displayResult||format(Number(x.result));if(m==='q'||m==='b'){exprEl.value=q;caret=q.length}else{exprEl.value=r;caret=exprEl.value.length}if(m==='r'||m==='b'){lastResult=Number(x.result);setResult(Number(x.result),false)}else live();closeAllDrawers();hideKeyboard();}
function clearHistory(){const h=getHistory();if(!h.length)return;const backup=JSON.stringify(h);if(confirm('Clear calculator history?\n\n'+h.length+' calculations will be removed.')){localStorage.removeItem(HISTORY_KEY);renderHistory();toast('History cleared');const undo=document.createElement('button');undo.textContent='UNDO';undo.className='toast-action';undo.onclick=()=>{localStorage.setItem(HISTORY_KEY,backup);renderHistory();toast('History restored');};const t=document.getElementById('toast');t.appendChild(undo);setTimeout(()=>undo.remove(),5000)}}
function renderSaved(){let a=[];try{a=JSON.parse(localStorage.getItem(INBOX_KEY)||'[]')}catch(e){}const c=document.getElementById('savedList');if(!a.length){c.innerHTML='<div class="empty">No saved operations</div>';return}c.innerHTML=a.map((x,i)=>`<div class="srow"><div class="smain"><div class="hq">${esc(x.type||'general')} · ${esc(x.expr||'Manual')}</div><div class="hr">${esc(format(Number(x.result)))}</div><div class="sts">${esc(x.note||'')} ${esc(x.ts||'')}</div></div><button class="sbtn" data-sdel="${i}">Delete</button></div>`).join('')}
function saveInbox(type){const s=lastExpression||exprEl.value.trim();let r=lastResult;if(r===null&&s){try{r=evaluate(s)}catch(e){}}if(r===null||Number.isNaN(r))return toast('Calculate a value first');const note=document.getElementById('note').value.trim();try{const a=JSON.parse(localStorage.getItem(INBOX_KEY)||'[]');a.unshift({id:uid(),expr:s||'Manual',result:r,note,type,items:queryItems(s||''),ts:new Date().toISOString(),status:'new',source:'calculator'});localStorage.setItem(INBOX_KEY,JSON.stringify(a));document.getElementById('note').value='';renderSaved();toast('Saved operation');openDrawer(saveDrawer)}catch(e){toast('Could not save operation')}}
function saveExpense(){saveInbox('expense')}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function hideKeyboard(){try{exprEl.blur()}catch(e){};try{document.activeElement&&document.activeElement.blur&&document.activeElement.blur()}catch(e){}}
function syncCalculatorLayout(){
  const main=document.getElementById('main'), controls=document.getElementById('calculatorControls'), sci=document.getElementById('scientific'), list=document.getElementById('historyList');
  if(!main||!controls||!sci)return;

  const mainH=main.clientHeight||window.innerHeight;
  const DISPLAY_MIN=150;
  // Full-size controls when History is closed. This scales with the screen so
  // the normal calculator keeps the large Google-Calculator-like buttons.
  const NORMAL_CONTROLS=Math.min(900,Math.max(520,Math.round(mainH*0.58)));
  const CONTROLS_MIN=230;
  const HISTORY_MIN=120;

  // IMPORTANT: keep the calculator at its normal/full size when History is closed.
  // Only the portion occupied by visible History is taken away from the controls.
  // This makes button shrinking proportional to the actual visible history height.
  let histH=0;
  const historyOpen=main.classList.contains('history-open');

  if(historyOpen){
    const contentH=(list?list.scrollHeight:0)+72;
    // Leave enough room for the calculator display and keypad. Once that limit is
    // reached, the history list scrolls instead of making the keypad unusably small.
    const maxHistory=Math.max(HISTORY_MIN, mainH-DISPLAY_MIN-CONTROLS_MIN);
    histH=Math.min(Math.max(HISTORY_MIN,contentH),maxHistory);
    main.style.setProperty('--history-height',histH+'px');
  }else{
    main.style.setProperty('--history-height','0px');
  }

  // No history: full normal controls.
  // History open: shrink proportionally to the amount of History that is
  // actually visible. Closing History restores the exact normal size.
  let controlsH=NORMAL_CONTROLS;
  if(historyOpen){
    const historyFraction=Math.min(0.72,histH/mainH);
    controlsH=Math.round(NORMAL_CONTROLS*(1-historyFraction));
    // Keep a usable keypad even on a very small screen.
    const available=mainH-histH-DISPLAY_MIN;
    controlsH=Math.min(controlsH,Math.max(CONTROLS_MIN,available));
    controlsH=Math.max(CONTROLS_MIN,controlsH);
  }
  controls.style.setProperty('--controls-height',controlsH+'px');

  // Scientific rows share the SAME controls area. They become smaller only when
  // the controls area itself has been reduced by visible History.
  if(sci.classList.contains('open')){
    const expandH=44, gapTotal=16;
    const usable=Math.max(130,controlsH-expandH-gapTotal);
    const sciH=Math.round(usable*0.38);
    sci.style.setProperty('--scientific-height',Math.max(90,sciH)+'px');
  }
}
function scrollActiveHistoryIntoView(index){
  const list=document.getElementById('historyList');
  if(!list||index==null)return;
  const row=list.querySelectorAll('.hrow')[index];
  if(row)requestAnimationFrame(()=>row.scrollIntoView({block:'nearest',behavior:'smooth'}));
}
function closeAllDrawers(){historyDrawer.classList.remove('open');saveDrawer.classList.remove('open');document.getElementById('drawerBackdrop').classList.remove('open');document.getElementById('main').classList.remove('history-open');hideKeyboard()}
function openDrawer(d){closeAllDrawers();d.classList.add('open');if(d===historyDrawer)document.getElementById('main').classList.add('history-open');document.getElementById('drawerBackdrop').classList.add('open');if(d===historyDrawer)renderHistory();if(d===saveDrawer)renderSaved();syncCalculatorLayout();hideKeyboard()}
function closeDrawer(d){d.classList.remove('open');if(d===historyDrawer)document.getElementById('main').classList.remove('history-open');if(!historyDrawer.classList.contains('open')&&!saveDrawer.classList.contains('open'))document.getElementById('drawerBackdrop').classList.remove('open');syncCalculatorLayout();hideKeyboard()}
function applyTheme(mode){settings.theme=mode||'system';if(settings.theme==='dark')document.documentElement.dataset.theme='dark';else if(settings.theme==='light')document.documentElement.dataset.theme='light';else {const dark=window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches;document.documentElement.dataset.theme=dark?'dark':'light'}localStorage.setItem('SP_calc_theme',settings.theme);const b=document.getElementById('themeMode');if(b)b.value=settings.theme} function toggleScientific(){const el=document.getElementById('scientific'),b=document.getElementById('expandBtn');const open=el.classList.toggle('open');b.textContent=open?'⌄':'⌃';b.setAttribute('aria-expanded',String(open));syncCalculatorLayout()}
async function copyText(text){try{await navigator.clipboard.writeText(text);localStorage.setItem(CLIP_KEY,text);toast('Copied')}catch(e){try{localStorage.setItem(CLIP_KEY,text);toast('Copied to internal clipboard')}catch(x){toast('Copy failed')}}}
function copyExpr(){copyText(exprEl.value)}
function cutExpr(){const s=exprEl.selectionStart,e=exprEl.selectionEnd;if(s===e)return toast('Select text first');copyText(exprEl.value.slice(s,e));exprEl.setRangeText('',s,e,'start');caret=s;live()}
async function pasteExpr(){let x='';try{x=await navigator.clipboard.readText()}catch(e){x=localStorage.getItem(CLIP_KEY)||''}if(!x)return toast('Clipboard is empty');insert(normalize(x))}
function openMainApp(){closeAllDrawers();if(window.frameElement){try{window.parent.postMessage({type:'cashtracker-close-calculator'},'*')}catch(e){};return}if(window.Android&&Android.closeCalculator){try{Android.closeCalculator();return}catch(e){}}if(window.Android&&Android.openMain){try{Android.openMain();return}catch(e){}}location.href='index.html'}
function applySettingsUI(){applyTheme(settings.theme);document.getElementById('themeMode').value=settings.theme;const angle=localStorage.getItem('SP_calc_angle')||'deg';document.getElementById('angleMode').value=angle;const rb=document.querySelector('[data-k="rad"]');if(rb)rb.textContent=angle==='rad'?'Rad':'Deg';document.getElementById('fullscreenSetting').checked=!!settings.fullscreen;document.getElementById('autoHistorySetting').checked=!!settings.autoHistory;document.getElementById('hapticSetting').checked=!!settings.haptic;persistSettings()}
function openSettings(){applySettingsUI();document.getElementById('settings').classList.add('open')}
function closeSettings(){document.getElementById('settings').classList.remove('open');hideKeyboard()}
exprEl.addEventListener('input',live);['keyup','mouseup','select','focus'].forEach(e=>exprEl.addEventListener(e,rememberCaret));exprEl.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key==='='){e.preventDefault();equals()}else if(e.key==='Escape'){e.preventDefault();key('AC')}});
document.querySelectorAll('.key').forEach(b=>{b.addEventListener('pointerdown',e=>e.preventDefault());b.addEventListener('click',()=>key(b.dataset.k))});
document.getElementById('mainBackBtn').onclick=openMainApp;document.getElementById('historyTopBtn').onclick=()=>historyDrawer.classList.contains('open')?closeDrawer(historyDrawer):openDrawer(historyDrawer);document.getElementById('clearHistoryBtn').onclick=clearHistory;document.getElementById('closeHistoryBtn').onclick=()=>closeDrawer(historyDrawer);document.getElementById('closeSavedBtn').onclick=()=>closeDrawer(saveDrawer);document.getElementById('savedOpenBtn').onclick=()=>{closeSettings();openDrawer(saveDrawer)};document.getElementById('saveGeneralBtn').onclick=()=>saveInbox('general');document.getElementById('saveSaleBtn').onclick=()=>saveInbox('sale');document.getElementById('savePurchaseBtn').onclick=()=>saveInbox('purchase');document.getElementById('saveExpenseBtn').onclick=saveExpense;document.getElementById('openMainBtn').onclick=openMainApp;document.getElementById('settingsBtn').onclick=openSettings;
const shareTop=document.createElement('button');shareTop.id='shareCalcBtn';shareTop.type='button';shareTop.setAttribute('aria-label','Share calculation');shareTop.textContent='↗';shareTop.onclick=shareCurrent;document.querySelector('.top-actions').insertBefore(shareTop,document.getElementById('settingsBtn'));
document.getElementById('closeSettings').onclick=closeSettings;document.getElementById('expandBtn').onclick=toggleScientific;document.getElementById('themeMode').onchange=e=>{settings.theme=e.target.value;persistSettings();applyTheme(settings.theme)};document.getElementById('angleMode').onchange=e=>localStorage.setItem('SP_calc_angle',e.target.value);
document.getElementById('fullscreenSetting').onchange=e=>{settings.fullscreen=e.target.checked;persistSettings()};document.getElementById('autoHistorySetting').onchange=e=>{settings.autoHistory=e.target.checked;persistSettings()};document.getElementById('hapticSetting').onchange=e=>{settings.haptic=e.target.checked;persistSettings()};
document.getElementById('historyList').onclick=e=>{const t=e.target.closest('button');if(!t)return;if(t.dataset.hmore!==undefined){const i=Number(t.dataset.hmore);document.querySelectorAll('.hmenu.open').forEach(m=>m.classList.remove('open'));document.querySelectorAll('.hmore[aria-expanded="true"]').forEach(b=>b.setAttribute('aria-expanded','false'));const menu=document.querySelector(`.hmenu[data-hmenu="${i}"]`);if(menu){menu.classList.add('open');t.setAttribute('aria-expanded','true')}e.stopPropagation();return}if(t.dataset.rq!==undefined)recall(Number(t.dataset.rq),'q');else if(t.dataset.rr!==undefined)recall(Number(t.dataset.rr),'r');else if(t.dataset.rb!==undefined)recall(Number(t.dataset.rb),'b');else if(t.dataset.hsale!==undefined)saveHistoryAs('sale',Number(t.dataset.hsale));else if(t.dataset.hpurchase!==undefined)saveHistoryAs('purchase',Number(t.dataset.hpurchase));else if(t.dataset.hpeople!==undefined)saveHistoryAs('peopleMoney',Number(t.dataset.hpeople));else if(t.dataset.hshare!==undefined)shareCalculation(getHistory()[Number(t.dataset.hshare)]);};document.getElementById('savedList').onclick=e=>{const t=e.target;if(t.dataset.sdel!==undefined){const a=JSON.parse(localStorage.getItem(INBOX_KEY)||'[]');a.splice(Number(t.dataset.sdel),1);localStorage.setItem(INBOX_KEY,JSON.stringify(a));renderSaved()}};
document.getElementById('drawerBackdrop').addEventListener('click',()=>closeAllDrawers());document.addEventListener('click',e=>{if(!e.target.closest('.hmenu')&&!e.target.closest('.hmore')){document.querySelectorAll('.hmenu.open').forEach(m=>m.classList.remove('open'));document.querySelectorAll('.hmore[aria-expanded="true"]').forEach(b=>b.setAttribute('aria-expanded','false'))}});
// Never let calculator keypad/tool buttons retain expression focus or summon Android keyboard.
document.querySelectorAll('.key,.tool,.top button').forEach(b=>b.addEventListener('pointerdown',hideKeyboard,{passive:true}));

window.addEventListener('resize',syncCalculatorLayout);window.addEventListener('orientationchange',()=>setTimeout(syncCalculatorLayout,100));if(window.ResizeObserver){const historyResizeObserver=new ResizeObserver(()=>syncCalculatorLayout());const historyListEl=document.getElementById('historyList');if(historyListEl)historyResizeObserver.observe(historyListEl)}applySettingsUI();renderHistory();renderSaved();syncCalculatorLayout();if(window.matchMedia){const mq=window.matchMedia('(prefers-color-scheme: dark)');const sync=()=>{if(settings.theme==='system')applyTheme('system')};if(mq.addEventListener)mq.addEventListener('change',sync);else if(mq.addListener)mq.addListener(sync)}
})();
