// ============================================
// APPLICATION STATE - COMPLETE FIXED
// ============================================

// Check if Storage is available
if (typeof Storage === 'undefined') {
    console.error('❌ Storage is not defined! Creating emergency fallback...');
    window.Storage = {
        getSetting: function(key, defaultValue) { 
            try { const value = localStorage.getItem(key); return value !== null ? value : defaultValue; } 
            catch(e) { return defaultValue; } 
        },
        setSetting: function(key, value) { 
            try { localStorage.setItem(key, value); return true; } 
            catch(e) { return false; } 
        },
        getProfileId: function() { 
            try { return localStorage.getItem('currentProfileId') || 'default'; } 
            catch(e) { return 'default'; } 
        },
        getKey: function(storeName) { 
            try { return 'SMDB_' + this.getProfileId() + '_' + storeName; } 
            catch(e) { return 'SMDB_default_' + storeName; } 
        },
        save: function(storeName, data) { 
            try { localStorage.setItem(this.getKey(storeName), JSON.stringify(data)); return true; } 
            catch(e) { return false; } 
        },
        load: function(storeName) { 
            try { const raw = localStorage.getItem(this.getKey(storeName)); return raw ? JSON.parse(raw) : []; } 
            catch(e) { return []; } 
        },
        remove: function(storeName) { 
            try { localStorage.removeItem(this.getKey(storeName)); return true; } 
            catch(e) { return false; } 
        }
    };
    console.log('✅ Storage fallback created in state.js');
}

const State = {
    // Data stores
    products: [],
    sales: [],
    purchases: [],
    customers: [],
    suppliers: [],
    supplierAdvances: [],
    paymentLedger: [],
    expenseTypes: [],
    directExpenses: [],
    returns: [],
    calculations: [],
    stockHistory: [],
    auditLog: [],
    accountingMeta: { version: 5, migratedAt: null },
    cashAccounts: [],
    moneyTransactions: [],
    peopleMoney: [],
    peopleMoneyTx: [],
    cashierSessions: [],
    cashCounts: [],
    cashReconciliations: [],
    branches: [],
    staffUsers: [],
    branchAccessMeta: { version: 1, activeBranchId: 'main', currentStaffId: '' },
    
    // Settings
    sortMode: 'alphabet',
    profiles: [],
    currentProfileId: 'default',
    
    // Undo stack
    undoStack: [],
    
    // Report data cache
    reportData: null,
    
    // Auto report flag
    dailyAutoReport: false,

    // Initialize state
    async init() {
        console.log('📦 State initializing...');
        
        try {
            if (window.StorageIDB?.bootstrap) await StorageIDB.bootstrap();
            // Load settings
            this.sortMode = Storage.getSetting('stockSortMode', 'alphabet');
            this.dailyAutoReport = Storage.getSetting('dailyAutoReport', 'false') === 'true';
            this.currentProfileId = Storage.getProfileId();

            // DATA-SAFETY: make a one-time pre-update snapshot before loading/migrating data.
            // This snapshot is never overwritten during the same app version.
            if (Storage.createSafetySnapshot) Storage.createSafetySnapshot(CONFIG && CONFIG.VERSION ? CONFIG.VERSION : 'unknown');
            
            // Load profiles
            await this.loadProfiles();
            
            // Load all data
            await this.loadAllData();
            
            // Do not rewrite every store on first launch. Existing records remain untouched;
            // Money.encode() converts monetary fields to integer minor units only when a store is actually saved.
            // This avoids a destructive first-start migration and lets the owner export a plain JSON backup first.

            // Ensure walk-in customer exists
            this.ensureWalkInCustomer();
            
            console.log('✅ State initialized:', this.products.length, 'products,', this.customers.length, 'customers');
            
        } catch (error) {
            console.error('❌ State init error:', error);
            // Create default data if loading fails
            this.createDefaultData();
        }
    },

    // Load profiles
    async loadProfiles() {
        try {
            this.profiles = JSON.parse(localStorage.getItem('stockProfilesList') || '[]');
            if (this.profiles.length === 0) {
                this.profiles.push({
                    id: 'default',
                    name: 'Default Store',
                    createdAt: new Date().toISOString()
                });
                localStorage.setItem('stockProfilesList', JSON.stringify(this.profiles));
                Storage.setSetting('currentProfileId', 'default');
            }
        } catch (error) {
            console.warn('loadProfiles error:', error);
            this.profiles = [{ id: 'default', name: 'Default Store', createdAt: new Date().toISOString() }];
        }
    },

    // Load all data from storage
    async loadAllData() {
        try {
            this.products = Storage.load('products') || [];
            this.sales = Storage.load('sales') || [];
            this.purchases = Storage.load('purchases') || [];
            this.customers = Storage.load('customers') || [];
            this.suppliers = Storage.load('suppliers') || [];
            this.supplierAdvances = Storage.load('supplierAdvances') || [];
            this.paymentLedger = Storage.load('paymentLedger') || [];
            this.customers.forEach(c => { if (typeof c.customerAdvance !== 'number') c.customerAdvance = 0; });
            this.suppliers.forEach(s => { if (typeof s.supplierAdvance !== 'number') s.supplierAdvance = 0; });
            this.expenseTypes = Storage.load('expenseTypes') || [];
            this.directExpenses = Storage.load('directExpenses') || [];
            this.returns = Storage.load('returns') || [];
            this.calculations = Storage.load('calculations') || [];
            this.stockHistory = Storage.load('stockHistory') || [];
            this.auditLog = Storage.load('auditLog') || [];
            this.accountingMeta = Storage.load('accountingMeta') || { version: 5, migratedAt: null };
            this.cashAccounts = Storage.load('cashAccounts') || [];
            this.moneyTransactions = Storage.load('moneyTransactions') || [];
            this.peopleMoney = Storage.load('peopleMoney') || [];
            this.peopleMoneyTx = Storage.load('peopleMoneyTx') || [];
            this.cashierSessions = Storage.load('cashierSessions') || [];
            this.cashCounts = Storage.load('cashCounts') || [];
            this.cashReconciliations = Storage.load('cashReconciliations') || [];
            this.branches = Storage.load('branches') || [];
            this.staffUsers = Storage.load('staffUsers') || [];
            const loadedBranchMeta = Storage.load('branchAccessMeta');
            this.branchAccessMeta = (loadedBranchMeta && typeof loadedBranchMeta === 'object' && !Array.isArray(loadedBranchMeta)) ? loadedBranchMeta : { version: 1, activeBranchId: 'main', currentStaffId: '' };
            if (!this.branches.length) this.branches = [{ id: 'main', name: 'Main branch', code: 'MAIN', address: '', phone: '', active: true, createdAt: new Date().toISOString(), legacyDefault: true }];
            if (!this.branchAccessMeta.activeBranchId || !this.branches.some(b => b.id === this.branchAccessMeta.activeBranchId)) this.branchAccessMeta.activeBranchId = this.branches[0].id;
            Storage.save('branches', this.branches); Storage.save('staffUsers', this.staffUsers); Storage.save('branchAccessMeta', this.branchAccessMeta);
            
            // FIRST-RUN ONLY: never infer that an empty product list means a new installation.
            // A real business can legitimately have zero products, and a failed/corrupt read must
            // never trigger sample-data creation or overwrite saved business data.
            const initialized = Storage.getSetting('stockpro_initialized_v2', 'false') === 'true';
            const hasAnyStoredBusinessData = [
                'products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger',
                'expenseTypes','directExpenses','returns','calculations','stockHistory','auditLog',
                'cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','branches','staffUsers','branchAccessMeta'
            ].some(store => {
                try { return localStorage.getItem(Storage.getKey(store)) !== null; } catch(e) { return false; }
            });

            if (!initialized && !hasAnyStoredBusinessData) {
                console.log('📦 First run with no stored business data; creating sample data...');
                this.createSampleData();
                Storage.setSetting('stockpro_initialized_v2', 'true');
            } else {
                // Existing data (including intentionally empty stores) is preserved exactly.
                Storage.setSetting('stockpro_initialized_v2', 'true');
            }
            
        } catch (error) {
            console.error('❌ loadAllData failed. Business data will NOT be replaced with sample/default data:', error);
            // Do not call createSampleData/createDefaultData here. Safety snapshot and backup
            // recovery are the correct paths for a corrupted or incompatible store.
        }
    },

    // Ensure walk-in customer exists
    ensureWalkInCustomer() {
        if (!this.customers.find(c => c.id === 'walkin')) {
            this.customers.push({
                id: 'walkin',
                name: 'Walk-in Customer',
                contact: '',
                address: '',
                balance: 0,
                createdAt: new Date().toISOString()
            });
            Storage.save('customers', this.customers);
        }
    },

    // Create sample data on first run
    createSampleData() {
        console.log('📦 Creating sample data...');
        
        // Sample Products
        this.products = [
            {
                id: 'prod_1',
                name: 'Laptop HP 15',
                category: 'Electronics',
                buy: 25000,
                sell: 32000,
                stock: 10,
                notes: 'Core i5, 8GB RAM, 512GB SSD',
                createdAt: new Date().toISOString()
            },
            {
                id: 'prod_2',
                name: 'Samsung Galaxy S23',
                category: 'Electronics',
                buy: 35000,
                sell: 45000,
                stock: 8,
                notes: '6.1" Display, 128GB',
                createdAt: new Date().toISOString()
            },
            {
                id: 'prod_3',
                name: 'Apple AirPods Pro',
                category: 'Accessories',
                buy: 12000,
                sell: 16000,
                stock: 15,
                notes: 'Noise Cancelling',
                createdAt: new Date().toISOString()
            }
        ];
        Storage.save('products', this.products);
        
        // Sample Customers
        this.customers = [
            {
                id: 'walkin',
                name: 'Walk-in Customer',
                contact: '',
                address: '',
                balance: 0,
                createdAt: new Date().toISOString()
            },
            {
                id: 'cust_1',
                name: 'Abebe Kebede',
                contact: '0912345678',
                address: 'Addis Ababa, Bole',
                balance: 0,
                createdAt: new Date().toISOString()
            },
            {
                id: 'cust_2',
                name: 'Tigist Hailu',
                contact: '0923456789',
                address: 'Addis Ababa, CMC',
                balance: 0,
                createdAt: new Date().toISOString()
            }
        ];
        Storage.save('customers', this.customers);
        
        // Sample Suppliers
        this.suppliers = [
            {
                id: 'supp_1',
                name: 'TechHub Ethiopia',
                contact: '0934567890',
                address: 'Addis Ababa, Bole',
                balance: 0,
                createdAt: new Date().toISOString()
            },
            {
                id: 'supp_2',
                name: 'Global Electronics',
                contact: '0945678901',
                address: 'Addis Ababa, Kazanchis',
                balance: 0,
                createdAt: new Date().toISOString()
            }
        ];
        Storage.save('suppliers', this.suppliers);
        
        // Sample Expense Types
        this.expenseTypes = [
            { id: 'exp_1', name: 'Rent' },
            { id: 'exp_2', name: 'Salary' },
            { id: 'exp_3', name: 'Transport' },
            { id: 'exp_4', name: 'Marketing' },
            { id: 'exp_5', name: 'Utilities' }
        ];
        Storage.save('expenseTypes', this.expenseTypes);
        
        // Mark as initialized
        localStorage.setItem('stockpro_has_run', 'true');
        
        console.log('✅ Sample data created:', this.products.length, 'products');
    },

    // Create default data (emergency)
    createDefaultData() {
        console.log('📦 Creating default data...');
        this.products = [];
        this.customers = [{ id: 'walkin', name: 'Walk-in Customer', contact: '', address: '', balance: 0, createdAt: new Date().toISOString() }];
        this.suppliers = [];
        this.expenseTypes = [];
        this.sales = [];
        this.purchases = [];
        this.directExpenses = [];
        this.returns = [];
        this.calculations = [];
        this.stockHistory = [];
        
        Storage.save('products', this.products);
        Storage.save('customers', this.customers);
        Storage.save('suppliers', this.suppliers);
        Storage.save('expenseTypes', this.expenseTypes);
    },

    // Financial reporting helper: voided sales remain stored for audit, but are not active transactions.
    isActiveSale(sale) {
        return !!sale && sale.voided !== true && sale.status !== 'void';
    },

    activeSales() {
        return (this.sales || []).filter(s => this.isActiveSale(s));
    },

    // Save specific store
    save(storeName) {
        if (this[storeName] !== undefined) {
            return Storage.save(storeName, this[storeName]) === true;
        }
        return false;
    },

    // Save all data
    saveAll() {
        const stores = ['products', 'sales', 'purchases', 'customers', 'suppliers', 'supplierAdvances', 'paymentLedger', 
                        'expenseTypes', 'directExpenses', 'returns', 'calculations', 'stockHistory', 'auditLog', 'accountingMeta',
                        'cashAccounts', 'moneyTransactions', 'peopleMoney', 'peopleMoneyTx', 'cashierSessions', 'cashCounts', 'cashReconciliations', 'branches', 'staffUsers', 'branchAccessMeta'];
        for (const store of stores) {
            if (!this.save(store)) throw new Error('Could not persist store: ' + store);
        }
        return true;
    },

    // Save state for undo
    saveUndoState(action = 'Action') {
        this.undoStack.push({
            products: JSON.parse(JSON.stringify(this.products)),
            sales: JSON.parse(JSON.stringify(this.sales)),
            purchases: JSON.parse(JSON.stringify(this.purchases)),
            customers: JSON.parse(JSON.stringify(this.customers)),
            suppliers: JSON.parse(JSON.stringify(this.suppliers)),
            supplierAdvances: JSON.parse(JSON.stringify(this.supplierAdvances || [])),
            paymentLedger: JSON.parse(JSON.stringify(this.paymentLedger || [])),
            expenseTypes: JSON.parse(JSON.stringify(this.expenseTypes)),
            directExpenses: JSON.parse(JSON.stringify(this.directExpenses)),
            returns: JSON.parse(JSON.stringify(this.returns)),
            calculations: JSON.parse(JSON.stringify(this.calculations)),
            stockHistory: JSON.parse(JSON.stringify(this.stockHistory)),
            auditLog: JSON.parse(JSON.stringify(this.auditLog || [])),
            accountingMeta: JSON.parse(JSON.stringify(this.accountingMeta || {version:5,migratedAt:null})),
            cashAccounts: JSON.parse(JSON.stringify(this.cashAccounts || [])),
            moneyTransactions: JSON.parse(JSON.stringify(this.moneyTransactions || [])),
            peopleMoney: JSON.parse(JSON.stringify(this.peopleMoney || [])),
            peopleMoneyTx: JSON.parse(JSON.stringify(this.peopleMoneyTx || [])),
            cashierSessions: JSON.parse(JSON.stringify(this.cashierSessions || [])),
            cashCounts: JSON.parse(JSON.stringify(this.cashCounts || [])),
            cashReconciliations: JSON.parse(JSON.stringify(this.cashReconciliations || [])),
            action: action
        });
        
        if (this.undoStack.length > 10) {
            this.undoStack.shift();
        }
    },

    // Create a deep snapshot of all mutable business data.
    createSnapshot() {
        const stores = ['products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger','expenseTypes','directExpenses','returns','calculations','stockHistory','auditLog','accountingMeta','cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','branches','staffUsers','branchAccessMeta'];
        const snapshot = {};
        stores.forEach(store => { snapshot[store] = JSON.parse(JSON.stringify(this[store] || [])); });
        return snapshot;
    },

    // Restore a snapshot in memory and persist it. Used to make multi-store operations atomic.
    restoreSnapshot(snapshot) {
        if (!snapshot) return;
        Object.keys(snapshot).forEach(store => { this[store] = JSON.parse(JSON.stringify(snapshot[store] || [])); });
        this.saveAll();
    },

    // Execute a business operation atomically from the app's authoritative point of view.
    // localStorage writes are synchronous, so the committed state is immediately readable.
    // IndexedDB is a durable mirror; callers that need the mirror confirmed should await
    // runAtomicDurable() instead.
    runAtomic(action, fn) {
        const snapshot = this.createSnapshot();
        try {
            const result = fn();
            this.saveAll();
            return result;
        } catch (error) {
            console.error('Atomic operation failed:', action, error);
            this.restoreSnapshot(snapshot);
            throw error;
        }
    },

    // Durable transaction helper for operations whose completion must wait until the
    // IndexedDB mirror has caught up with the synchronous localStorage commit.
    async runAtomicDurable(action, fn) {
        const snapshot = this.createSnapshot();
        try {
            const result = fn();
            this.saveAll();
            if (window.StorageIDB?.flush) await StorageIDB.flush();
            return result;
        } catch (error) {
            console.error('Durable atomic operation failed:', action, error);
            try {
                Object.keys(snapshot).forEach(store => {
                    this[store] = JSON.parse(JSON.stringify(snapshot[store] || []));
                });
                this.saveAll();
                if (window.StorageIDB?.flush) await StorageIDB.flush();
            } catch (rollbackError) {
                console.error('Durable rollback failed:', rollbackError);
            }
            throw error;
        }
    },

    // Undo last action
    undo() {
        if (this.undoStack.length < 1) {
            Toast.show('Nothing to undo', 'warning');
            return false;
        }
        
        const prev = this.undoStack.pop();
        this.products = prev.products || [];
        this.sales = prev.sales || [];
        this.purchases = prev.purchases || [];
        this.customers = prev.customers || [];
        this.suppliers = prev.suppliers || [];
        this.supplierAdvances = prev.supplierAdvances || [];
        this.paymentLedger = prev.paymentLedger || [];
        this.expenseTypes = prev.expenseTypes || [];
        this.directExpenses = prev.directExpenses || [];
        this.returns = prev.returns || [];
        this.calculations = prev.calculations || [];
        this.stockHistory = prev.stockHistory || [];
        this.auditLog = prev.auditLog || [];
        this.accountingMeta = prev.accountingMeta || {version:5,migratedAt:null};
        this.cashAccounts = prev.cashAccounts || [];
        this.moneyTransactions = prev.moneyTransactions || [];
        this.peopleMoney = prev.peopleMoney || [];
        this.peopleMoneyTx = prev.peopleMoneyTx || [];
        this.cashierSessions = prev.cashierSessions || [];
        this.cashCounts = prev.cashCounts || [];
        this.cashReconciliations = prev.cashReconciliations || [];
        
        this.saveAll();
        Toast.show('↩️ Undid: ' + prev.action, 'info');
        return true;
    }
};

// Expose State globally
window.State = State;

// Signal that State is ready
if (window.__notifyStateReady) {
    window.__notifyStateReady();
}

console.log('✅ State loaded successfully');