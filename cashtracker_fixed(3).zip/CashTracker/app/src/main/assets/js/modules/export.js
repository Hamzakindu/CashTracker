// ============================================
// EXPORT MODULE
// ============================================

(function() {
    'use strict';
    
    const MODULE_NAME = 'Export';
    
    console.log('📦 Registering ' + MODULE_NAME + '...');
    
    window.registerModule(MODULE_NAME, function() {
        console.log('✅ ' + MODULE_NAME + ' initializing...');
        
        const Export = {
            // Export all data to JSON
            async exportAllJSON() {
                const data = {
                    exportedAt: new Date().toISOString(),
                    appVersion: CONFIG.VERSION,
                    profileId: State.currentProfileId,
                    products: State.products,
                    sales: State.sales,
                    purchases: State.purchases,
                    customers: State.customers,
                    suppliers: State.suppliers,
                    expenseTypes: State.expenseTypes,
                    directExpenses: State.directExpenses,
                    returns: State.returns
                };
                
                const json = JSON.stringify(data, null, 2);
                const filename = `stockpro-full-backup-${new Date().toISOString().slice(0, 10)}.json`;
                try {
                    const result = await Helpers.downloadFile(json, filename, 'application/json');
                    if (result && result.confirmed) Toast.success('✅ Full backup saved to Downloads: ' + filename);
                    else Toast.info('Download requested: ' + filename + '. Check your Downloads list; the browser has not confirmed the save.');
                    return result;
                } catch (error) {
                    Toast.error('❌ Full backup export failed: ' + (error.message || error));
                    return { ok: false, error: error.message || String(error) };
                }
            },
            
            // Export to CSV
            async exportCSV() {
                let csv = '';
                
                // Products
                csv += '=== PRODUCTS ===\nName,Category,Buy Price,Sell Price,Stock\n';
                State.products.forEach(p => {
                    csv += `"${p.name}","${p.category || ''}",${p.buy || 0},${p.sell || 0},${p.stock || 0}\n`;
                });
                
                // Customers
                csv += '\n=== CUSTOMERS ===\nName,Phone,Address,Balance\n';
                State.customers.forEach(c => {
                    csv += `"${c.name}","${c.contact || ''}","${c.address || ''}",${c.balance || 0}\n`;
                });
                
                // Suppliers
                csv += '\n=== SUPPLIERS ===\nName,Phone,Address,Balance\n';
                State.suppliers.forEach(s => {
                    csv += `"${s.name}","${s.contact || ''}","${s.address || ''}",${s.balance || 0}\n`;
                });
                
                // Sales
                csv += '\n=== SALES ===\nDate,Customer,Total,Paid,Balance,Profit\n';
                State.activeSales().forEach(s => {
                    csv += `"${s.date}","${s.customer || ''}",${s.total || 0},${s.paymentReceived || 0},${s.debitRemaining || 0},${s.profit || 0}\n`;
                });
                
                // Purchases
                csv += '\n=== PURCHASES ===\nDate,Supplier,Total,Paid,Balance\n';
                State.purchases.forEach(p => {
                    csv += `"${p.date}","${p.supplier || ''}",${p.total || 0},${p.paid || 0},${p.debit || 0}\n`;
                });
                
                // Expenses
                csv += '\n=== EXPENSES ===\nDate,Type,Amount,Reason\n';
                State.directExpenses.forEach(e => {
                    csv += `"${e.date}","${e.typeName || ''}",${e.amount || 0},"${e.reason || ''}"\n`;
                });
                
                try {
                    const filename = `stockpro-data-${new Date().toISOString().slice(0, 10)}.csv`;
                    const result = await Helpers.downloadFile(csv, filename, 'text/csv');
                    if (result && result.confirmed) Toast.success('✅ CSV saved to Downloads: ' + filename);
                    else Toast.info('CSV download requested: ' + filename + '. Check your Downloads list.');
                    return result;
                } catch (error) {
                    Toast.error('❌ CSV export failed: ' + (error.message || error));
                    return { ok: false, error: error.message || String(error) };
                }
            }
        };
        
        window.Export = Export;
        console.log('✅ ' + MODULE_NAME + ' loaded successfully');
        return Export;
    });
    
})();