import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const read = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');

test('Android download bridge reports completion only through native callback', () => {
  const shim = read('../app/src/main/assets/js/android-shim.js');
  assert.match(shim, /window\.Android\.saveFile\([^;]+,\s*id\)/);
  assert.match(shim, /window\.__cashTrackerDownloadResult/);
  assert.match(shim, /Android did not confirm the file save/);
});

test('Backup export waits for download result before showing success', () => {
  const backup = read('../app/src/main/assets/js/backup.js');
  assert.match(backup, /async exportBackup\(\)/);
  assert.match(backup, /await Helpers\.downloadFile\(json, filename, 'application\/json'\)/);
  assert.match(backup, /if \(result\.confirmed\)/);
  assert.match(backup, /Backup export failed/);
});

test('Local safety snapshot is not described as a Downloads file', () => {
  const backup = read('../app/src/main/assets/js/backup.js');
  assert.match(backup, /Local safety copy saved inside CashTracker on this device\. This is NOT a file in Downloads/);
});

test('Backup reminder records a date only after successful export', () => {
  const nag = read('../app/src/main/assets/js/modules/backup-nag.js');
  assert.match(nag, /await o\.apply\(Backup,arguments\)/);
  assert.match(nag, /if\(result&&result\.ok===true\)localStorage\.setItem\(K/);
});

test('Native writer verifies non-empty bytes and finalizes MediaStore row before success', () => {
  const main = read('../app/src/main/java/com/example/cashtracker/MainActivity.kt');
  assert.match(main, /bytes\.isEmpty\(\)/);
  assert.match(main, /contentResolver\.update\(uri/);
  assert.match(main, /if \(updated <= 0\)/);
  assert.match(main, /f\.length\(\) != bytes\.size\.toLong\(\)/);
  assert.match(main, /window\.__cashTrackerDownloadResult/);
});


test('Android Downloads entry is read back and verified after finalization', () => {
  const main = read('../app/src/main/java/com/example/cashtracker/MainActivity.kt');
  assert.match(main, /contentResolver\.query\(uri, arrayOf\(MediaStore\.Downloads\.SIZE, MediaStore\.Downloads\.IS_PENDING\)/);
  assert.match(main, /verifiedSize != bytes\.size\.toLong\(\)/);
  assert.match(main, /Downloads verification failed/);
});

test('Backup export adds a SHA-256 integrity seal and restore verifies it before writes', () => {
  const backup = read('../app/src/main/assets/js/backup.js');
  assert.match(backup, /data\.backupIntegrity = await this\.createIntegritySeal\(data\)/);
  assert.match(backup, /await this\.verifyIntegritySeal\(data\)/);
  assert.match(backup, /Backup integrity check failed/);
  assert.match(backup, /compatibility with older, unsealed JSON backups/);
});

test('SHA-256 backup seal detects payload modification while legacy backups remain compatible', async () => {
  const vm = await import('node:vm');
  const { webcrypto } = await import('node:crypto');
  const source = read('../app/src/main/assets/js/backup.js');
  const context = {
    console, crypto: webcrypto, TextEncoder,
    window: { addEventListener() {} },
    Storage: { getSetting() { return 'disabled'; } }
  };
  vm.runInNewContext(source + '\n;globalThis.__BackupForTest = Backup;', context);
  const backup = context.__BackupForTest;
  const data = { format: 'StockPro', products: [{ id: 'p1', name: 'Test' }], sales: [], purchases: [], customers: [], suppliers: [] };
  data.backupIntegrity = await backup.createIntegritySeal(data);
  assert.equal(data.backupIntegrity.algorithm, 'SHA-256');
  assert.equal(await backup.verifyIntegritySeal(data), true);
  data.products[0].name = 'Modified';
  await assert.rejects(() => backup.verifyIntegritySeal(data), /integrity check failed/i);
  assert.equal(await backup.verifyIntegritySeal({ products: [], sales: [], purchases: [], customers: [], suppliers: [] }), true);
});
