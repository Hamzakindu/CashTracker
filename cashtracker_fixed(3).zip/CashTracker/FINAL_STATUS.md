# CashTracker V8.40 — Release Status

**Version:** 5.10.84  
**Android version code:** 84  
**Release:** Professional financial report exports

## Delivered
- Print-ready PDF workflow for all financial statements and reports.
- Excel-compatible SpreadsheetML exports for balance sheet, receivable/payable aging, inventory valuation, cash flow, Profit & Loss and period comparison.
- Export metadata includes selected dates and report notes.
- Existing CSV export features remain available.

## Data protection
All new export functions are read-only. They extract data from the rendered report and do not modify financial transactions, balances, accounting journal entries, storage schemas or the persistent posting ledger. No destructive migration was introduced.

## Verification
- Automated tests: **262 passed, 0 failed**.
- TypeScript typecheck: passed.
- Android asset TypeScript build: passed.
- JavaScript syntax checks: passed.
- JSON and Android manifest validation: passed.
- ZIP integrity: passed.

## Not verified
- Vite web build (Vite dependency unavailable in the supplied environment).
- Android APK/Gradle build.
- Physical Android device printing / Save as PDF and native download behavior.
- Live-data backup/restore, cloud deployment and multi-device synchronization.

This is a tested source release candidate, not a production-certified APK. Back up current business data before installing an app build made from this source.
