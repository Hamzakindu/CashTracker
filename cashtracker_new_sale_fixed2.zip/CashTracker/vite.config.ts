import { defineConfig } from 'vite';
export default defineConfig({
  build: { lib: { entry: 'src-ts/index.ts', formats: ['es'], fileName: () => 'cashtracker-core.js' }, outDir: 'dist-ts', emptyOutDir: true },
  esbuild: { target: 'es2022' }
});
