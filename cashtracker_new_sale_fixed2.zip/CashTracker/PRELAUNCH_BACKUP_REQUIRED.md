# Before installing this build

1. Open the currently installed CashTracker.
2. Use **Export Backup** and save the plain `.json` file somewhere outside the app (Google Drive, Files, etc.).
3. Keep that file until you have successfully tested restore on the new build.

This build no longer performs the old first-start money-store rewrite automatically. It still keeps a local safety snapshot, but the plain JSON export is the primary recovery copy.

## Restore test

After installing the new build:

1. Export a fresh plain JSON backup.
2. Clear app data.
3. Launch CashTracker and choose **Import Backup**.
4. Select the JSON backup.
5. Confirm products, sales, purchases, customers, suppliers and balances.

Encrypted Telegram/Cloudflare backups use a passphrase-derived AES-256-GCM key (PBKDF2-SHA256, random salt per backup). The passphrase is required for restore. Plain JSON backups remain accepted by local import and restore flows.
