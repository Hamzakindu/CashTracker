# CashTracker final hardening status

Version: 5.10.43
Application ID: com.stockpro.banksms
Compile/target SDK: 35

## 16-item follow-up hardening

1. Plain JSON pre-launch backup documented; first-start money-store rewrite removed.
2. AES-GCM cloud backups now derive the key from a user passphrase with PBKDF2-SHA256 and a random per-backup salt. Plain JSON restore remains supported.
3. Entry drafts are cleared after successful saves and otherwise ask whether to restore an unfinished draft.
4. Cloudflare Worker + D1 deployment files are in cloudflare/worker; release signing secrets remain GitHub/owner-managed.
5. Bank SMS sender allowlist covers CBE, Telebirr, Awash, Dashen and BOA for native SMS ingestion.
6. Legacy native SMS queue records receive queue IDs before acknowledgement.
7. Duplicate SMS without references is hashed from normalized text; pasted duplicates therefore do not depend on a fresh timestamp.
8. Bulk SMS approval creates one undo snapshot before posting.
9. Parser direction handles sent/received wording and labelled amounts before balance values.
10. Node tests import the real browser parser/money implementations; a Kotlin SmsParser JUnit test is included.
11. Runtime money helpers use integer minor-unit arithmetic for common sales/purchase calculations; persistence remains integer-minor-unit encoded.
12. IndexedDB is the primary business-data store when available; localStorage is retained as a synchronous fallback/recovery copy.
13. The app CSP no longer allows script `unsafe-inline`; legacy inline event attributes were converted to CSP-safe delegated event listeners.
14. Version name is sourced from Gradle `VERSION_NAME`; AppMint metadata is aligned to 5.10.43 / versionCode 43.
15. compileSdk/targetSdk are 35.
16. src-ts is wired to Vite and the CI workflow runs typecheck/tests/build for the TypeScript core.

## Verification in this environment

- Node parser/money tests: 7/7 passed.
- TypeScript typecheck: passed.
- JavaScript syntax checks: passed for the newly hardened JS modules.
- Android Gradle build: not executed here because a Gradle wrapper is not present in the project/container; GitHub Actions is configured to build the signed release APK.

## Cloud backend migration

- Firebase web SDKs/config/backend were removed from the Android asset runtime.
- CashTracker cloud sync is now Cloudflare Workers + D1.
- Cloudflare sync payloads are encrypted client-side before upload.
- Existing Telegram/BotSync Cloudflare integration was preserved and is not replaced by the new sync Worker.
- Cloudflare deployment requires the user's own Cloudflare account and D1 database; no account credentials are stored in the repository.
