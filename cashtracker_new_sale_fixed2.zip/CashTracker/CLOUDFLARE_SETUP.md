# CashTracker Cloudflare setup

This build removes Firebase as a CashTracker cloud dependency.

## What remains unchanged

The existing Telegram bot integration is separate. Its Cloudflare Worker URL and `PUSH_KEY` remain configured through **Tools → Telegram bot (Cloudflare)**. Do not replace that Worker with the CashTracker sync Worker.

## CashTracker cloud sync

CashTracker cloud sync uses a separate Cloudflare Worker + D1 database. Business data is encrypted in the app before upload.

### Create the D1 database

From `cloudflare/worker`:

```bash
npx wrangler login
npx wrangler d1 create cashtracker
```

Copy the returned database ID into `cloudflare/worker/wrangler.toml`.

### Apply the schema

```bash
npx wrangler d1 execute cashtracker --remote --file=./schema.sql
```

### Deploy the sync Worker

```bash
npx wrangler deploy
```

Copy the resulting Worker URL into CashTracker's **Cloud → Worker address** field.

### First device

1. Open CashTracker.
2. Tap **Cloud**.
3. Enter the sync Worker URL.
4. Create an account.
5. Upload the current profile.

### Second device

1. Install the same CashTracker release.
2. Tap **Cloud**.
3. Enter the same sync Worker URL.
4. Sign in with the same account.
5. Restore/download the cloud copy.

### Important

The Cloudflare account password also unlocks the client-side AES-GCM encrypted cloud data. Keep it safe. If it is forgotten, the server cannot decrypt the stored business data for you.

Telegram backup/restore remains available independently of this cloud sync system.
