# CashTracker release signing

The repository no longer contains a debug keystore. GitHub Actions signs `assembleRelease` builds using GitHub Secrets.

Create these repository secrets:

- `RELEASE_KEYSTORE_B64` — base64 contents of the generated `cashtracker-release.jks`
- `RELEASE_STORE_PASSWORD` — keystore password
- `RELEASE_KEY_ALIAS` — `cashtracker-release`
- `RELEASE_KEY_PASSWORD` — private-key password

The workflow sets `versionCode` to `${GITHUB_RUN_NUMBER}` and publishes only the signed release APK. It does not use the old ZIP fallback and does not publish debug APKs.

For the generated key from this build, use the accompanying secret bundle outside the project ZIP. Never commit the `.jks`, password file, or base64 key to Git.

Important: a release-signed APK cannot update an APK installed with a different signing key (including the old repository debug key). If the existing installation is debug-signed, uninstall it only after exporting/backing up the business data, then install the release-signed APK.
