export const MONEY_SCALE=100;
export function toMinor(value:number):number{if(!Number.isFinite(value))throw new Error('Invalid money');return Math.round(value*MONEY_SCALE)}
export function fromMinor(value:number):number{if(!Number.isFinite(value))throw new Error('Invalid minor amount');return value/MONEY_SCALE}
export function add(...values:number[]):number{return fromMinor(values.reduce((sum,v)=>sum+toMinor(v),0))}
export function subtract(a:number,b:number):number{return fromMinor(toMinor(a)-toMinor(b))}
export function multiply(a:number,b:number):number{return fromMinor(Math.round(toMinor(a)*b))}
export function divide(a:number,b:number):number{return b===0?0:fromMinor(Math.round(toMinor(a)/b))}
export function addMinor(a:number,b:number):number{return toMinor(a/100)+toMinor(b/100)}
