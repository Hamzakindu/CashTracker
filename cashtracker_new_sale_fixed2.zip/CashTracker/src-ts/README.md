# CashTracker TypeScript migration seam
This directory is the typed core for money math and SMS parsing. The production WebView still loads the legacy JS modules for compatibility; new code should be added here first, with tests under `tests/`.
