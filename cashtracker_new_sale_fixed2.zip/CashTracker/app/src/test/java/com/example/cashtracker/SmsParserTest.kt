package com.example.cashtracker

import org.junit.Assert.*
import org.junit.Test

class SmsParserTest {
    @Test fun outgoingSentReceivedUsesOutDirection() {
        val p = SmsParser.parse("CBE: Amount debited 1,250 ETB. Sent to ABEBE, received by ABEBE")!!
        assertEquals(1250.0, p.getDouble("amount"), 0.001)
        assertEquals("out", p.getString("dir"))
    }
    @Test fun incomingCreditUsesInDirection() {
        val p = SmsParser.parse("Amount credited: 850 ETB received from ABEBE")!!
        assertEquals("in", p.getString("dir"))
    }
}
