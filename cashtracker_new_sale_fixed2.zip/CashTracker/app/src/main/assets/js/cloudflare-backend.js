// CASH TRACKER CLOUD - CLOUDFLARE WORKERS + D1
// Offline-first. Telegram/BotSync remains completely independent.
(function(){
  'use strict';
  const STORE_NAMES = ['products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger','expenseTypes','directExpenses','returns','calculations','stockHistory','auditLog','accountingMeta','cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','branches','staffUsers','branchAccessMeta'];
  const TOKEN_KEY='stockpro_cloudflare_session';
  const EMAIL_KEY='stockpro_cloud_email';
  const URL_KEY='cashtracker_cloudflare_worker_url';
  const PASS_KEY='cashtracker_cloud_passphrase_session';
  const DEVICE_KEY='stockpro_cloud_device_id';
  const STATUS_ID='cloudSyncStatus';
  const CHUNK_SIZE=650000;
  let url=(window.CASH_TRACKER_CLOUDFLARE?.WORKER_URL||localStorage.getItem(URL_KEY)||'').replace(/\/+$/,'');
  const CloudSync={
    ready:false,busy:false,queue:new Set(),timer:null,initialized:false,passphrase:null,
    init(){
      if(this.initialized)return; this.initialized=true;
      if(!localStorage.getItem(DEVICE_KEY)) localStorage.setItem(DEVICE_KEY,'dev_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,10));
      this.patchStorage(); this.updateHeader();
      if(url){this.setStatus('☁️ Cloudflare ready'); this.restoreSession();}
      else this.setStatus('☁️ Cloudflare not configured');
    },
    configure(workerUrl){
      try{const u=new URL(workerUrl.trim()); if(u.protocol!=='https:')throw new Error('Worker URL must use HTTPS'); url=u.origin; localStorage.setItem(URL_KEY,url); window.CASH_TRACKER_CLOUDFLARE.WORKER_URL=url; this.setStatus('☁️ Cloudflare ready'); this.updateHeader(); return true;}catch(e){Toast.error(e.message);return false;}
    },
    getUrl(){return url||localStorage.getItem(URL_KEY)||'';},
    token(){return sessionStorage.getItem(TOKEN_KEY)||'';},
    email(){return localStorage.getItem(EMAIL_KEY)||'';},
    setStatus(text){const el=document.getElementById(STATUS_ID);if(el)el.textContent=text;},
    updateHeader(){
      const el=document.getElementById(STATUS_ID); if(!el)return;
      if(!this.getUrl())el.textContent='☁️ Cloud: not configured';
      else if(this.ready)el.textContent='☁️ Cloudflare: signed in';
      else el.textContent='☁️ Cloudflare: not signed in';
    },
    async request(path,opts={}){
      const base=this.getUrl(); if(!base)throw new Error('Configure the Cloudflare Worker URL first.');
      const headers=Object.assign({'Content-Type':'application/json'},opts.headers||{});
      const token=this.token(); if(token)headers.Authorization='Bearer '+token;
      const r=await fetch(base+path,Object.assign({},opts,{headers}));
      let data=null; try{data=await r.json();}catch(e){data={};}
      if(!r.ok)throw new Error(data.error||('Cloudflare request failed ('+r.status+')'));
      return data;
    },
    async register(email,password){
      this.configure(this.getUrl());
      if(!email||!password)throw new Error('Email and password are required.');
      if(password.length<8)throw new Error('Cloud password must be at least 8 characters.');
      const data=await this.request('/api/register',{method:'POST',body:JSON.stringify({email,password})});
      sessionStorage.setItem(TOKEN_KEY,data.token); localStorage.setItem(EMAIL_KEY,email); this.passphrase=password; this.ready=true; this.updateHeader();
      Toast.success('☁️ Cloudflare account created'); return data;
    },
    async signIn(email,password){
      if(!email||!password)throw new Error('Email and password are required.');
      if(password.length<8)throw new Error('Cloud password must be at least 8 characters.');
      const data=await this.request('/api/login',{method:'POST',body:JSON.stringify({email,password})});
      sessionStorage.setItem(TOKEN_KEY,data.token); localStorage.setItem(EMAIL_KEY,email); this.passphrase=password; this.ready=true; this.updateHeader();
      Toast.success('☁️ Signed in to CashTracker Cloud'); return data;
    },
    async restoreSession(){
      if(!this.token())return;
      try{const data=await this.request('/api/me');this.ready=!!data.ok;this.updateHeader();}
      catch(e){sessionStorage.removeItem(TOKEN_KEY);this.ready=false;this.updateHeader();}
    },
    async unlock(){
      if(this.passphrase&&this.passphrase.length>=8)return this.passphrase;
      const p=prompt('Enter your Cloudflare CashTracker password to unlock encrypted cloud data:');
      if(!p)throw new Error('Cloud password was cancelled.');
      if(p.length<8)throw new Error('Cloud password must be at least 8 characters.');
      this.passphrase=p; try{sessionStorage.setItem(PASS_KEY,'unlocked');}catch(e){} return p;
    },
    patchStorage(){
      if(!window.Storage||Storage.__cloudflarePatched)return;
      const originalSave=Storage.save.bind(Storage), originalRemove=Storage.remove.bind(Storage);
      Storage.save=(name,data)=>{const ok=originalSave(name,data);if(ok&&CloudSync.ready&&STORE_NAMES.includes(name))CloudSync.queueStore(name);return ok;};
      Storage.remove=(name)=>{const ok=originalRemove(name);if(ok&&CloudSync.ready&&STORE_NAMES.includes(name))CloudSync.queueStore(name);return ok;};
      Storage.__cloudflarePatched=true;
    },
    queueStore(name){this.queue.add(name);clearTimeout(this.timer);this.timer=setTimeout(()=>this.flushQueue(),2500);},
    async flushQueue(){
      if(!this.ready||this.busy||!this.queue.size)return;
      const stores=[...this.queue];this.queue.clear();this.busy=true;
      try{for(const s of stores)await this.uploadStore(s);this.setStatus('☁️ Cloudflare synced '+stores.length+' store'+(stores.length===1?'':'s'));}
      catch(e){stores.forEach(s=>this.queue.add(s));this.setStatus('⚠️ Cloud sync pending');console.error('Cloudflare sync error',e);}
      finally{this.busy=false;}
    },
    async uploadStore(storeName){
      if(!this.ready)throw new Error('Sign in first');
      const pass=await this.unlock();
      const data=State[storeName]!==undefined?State[storeName]:Storage.load(storeName);
      const encrypted=await BackupCrypto.encryptJson(data===undefined?[]:data,pass);
      const chunks=[];for(let i=0;i<encrypted.length;i+=CHUNK_SIZE)chunks.push(encrypted.slice(i,i+CHUNK_SIZE));
      await this.request('/api/stores/'+encodeURIComponent(State.currentProfileId||'default')+'/'+encodeURIComponent(storeName),{method:'PUT',body:JSON.stringify({chunks,deviceId:localStorage.getItem(DEVICE_KEY),appVersion:(window.CONFIG&&CONFIG.VERSION)||'unknown'})});
    },
    async downloadStore(storeName){
      const pass=await this.unlock();
      const data=await this.request('/api/stores/'+encodeURIComponent(State.currentProfileId||'default')+'/'+encodeURIComponent(storeName));
      if(!data.exists)return false;
      const encrypted=(data.chunks||[]).join('');
      const parsed=await BackupCrypto.decryptJson(encrypted,pass); Storage.save(storeName,parsed); return true;
    },
    async uploadAll(){
      if(!this.ready){this.openAuth();return false;} if(this.busy)return false;
      if(!confirm('Upload the current CashTracker profile to Cloudflare?\n\nThis becomes the cloud copy for this profile.'))return false;
      this.busy=true;try{for(const s of STORE_NAMES)await this.uploadStore(s);Toast.success('☁️ CashTracker data uploaded to Cloudflare');this.setStatus('☁️ Cloud backup complete');return true;}catch(e){Toast.error('Cloud upload failed: '+e.message);return false;}finally{this.busy=false;}
    },
    async downloadAll(){
      if(!this.ready){this.openAuth();return false;}if(this.busy)return false;
      if(!confirm('Download the Cloudflare copy and replace this device profile?\n\nExport a local backup first if you have unsynced changes.'))return false;
      this.busy=true;try{if(State.saveUndoState)State.saveUndoState('Before Cloudflare restore');let n=0;for(const s of STORE_NAMES){if(await this.downloadStore(s))n++;}await State.loadAllData();this.refreshApp();Toast.success('☁️ Cloudflare data restored ('+n+' stores)');return true;}catch(e){Toast.error('Cloud restore failed: '+e.message);return false;}finally{this.busy=false;}
    },
    async signOut(){try{if(this.token())await this.request('/api/logout',{method:'POST'});}catch(e){}sessionStorage.removeItem(TOKEN_KEY);this.passphrase=null;this.ready=false;this.updateHeader();this.setStatus('☁️ Cloudflare: not signed in');},
    openAuth(){
      let m=document.getElementById('cloudAuthModal');if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='cloudAuthModal';m.innerHTML='<div class="modal" style="max-width:460px"><button class="close-btn" data-cashtracker-onclick="Modals.close(\'cloudAuthModal\')">✕</button><h3>☁️ CashTracker Cloudflare</h3><p style="opacity:.75">Cloud data is encrypted in the app before it reaches Cloudflare. The server stores only encrypted data.</p><div class="form-group"><label>Worker address</label><input id="cloudWorkerUrl" class="form-control" type="url" placeholder="https://your-worker.yourname.workers.dev"></div><div id="cloudAuthMessage" style="margin:8px 0;font-size:.85rem"></div><div class="form-group"><label>Email</label><input id="cloudEmail" class="form-control" type="email" autocomplete="username"></div><div class="form-group"><label>Password</label><input id="cloudPassword" class="form-control" type="password" autocomplete="new-password"></div><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn-primary" data-cashtracker-onclick="CloudSync.loginFromModal()">Sign in</button><button class="btn btn-success" data-cashtracker-onclick="CloudSync.signupFromModal()">Create account</button></div><hr><small style="opacity:.7">Use at least 8 characters. This password also unlocks your client-side encrypted cloud data. Keep it safe.</small></div>';document.body.appendChild(m);}document.getElementById('cloudWorkerUrl').value=this.getUrl();document.getElementById('cloudEmail').value=this.email();document.getElementById('cloudPassword').value='';document.getElementById('cloudAuthMessage').textContent='';Modals.open('cloudAuthModal');
    },
    async loginFromModal(){try{if(!this.configure(document.getElementById('cloudWorkerUrl').value))return;await this.signIn(document.getElementById('cloudEmail').value.trim(),document.getElementById('cloudPassword').value);Modals.close('cloudAuthModal');}catch(e){document.getElementById('cloudAuthMessage').textContent='❌ '+e.message;}},
    async signupFromModal(){try{if(!this.configure(document.getElementById('cloudWorkerUrl').value))return;await this.register(document.getElementById('cloudEmail').value.trim(),document.getElementById('cloudPassword').value);Modals.close('cloudAuthModal');}catch(e){document.getElementById('cloudAuthMessage').textContent='❌ '+e.message;}},
    openPanel(){
      if(!this.ready){this.openAuth();return;}let m=document.getElementById('cloudPanelModal');if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='cloudPanelModal';m.innerHTML='<div class="modal" style="max-width:460px"><button class="close-btn" data-cashtracker-onclick="Modals.close(\'cloudPanelModal\')">✕</button><h3>☁️ CashTracker Cloudflare</h3><div id="cloudPanelUser" style="margin-bottom:12px"></div><div style="display:grid;gap:8px"><button class="btn btn-primary" data-cashtracker-onclick="CloudSync.uploadAll()">⬆️ Upload current data</button><button class="btn btn-success" data-cashtracker-onclick="CloudSync.downloadAll()">⬇️ Restore cloud data</button><button class="btn btn-outline" data-cashtracker-onclick="CloudSync.flushQueue()">🔄 Sync pending changes</button><button class="btn btn-danger" data-cashtracker-onclick="CloudSync.signOut();Modals.close(\'cloudPanelModal\')">Sign out</button></div><p style="font-size:.75rem;opacity:.7;margin-top:12px">Cloudflare stores encrypted CashTracker data separated by account and profile. Telegram remains independent.</p></div>';document.body.appendChild(m);}document.getElementById('cloudPanelUser').textContent=this.email()+' · '+this.getUrl();Modals.open('cloudPanelModal');
    },
    refreshApp(){try{if(window.Dashboard?.render)Dashboard.render();if(window.Tabs?.refreshCurrent)Tabs.refreshCurrent();else if(window.Tabs?.renderCurrent)Tabs.renderCurrent();}catch(e){console.warn('Cloud refresh UI',e);}},
    authError(e){return e?.message||String(e)}
  };
  window.CloudSync=CloudSync;
  document.addEventListener('DOMContentLoaded',()=>setTimeout(()=>CloudSync.init(),80));
  window.addEventListener('online',()=>{CloudSync.updateHeader();if(CloudSync.ready)CloudSync.flushQueue();});
  window.addEventListener('offline',()=>CloudSync.updateHeader());
})();
