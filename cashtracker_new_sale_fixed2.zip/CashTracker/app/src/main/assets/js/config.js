// ============================================
// CONFIGURATION - FIXED
// ============================================

// Check if CONFIG already exists
if (typeof window.CONFIG === 'undefined') {
    
    const CONFIG = {
        APP_NAME: 'CashTracker',
        VERSION: '5.10.43',
        
        // Telegram Settings
        // IMPORTANT: The bot token is intentionally NOT bundled in the app.
        // Configure it from Telegram Settings at runtime.

        TELEGRAM: {
            TOKEN: (localStorage.getItem('stockpro_telegram_bot_token') || '')
        },
        
        // Storage
        STORAGE_PREFIX: 'SMDB_',
        
        // UI
        TOAST_DURATION: 3500,
        MAX_UNDO_STACK: 10,
        MAX_PRODUCT_IMAGES: 5,
        IMAGE_COMPRESSION: 0.6,
        IMAGE_MAX_DIMENSION: 400,
        
        // Backup
        DEFAULT_BACKUP_FREQUENCY: 24, // hours
        BACKUP_CHECK_INTERVAL: 3600000, // 1 hour in ms
    };
    
    window.CONFIG = CONFIG;
    console.log('✅ Config loaded successfully');
    
} else {
    console.log('✅ Config already exists');
}