/* Money math: runtime values stay numeric for compatibility; persistent monetary fields are integer minor units. */
(function(){'use strict';
const KEYS=new Set(['amount','total','grandTotal','cost','profit','buy','sell','price','paid','debit','debitRemaining','paymentReceived','advanceUsed','excessPayment','excessPaid','openingBalance','balance','difference','expectedBalance','actualBalance','refundPerUnit','totalRefund','costAmount','customerAdvance','supplierAdvance']);
const SCALE=100;
function minor(v){const n=Number(v);return Number.isFinite(n)?Math.round(n*SCALE):0}
function major(v){const n=Number(v);return Number.isFinite(n)?n/SCALE:0}
function encode(value){
 if(Array.isArray(value))return value.map(encode);
 if(value&&typeof value==='object'){const out={};for(const [k,v] of Object.entries(value)){if(KEYS.has(k)&&typeof v==='number'&&Number.isFinite(v)){out[k+'Minor']=minor(v);continue;}out[k]=encode(v);}out.__moneyMinorV1=true;return out;}
 return value;
}
function decode(value){
 if(Array.isArray(value))return value.map(decode);
 if(value&&typeof value==='object'){const out={};for(const [k,v] of Object.entries(value)){if(k==='__moneyMinorV1')continue;if(k.endsWith('Minor')&&KEYS.has(k.slice(0,-5))){out[k.slice(0,-5)]=major(v);continue;}out[k]=decode(v);}return out;}
 return value;
}
function add(...vs){return major(vs.reduce((a,v)=>a+minor(v),0))} function sub(a,b){return major(minor(a)-minor(b))} function mul(a,b){return major(Math.round(minor(a)*Number(b||0)))} function div(a,b){return Number(b)?major(Math.round(minor(a)/Number(b))):0} function round(v){return major(minor(v))} window.Money={SCALE,minor,major,encode,decode,add,sub,mul,div,round,format(v){return 'ETB '+major(minor(v)).toFixed(2)}};
})();
