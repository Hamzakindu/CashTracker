/* Remember the last successful counterparty/account/type for fast repeat entries. */
(function(){'use strict';
const KEY='cashtracker_entry_memory_v1';
function read(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch(e){return {}}}
function write(x){try{localStorage.setItem(KEY,JSON.stringify(x))}catch(e){}}
function remember(type, record){const all=read();all[type]={...all[type],last:{customerId:record.customerId||'',supplierId:record.supplierId||'',personId:record.personId||'',accountId:record.accountId||'',paymentMethod:record.paymentMethod||'',expenseTypeId:record.expenseTypeId||'',date:record.date||''},byParty:{...(all[type]?.byParty||{})}};const party=record.customerId||record.supplierId||record.personId;if(party)all[type].byParty[party]=all[type].last;write(all)}
function last(type,party){const x=read()[type];return x?.byParty?.[party]||x?.last||null}
function apply(type, party){const x=last(type,party);if(!x)return false;const set=(id,v)=>{const e=document.getElementById(id);if(e&&v!==undefined&&v!=='')e.value=v};if(type==='sale'){set('sellCustomerId',x.customerId);set('sellPaymentMethod',x.paymentMethod);set('sellMoneyAccount',x.accountId);set('sellExpenseId',x.expenseTypeId);set('sellCustomerSearch',(State.customers||[]).find(c=>c.id===x.customerId)?.name||'');const e=document.getElementById('sellCustomerId');if(e)e.dispatchEvent(new Event('change'));}if(type==='purchase'){set('purchaseSupplier',x.supplierId);set('purchaseMoneyAccount',x.accountId);set('purchasePaymentMethod',x.paymentMethod);set('purchaseSupplierSearch',(State.suppliers||[]).find(s=>s.id===x.supplierId)?.name||'');const e=document.getElementById('purchaseSupplier');if(e)e.dispatchEvent(new Event('change'));}if(type==='peopleMoney'){set('pmPerson',x.personId);set('pmKind',x.entryKind);set('pmAccount',x.accountId);if(x.date)set('pmDate',x.date);}return true}
window.EntryMemory={remember,last,apply,clear(){localStorage.removeItem(KEY)}};
})();
