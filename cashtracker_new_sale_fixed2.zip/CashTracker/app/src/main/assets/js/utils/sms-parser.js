// Shared bank SMS parser used by the Web/PWA path and Node tests.
(function(){'use strict';
const BANKS=[['commercial bank of ethiopia','CBE'],['cbe','CBE'],['awash','Awash'],['dashen','Dashen'],['bank of abyssinia','BOA'],['boa','BOA'],['telebirr','Telebirr']];
const DEB=/(?:debited|spent|purchase|withdrawn|withdrawal|paid|payment|sent|charged|deducted|transferred|bought|outgoing)/i;
const CRE=/(?:credited|received|deposit|salary|refund|cashback|incoming)/i;
const BAL=/(?:current\s+balance|available\s+balance|avl\.?\s*bal(?:ance)?|balance|bal)\s*(?:is|:)?\s*(?:etb|birr|br)?\s*([0-9][0-9,]*(?:\.[0-9]+)?)/i;
const REF=/(?:ref(?:erence)?|txn(?:\.?|\s*id)?|transaction\s*id|trx)\s*[:#-]?\s*([A-Za-z0-9-]{4,40})/i;
const AMOUNT_LABEL=/(?:amount|amt|transaction\s+amount|debit(?:ed)?|credit(?:ed)?|spent|paid|received|withdrawn|sent|transferred)\s*(?:is|:|=)?\s*(?:etb|birr|br)?\s*([0-9][0-9,]*(?:\.[0-9]+)?)/i;
function num(x){return Number(String(x).replace(/,/g,''))}
function detectBank(t){const l=t.toLowerCase();return BANKS.find(x=>l.includes(x[0]))?.[1]||''}
function parse(body){
 const t=String(body||'').trim();if(!t)return null;const bank=detectBank(t);const bm=t.match(BAL);const b=bm?t.replace(bm[0],' '):t;
 const labelled=b.match(AMOUNT_LABEL);const currency=b.match(/(?:etb|birr|br|rs\.?|inr|usd|egp|kes|ngn|sar|aed|eur|gbp|[$€£₦₹])\s*([0-9][0-9,]*(?:\.[0-9]+)?)/i)||b.match(/([0-9][0-9,]*(?:\.[0-9]+)?)\s*(?:etb|birr|br|rs|inr|usd|egp|kes|ngn|sar|aed|eur|gbp|[$€£₦₹])(?![a-z])/i);
 const amount=labelled?num(labelled[1]):currency?num(currency[1]):null;if(!(amount>0))return null;
 const lower=b.toLowerCase();const sentReceived=/sent[\s\S]{0,80}received\s+by/i.test(lower)||/received\s+by[\s\S]{0,80}sent/i.test(lower);
 let dir='out';if(sentReceived){dir=/sent[\s\S]{0,40}received\s+by/i.test(lower)?'out':'in';}else{const d=lower.search(DEB),c=lower.search(CRE);dir=c>=0&&(d<0||c<d)?'in':'out';}
 const wm=b.match(/(?:\bat\b|\bto\b|\bfrom\b|@|towards)\s+([A-Za-z0-9&.'\- ]{2,40}?)(?=\s+(?:on|using|via|ref|bal|a\/c|acct|card|dated|with|your|and|txn|transaction)\b|[.,;(]|$)/i);
 return {amount,dir,who:wm?wm[1].trim():'',bal:bm?num(bm[1]):null,reference:(t.match(REF)||[])[1]||'',bankName:bank};
}
window.BankSmsParser={parse,detectBank};
if(typeof globalThis!=='undefined')globalThis.BankSmsParser=globalThis.BankSmsParser||{parse,detectBank};
})();
