/* CashTracker durable storage: IndexedDB is the primary store when available.
 * localStorage is retained as a synchronous fallback and recovery copy.
 */
(function(){'use strict';
const DB='cashtracker_v3',VER=1,STORE='records';let dbPromise=null;const cache=new Map();
function open(){if(dbPromise)return dbPromise;dbPromise=new Promise((resolve,reject)=>{if(!window.indexedDB)return reject(new Error('IndexedDB unavailable'));const r=indexedDB.open(DB,VER);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(STORE))r.result.createObjectStore(STORE,{keyPath:'key'});};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error||new Error('IndexedDB open failed'));});return dbPromise}
async function put(key,value){const db=await open();cache.set(key,value);return new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).put({key,value,updatedAt:Date.now()});tx.oncomplete=()=>resolve(true);tx.onerror=()=>reject(tx.error||new Error('IndexedDB write failed'));})}
async function get(key){if(cache.has(key))return cache.get(key);const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readonly'),r=tx.objectStore(STORE).get(key);r.onsuccess=()=>{const v=r.result?.value;if(r.result)cache.set(key,v);resolve(v)};r.onerror=()=>reject(r.error||new Error('IndexedDB read failed'));})}
async function remove(key){cache.delete(key);const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).delete(key);tx.oncomplete=()=>resolve(true);tx.onerror=()=>reject(tx.error||new Error('IndexedDB delete failed'));})}
async function allForProfile(pid){const prefix='SMDB_'+pid+'_';const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readonly'),req=tx.objectStore(STORE).getAll();req.onsuccess=()=>{const out=req.result.filter(x=>String(x.key).startsWith(prefix));out.forEach(x=>cache.set(x.key,x.value));resolve(out)};req.onerror=()=>reject(req.error||new Error('IndexedDB read failed'));})}
async function quota(){if(!navigator.storage?.estimate)return null;try{return await navigator.storage.estimate()}catch(e){return null}}
async function bootstrap(){
 try{await open();const pid=localStorage.getItem('currentProfileId')||'default';const idbRows=await allForProfile(pid);const idbKeys=new Set(idbRows.map(x=>x.key));
   // localStorage is imported only for keys that have no IndexedDB record, preserving newer IDB data.
   for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.startsWith('SMDB_'+pid+'_')&&!idbKeys.has(k)){try{await put(k,JSON.parse(localStorage.getItem(k)||'null'))}catch(e){console.warn('IDB import failed',k,e)}}}
   return true;
 }catch(e){console.warn('IndexedDB primary unavailable; localStorage fallback active:',e.message);return false}
}
async function checkAndWarn(){const q=await quota();if(q?.quota&&q?.usage&&q.usage/q.quota>.9){Toast?.warning?.('Storage is over 90% full. Export a backup and free space soon.');return false}return true}
window.StorageIDB={open,put,get,remove,quota,bootstrap,checkAndWarn,cache,has:key=>cache.has(key)};
})();
