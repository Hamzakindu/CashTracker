// ============================================
// STORAGE UTILITIES - DATA-SAFE V5.10.26
// ============================================
(function() {
    'use strict';
    const SAFETY_STORES = ['products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger','expenseTypes','directExpenses','returns','calculations','stockHistory','auditLog','accountingMeta','cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','branches','staffUsers','branchAccessMeta'];
    const SAFETY_PREFIX = 'stockpro_safety_';
    const MAX_SAFETY_SNAPSHOTS = 3;
    const Storage = {
        getProfileId() { try { return localStorage.getItem('currentProfileId') || 'default'; } catch(e) { return 'default'; } },
        getKey(storeName) { try { return 'SMDB_' + this.getProfileId() + '_' + storeName; } catch(e) { return 'SMDB_default_' + storeName; } },
        save(storeName, data) { try { const key=this.getKey(storeName), encoded=(window.Money?.encode?Money.encode(data):data), raw=JSON.stringify(encoded); if(raw.length>4*1024*1024) throw new Error('This record is too large to save safely. Export a backup first.'); localStorage.setItem(key, raw); if(window.StorageIDB?.put) StorageIDB.put(key,encoded).catch(e=>console.warn('IndexedDB primary write failed; localStorage retained:',e)); if(window.StorageIDB?.checkAndWarn) StorageIDB.checkAndWarn().catch(()=>{}); return true; } catch(e) { console.error('Storage save error:',e); try{Toast?.error?.('Could not save data: '+e.message)}catch(_){} return false; } },
        load(storeName) { try { const key=this.getKey(storeName); const rawIdb=window.StorageIDB?.cache?.has(key)?window.StorageIDB.cache.get(key):undefined; if(rawIdb!==undefined) return window.Money?.decode?Money.decode(rawIdb):rawIdb; const raw=localStorage.getItem(key); return raw ? (window.Money?.decode?Money.decode(JSON.parse(raw)):JSON.parse(raw)) : []; } catch(e) { console.error('Storage load error:',e); return []; } },
        getSetting(key, defaultValue=null) { try { const v=localStorage.getItem(key); return v!==null?v:defaultValue; } catch(e) { return defaultValue; } },
        setSetting(key,value) { try { localStorage.setItem(key,value); return true; } catch(e) { return false; } },
        remove(storeName) { try { const key=this.getKey(storeName); localStorage.removeItem(key); if(window.StorageIDB?.remove) StorageIDB.remove(key).catch(()=>{}); return true; } catch(e) { return false; } },
        removeSetting(key) { try { localStorage.removeItem(key); return true; } catch(e) { return false; } },
        hasSetting(key) { try { return localStorage.getItem(key)!==null; } catch(e) { return false; } },
        // Create exactly one immutable pre-update snapshot for each app version.
        // It is made BEFORE State.loadAllData(), so a future initialization bug cannot erase the only recovery copy.
        createSafetySnapshot(version) {
            try {
                const pid=this.getProfileId();
                const key=SAFETY_PREFIX+pid+'_v'+String(version||'unknown').replace(/[^a-zA-Z0-9._-]/g,'_');
                if(localStorage.getItem(key)) return {created:false,key};
                const data={snapshotAt:new Date().toISOString(),profileId:pid,appVersion:String(version||'unknown'),stores:{}};
                let count=0;
                SAFETY_STORES.forEach(store=>{ const raw=localStorage.getItem(this.getKey(store)); if(raw!==null){ try{data.stores[store]=JSON.parse(raw); count++;}catch(e){data.stores[store]=null;} } });
                if(count===0) return {created:false,key,empty:true};
                localStorage.setItem(key,JSON.stringify(data));
                localStorage.setItem(SAFETY_PREFIX+pid+'_latest',key);
                // Keep only the newest few snapshots to avoid filling WebView localStorage.
                const prefix=SAFETY_PREFIX+pid+'_v';
                const keys=[];
                for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.indexOf(prefix)===0)keys.push(k);}
                keys.sort((a,b)=>{
                    try{return JSON.parse(localStorage.getItem(b)).snapshotAt.localeCompare(JSON.parse(localStorage.getItem(a)).snapshotAt)}catch(e){return b.localeCompare(a)}
                });
                keys.slice(MAX_SAFETY_SNAPSHOTS).forEach(k=>{try{localStorage.removeItem(k)}catch(e){}});
                return {created:true,key,count};
            } catch(e) { console.error('Safety snapshot error:',e); return {created:false,error:e.message}; }
        },
        getSafetySnapshot() {
            try { const pid=this.getProfileId(); const key=localStorage.getItem(SAFETY_PREFIX+pid+'_latest'); if(!key)return null; const raw=localStorage.getItem(key); return raw?JSON.parse(raw):null; } catch(e){return null;}
        },
        restoreSafetySnapshot() {
            try {
                const snap=this.getSafetySnapshot();
                if(!snap||!snap.stores)return {ok:false,error:'No safety snapshot found.'};
                let n=0;
                // Recovery means returning to the captured state, so remove stores that did not
                // exist in that snapshot instead of leaving mixed-version data behind.
                SAFETY_STORES.forEach(store=>{
                    const key=this.getKey(store);
                    if(Object.prototype.hasOwnProperty.call(snap.stores,store)){
                        localStorage.setItem(key,JSON.stringify(snap.stores[store])); n++;
                    } else {
                        localStorage.removeItem(key);
                    }
                });
                localStorage.setItem('stockpro_initialized_v2','true');
                return {ok:true,count:n,snapshotAt:snap.snapshotAt,appVersion:snap.appVersion};
            } catch(e){return {ok:false,error:e.message};}
        },
        safetyStores(){return SAFETY_STORES.slice();},
        clearAll() {
            try { SAFETY_STORES.forEach(store=>localStorage.removeItem(this.getKey(store))); return true; } catch(e) { console.error('Storage clearAll error:',e); return false; }
        }
    };
    window.Storage=Storage;
    console.log('\u2705 Data-safe Storage V5.10.26 loaded');
    if(window.__notifyStorageReady) window.__notifyStorageReady();
})();
