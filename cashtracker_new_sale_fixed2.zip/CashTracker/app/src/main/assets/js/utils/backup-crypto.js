// Passphrase-based AES-GCM backup encryption.
(function(){'use strict';
const ITER=210000, KEYLEN=256, ALG='AES-256-GCM';
function b64(bytes){let s='';bytes=new Uint8Array(bytes);for(let i=0;i<bytes.length;i+=0x8000)s+=String.fromCharCode.apply(null,bytes.subarray(i,i+0x8000));return btoa(s)}
function unb64(s){const raw=atob(s),a=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)a[i]=raw.charCodeAt(i);return a}
async function derive(pass,salt){if(!crypto?.subtle)throw new Error('Secure encryption is unavailable');if(!pass||String(pass).length<8)throw new Error('Backup passphrase must be at least 8 characters.');const base=await crypto.subtle.importKey('raw',new TextEncoder().encode(String(pass)),{name:'PBKDF2'},false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',salt,iterations:ITER,hash:'SHA-256'},base,{name:'AES-GCM',length:KEYLEN},false,['encrypt','decrypt'])}
function isEnvelope(x){return x&&x.v===2&&x.alg===ALG&&x.salt&&x.iv&&x.ciphertext}
async function encryptText(text,passphrase){const salt=crypto.getRandomValues(new Uint8Array(16)),iv=crypto.getRandomValues(new Uint8Array(12)),key=await derive(passphrase,salt);const ct=await crypto.subtle.encrypt({name:'AES-GCM',iv},key,new TextEncoder().encode(text));return JSON.stringify({v:2,alg:ALG,kdf:'PBKDF2-SHA256',iterations:ITER,salt:b64(salt),iv:b64(iv),ciphertext:b64(ct)})}
async function decryptText(envelope,passphrase){
 const x=typeof envelope==='string'?JSON.parse(envelope):envelope;
 if(!isEnvelope(x)){
   // Backward compatibility: old cloud/Telegram files were plain JSON or old v1
   // local-key envelopes. Plain JSON is deliberately accepted here; v1 is not,
   // because its key was device-local and cannot be safely reconstructed.
   if(x&&typeof x==='object'&&x.v===1&&x.alg==='AES-256-GCM') throw new Error('This old encrypted backup used a device-local key. Restore it on the original installation or export a new passphrase backup.');
   if(x&&typeof x==='object') return JSON.stringify(x);
   throw new Error('Unsupported backup format');
 }
 const key=await derive(passphrase,unb64(x.salt));const pt=await crypto.subtle.decrypt({name:'AES-GCM',iv:unb64(x.iv)},key,unb64(x.ciphertext));return new TextDecoder().decode(pt)
}
async function getPassphrase(confirmIt){const sk='cashtracker_backup_passphrase_session';try{const cached=sessionStorage.getItem(sk);if(cached&&cached.length>=8)return cached}catch(e){}const p=prompt(confirmIt?'Create a backup passphrase (8+ characters). You will need it to restore this backup.':'Enter the backup passphrase:');if(!p)throw new Error('Backup passphrase was cancelled.');if(p.length<8)throw new Error('Backup passphrase must be at least 8 characters.');if(confirmIt){const q=prompt('Confirm the backup passphrase:');if(p!==q)throw new Error('Passphrases do not match.');}try{sessionStorage.setItem(sk,p)}catch(e){}return p}
window.BackupCrypto={encryptText,decryptText,encryptJson:(obj,p)=>encryptText(JSON.stringify(obj),p),decryptJson:async(x,p)=>JSON.parse(await decryptText(x,p)),getPassphrase,isEncrypted:isEnvelope};
})();
