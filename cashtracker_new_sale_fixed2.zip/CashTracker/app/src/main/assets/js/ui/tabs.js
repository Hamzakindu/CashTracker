// ============================================
// TAB MANAGEMENT - COMPLETE FIXED
// ============================================
const Tabs = {
    currentTab: 'dashboard',
    calculatorPreviousTab: 'dashboard',

    enterCalculatorFullscreen() {
        if (document.body) document.body.classList.add('stockpro-calculator-fullscreen');
    },

    exitCalculatorFullscreen() {
        const previous = this.calculatorPreviousTab && this.calculatorPreviousTab !== 'calculator'
            ? this.calculatorPreviousTab : 'dashboard';
        if (document.body) document.body.classList.remove('stockpro-calculator-fullscreen');
        this.switchTo(previous);
    },

    switchTo(tabName) {
        console.log('🔄 Switching to tab:', tabName);

        // V5.10.43: remember the tab the user came from, then make Calculator
        // occupy the full screen. Leaving Calculator restores the previous tab.
        if (tabName === 'calculator' && this.currentTab !== 'calculator') {
            this.calculatorPreviousTab = this.currentTab || 'dashboard';
            this.enterCalculatorFullscreen();
        } else if (tabName !== 'calculator') {
            if (document.body) document.body.classList.remove('stockpro-calculator-fullscreen');
        }
        
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.tab === tabName) {
                btn.classList.add('active');
            }
        });

        document.querySelectorAll('.tab-pane').forEach(pane => {
            pane.classList.remove('active');
        });
        
        const pane = document.getElementById('tab-' + tabName);
        if (pane) {
            pane.classList.add('active');
        } else {
            console.warn('⚠️ Tab pane not found:', tabName);
        }

        this.currentTab = tabName;
        this.refreshTab(tabName);
    },

    refreshTab(tabName) {
        console.log('🔄 Refreshing tab:', tabName);
        
        const pane = document.getElementById('tab-' + tabName);
        if (!pane) return;
        
        if (pane.innerHTML.trim() === '') {
            console.log('📄 Tab pane empty, rendering:', tabName);
            this.renderTabContent(tabName);
        }
        
        const actions = {
            dashboard: () => {
                if (typeof Dashboard !== 'undefined') {
                    if (Dashboard.update) Dashboard.update();
                    else if (Dashboard.init) Dashboard.init();
                }
            },
            products: () => {
                if (typeof Products !== 'undefined') {
                    if (Products.render) Products.render();
                    else if (Products.init) Products.init();
                }
            },
            purchases: () => {
                if (typeof Purchases !== 'undefined') {
                    if (Purchases.render) Purchases.render();
                    else if (Purchases.init) Purchases.init();
                }
            },
            // ✅ FIXED: Sales tab refresh
            sales: () => {
                console.log('🔄 Refreshing sales tab...');
                if (typeof Sales !== 'undefined') {
                    try {
                        if (typeof Sales.render === 'function') {
                            Sales.render();
                            console.log('✅ Sales rendered');
                        } else if (typeof Sales.init === 'function') {
                            Sales.init();
                            console.log('✅ Sales initialized');
                        } else {
                            console.warn('⚠️ Sales has no render or init method');
                        }
                    } catch(e) {
                        console.error('❌ Error refreshing sales:', e);
                    }
                } else {
                    console.warn('⚠️ Sales module not available');
                    // Try to load it
                    const pane = document.getElementById('tab-sales');
                    if (pane) {
                        pane.innerHTML = `
                            <div class="card">
                                <div class="flex-between">
                                    <div class="card-title">💰 Sales History</div>
                                    <button class="btn btn-success btn-sm" data-cashtracker-onclick="Sales.openSellModal()">➕ New Sale</button>
                                </div>
                                <div id="salesList"></div>
                            </div>
                        `;
                        // Try to initialize after a delay
                        setTimeout(() => {
                            if (typeof Sales !== 'undefined' && Sales.init) {
                                Sales.init();
                            }
                        }, 500);
                    }
                }
            },
            customers: () => {
                if (typeof Customers !== 'undefined') {
                    if (Customers.render) Customers.render();
                    else if (Customers.init) Customers.init();
                }
            },
            suppliers: () => {
                if (typeof Suppliers !== 'undefined') {
                    if (Suppliers.render) Suppliers.render();
                    else if (Suppliers.init) Suppliers.init();
                }
            },
            expenses: () => { 
                if (typeof Expenses !== 'undefined') {
                    if (Expenses.renderTypes) Expenses.renderTypes(); 
                    if (Expenses.renderDirect) Expenses.renderDirect();
                    if (Expenses.init) Expenses.init();
                }
            },
            returns: () => {
                if (typeof Returns !== 'undefined') {
                    if (Returns.render) Returns.render();
                    else if (Returns.init) Returns.init();
                }
            },
            cashier: () => {
                if (typeof Cashier !== 'undefined') {
                    if (Cashier.render) Cashier.render();
                    else if (Cashier.init) Cashier.init();
                }
            },
            finance: () => {
                if (typeof FinanceControl !== 'undefined') {
                    if (FinanceControl.render) FinanceControl.render();
                }
            },
            calculator: () => { 
                if (typeof initCalcTab === 'function') {
                    initCalcTab();
                }
                if (typeof renderCalcHistory === 'function') {
                    renderCalcHistory();
                }
            },
            accounting: () => {
                if (typeof AccountingLedger !== 'undefined') {
                    const pane = document.getElementById('tab-accounting');
                    if (pane && pane.innerHTML.trim() === '') pane.innerHTML = AccountingLedger.dashboard();
                    else if (pane) pane.innerHTML = AccountingLedger.dashboard();
                }
            },
            reports: () => {
                try {
                    const today = Helpers.getToday();
                    const fromEl = document.getElementById('reportFromDate');
                    const toEl = document.getElementById('reportToDate');
                    if (fromEl) fromEl.value = today;
                    if (toEl) toEl.value = today;
                    if (typeof Reports !== 'undefined' && Reports.prepareFilters) {
                        Reports.prepareFilters();
                    }
                    if (typeof EthiopianDate !== 'undefined') {
                        EthiopianDate.updateDisplay(today, today);
                    }
                } catch(e) {
                    console.warn('Reports refresh error:', e);
                }
            },
            add: () => {
                if (typeof Products !== 'undefined' && Products.init) {
                    Products.init();
                }
            }
        };

        if (actions[tabName]) {
            try {
                actions[tabName]();
            } catch (e) {
                console.warn('⚠️ Error refreshing tab:', tabName, e);
            }
        }
    },
    
    renderTabContent(tabName) {
        const pane = document.getElementById('tab-' + tabName);
        if (!pane) return;
        
        switch(tabName) {
            case 'products':
                if (typeof Products !== 'undefined' && Products.init) {
                    Products.init();
                }
                break;
            case 'sales':
                if (typeof Sales !== 'undefined' && Sales.init) {
                    Sales.init();
                } else {
                    // Fallback: render basic sales tab
                    pane.innerHTML = `
                        <div class="card">
                            <div class="flex-between">
                                <div class="card-title">💰 Sales History</div>
                                <button class="btn btn-success btn-sm" data-cashtracker-onclick="Sales.openSellModal()">➕ New Sale</button>
                            </div>
                            <div id="salesList"></div>
                        </div>
                    `;
                    setTimeout(() => {
                        if (typeof Sales !== 'undefined' && Sales.render) {
                            Sales.render();
                        }
                    }, 100);
                }
                break;
            case 'purchases':
                if (typeof Purchases !== 'undefined' && Purchases.init) {
                    Purchases.init();
                }
                break;
            case 'customers':
                if (typeof Customers !== 'undefined' && Customers.init) {
                    Customers.init();
                }
                break;
            case 'suppliers':
                if (typeof Suppliers !== 'undefined' && Suppliers.init) {
                    Suppliers.init();
                }
                break;
            case 'expenses':
                if (typeof App !== 'undefined' && App.initExpensesTab) {
                    App.initExpensesTab();
                } else if (typeof Expenses !== 'undefined' && Expenses.init) {
                    Expenses.init();
                }
                break;
            case 'returns':
                if (typeof App !== 'undefined' && App.initReturnsTab) {
                    App.initReturnsTab();
                } else if (typeof Returns !== 'undefined' && Returns.init) {
                    Returns.init();
                }
                break;
            case 'accounting':
                if (typeof AccountingLedger !== 'undefined') {
                    pane.innerHTML = AccountingLedger.dashboard();
                }
                break;
            case 'cashbanks':
                if (typeof CashBanks !== 'undefined') CashBanks.render();
                break;
            case 'stockcount':
                if (typeof StockCount !== 'undefined') StockCount.render();
                break;
            case 'loyalty':
                if (typeof Loyalty !== 'undefined') Loyalty.render();
                break;
            case 'payables':
                if (typeof Payables !== 'undefined') Payables.render();
                break;
            case 'stockcount':
                if (typeof StockCount !== 'undefined') StockCount.render();
                break;
            case 'lowstock':
                if (typeof StockAlerts !== 'undefined') StockAlerts.render();
                break;
            case 'audit':
                if (typeof Roles !== 'undefined') Roles.render();
                break;
            case 'tools':
                if (typeof Tools !== 'undefined') Tools.render();
                break;
            case 'marketing':
                if (typeof Marketing !== 'undefined') Marketing.render();
                break;
            case 'receivables':
                if (typeof Receivables !== 'undefined') Receivables.render();
                break;
            case 'calcinbox':
                if (typeof CalcInbox !== 'undefined') CalcInbox.render();
                break;
            case 'banksms':
                if (typeof BankSMS !== 'undefined') BankSMS.render();
                break;
            case 'peoplemoney':
                if (typeof PeopleMoney !== 'undefined') PeopleMoney.render();
                break;
            case 'cashier':
                if (typeof Cashier !== 'undefined' && Cashier.render) Cashier.render();
                break;
            case 'finance':
                if (typeof FinanceControl !== 'undefined' && FinanceControl.render) FinanceControl.render();
                break;
            case 'reports':
                if (typeof App !== 'undefined' && App.initReportsTab) {
                    App.initReportsTab();
                } else if (typeof Reports !== 'undefined' && Reports.init) {
                    Reports.init();
                }
                break;
            case 'calculator':
                if (typeof App !== 'undefined' && App.initCalculatorTab) {
                    App.initCalculatorTab();
                } else if (typeof initCalcTab === 'function') {
                    initCalcTab();
                }
                break;
            case 'add':
                if (typeof Products !== 'undefined' && Products.init) {
                    Products.init();
                }
                break;
            case 'dashboard':
                if (typeof Dashboard !== 'undefined' && Dashboard.init) {
                    Dashboard.init();
                }
                break;
        }
    },

    init() {
        console.log('📌 Initializing tabs...');
        
        const buttons = document.querySelectorAll('.tab-btn');
        console.log('Found', buttons.length, 'tab buttons');
        
        buttons.forEach(btn => {
            const newBtn = btn.cloneNode(true);
            btn.parentNode.replaceChild(newBtn, btn);
        });
        
        const freshButtons = document.querySelectorAll('.tab-btn');
        
        freshButtons.forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const tabName = this.dataset.tab;
                Tabs.switchTo(tabName);
            });
        });
        
        const activeTab = document.querySelector('.tab-btn.active');
        if (!activeTab && freshButtons.length > 0) {
            const dashboardBtn = document.querySelector('.tab-btn[data-tab="dashboard"]') || freshButtons[0];
            dashboardBtn.classList.add('active');
            const pane = document.getElementById('tab-' + dashboardBtn.dataset.tab);
            if (pane) {
                pane.classList.add('active');
                this.currentTab = dashboardBtn.dataset.tab;
            }
        }
        
        const activeTabName = document.querySelector('.tab-btn.active')?.dataset?.tab || 'dashboard';
        if (activeTabName !== 'calculator') {
            const pane = document.getElementById('tab-' + activeTabName);
            if (pane && pane.innerHTML.trim() === '') {
                this.renderTabContent(activeTabName);
            }
            this.refreshTab(activeTabName);
        }
        
        console.log('✅ Tabs initialized, current tab:', this.currentTab);
    }
};