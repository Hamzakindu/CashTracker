// ============================================
// TOAST NOTIFICATIONS
// ============================================
const Toast = {
    // Show a toast notification
    show(message, type = 'info', duration = CONFIG.TOAST_DURATION) {
        const icons = {
            success: '✅',
            error: '❌',
            warning: '⚠️',
            info: 'ℹ️'
        };

        const container = document.getElementById('toast-container');
        if (!container) return;

        const toast = document.createElement('div');
        toast.className = 'toast toast-' + type;
        toast.innerHTML = `
            <span>${icons[type] || ''} ${message}</span>
            <button style="margin-left:auto;background:none;border:none;color:var(--text);cursor:pointer;font-size:1.1rem;" data-cashtracker-onclick="this.parentElement.remove()">✕</button>
        `;

        container.appendChild(toast);

        // Auto-remove after duration
        setTimeout(() => {
            if (toast.parentElement) {
                toast.style.animation = 'slideOut 0.3s ease forwards';
                setTimeout(() => toast.remove(), 300);
            }
        }, duration);
    },

    // Convenience methods
    success(message, duration) {
        this.show(message, 'success', duration);
    },

    error(message, duration) {
        this.show(message, 'error', duration);
    },

    warning(message, duration) {
        this.show(message, 'warning', duration);
    },

    info(message, duration) {
        this.show(message, 'info', duration);
    }
};

// Add slideOut animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(80px); opacity: 0; }
    }
`;
document.head.appendChild(style);