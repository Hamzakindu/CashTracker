// ============================================
// PROFILE MANAGEMENT
// ============================================
const Profiles = {
    // Load profile data
    load() {
        const profile = JSON.parse(localStorage.getItem('stockProfile') || 'null');
        
        if (profile) {
            document.getElementById('profileStatus').textContent = '✅ ' + (profile.username || 'No name');
            document.getElementById('profileLastLogin').textContent = profile.lastLogin || '-';
            this.updateBadge(profile);
        } else {
            document.getElementById('profileStatus').textContent = '❌ No profile';
            document.getElementById('profileLastLogin').textContent = '-';
            this.updateBadge(null);
        }

        this.updateProfileSelector();
    },

    // Update profile badge in header
    updateBadge(profile) {
        const existingBadge = document.getElementById('profileBadge');
        if (existingBadge) existingBadge.remove();

        if (profile && profile.username) {
            const badge = document.createElement('span');
            badge.id = 'profileBadge';
            badge.className = 'profile-badge';
            badge.textContent = '👤 ' + profile.username;
            badge.style.display = 'inline-block';
            
            const headerItem = document.querySelector('.header-item:nth-child(3)');
            if (headerItem) headerItem.appendChild(badge);
        }
    },

    // Open profile modal
    openProfileModal() {
        let modal = document.getElementById('profileModal');
        if (!modal) {
            modal = document.createElement('div');
            modal.className = 'modal-overlay';
            modal.id = 'profileModal';
            modal.innerHTML = `
                <div class="modal" style="max-width:420px;">
                    <button class="close-btn" data-cashtracker-onclick="Modals.close('profileModal')">✕</button>
                    <h3>👤 Profile Settings</h3>
                    <div class="form-group"><label>Username</label><input class="form-control" id="profileUsername"></div>
                    <div class="form-group"><label>Email</label><input class="form-control" id="profileEmail" type="email"></div>
                    <div class="form-group"><label>Store Name</label><input class="form-control" id="profileStoreName"></div>
                    <div class="form-group"><label>Phone</label><input class="form-control" id="profilePhone"></div>
                    <hr>
                    <h4>☁️ Auto Backup</h4>
                    <div class="form-group">
                        <label>Auto Backup</label>
                        <select class="form-control" id="autoBackupEnabled" data-cashtracker-onchange="Backup.toggleAuto()">
                            <option value="enabled">✅ Enabled</option>
                            <option value="disabled">❌ Disabled</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Frequency</label>
                        <select class="form-control" id="autoBackupFrequency">
                            <option value="1">Every 1 hour</option>
                            <option value="3">Every 3 hours</option>
                            <option value="6">Every 6 hours</option>
                            <option value="12">Every 12 hours</option>
                            <option value="24" selected>Every 24 hours</option>
                            <option value="168">Every 7 days</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Daily Report</label>
                        <button class="btn btn-sm btn-outline" id="dailyReportToggle" data-cashtracker-onclick="App.toggleDailyAutoReport()">
                            📊 <span id="dailyReportStatus">-</span>
                        </button>
                    </div>
                    <div style="display:flex;gap:6px;flex-wrap:wrap;">
                        <button class="btn btn-success btn-sm" data-cashtracker-onclick="Profiles.save()">💾 Save</button>
                        <button class="btn btn-primary btn-sm" data-cashtracker-onclick="Backup.manualBackup()">☁️ Backup</button>
                        <button class="btn btn-warning btn-sm" data-cashtracker-onclick="Backup.restoreFromCloud()">☁️ Restore</button>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
        }

        const profile = JSON.parse(localStorage.getItem('stockProfile') || '{}');
        document.getElementById('profileUsername').value = profile.username || '';
        document.getElementById('profileEmail').value = profile.email || '';
        document.getElementById('profileStoreName').value = profile.storeName || '';
        document.getElementById('profilePhone').value = profile.phone || '';
        
        const autoBackup = Storage.getSetting('autoBackupEnabled', 'enabled');
        const backupFreq = Storage.getSetting('autoBackupFrequency', CONFIG.DEFAULT_BACKUP_FREQUENCY.toString());
        
        document.getElementById('autoBackupEnabled').value = autoBackup;
        document.getElementById('autoBackupFrequency').value = backupFreq;
        document.getElementById('dailyReportStatus').textContent = State.dailyAutoReport ? '✅ ON' : '❌ OFF';

        Modals.open('profileModal');
    },

    // Save profile
    save() {
        const profile = {
            username: document.getElementById('profileUsername').value.trim(),
            email: document.getElementById('profileEmail').value.trim(),
            storeName: document.getElementById('profileStoreName').value.trim(),
            phone: document.getElementById('profilePhone').value.trim(),
            lastLogin: new Date().toLocaleString()
        };

        if (!profile.username) return Toast.warning('Username is required');

        localStorage.setItem('stockProfile', JSON.stringify(profile));
        
        // Save backup settings
        const autoBackup = document.getElementById('autoBackupEnabled').value;
        const backupFreq = document.getElementById('autoBackupFrequency').value;
        
        Storage.setSetting('autoBackupEnabled', autoBackup);
        Storage.setSetting('autoBackupFrequency', backupFreq);

        Toast.success('Profile saved!');
        this.load();
        Modals.close('profileModal');
    },

    // Add new profile
    addNewProfile() {
        const name = prompt('Profile name:', 'Store ' + (State.profiles.length + 1));
        if (!name) return;

        const id = name.trim().replace(/\s+/g, '_');
        
        if (State.profiles.find(p => p.id === id)) {
            return Toast.error('Profile already exists!');
        }

        const newProfile = {
            id,
            name: name.trim(),
            createdAt: new Date().toISOString()
        };

        State.profiles.push(newProfile);
        localStorage.setItem('stockProfilesList', JSON.stringify(State.profiles));

        // Initialize empty data for new profile
        Storage.setSetting('currentProfileId', id);
        
        const stores = ['products', 'sales', 'purchases', 'suppliers', 'expenseTypes', 'directExpenses', 'returns'];
        stores.forEach(store => Storage.save(store, []));
        
        // Create default walk-in customer
        Storage.save('customers', [{
            id: 'walkin',
            name: 'Walk-in Customer',
            contact: '',
            address: '',
            balance: 0,
            createdAt: new Date().toISOString()
        }]);

        State.currentProfileId = id;
        Toast.success(`Profile "${name}" created!`);
        
        this.updateProfileSelector();
        
        // Reload data
        setTimeout(async () => {
            await State.loadAllData();
            App.populateDropdowns();
            Dashboard.update();
            Products.render();
            Sales.render();
            Purchases.render();
            Customers.render();
            Suppliers.render();
            Expenses.renderTypes();
            Expenses.renderDirect();
            Returns.render();
            Tabs.refreshTab(Tabs.currentTab);
        }, 500);
    },

    // Switch profile
    async switchProfile(id) {
        if (!id || id === '__new__') {
            if (id === '__new__') {
                this.addNewProfile();
            }
            return;
        }

        if (id === State.currentProfileId) {
            document.getElementById('profileSwitcher').value = State.currentProfileId;
            return;
        }

        if (!confirm(`Switch to profile "${id}"?`)) {
            document.getElementById('profileSwitcher').value = State.currentProfileId;
            return;
        }

        State.currentProfileId = id;
        Storage.setSetting('currentProfileId', id);
        
        Toast.info('Switching profile...', 1500);
        
        setTimeout(async () => {
            await State.loadAllData();
            App.populateDropdowns();
            Dashboard.update();
            Products.render();
            Sales.render();
            Purchases.render();
            Customers.render();
            Suppliers.render();
            Expenses.renderTypes();
            Expenses.renderDirect();
            Returns.render();
            this.updateProfileSelector();
            Toast.success('Profile switched!');
        }, 400);
    },

    // Update profile selector dropdown
    updateProfileSelector() {
        const selector = document.getElementById('profileSwitcher');
        if (!selector) return;

        selector.style.display = State.profiles.length > 1 ? 'inline-block' : 'none';
        selector.innerHTML = '';

        State.profiles.forEach(profile => {
            const option = document.createElement('option');
            option.value = profile.id;
            option.textContent = profile.name + (profile.id === State.currentProfileId ? ' ✅' : '');
            if (profile.id === State.currentProfileId) option.selected = true;
            selector.appendChild(option);
        });

        // Add separator and "new" option
        const separator = document.createElement('option');
        separator.disabled = true;
        separator.textContent = '──────────';
        selector.appendChild(separator);

        const addOption = document.createElement('option');
        addOption.value = '__new__';
        addOption.textContent = '➕ New Profile...';
        selector.appendChild(addOption);
    }
};