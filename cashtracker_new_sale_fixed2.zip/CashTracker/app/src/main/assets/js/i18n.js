// CashTracker multilingual UI: English, አማርኛ, Afaan Oromoo, ትግርኛ (and العربية).
// Translates what is on screen by matching text against the table in i18n-data.js. It can switch back and forth,
// and keeps translating screens that the app draws later. Anything not in the table simply stays English.
(function(){'use strict';
const LANGS={en:'English',am:'አማርኛ',om:'Afaan Oromoo',ti:'ትግርኛ',ar:'العربية'};
const KEY='stockpro_language';   // same key as older versions, so a saved choice is kept
const IDX={am:1,om:2,ti:3};
const D={am:{},om:{},ti:{},ar:{}};
const norm=s=>String(s==null?'':s).replace(/\s+/g,' ').trim();
(function build(){
  (window.I18N_ROWS||[]).forEach(r=>{const k=norm(r[0]).toLowerCase();Object.keys(IDX).forEach(l=>{if(r[IDX[l]])D[l][k]=r[IDX[l]]})});
  const ar=window.I18N_AR||{};Object.keys(ar).forEach(k=>D.ar[norm(k).toLowerCase()]=ar[k]);
})();
const PREFIX=/^[^\p{L}\p{N}]*/u;
const SPLIT=/^([^\p{L}\p{N}]*)(.*?)([\s:：]*(?:[\(\[]\s*[\d.,\s\/]*[\)\]])?[\s:：]*)$/u;
function lookup(text,lang){
  const d=D[lang];if(!d)return null;
  const s=norm(text);if(!s)return null;
  const k=s.toLowerCase();if(d[k])return d[k];
  const pre=PREFIX.exec(s)[0];
  if(pre){const v=d[s.slice(pre.length).toLowerCase()];if(v)return pre+v}
  const m=SPLIT.exec(s);
  if(m&&m[2]){const v=d[m[2].toLowerCase()];if(v)return m[1]+v+m[3]}
  return null;
}
const SKIP_TAG={SCRIPT:1,STYLE:1,TEXTAREA:1,NOSCRIPT:1,CODE:1};
function skip(el){
  if(!el)return true;
  if(SKIP_TAG[el.tagName])return true;
  if(el.closest&&el.closest('#languageSelect,[data-no-i18n],[contenteditable="true"],.list-item .info .title'))return true;
  return false;
}
const texts=new WeakMap(),attrs=new WeakMap();
const ATTRS=['placeholder','title','aria-label'];
let mem='en';
function cur(){let v=null;try{v=localStorage.getItem(KEY)}catch(e){}return v||mem}
function doText(n,lang){
  const val=n.nodeValue,r=texts.get(n);
  const orig=(r&&val===r.shown)?r.orig:val;
  let out=orig;
  if(lang!=='en'){
    const core=norm(orig);
    if(core){const t=lookup(core,lang);if(t){const lead=/^\s*/.exec(orig)[0],trail=/\s*$/.exec(orig)[0];out=lead+t+trail}}
  }
  if(out!==val)n.nodeValue=out;
  texts.set(n,{orig,shown:out});
}
function doAttrs(el,lang){
  ATTRS.forEach(a=>{
    if(!el.hasAttribute(a))return;
    const val=el.getAttribute(a);let rec=attrs.get(el);if(!rec){rec={};attrs.set(el,rec)}
    const r=rec[a],orig=(r&&val===r.shown)?r.orig:val;
    let out=orig;if(lang!=='en'){const t=lookup(orig,lang);if(t)out=t}
    if(out!==val)el.setAttribute(a,out);
    rec[a]={orig,shown:out};
  });
}
function walk(root,lang){
  if(!root)return;
  if(root.nodeType===3){if(!skip(root.parentElement))doText(root,lang);return}
  if(root.nodeType!==1||skip(root))return;
  if(root.matches&&root.matches('[placeholder],[title],[aria-label]'))doAttrs(root,lang);
  const tw=document.createTreeWalker(root,NodeFilter.SHOW_ELEMENT|NodeFilter.SHOW_TEXT);
  let n;while((n=tw.nextNode())){
    if(n.nodeType===3){if(!skip(n.parentElement))doText(n,lang)}
    else if(n.hasAttribute&&(n.hasAttribute('placeholder')||n.hasAttribute('title')||n.hasAttribute('aria-label')))doAttrs(n,lang);
  }
}
let obs=null,queue=new Set(),timer=null;
function flush(){
  timer=null;const lang=cur();const items=Array.from(queue);queue.clear();
  items.forEach(n=>{try{
    if(n.nodeType===3){const r=texts.get(n);if(r&&r.shown===n.nodeValue)return}
    else if(n.nodeType===1&&!n.isConnected)return;
    walk(n,lang);
  }catch(e){}});
}
function watch(){
  if(obs||!window.MutationObserver||!document.body)return;
  obs=new MutationObserver(ms=>{
    if(cur()==='en'&&!document.documentElement.getAttribute('data-i18n-was'))return;   // nothing to do in English unless we just switched back
    ms.forEach(m=>{
      if(m.type==='childList')m.addedNodes.forEach(n=>queue.add(n));
      else if(m.type==='characterData')queue.add(m.target);
      else if(m.type==='attributes')queue.add(m.target);
    });
    if(!timer)timer=setTimeout(flush,30);
  });
  obs.observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:ATTRS});
}
const I18n={
  languages:LANGS,
  current:cur,
  t(s){const l=cur();if(l==='en')return norm(s);return lookup(s,l)||norm(s)},
  set(lang){
    if(!LANGS[lang])return;
    mem=lang;try{localStorage.setItem(KEY,lang)}catch(e){}
    if(lang!=='en')document.documentElement.setAttribute('data-i18n-was','1');
    document.documentElement.lang=lang;document.documentElement.dir=lang==='ar'?'rtl':'ltr';
    this.translatePage();
    const ls=document.getElementById('languageSelect');if(ls&&ls.value!==lang)ls.value=lang;
    if(window.App&&App.refreshAll)try{App.refreshAll()}catch(e){}
  },
  translatePage(){
    if(!document.body)return;const lang=cur();
    document.querySelectorAll('[data-i18n]').forEach(el=>{const k=el.getAttribute('data-i18n');const t=lang==='en'?k:(lookup(k,lang)||k);el.textContent=t});
    walk(document.body,lang);
  },
  init(){
    const l=cur();
    if(l!=='en')document.documentElement.setAttribute('data-i18n-was','1');
    document.documentElement.lang=l;document.documentElement.dir=l==='ar'?'rtl':'ltr';
    this.translatePage();watch();
  }
};
window.I18n=I18n;window.t=s=>I18n.t(s);
})();
