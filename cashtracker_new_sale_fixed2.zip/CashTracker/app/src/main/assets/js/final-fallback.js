(function() {
        'use strict';
        
        console.log('🔄 Final fallback running...');
        
        // Share helpers (fallback)
        window.shareViaSMS = function() {
            const phone = document.getElementById('sharePhoneNumber')?.value || '';
            const msg = document.getElementById('shareMessagePreview')?.textContent || '';
            if (!phone) { alert('📱 Enter phone number'); return; }
            window.open('sms:' + phone + '?body=' + encodeURIComponent(msg), '_blank');
        };
        
        window.shareViaWhatsApp = function() {
            const phone = document.getElementById('sharePhoneNumber')?.value || '';
            const msg = document.getElementById('shareMessagePreview')?.textContent || '';
            if (!phone) { alert('📱 Enter phone number'); return; }
            window.open('whatsapp://send?phone=' + encodeURIComponent(phone) + '&text=' + encodeURIComponent(msg), '_blank');
        };
        
        window.shareViaTelegram = function() {
            const phone = document.getElementById('sharePhoneNumber')?.value || '';
            const msg = document.getElementById('shareMessagePreview')?.textContent || '';
            if (!phone) { alert('📱 Enter phone number'); return; }
            window.open('tg://msg?phone=' + encodeURIComponent(phone) + '&text=' + encodeURIComponent(msg), '_blank');
        };
        
        window.shareViaTelegramUsername = function() {
            const username = prompt('📡 Enter Telegram username (without @):', '');
            if (!username) return;
            const msg = document.getElementById('shareMessagePreview')?.textContent || '';
            window.open('tg://resolve?domain=' + encodeURIComponent(username) + '&text=' + encodeURIComponent(msg), '_blank');
        };
        
        window.shareViaTelegramChannel = function() {
            const msg = document.getElementById('shareMessagePreview')?.textContent || '';
            if (!msg) { alert('No message to send'); return; }
            fetch(`https://api.telegram.org/bot${CONFIG.TELEGRAM.TOKEN}/sendMessage`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    chat_id: localStorage.getItem('stockpro_telegram_backup_channel') || '',
                    text: msg,
                    parse_mode: 'Markdown'
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.ok) {
                    alert('✅ Sent to Telegram Channel!');
                } else {
                    alert('❌ Failed: ' + (data.description || 'Unknown error'));
                }
            })
            .catch(err => {
                alert('❌ Network error: ' + err.message);
            });
        };
        
        window.copyShareMessage = function() {
            const msg = document.getElementById('shareMessagePreview')?.textContent || '';
            if (!msg) { alert('No message to copy'); return; }
            if (navigator.clipboard) {
                navigator.clipboard.writeText(msg).then(() => alert('✅ Copied!')).catch(() => alert('❌ Copy failed'));
            } else {
                prompt('Copy this:', msg);
            }
        };
        
        window.shareViaEmail = function() {
            const msg = document.getElementById('shareMessagePreview')?.textContent || '';
            const subject = 'Balance Update';
            window.open('mailto:?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(msg), '_blank');
        };
        
        window.shareBalanceReport = function() {
            alert('📊 Please use the Share Balance button from Customer or Supplier list');
        };
        
        // Fix Storage
        if (typeof Storage === 'undefined' || typeof Storage.getSetting !== 'function') {
            console.warn('⚠️ Storage incomplete, creating fallback...');
            window.Storage = {
                getSetting: function(key, def) { try { return localStorage.getItem(key) || def; } catch(e) { return def; } },
                setSetting: function(key, val) { try { localStorage.setItem(key, val); return true; } catch(e) { return false; } },
                getProfileId: function() { try { return localStorage.getItem('currentProfileId') || 'default'; } catch(e) { return 'default'; } },
                getKey: function(store) { return 'SMDB_' + this.getProfileId() + '_' + store; },
                save: function(store, data) { try { localStorage.setItem(this.getKey(store), JSON.stringify(data)); return true; } catch(e) { return false; } },
                load: function(store) { try { const raw = localStorage.getItem(this.getKey(store)); return raw ? JSON.parse(raw) : []; } catch(e) { return []; } }
            };
            console.log('✅ Storage fallback created');
        }
        
        // V5.9.9 AppMint/WebView menu bridge: single inline-style controller.
        (function installAppMintMenuBridge(){
            function install(){
                const hamburger=document.getElementById('hamburgerBtn');
                const menu=document.getElementById('optionsDropdown');
                if(!hamburger || !menu) return false;

                // Portal the menu to body; inline styles deliberately avoid WebView CSS clipping/stacking quirks.
                if(menu.parentElement!==document.body) document.body.appendChild(menu);
                menu.setAttribute('data-stockpro-menu','appmint-v5.9.9');
                hamburger.setAttribute('aria-controls','optionsDropdown');
                hamburger.setAttribute('aria-expanded','false');

                function close(){
                    menu.classList.remove('show');
                    menu.style.setProperty('display','block','important');
                    menu.style.setProperty('position','fixed','important');
                    menu.style.setProperty('visibility','hidden','important');
                    menu.style.setProperty('opacity','0','important');
                    menu.style.setProperty('pointer-events','none','important');
                    menu.style.setProperty('z-index','2147483647','important');
                    hamburger.classList.remove('active');
                    hamburger.setAttribute('aria-expanded','false');
                    document.body.classList.remove('stockpro-menu-portal-open');
                }
                function open(){
                    menu.classList.add('show');
                    menu.style.setProperty('display','block','important');
                    menu.style.setProperty('position','fixed','important');
                    menu.style.setProperty('top','56px','important');
                    menu.style.setProperty('left','8px','important');
                    menu.style.setProperty('right','8px','important');
                    menu.style.setProperty('width','auto','important');
                    menu.style.setProperty('max-width','none','important');
                    menu.style.setProperty('height','auto','important');
                    menu.style.setProperty('max-height','calc(100vh - 68px)','important');
                    menu.style.setProperty('overflow-y','auto','important');
                    menu.style.setProperty('visibility','visible','important');
                    menu.style.setProperty('opacity','1','important');
                    menu.style.setProperty('pointer-events','auto','important');
                    menu.style.setProperty('z-index','2147483647','important');
                    menu.style.setProperty('background','var(--surface, #fff)','important');
                    hamburger.classList.add('active');
                    hamburger.setAttribute('aria-expanded','true');
                    document.body.classList.add('stockpro-menu-portal-open');
                }
                function toggle(e){
                    if(e){e.preventDefault();e.stopPropagation();}
                    if(menu.classList.contains('show') && menu.style.visibility!=='hidden') close(); else open();
                }
                // Remove known prior handlers.
                if(hamburger._stockProMenuHandler) hamburger.removeEventListener('click',hamburger._stockProMenuHandler);
                if(hamburger._stockProFallbackHandler) hamburger.removeEventListener('click',hamburger._stockProFallbackHandler);
                if(hamburger._stockProPointerHandler) hamburger.removeEventListener('pointerup',hamburger._stockProPointerHandler);
                hamburger._stockProMenuHandler=toggle;
                hamburger.addEventListener('click',toggle,false);

                // Pointer fallback for WebViews that dispatch pointer events but delay click.
                let pointerAt=0;
                const pointer=function(e){ pointerAt=Date.now(); };
                hamburger._stockProPointerHandler=pointer;
                hamburger.addEventListener('pointerup',pointer,false);

                if(document._stockProMenuBridgeOutside) document.removeEventListener('click',document._stockProMenuBridgeOutside,false);
                const outside=function(e){
                    if(!hamburger.contains(e.target) && !menu.contains(e.target)) close();
                };
                document._stockProMenuBridgeOutside=outside;
                document.addEventListener('click',outside,false);

                if(document._stockProMenuBridgeKey) document.removeEventListener('keydown',document._stockProMenuBridgeKey,false);
                const key=function(e){if(e.key==='Escape') close();};
                document._stockProMenuBridgeKey=key;
                document.addEventListener('keydown',key,false);

                // Start hidden but rendered; this avoids WebView display:none caching.
                close();
                return true;
            }
            let tries=0;
            const boot=()=>{if(install() || ++tries>30) return; setTimeout(boot,150);};
            if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot); else boot();
            window.StockProAppMintMenu={install,version:'5.9.9'};
        })();

        // Fix Tabs
        function fixTabs() {
            const tabs = document.querySelectorAll('.tab-btn');
            tabs.forEach(function(btn) {
                btn.addEventListener('click', function() {
                    tabs.forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                    document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
                    const pane = document.getElementById('tab-' + this.dataset.tab);
                    if (pane) pane.classList.add('active');
                    
                    if (typeof Tabs !== 'undefined' && Tabs.refreshTab) {
                        Tabs.refreshTab(this.dataset.tab);
                    }
                });
            });
        }
        
        setTimeout(function() {
            fixHamburger();
            fixTabs();
        }, 100);
        
        if (typeof I18n !== 'undefined') { I18n.init(); const ls=document.getElementById('languageSelect'); if(ls) ls.value=I18n.current(); }
        console.log('✅ Final fallback ready');
    })();
