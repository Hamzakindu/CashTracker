// PERIOD LOCK: once a month is closed, sales, purchases, expenses and returns dated on or before the lock date cannot be added, edited or deleted.
(function(){'use strict';
const KEY='SP_lock_date';
const PeriodLock={
  get(){try{return localStorage.getItem(KEY)||''}catch(e){return ''}},
  set(d){try{d?localStorage.setItem(KEY,d):localStorage.removeItem(KEY)}catch(e){}
    if(window.Security&&Security.audit)Security.audit('period_lock_set','security','',{lockDate:d||''});},
  isLocked(date){const l=this.get(),d=String(date||'').slice(0,10);return !!(l&&d&&d<=l)},
  blocked(date){
    if(!this.isLocked(date))return false;
    if(window.Toast)Toast.error('🔒 This period is closed (up to '+this.get()+'). Change the lock date in Finance to edit it.');
    return true;
  },
  dialog(){
    const cur=this.get();
    const v=prompt('Close the books up to this date (YYYY-MM-DD). Entries on or before it cannot be changed.\nLeave empty to unlock.',cur||'');
    if(v===null)return;
    const t=v.trim();
    if(t&&!/^\d{4}-\d{2}-\d{2}$/.test(t))return Toast.warning('Use the format YYYY-MM-DD, for example 2026-09-30');
    this.set(t);Toast.success(t?'🔒 Books closed up to '+t:'🔓 Books unlocked');
    if(window.FinanceControl&&FinanceControl.render)try{FinanceControl.render()}catch(e){}
  },
  label(){const l=this.get();return l?'🔒 Closed up to '+l:'🔓 Not closed'}
};
const dom=id=>document.getElementById(id)?.value||'';
const find=(list,id)=>(list||[]).find(x=>x.id===id);
function wrap(objName,fn,datesOf){
  const o=window[objName];if(!o||typeof o[fn]!=='function'||o[fn].__locked)return;
  const orig=o[fn];
  const w=function(...a){
    let ds=[];try{ds=datesOf(...a)||[]}catch(e){}
    for(const d of ds){if(PeriodLock.blocked(d))return}
    return orig.apply(this,a);
  };
  w.__locked=true;o[fn]=w;
}
function install(){
  wrap('Sales','submit',()=>[dom('sellDate')]);
  wrap('Sales','update',id=>[dom('sellDate'),(find(State.sales,id)||{}).date]);
  wrap('Sales','delete',id=>[(find(State.sales,id)||{}).date]);
  wrap('Purchases','submit',()=>[dom('purchaseDate')]);
  wrap('Purchases','update',id=>[dom('purchaseDate'),(find(State.purchases,id)||{}).date]);
  wrap('Purchases','delete',id=>[(find(State.purchases,id)||{}).date]);
  wrap('Expenses','submitDirect',()=>[dom('directExpenseDate')]);
  wrap('Expenses','deleteDirect',id=>[(find(State.directExpenses,id)||{}).date]);
}
window.PeriodLock=PeriodLock;
// Modules register after the page loads, so install the guards a little later and once more to be safe.
window.addEventListener('load',()=>{setTimeout(install,1500);setTimeout(install,6000)});
})();
