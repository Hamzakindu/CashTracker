// CATALOG: draws one picture with several products (photo, name, price) ready to share
(function(){'use strict';
const store=()=>{try{return JSON.parse(localStorage.getItem('stockProfile')||'{}').storeName||'CashTracker'}catch(e){return 'CashTracker'}};
const cache={};
const load=src=>new Promise(res=>{if(!src)return res(null);const i=new Image();i.onload=()=>res(i);i.onerror=()=>res(null);i.src=src});
const photo=p=>(p.images||[]).find(u=>String(u).indexOf('data:image')===0)||'';
async function make(ps){
  ps=ps.slice(0,8);
  const sig=ps.map(p=>[p.id,p.sell,p.stock,photo(p).length].join(':')).join('|');
  if(cache.sig===sig&&cache.url)return cache.url;
  const W=900,pad=20,cw=(W-pad*3)/2,ih=cw,ch=ih+110,rows=Math.ceil(ps.length/2),top=130,H=top+rows*(ch+pad)+90;
  const cv=document.createElement('canvas');cv.width=W;cv.height=H;const g=cv.getContext('2d');
  g.fillStyle='#fff';g.fillRect(0,0,W,H);
  g.fillStyle='#0d1b3d';g.fillRect(0,0,W,top-20);
  g.fillStyle='#fff';g.font='bold 44px sans-serif';g.fillText(store(),pad,62);
  g.fillStyle='#cdd6ee';g.font='26px sans-serif';g.fillText('Catalog · '+new Date().toLocaleDateString(),pad,100);
  const imgs=await Promise.all(ps.map(p=>load(photo(p))));
  ps.forEach((p,i)=>{
    const x=pad+(i%2)*(cw+pad),y=top+Math.floor(i/2)*(ch+pad),im=imgs[i];
    g.fillStyle='#f3f5f9';g.fillRect(x,y,cw,ch);
    if(im){const s=Math.max(cw/im.width,ih/im.height),w=im.width*s,h=im.height*s;g.save();g.beginPath();g.rect(x,y,cw,ih);g.clip();g.drawImage(im,x+(cw-w)/2,y+(ih-h)/2,w,h);g.restore()}
    else{g.fillStyle='#d9deea';g.fillRect(x,y,cw,ih);g.fillStyle='#8892a8';g.font='bold 120px sans-serif';g.textAlign='center';g.fillText((p.name||'?').charAt(0).toUpperCase(),x+cw/2,y+ih/2+40);g.textAlign='left'}
    g.fillStyle='#111';g.font='bold 28px sans-serif';
    let n=String(p.name||'');while(g.measureText(n).width>cw-24&&n.length>3)n=n.slice(0,-1);if(n!==p.name)n+='…';
    g.fillText(n,x+12,y+ih+38);
    g.fillStyle='#198754';g.font='bold 32px sans-serif';g.fillText(Helpers.formatCurrency(Number(p.sell)||0),x+12,y+ih+82);
    if(!(Number(p.stock)>0)){g.fillStyle='#dc3545';g.font='bold 22px sans-serif';g.textAlign='right';g.fillText('Out of stock',x+cw-12,y+ih+82);g.textAlign='left'}
  });
  g.fillStyle='#555';g.font='26px sans-serif';g.fillText('Reply to order · '+store(),pad,H-34);
  const url=cv.toDataURL('image/jpeg',0.85);cache.sig=sig;cache.url=url;return url;
}
async function shrink(src,max){
  max=max||1280;const im=await load(src);if(!im)return src;
  const k=Math.min(1,max/Math.max(im.width,im.height));if(k>=1&&String(src).length<400000)return src;
  const cv=document.createElement('canvas');cv.width=Math.round(im.width*k);cv.height=Math.round(im.height*k);
  cv.getContext('2d').drawImage(im,0,0,cv.width,cv.height);return cv.toDataURL('image/jpeg',0.82);
}
async function card(p){
  const W=900,PH=900,TP=300,H=PH+TP,cv=document.createElement('canvas');cv.width=W;cv.height=H;const g=cv.getContext('2d');
  g.fillStyle='#0d1b3d';g.fillRect(0,0,W,H);
  const im=await load(photo(p));
  g.save();g.beginPath();g.rect(0,0,W,PH);g.clip();
  if(im){const k=Math.max(W/im.width,PH/im.height),w=im.width*k,h=im.height*k;g.drawImage(im,(W-w)/2,(PH-h)/2,w,h)}
  else{g.fillStyle='#d9deea';g.fillRect(0,0,W,PH);g.fillStyle='#8892a8';g.font='bold 300px sans-serif';g.textAlign='center';g.fillText((p.name||'?').charAt(0).toUpperCase(),W/2,PH/2+100);g.textAlign='left'}
  g.restore();
  g.fillStyle='#fff';g.font='bold 46px sans-serif';
  const words=String(p.name||'').split(' ');let lines=[],cur='';
  words.forEach(w=>{const t=cur?cur+' '+w:w;if(g.measureText(t).width>W-60&&cur){lines.push(cur);cur=w}else cur=t});lines.push(cur);
  lines=lines.slice(0,2);let y=PH+62;lines.forEach(l=>{g.fillText(l,30,y);y+=54});
  g.fillStyle='#5ef0a0';g.font='bold 56px sans-serif';g.fillText(Helpers.formatCurrency(Number(p.sell)||0),30,PH+TP-70);
  g.font='28px sans-serif';g.fillStyle=Number(p.stock)>0?'#cdd6ee':'#ff8a8a';g.fillText(Number(p.stock)>0?'In stock':'Out of stock',30,PH+TP-26);
  g.textAlign='right';g.fillStyle='#cdd6ee';g.fillText(store(),W-30,PH+TP-26);g.textAlign='left';
  return cv.toDataURL('image/jpeg',0.85);
}
window.Catalog={make,shrink,card};
})();
