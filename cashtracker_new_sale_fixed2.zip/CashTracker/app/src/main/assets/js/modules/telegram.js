// ============================================
// TELEGRAM INTEGRATION MODULE
// ============================================

(function() {
    'use strict';
    
    const MODULE_NAME = 'TelegramModule';
    const PHOTO_KEY = 'stockpro_telegram_photo_channel';
    const BACKUP_KEY = 'stockpro_telegram_backup_channel';
    const htmlEsc = v => (window.Helpers && Helpers.esc) ? Helpers.esc(String(v == null ? '' : v)) : String(v == null ? '' : v).replace(/[&<>\"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]));
    const getPhotoChannel = () => localStorage.getItem(PHOTO_KEY) || '';
    const getBackupChannel = () => localStorage.getItem(BACKUP_KEY) || '';
    const channelRequired = (value, label) => { if (!value) { Toast.warning('Configure '+label+' first'); return false; } return true; };
    
    console.log('📦 Registering ' + MODULE_NAME + '...');
    
    window.registerModule(MODULE_NAME, function() {
        console.log('✅ ' + MODULE_NAME + ' initializing...');
        
        const TelegramModule = {
            updateStatus() {
                const el = document.getElementById('telegramStatus');
                if (el) {
                    el.textContent = `✅ Photos: ${htmlEsc(getPhotoChannel())} | Backup: ${htmlEsc(getBackupChannel())}`;
                    el.style.color = 'var(--success)';
                }
            },

            openSettings() {
                const existingModal = document.getElementById('telegramModal');
                if (existingModal) {
                    existingModal.remove();
                }

                const modal = document.createElement('div');
                modal.className = 'modal-overlay';
                modal.id = 'telegramModal';
                modal.innerHTML = `
                    <div class="modal" style="max-width:520px;">
                        <button class="close-btn" data-cashtracker-onclick="Modals.close('telegramModal')">✕</button>
                        <h3>📡 Telegram Settings</h3>
                        <p style="font-size:0.85rem;color:var(--text2);margin-bottom:12px;">
                            📸 Products → ${htmlEsc(getPhotoChannel())}<br>
                            📦 Backups → Channel ID: ${htmlEsc(getBackupChannel())}
                        </p>
                        <div class="form-group">
                            <label>🤖 Bot Token</label>
                            <input class="form-control" id="telegramBotToken" value="${htmlEsc(CONFIG.TELEGRAM.TOKEN || '')}" placeholder="Paste bot token from @BotFather" style="font-family:monospace;font-size:0.8rem;">
                            <small style="color:var(--text2);font-size:0.7rem;">The token is stored only in this browser. Never publish it in your source code.</small>
                            <button class="btn btn-primary btn-sm" style="margin-top:6px;" data-cashtracker-onclick="TelegramModule.saveToken()">💾 Save Bot Token</button>
                        </div>
                        <div class="form-group">
                            <label>📸 Product Photo Channel</label>
                            <input class="form-control" id="telegramPhotoChannel" value="${htmlEsc(getPhotoChannel())}" style="font-family:monospace;font-size:0.8rem;">
                        </div>
                        <div class="form-group">
                            <label>📦 Backup Channel</label>
                            <input class="form-control" id="telegramBackupChannel" value="${htmlEsc(getBackupChannel())}" style="font-family:monospace;font-size:0.8rem;"><button class="btn btn-sm btn-primary" style="margin-top:6px" data-cashtracker-onclick="TelegramModule.saveChannels()">Save channels</button>
                        </div>
                        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;">
                            <button class="btn btn-primary btn-sm" id="testTelegramBtn" data-cashtracker-onclick="TelegramModule.testConnection()">📡 Test Both Channels</button>
                        </div>
                        <hr style="border-color:var(--border);margin:12px 0;">
                        <div class="form-group">
                            <label>☁️ Backup to Telegram</label>
                            <button class="btn btn-info btn-block" id="backupToTelegramBtn" data-cashtracker-onclick="TelegramModule.backupToTelegram()" style="background:#0088cc;color:#fff;">📤 Send Backup to Channel</button>
                            <small style="color:var(--text2);font-size:0.7rem;">Backup goes to channel: ${htmlEsc(getBackupChannel())}</small>
                        </div>
                        <div class="form-group">
                            <label>📥 Restore from Telegram</label>
                            <div style="display:flex;gap:6px;flex-wrap:wrap;">
                                <input class="form-control" id="telegramFileId" placeholder="Paste file_id from bot reply" style="flex:1;min-width:150px;">
                                <button class="btn btn-warning" id="restoreFromTelegramBtn" data-cashtracker-onclick="TelegramModule.restoreFromTelegram()">📥 Restore</button>
                            </div>
                            <small style="color:var(--text2);font-size:0.7rem;">
                                Steps:<br>
                                1. Click "Backup to Telegram" above<br>
                                2. Bot sends a file to the backup channel<br>
                                3. Reply to that file with /getid<br>
                                4. Copy the file_id from bot's reply<br>
                                5. Paste it here and click Restore
                            </small>
                        </div>
                        <div id="telegramStatusModal" style="padding:8px;background:var(--bg);border-radius:var(--radius-sm);margin-top:8px;font-size:0.85rem;"></div>
                    </div>
                `;
                
                document.body.appendChild(modal);
                Modals.open('telegramModal');
            },

            saveChannels() {
                const photo = (document.getElementById('telegramPhotoChannel')?.value || '').trim();
                const backup = (document.getElementById('telegramBackupChannel')?.value || '').trim();
                if (photo) localStorage.setItem(PHOTO_KEY, photo); else localStorage.removeItem(PHOTO_KEY);
                if (backup) localStorage.setItem(BACKUP_KEY, backup); else localStorage.removeItem(BACKUP_KEY);
                Toast.success('Telegram channels saved on this device');
                this.updateStatus();
                return true;
            },

            saveToken() {
                const input = document.getElementById('telegramBotToken');
                const token = (input?.value || '').trim();
                if (!token) {
                    localStorage.removeItem('stockpro_telegram_bot_token');
                    CONFIG.TELEGRAM.TOKEN = '';
                    Toast.warning('Bot token cleared');
                    return false;
                }
                localStorage.setItem('stockpro_telegram_bot_token', token);
                CONFIG.TELEGRAM.TOKEN = token;
                Toast.success('Bot token saved on this device');
                return true;
            },

            async testConnection() {
                if (!channelRequired(getPhotoChannel(), 'Photo channel') || !channelRequired(getBackupChannel(), 'Backup channel')) return;
                const statusEl = document.getElementById('telegramStatusModal');
                if (!CONFIG.TELEGRAM.TOKEN) {
                    if (statusEl) { statusEl.textContent = '⚠️ Enter and save a Telegram bot token first.'; statusEl.style.whiteSpace='pre-wrap'; }
                    Toast.warning('Enter and save the Telegram bot token first');
                    return;
                }
                const testBtn = document.getElementById('testTelegramBtn');
                
                if (statusEl) { statusEl.textContent = '⏳ Testing connection...'; statusEl.style.whiteSpace='pre-wrap'; }
                if (testBtn) {
                    testBtn.disabled = true;
                    testBtn.textContent = '⏳ Testing...';
                }

                try {
                    const response = await fetch(`https://api.telegram.org/bot${CONFIG.TELEGRAM.TOKEN}/getMe`);
                    const data = await response.json();

                    if (!data.ok) {
                        if (statusEl) { statusEl.textContent = '❌ Invalid bot token. Check CONFIG.TELEGRAM.TOKEN'; statusEl.style.whiteSpace='pre-wrap'; }
                        Toast.error('Invalid bot token');
                        if (testBtn) { testBtn.disabled = false; testBtn.textContent = '📡 Test Both Channels'; }
                        return;
                    }

                    let result = `✅ Bot: @${data.result.username}\n`;

                    try {
                        const photoRes = await fetch(`https://api.telegram.org/bot${CONFIG.TELEGRAM.TOKEN}/sendMessage`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                chat_id: getPhotoChannel(),
                                text: '📸 Photo channel test OK - CashTracker'
                            })
                        });
                        const photoData = await photoRes.json();
                        result += photoData.ok ? '✅ Photo channel OK\n' : '❌ Photo channel: ' + (photoData.description || 'Error') + '\n';
                    } catch (e) {
                        result += '❌ Photo channel: Network error\n';
                    }

                    try {
                        const backupRes = await fetch(`https://api.telegram.org/bot${CONFIG.TELEGRAM.TOKEN}/sendMessage`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                chat_id: getBackupChannel(),
                                text: '📦 Backup channel test OK - CashTracker'
                            })
                        });
                        const backupData = await backupRes.json();
                        result += backupData.ok ? '✅ Backup channel OK' : '❌ Backup channel: ' + (backupData.description || 'Error');
                    } catch (e) {
                        result += '❌ Backup channel: Network error';
                    }

                    if (statusEl) { statusEl.textContent = result; statusEl.style.whiteSpace='pre-wrap'; }
                    
                    if (result.includes('❌')) {
                        Toast.warning('Some channels failed');
                    } else {
                        Toast.success('All channels connected!');
                    }

                } catch (error) {
                    if (statusEl) { statusEl.textContent = '❌ Network error: ' + error.message; statusEl.style.whiteSpace='pre-wrap'; }
                    Toast.error('Connection failed');
                } finally {
                    if (testBtn) {
                        testBtn.disabled = false;
                        testBtn.textContent = '📡 Test Both Channels';
                    }
                }
            },

            async sendProduct(product) {
                if (!channelRequired(getPhotoChannel(), 'Photo channel')) return;
                if (!product.images || !product.images.length) return;

                try {
                    const caption = `📦 *${product.name}*\n💰 Sell: ${Helpers.formatCurrency(product.sell)}\n📦 Stock: ${product.stock || 0}${product.notes ? '\n📝 ' + product.notes : ''}`;

                    for (let i = 0; i < product.images.length; i++) {
                        try {
                            const response = await fetch(product.images[i]);
                            const blob = await response.blob();
                            const formData = new FormData();
                            formData.append('chat_id', getPhotoChannel());
                            formData.append('photo', blob, 'product_' + i + '.jpg');
                            
                            if (i === 0) {
                                formData.append('caption', caption);
                            }

                            await fetch(`https://api.telegram.org/bot${CONFIG.TELEGRAM.TOKEN}/sendPhoto`, {
                                method: 'POST',
                                body: formData
                            });
                        } catch (err) {
                            console.error('Photo send error:', err);
                        }
                    }
                } catch (error) {
                    console.error('sendProductToTelegram error:', error);
                }
            },

            async backupToTelegram() {
                if (!channelRequired(getBackupChannel(), 'Backup channel')) return;
                const statusEl = document.getElementById('telegramStatusModal');
                const backupBtn = document.getElementById('backupToTelegramBtn');
                
                if (!statusEl) {
                    this.openSettings();
                    setTimeout(() => this.backupToTelegram(), 500);
                    return;
                }

                statusEl.textContent = '⏳ Preparing backup...';
                if (backupBtn) {
                    backupBtn.disabled = true;
                    backupBtn.textContent = '⏳ Uploading...';
                }
                
                Toast.info('Preparing backup...');

                try {
                    const data = {
                        exportedAt: new Date().toISOString(),
                        profileId: State.currentProfileId,
                        appVersion: CONFIG.VERSION,
                        products: State.products,
                        sales: State.sales,
                        purchases: State.purchases,
                        customers: State.customers,
                        suppliers: State.suppliers,
                        expenseTypes: State.expenseTypes,
                        directExpenses: State.directExpenses,
                        returns: State.returns,
                        calculations: State.calculations,
                        stockHistory: State.stockHistory
                    };

                    const passphrase = await BackupCrypto.getPassphrase(true);
                    const encrypted = await BackupCrypto.encryptJson(data, passphrase);
                    const blob = new Blob([encrypted], { type: 'application/octet-stream' });
                    const filename = `stockpro-backup-${new Date().toISOString().slice(0, 10)}.ctbackup`;
                    const file = new File([blob], filename, { type: 'application/json' });

                    const formData = new FormData();
                    formData.append('chat_id', getBackupChannel());
                    formData.append('document', file);
                    formData.append('caption', '📦 CashTracker Backup - ' + new Date().toLocaleString());

                    statusEl.textContent = '⏳ Uploading to Telegram...';

                    const response = await fetch(`https://api.telegram.org/bot${CONFIG.TELEGRAM.TOKEN}/sendDocument`, {
                        method: 'POST',
                        body: formData
                    });

                    const result = await response.json();

                    if (result.ok) {
                        const fileId = result.result.document.file_id;
                        statusEl.textContent = '✅ Backup sent successfully!\nFile ID: ' + String(fileId) + '\nSave this File ID to restore later';
                        statusEl.style.whiteSpace = 'pre-wrap';
                        Toast.success('Backup sent to Telegram!');
                    } else {
                        statusEl.textContent = '❌ Error: ' + (result.description || 'Unknown error');
                        Toast.error('Backup failed');
                    }

                } catch (error) {
                    statusEl.textContent = '❌ Error: ' + error.message;
                    Toast.error('Backup failed: ' + error.message);
                } finally {
                    if (backupBtn) {
                        backupBtn.disabled = false;
                        backupBtn.textContent = '📤 Send Backup to Channel';
                    }
                }
            },

            async restoreFromTelegram() {
                if (!channelRequired(getBackupChannel(), 'Backup channel')) return;
                const fileIdInput = document.getElementById('telegramFileId');
                const statusEl = document.getElementById('telegramStatusModal');
                const restoreBtn = document.getElementById('restoreFromTelegramBtn');
                
                if (!fileIdInput) {
                    this.openSettings();
                    setTimeout(() => this.restoreFromTelegram(), 500);
                    return;
                }

                const fileId = fileIdInput.value.trim();
                
                if (!fileId) {
                    Toast.warning('Please paste a file_id first');
                    return;
                }

                if (!confirm('⚠️ This will OVERWRITE all current data with the Telegram backup. Continue?')) {
                    return;
                }

                if (statusEl) statusEl.textContent = '⏳ Downloading backup from Telegram...';
                if (restoreBtn) {
                    restoreBtn.disabled = true;
                    restoreBtn.textContent = '⏳ Downloading...';
                }

                try {
                    const getFileResponse = await fetch(`https://api.telegram.org/bot${CONFIG.TELEGRAM.TOKEN}/getFile?file_id=${encodeURIComponent(fileId)}`);
                    const fileData = await getFileResponse.json();

                    if (!fileData.ok) {
                        throw new Error('Invalid file_id or file not found. Error: ' + (fileData.description || 'Unknown'));
                    }

                    if (statusEl) statusEl.textContent = '⏳ Downloading file...';

                    const downloadUrl = `https://api.telegram.org/file/bot${CONFIG.TELEGRAM.TOKEN}/${fileData.result.file_path}`;
                    const downloadResponse = await fetch(downloadUrl);
                    
                    if (!downloadResponse.ok) {
                        throw new Error('Failed to download file from Telegram');
                    }

                    const text = await downloadResponse.text();
                    let data;
                    try {
                        const parsedEnvelope = JSON.parse(text);
                        if (BackupCrypto.isEncrypted(parsedEnvelope)) { const passphrase = await BackupCrypto.getPassphrase(false); data = await BackupCrypto.decryptJson(parsedEnvelope, passphrase); } else { data = parsedEnvelope; }
                    } catch (parseError) {
                        throw new Error('Could not decrypt this backup. Check the passphrase, or select a plain JSON backup.');
                    }

                    if (!data.products || !Array.isArray(data.products)) {
                        throw new Error('Invalid backup format. Missing products data.');
                    }

                    State.saveUndoState('Before Telegram restore');

                    const stores = ['products', 'sales', 'purchases', 'customers', 'suppliers', 'expenseTypes', 'directExpenses', 'returns', 'calculations', 'stockHistory'];
                    let restoredCount = 0;

                    for (const store of stores) {
                        if (data[store] && Array.isArray(data[store])) {
                            Storage.save(store, data[store]);
                            restoredCount++;
                        }
                    }

                    if (restoredCount === 0) {
                        throw new Error('No valid data found in backup');
                    }

                    if (statusEl) statusEl.textContent = '✅ Data restored successfully! Reloading...';
                    Toast.success('Data restored from Telegram!', 4000);

                    fileIdInput.value = '';

                    setTimeout(async () => {
                        await State.loadAllData();
                        App.populateDropdowns();
                        Dashboard.update();
                        Products.render();
                        Sales.render();
                        Purchases.render();
                        Customers.render();
                        Suppliers.render();
                        Expenses.renderTypes();
                        Expenses.renderDirect();
                        Returns.render();
                        Tabs.switchTo('dashboard');
                        Toast.success('✅ Restore complete! ' + restoredCount + ' data stores loaded.', 3000);
                    }, 1000);

                } catch (error) {
                    console.error('Telegram restore error:', error);
                    if (statusEl) statusEl.textContent = '❌ ' + error.message;
                    Toast.error('Restore failed: ' + error.message, 5000);
                } finally {
                    if (restoreBtn) {
                        restoreBtn.disabled = false;
                        restoreBtn.textContent = '📥 Restore';
                    }
                }
            }
        };
        
        window.TelegramModule = TelegramModule;
        console.log('✅ ' + MODULE_NAME + ' loaded successfully');
        return TelegramModule;
    });
    
})();