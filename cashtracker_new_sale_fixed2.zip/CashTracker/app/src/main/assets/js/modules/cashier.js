(function(){
'use strict';
window.registerModule('Cashier', function(){
const C={
init(){
  State.cashierSessions=Array.isArray(State.cashierSessions)?State.cashierSessions:[];
  State.cashCounts=Array.isArray(State.cashCounts)?State.cashCounts:[];
},
current(){this.init();return State.cashierSessions.find(x=>x.status==='open');},
cashAccounts(){
  if(!window.CashBanks)return [];
  return CashBanks.accounts().filter(a=>a.type==='cash');
},
round(n){return Math.round((Number(n)||0)*100)/100;},
totals(s){
  let incoming=0,outgoing=0;
  const openedAt=Date.parse(s.openedAt||'')||0;
  (State.moneyTransactions||[]).filter(t=>{
    if(t.status==='void'||t.accountId!==s.accountId||String(t.date||'')!==String(s.date||''))return false;
    if(t.type==='opening')return false;
    const created=Date.parse(t.createdAt||'')||0;
    return !openedAt || !created || created>=openedAt;
  }).forEach(t=>{
    const n=Number(t.amount||0);
    if(['in','income','transfer_in','adjustment_in'].includes(t.type)) incoming+=n;
    else if(['out','expense','transfer_out','adjustment_out'].includes(t.type)) outgoing+=n;
  });
  return {incoming:this.round(incoming),outgoing:this.round(outgoing),expected:this.round(Number(s.opening||0)+incoming-outgoing)};
},
open(){
  const aId=document.getElementById('cashSessionAccount')?.value;
  const opening=Number(document.getElementById('cashOpening')?.value);
  if(this.current())return Toast.warning('A cashier session is already open');
  if(!aId||!Number.isFinite(opening)||opening<0)return Toast.warning('Choose a cash account and enter opening cash');
  const account=this.cashAccounts().find(a=>a.id===aId);
  if(!account)return Toast.warning('Select a valid cash account');
  const today=Helpers.getToday();
  if(State.cashierSessions.some(x=>x.date===today&&x.status==='closed'))
    return Toast.warning('Today is already closed. Use the next business day.');
  const s={id:Helpers.uid(),date:today,accountId:aId,opening:this.round(opening),status:'open',openedAt:new Date().toISOString()};
  State.saveUndoState('Open cashier session');
  State.cashierSessions.unshift(s);
  Storage.save('cashierSessions',State.cashierSessions);
  // Opening cash is a snapshot, not new money. Do not post it to the account ledger.
  this.render();
  Toast.success('Cashier opened');
},
close(){
  const s=this.current();
  const actual=Number(document.getElementById('cashActual')?.value);
  const note=(document.getElementById('cashCloseNote')?.value||'').trim();
  if(!s)return Toast.warning('No open cashier session');
  if(!Number.isFinite(actual)||actual<0)return Toast.warning('Enter the physical cash counted');
  const t=this.totals(s), diff=this.round(actual-t.expected);
  if(diff!==0&&!note)return Toast.warning('Enter a closing note explaining the cash difference');
  State.saveUndoState('Close cashier session');
  Object.assign(s,{status:'closed',closedAt:new Date().toISOString(),expected:t.expected,actual:this.round(actual),difference:diff,note});
  State.cashCounts.unshift({id:Helpers.uid(),sessionId:s.id,date:s.date,expected:t.expected,actual:this.round(actual),difference:diff,note,accountId:s.accountId,closedAt:s.closedAt});
  Storage.save('cashierSessions',State.cashierSessions);
  Storage.save('cashCounts',State.cashCounts);
  if(diff!==0&&window.AccountingLedger?.audit)
    AccountingLedger.audit('user','cashier_difference','cashier_session',{sessionId:s.id,expected:t.expected,actual:this.round(actual),difference:diff,note});
  this.render();
  if(typeof Dashboard!=='undefined'&&Dashboard.update)Dashboard.update();
  Toast.success(diff!==0?'Day closed with a cash difference':'Day closed and balanced');
},
setOpeningFromAccount(){
  const select=document.getElementById('cashSessionAccount'),input=document.getElementById('cashOpening');
  if(!select||!input||!window.CashBanks)return;
  const a=CashBanks.get(select.value);
  if(a)input.value=this.round(CashBanks.balance(a.id)).toFixed(2);
},
render(){
  this.init();
  const p=document.getElementById('tab-cashier');if(!p)return;
  const s=this.current();
  if(!s){
    const accounts=this.cashAccounts();
    p.innerHTML=`<div class="card"><div class="card-title">🧾 Cashier & Daily Closing</div>
      <p style="opacity:.75">Open one cash drawer for the business day, record its opening cash, then close it by counting the physical cash.</p>
      ${accounts.length?`
      <div class="form-group"><label>Cash drawer account</label><select class="form-control" id="cashSessionAccount" data-cashtracker-onchange="Cashier.setOpeningFromAccount()">${accounts.map(a=>`<option value="${Helpers.esc(a.id)}">${Helpers.esc(a.name)}</option>`).join('')}</select></div>
      <div class="form-group"><label>Opening cash</label><input class="form-control" id="cashOpening" type="number" min="0" step=".01" value="0"></div>
      <button class="btn btn-success" data-cashtracker-onclick="Cashier.open()">▶ Open Day</button>
      <button class="btn" data-cashtracker-onclick="CashBanks.openAccountModal()">＋ Add Cash Account</button>
      `:'<div class="empty-state">No cash account exists. Add a cash account in Cash & Banks first.</div>'}
      </div>${this.history()}`;
    if(accounts.length)this.setOpeningFromAccount();
    return;
  }
  const t=this.totals(s),account=window.CashBanks?.get(s.accountId);
  p.innerHTML=`<div class="card"><div class="flex-between"><div><div class="card-title">🧾 Open Cashier — ${Helpers.formatDate(s.date)}</div><small>${Helpers.esc(account?.name||'Cash drawer')}</small></div><span style="padding:4px 9px;border-radius:999px;background:var(--success,#198754);color:#fff;font-size:12px;font-weight:700">OPEN</span></div>
    <div class="stock-summary-grid">
      <div class="stock-summary-item"><span class="summary-label">Opening</span><span class="summary-value">${Helpers.formatCurrency(s.opening)}</span></div>
      <div class="stock-summary-item"><span class="summary-label">Money in</span><span class="summary-value">${Helpers.formatCurrency(t.incoming)}</span></div>
      <div class="stock-summary-item"><span class="summary-label">Money out</span><span class="summary-value">${Helpers.formatCurrency(t.outgoing)}</span></div>
      <div class="stock-summary-item"><span class="summary-label">Expected cash</span><span class="summary-value">${Helpers.formatCurrency(t.expected)}</span></div>
    </div></div>
    <div class="card"><div class="card-title">🔒 Close Day</div>
      <div class="form-group"><label>Physical cash counted</label><input class="form-control" id="cashActual" type="number" min="0" step=".01" placeholder="Count the cash in the drawer"></div>
      <div class="form-group"><label>Closing note <small>(required when there is a difference)</small></label><input class="form-control" id="cashCloseNote" maxlength="250" placeholder="Reason for shortage/overage, if any"></div>
      <button class="btn btn-danger" data-cashtracker-onclick="Cashier.close()">🔒 Close Day</button>
    </div>${this.history()}`;
},
history(){
  const h=(State.cashCounts||[]).slice().sort((a,b)=>String(b.closedAt||b.date||'').localeCompare(String(a.closedAt||a.date||''))).slice(0,30);
  if(!h.length)return '<div class="card"><div class="card-title">Previous Closings</div><div class="empty-state">No closed days</div></div>';
  return `<div class="card"><div class="card-title">Previous Closings</div><div style="overflow-x:auto"><table class="transaction-table"><thead><tr><th>Date</th><th>Expected</th><th>Actual</th><th>Difference</th><th>Status</th><th>Note</th></tr></thead><tbody>${h.map(x=>`<tr><td>${Helpers.formatDate(x.date)}</td><td>${Helpers.formatCurrency(x.expected)}</td><td>${Helpers.formatCurrency(x.actual)}</td><td>${Helpers.formatCurrency(x.difference)}</td><td>${Number(x.difference||0)===0?'✅ Balanced':'⚠️ Difference'}</td><td>${Helpers.esc(x.note||'—')}</td></tr>`).join('')}</tbody></table></div></div>`;
}
};
window.Cashier=C;return C;});
})();
