// STATEMENTS: balance sheet, receivable/payable aging, inventory value and cash flow, built from live balances.
(function(){'use strict';
const n=v=>Number(v)||0;
const esc=s=>Helpers.esc(String(s==null?'':s));
const fmt=v=>Helpers.formatCurrency(n(v));
const today=()=>Helpers.getToday();
const days=d=>{const t=new Date(String(d||'').slice(0,10)+'T00:00:00');return isNaN(t)?9999:Math.max(0,Math.floor((Date.now()-t)/864e5))};
const BUCKETS=[['0-30',0,30],['31-60',31,60],['61-90',61,90],['90+',91,1e9]];
const bucketOf=a=>BUCKETS.findIndex(b=>a>=b[1]&&a<=b[2]);
const out=()=>document.getElementById('statementsOutput');
const live=x=>x&&x.status!=='void'&&x.accountingStatus!=='void';
const table=(head,rows,foot)=>`<div style="overflow-x:auto"><table class="table" style="width:100%;font-size:.9rem"><thead><tr>${head.map((h,i)=>`<th style="text-align:${i?'right':'left'}">${h}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map((c,i)=>`<td style="text-align:${i?'right':'left'}">${c}</td>`).join('')}</tr>`).join('')}${foot?`<tr style="font-weight:700">${foot.map((c,i)=>`<td style="text-align:${i?'right':'left'}">${c}</td>`).join('')}</tr>`:''}</tbody></table></div>`;
function inventoryRows(){
  return (State.products||[]).filter(p=>n(p.stock)>0).map(p=>({p,qty:n(p.stock),cost:n(p.buy),val:n(p.stock)*n(p.buy),retail:n(p.stock)*n(p.sell)}));
}
// Allocate an outstanding balance to the newest unpaid invoices first (older ones were paid first); the rest is older/opening debt.
function ageParty(balance,docs,getAmt){
  const b=[0,0,0,0];let left=n(balance);if(left<=0)return b;
  docs.sort((x,y)=>String(y.date).localeCompare(String(x.date)));
  for(const d of docs){if(left<=0)break;const a=Math.min(left,n(getAmt(d)));if(a<=0)continue;b[bucketOf(days(d.date))]+=a;left-=a}
  if(left>0)b[3]+=left;
  return b;
}
function agingReport(kind){
  const cust=kind==='customer';
  const parties=(cust?State.customers:State.suppliers)||[];
  const docs=cust?(State.sales||[]).filter(s=>live(s)&&n(s.debitRemaining)>0):(State.purchases||[]).filter(p=>live(p)&&n(p.debit)>0);
  const rows=[],tot=[0,0,0,0];
  parties.filter(x=>n(x.balance)>0).forEach(x=>{
    const mine=docs.filter(d=>(cust?d.customerId:d.supplierId)===x.id).map(d=>({date:d.date||d.createdAt,amt:cust?d.debitRemaining:d.debit}));
    const b=ageParty(x.balance,mine,d=>d.amt);b.forEach((v,i)=>tot[i]+=v);
    rows.push({name:x.name,b,total:n(x.balance)});
  });
  rows.sort((a,b)=>b.total-a.total);
  const grand=tot.reduce((a,v)=>a+v,0);
  return `<div class="card"><div class="card-title">${cust?'🧾 Who owes you':'📤 Who you owe'} — aging</div>
  <small>${cust?'Unpaid customer balances':'Unpaid supplier balances'} grouped by how old the invoice is. Payments are assumed to settle the oldest invoices first.</small>
  ${rows.length?table(['Name',...BUCKETS.map(b=>b[0]+' d'),'Total'],rows.map(r=>[esc(r.name),...r.b.map(fmt),`<b>${fmt(r.total)}</b>`]),['Total',...tot.map(fmt),fmt(grand)]):'<p>Nothing outstanding 🎉</p>'}</div>`;
}
function balanceSheet(){
  const cb=window.CashBanks?CashBanks.totals():{cash:0,bank:0,wallet:0,total:0};
  const rec=(State.customers||[]).reduce((a,c)=>a+Math.max(0,n(c.balance)),0);
  const inv=inventoryRows().reduce((a,r)=>a+r.val,0);
  const supAdv=(State.suppliers||[]).reduce((a,s)=>a+n(s.supplierAdvance),0);
  const pay=(State.suppliers||[]).reduce((a,s)=>a+Math.max(0,n(s.balance)),0);
  const cusAdv=(State.customers||[]).reduce((a,c)=>a+n(c.customerAdvance),0);
  const assets=cb.total+rec+inv+supAdv,liab=pay+cusAdv,eq=assets-liab;
  const noCost=inventoryRows().filter(r=>r.cost<=0).length;
  return `<div class="card"><div class="card-title">⚖️ Balance sheet — ${esc(today())}</div>
  ${table(['Assets',''],[['Cash',fmt(cb.cash)],['Bank',fmt(cb.bank)],['Mobile wallets',fmt(cb.wallet)],['Customers owe you',fmt(rec)],['Stock (at cost)',fmt(inv)],['Advances paid to suppliers',fmt(supAdv)]],['Total assets',fmt(assets)])}
  ${table(['Liabilities',''],[['You owe suppliers',fmt(pay)],['Customer credit / advances',fmt(cusAdv)]],['Total liabilities',fmt(liab)])}
  ${table(['Owner’s equity',''],[['Assets minus liabilities',fmt(eq)]],null)}
  ${noCost?`<p style="color:var(--warning)">⚠️ ${noCost} product(s) in stock have no buying price, so stock value is understated.</p>`:''}
  <small>Taken from live balances today. Equity includes your capital plus all profit kept in the business.</small></div>`;
}
function inventoryValue(){
  const rows=inventoryRows(),groups={};
  rows.forEach(r=>{const k=r.p.category||'(no category)';const g=groups[k]||(groups[k]={units:0,val:0,retail:0,items:0});g.units+=r.qty;g.val+=r.val;g.retail+=r.retail;g.items++});
  const list=Object.keys(groups).sort((a,b)=>groups[b].val-groups[a].val);
  const T=rows.reduce((a,r)=>({units:a.units+r.qty,val:a.val+r.val,retail:a.retail+r.retail}),{units:0,val:0,retail:0});
  const top=rows.slice().sort((a,b)=>b.val-a.val).slice(0,10);
  const noCost=rows.filter(r=>r.cost<=0);
  return `<div class="card"><div class="card-title">📦 Inventory value</div>
  ${table(['Category','Items','Units','At cost','At selling price'],list.map(k=>[esc(k),groups[k].items,groups[k].units,fmt(groups[k].val),fmt(groups[k].retail)]),['Total',rows.length,T.units,fmt(T.val),fmt(T.retail)])}
  <p>Expected profit if everything sells: <b>${fmt(T.retail-T.val)}</b></p>
  <div class="card-title" style="margin-top:10px">Top 10 by money tied up</div>
  ${table(['Product','Units','Cost each','Value'],top.map(r=>[esc(r.p.name),r.qty,fmt(r.cost),fmt(r.val)]))}
  ${noCost.length?`<p style="color:var(--warning)">⚠️ No buying price: ${noCost.slice(0,8).map(r=>esc(r.p.name)).join(', ')}${noCost.length>8?' …':''}</p>`:''}</div>`;
}
function cashFlow(from,to){
  const m=(State.moneyTransactions||[]).filter(t=>t.status!=='void'&&t.type!=='opening'&&t.sourceType!=='transfer'&&!/^transfer_/.test(t.type)&&(!from||String(t.date)>=from)&&(!to||String(t.date)<=to));
  const LBL={sale:'Sales',payment:'Customer / supplier payments',purchase:'Purchases',expense:'Expenses',return:'Customer refunds',manual:'Manual entries',sms:'Bank SMS'};
  const g={};m.forEach(t=>{const k=LBL[t.sourceType]||t.sourceType||'Other';const o=g[k]||(g[k]={i:0,o:0});const a=n(t.amount);if(['in','income','adjustment_in'].includes(t.type))o.i+=a;else o.o+=a});
  const keys=Object.keys(g),ti=keys.reduce((a,k)=>a+g[k].i,0),to2=keys.reduce((a,k)=>a+g[k].o,0);
  return `<div class="card"><div class="card-title">💸 Cash flow ${esc(from||'start')} → ${esc(to||'today')}</div>
  ${keys.length?table(['Source','Money in','Money out','Net'],keys.map(k=>[esc(k),fmt(g[k].i),fmt(g[k].o),fmt(g[k].i-g[k].o)]),['Total',fmt(ti),fmt(to2),fmt(ti-to2)]):'<p>No money movements in this period.</p>'}
  <small>Transfers between your own accounts are left out.</small></div>`;
}
const Statements={
  show(kind){
    const el=out();if(!el)return;
    try{
      if(kind==='balance')el.innerHTML=balanceSheet();
      else if(kind==='ar')el.innerHTML=agingReport('customer');
      else if(kind==='ap')el.innerHTML=agingReport('supplier');
      else if(kind==='inventory')el.innerHTML=inventoryValue();
      else if(kind==='cashflow'){
        const d=new Date(),f=new Date(d.getFullYear(),d.getMonth(),1);const iso=x=>new Date(x.getTime()-x.getTimezoneOffset()*6e4).toISOString().slice(0,10);
        el.innerHTML=`<div class="card"><div style="display:flex;gap:6px;flex-wrap:wrap;align-items:end"><div><label>From</label><input type="date" class="form-control" id="cfFrom" value="${iso(f)}"></div><div><label>To</label><input type="date" class="form-control" id="cfTo" value="${iso(d)}"></div><button class="btn btn-primary btn-sm" data-cashtracker-onclick="Statements.runCash()">Show</button></div></div><div id="cfOut">${cashFlow(iso(f),iso(d))}</div>`;
      }
    }catch(e){el.innerHTML='<div class="card">Could not build this report: '+esc(e.message||e)+'</div>';console.error(e)}
  },
  runCash(){const o=document.getElementById('cfOut');if(o)o.innerHTML=cashFlow(document.getElementById('cfFrom')?.value,document.getElementById('cfTo')?.value)},
  _ageParty:ageParty,_bucketOf:bucketOf
};
window.Statements=Statements;
})();
