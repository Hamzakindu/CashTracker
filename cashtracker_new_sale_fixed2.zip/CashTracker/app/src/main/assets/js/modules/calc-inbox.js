// CALC INBOX: calculations saved from the standalone CashTracker Calc app
(function(){'use strict';
window.registerModule('CalcInbox',function(){
const profileId=()=>{try{return localStorage.getItem('currentProfileId')||'default'}catch(e){return 'default'}}; const KEY=()=> 'SP_calc_inbox_'+profileId();let pending=null,wrapped=false;
const read=()=>{try{let raw=localStorage.getItem(KEY());if(!raw&&localStorage.getItem('SP_calc_inbox')){raw=localStorage.getItem('SP_calc_inbox');localStorage.setItem(KEY(),raw);}const v=JSON.parse(raw||'[]');return Array.isArray(v)?v:[]}catch(e){return[]}};
const write=l=>{try{localStorage.setItem(KEY(),JSON.stringify(l))}catch(e){}};
const esc=s=>Helpers.esc(String(s==null?'':s));
const fmt=n=>Helpers.formatCurrency(Number(n)||0);
const isActive=()=>document.getElementById('tab-calcinbox')?.classList.contains('active');
const ICON={sale:'💰',purchase:'📥',expense:'💸',peopleMoney:'👥',general:'📋'};
function setStatus(id,st){const l=read(),it=l.find(x=>x.id===id);if(it){it.status=st;write(l)}}
function badge(){const n=read().filter(x=>x.status==='new').length,b=document.querySelector('.tab-btn[data-tab="calcinbox"]');if(b)b.textContent='🧮 Calc Inbox'+(n?' ('+n+')':'')}
// Mark an item done automatically once its expense is really saved.
function wrapExpenses(){
  if(wrapped||!window.Expenses||!Expenses.submitDirect)return;wrapped=true;
  const o=Expenses.submitDirect.bind(Expenses);
  Expenses.submitDirect=function(){const n=(State.directExpenses||[]).length,r=o.apply(Expenses,arguments);
    if(pending&&(State.directExpenses||[]).length>n){setStatus(pending,'done');pending=null;badge();if(isActive())render()}return r};
}
function itemLines(it){
  const items=Array.isArray(it.items)?it.items:[];
  if(!items.length)return '<div><small>'+esc(String(it.expr||'').replace(/\*/g,'×').replace(/\//g,'÷'))+'</small></div>';
  return '<div style="margin-top:6px">'+items.map((x,i)=>{
    const qty=Number(x.quantity||1), price=Number(x.price||0), amount=Number(x.amount||0);
    const label=x.kind==='peopleMoney'?'People Money':(x.adjustment?'Adjustment':('Item '+(i+1)));
    return '<div class="list-item" style="padding:5px 0"><div class="info"><span class="title">'+esc(label)+' · Qty '+esc(qty)+' × '+fmt(price)+'</span><span class="meta">'+fmt(amount)+(x.operation==='subtract'?' · subtraction':'')+'</span></div></div>';
  }).join('')+'</div>';
}
function card(it){
  const t=it.type||'general',acts=[];
  if(t==='expense'||t==='general')acts.push(['expense','💸 Expense']);
  if(t==='sale'||t==='general')acts.push(['sale','💰 Sale']);
  if(t==='purchase'||t==='general')acts.push(['purchase','📥 Purchase']); if(t==='peopleMoney')acts.push(['people','👥 People Money']);
  return `<div class="card" style="margin:8px 0;padding:10px"><div class="flex-between"><b style="font-size:17px">${fmt(it.result)}</b><small>${ICON[t]||'📋'} ${esc(t)} · ${esc(String(it.ts||'').slice(0,16).replace('T',' '))}</small></div>
  <div><small>${esc(String(it.expr||'').replace(/\*/g,'×').replace(/\//g,'÷'))}</small>${it.note?' · '+esc(it.note):''}</div>
  ${itemLines(it)}
  <div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap">${acts.map(a=>`<button class="btn btn-primary btn-sm" data-cashtracker-onclick="CalcInbox.use('${esc(it.id)}','${a[0]}')">${a[1]}</button>`).join('')}<button class="btn btn-success btn-sm" data-cashtracker-onclick="CalcInbox.done('${esc(it.id)}')">✓ Done</button><button class="btn btn-outline btn-sm" data-cashtracker-onclick="CalcInbox.remove('${esc(it.id)}')">🗑</button></div></div>`;
}
function render(){
  const p=document.getElementById('tab-calcinbox');if(!p)return;
  const all=read(),nw=all.filter(x=>x.status==='new'),dn=all.filter(x=>x.status==='done').slice(0,10);
  p.innerHTML=`<div class="card"><div class="flex-between"><div><div class="card-title">🧮 Calc Inbox</div><small>Calculations saved in the CashTracker Calc app. Turn them into an expense, sale or purchase here.</small></div><button class="btn btn-outline btn-sm" data-cashtracker-onclick="CalcInbox.render()">🔄</button></div></div>
  ${nw.map(card).join('')||'<div class="empty-state">Nothing waiting. Save a calculation in CashTracker Calc and it shows up here.</div>'}
  ${dn.length?`<div class="card"><div class="card-title">✅ Done</div>${dn.map(it=>`<div class="list-item"><div class="info"><span class="title">${fmt(it.result)} · ${esc(it.type)}</span><span class="meta">${esc(it.note||it.expr)}</span></div></div>`).join('')}</div>`:''}`;
  badge();
}
const CalcInbox={
  render,
  use(id,kind){
    const it=read().find(x=>x.id===id);if(!it)return;
    if(kind==='expense'){
      if(!window.Expenses||!Expenses.openDirectModal)return Toast.error('Expenses module not loaded');
      const amt=Math.round(Number(it.result)*100)/100;if(!(amt>0))return Toast.warning('Expense amount must be above zero');
      wrapExpenses();Expenses.openDirectModal();
      const a=document.getElementById('directExpenseAmount'),r=document.getElementById('directExpenseReason');
      if(a)a.value=amt;if(r)r.value=it.note||('Calc: '+it.expr);pending=id;
    }else if(kind==='people'){ if(!window.PeopleMoney||!PeopleMoney.openEntry)return Toast.error('People Money module not loaded'); PeopleMoney.openEntry((it.items||[]).find(x=>x.kind==='peopleMoney')||null); pending=id;
    }else if(kind==='sale'){
      if(!window.Sales||!Sales.openSellModal)return Toast.error('Sales module not loaded');
      Sales.openSellModal(null, Array.isArray(it.items)?it.items:[]);Toast.show('Calculator items loaded. Choose a product for each line, then complete the sale.','info');
    }else{
      if(!window.Purchases||!Purchases.openModal)return Toast.error('Purchases module not loaded');
      Purchases.openModal(Array.isArray(it.items)?it.items:[]);Toast.show('Calculator items loaded. Choose a product for each line, then complete the purchase.','info');
    }
  },
  done(id){setStatus(id,'done');render()},
  remove(id){write(read().filter(x=>x.id!==id));render()}
};
window.CalcInbox=CalcInbox;
setTimeout(badge,1500);
document.addEventListener('visibilitychange',()=>{if(!document.hidden){badge();if(isActive())render()}});
return CalcInbox;});
})();
