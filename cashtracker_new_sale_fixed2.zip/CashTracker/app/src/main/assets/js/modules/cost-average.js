// COST AVERAGE: after each new purchase, the product's buying price becomes the weighted average of the old stock and the new stock.
// Sales already copy product.buy onto each sale line, so profit and cost of goods sold follow automatically.
(function(){'use strict';
const ON=()=>{try{return localStorage.getItem('SP_avg_cost')!=='0'}catch(e){return true}};
const n=v=>Number(v)||0;
function install(){
  const P=window.Purchases;if(!P||typeof P.submit!=='function'||P.submit.__avg)return;
  const orig=P.submit;
  const w=function(...a){
    let before=null,firstId=null;
    try{before={};(State.products||[]).forEach(p=>{before[p.id]={stock:n(p.stock),buy:n(p.buy)}});firstId=(State.purchases||[])[0]&&State.purchases[0].id}catch(e){}
    const r=orig.apply(this,a);
    try{
      const pu=(State.purchases||[])[0];
      if(ON()&&before&&pu&&pu.id!==firstId&&Array.isArray(pu.items)){
        const done={};
        pu.items.forEach(it=>{
          const p=State.products.find(x=>x.id===it.productId),b=before[it.productId];if(!p||!b)return;
          const q=n(it.quantity),c=n(it.cost);if(q<=0||c<=0)return;
          const prev=done[p.id]||{qty:Math.max(0,b.stock),buy:b.buy};
          const oldQty=prev.qty,oldBuy=prev.buy||c;
          const avg=oldQty>0?((oldQty*oldBuy)+(q*c))/(oldQty+q):c;
          p.buy=Math.round(avg*100)/100;p.lastBuy=c;
          done[p.id]={qty:oldQty+q,buy:p.buy};
        });
        if(Object.keys(done).length&&State.saveAll)State.saveAll();
        if(window.Products&&Products.render)try{Products.render()}catch(e){}
      }
    }catch(e){console.error('Cost average failed',e)}
    return r;
  };
  w.__avg=true;P.submit=w;
}
window.CostAverage={on:ON,setOn(v){try{localStorage.setItem('SP_avg_cost',v?'1':'0')}catch(e){}}};
window.addEventListener('load',()=>{setTimeout(install,1500);setTimeout(install,6000)});
})();
