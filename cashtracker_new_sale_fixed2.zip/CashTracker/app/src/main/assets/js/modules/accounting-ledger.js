// ============================================
// STOCKPRO V5 - ACCOUNTING & LEDGER ENGINE
// ============================================
(function(){'use strict';
window.registerModule('AccountingLedger', function(){
const A={
  VERSION:6,
  init(){
    State.paymentLedger=Array.isArray(State.paymentLedger)?State.paymentLedger:[];
    State.auditLog=Array.isArray(State.auditLog)?State.auditLog:[];
    State.accountingMeta=State.accountingMeta||{version:5,migratedAt:null};
    this.migrate();
  },
  migrate(){
    let changed=false;
    const now=new Date().toISOString();
    (State.paymentLedger||[]).forEach(e=>{
      if(!e.id)e.id=Helpers.uid(),changed=true;
      if(!e.createdAt)e.createdAt=now,changed=true;
      if(!e.amountNumber)e.amountNumber=Number(e.amount||0),changed=true;
      if(!e.status)e.status='posted',changed=true;
      if(!e.sourceType)e.sourceType='legacy',changed=true;
    });
    State.sales.forEach(x=>{if(!x.id)x.id=Helpers.uid(),changed=true;if(!x.accountingStatus)x.accountingStatus='posted',changed=true;});
    (State.purchases||[]).forEach(x=>{if(!x.id)x.id=Helpers.uid(),changed=true;if(!x.accountingStatus)x.accountingStatus='posted',changed=true;});
    (State.directExpenses||[]).forEach(x=>{if(!x.id)x.id=Helpers.uid(),changed=true;if(!x.accountingStatus)x.accountingStatus='posted',changed=true;});
    (State.customers||[]).forEach(x=>{if(x.openingBalance===undefined){const hasTx=(State.sales||[]).some(s=>s.customerId===x.id)||this.payments().some(p=>p.entityType==='customer'&&p.entityId===x.id);x.openingBalance=hasTx?0:Number(x.balance||0);changed=true;}if(x.openingAdvance===undefined)x.openingAdvance=Number(x.customerAdvance||0),changed=true;});
    (State.suppliers||[]).forEach(x=>{if(x.openingBalance===undefined){const hasTx=(State.purchases||[]).some(p=>p.supplierId===x.id)||this.payments().some(p=>p.entityType==='supplier'&&p.entityId===x.id);x.openingBalance=hasTx?0:Number(x.balance||0);changed=true;}if(x.openingAdvance===undefined)x.openingAdvance=Number(x.supplierAdvance||0),changed=true;});
    if(State.accountingMeta.version!==6){State.accountingMeta={version:6,migratedAt:now};changed=true;}
    const ensureTx=(row,type)=>{if(!row)return;if(!row.transactionId)row.transactionId=row.id||Helpers.uid(),changed=true;if(!row.sourceType)row.sourceType=type,changed=true;if(!row.createdAt)row.createdAt=now,changed=true;};
    (State.sales||[]).forEach(x=>ensureTx(x,'sale'));(State.purchases||[]).forEach(x=>ensureTx(x,'purchase'));(State.returns||[]).forEach(x=>ensureTx(x,'return'));(State.directExpenses||[]).forEach(x=>ensureTx(x,'expense'));
    (State.paymentLedger||[]).forEach(x=>{if(!x.transactionId)x.transactionId=x.sourceId||x.id||Helpers.uid(),changed=true;});
    if(changed){this.audit('system','v5_migration','system',{version:5});if(State.saveAll)State.saveAll();}
    return changed;
  },
  audit(actor,action,entityType,details){
    State.auditLog=State.auditLog||[];
    State.auditLog.unshift({id:Helpers.uid(),actor:actor||'system',action,entityType,details:details||{},date:Helpers.getToday(),createdAt:new Date().toISOString()});
    if(State.auditLog.length>5000)State.auditLog.length=5000;
  },
  postPayment(entry){
    const e=Object.assign({id:Helpers.uid(),createdAt:new Date().toISOString(),status:'posted',sourceType:'payment'},entry);
    State.paymentLedger=State.paymentLedger||[]; State.paymentLedger.unshift(e); return e;
  },
  payments(){return State.paymentLedger||[];},
  customerStatement(id){return this.payments().filter(x=>x.entityType==='customer'&&x.entityId===id).sort(this._sort);},
  supplierStatement(id){return this.payments().filter(x=>x.entityType==='supplier'&&x.entityId===id).sort(this._sort);},
  _sort(a,b){return String(a.date||'').localeCompare(String(b.date||''))||String(a.createdAt||'').localeCompare(String(b.createdAt||''));},
  cashFlow(from,to){return this.payments().filter(x=>(!from||x.date>=from)&&(!to||x.date<=to)&&x.status!=='void').reduce((a,x)=>{const n=Number((x.amountNumber??x.amount)||0); if(['Cash','Bank','Telebirr','CBE Birr','Other'].includes(x.method)){a.in+=x.entityType==='customer'?n:0;a.out+=x.entityType==='supplier'?n:0;} return a;},{in:0,out:0});},
  summary(){
    const payments=this.payments().filter(x=>x.status!=='void');
    const cashReceived=payments.filter(x=>x.entityType==='customer').reduce((a,x)=>a+Number((x.amountNumber??x.amount)||0),0);
    const cashPaid=payments.filter(x=>x.entityType==='supplier').reduce((a,x)=>a+Number((x.amountNumber??x.amount)||0),0);
    return {cashReceived,cashPaid,netCash:cashReceived-cashPaid,customerAdvances:(State.customers||[]).reduce((a,x)=>a+Number(x.customerAdvance||0),0),supplierAdvances:(State.suppliers||[]).reduce((a,x)=>a+Number(x.supplierAdvance||0),0),customerDebt:(State.customers||[]).reduce((a,x)=>a+Math.max(0,Number(x.balance||0)),0),supplierDebt:(State.suppliers||[]).reduce((a,x)=>a+Math.max(0,Number(x.balance||0)),0)};
  },
  reconcile(){
    const issues=[];
    (State.customers||[]).forEach(c=>{
      if(c.id==='walkin') return;
      const salesDebit=State.activeSales().filter(s=>s.customerId===c.id).reduce((a,s)=>a+Number(s.debitRemaining||0),0);
      const laterPayments=this.customerStatement(c.id).filter(x=>x.kind==='settlement'&&x.sourceType!=='sale').reduce((a,x)=>a+Number((x.amountNumber??x.amount)||0),0);
      const expected=Math.max(0,Number(c.openingBalance||0)+salesDebit-laterPayments);
      const actual=Math.max(0,Number(c.balance||0));
      if(Math.abs(expected-actual)>0.01)issues.push({type:'customer',id:c.id,name:c.name,expected,actual,difference:actual-expected});
    });
    (State.suppliers||[]).forEach(su=>{
      const purchasesDebit=(State.purchases||[]).filter(p=>p.supplierId===su.id).reduce((a,p)=>a+Number(p.debit||0),0);
      const laterPayments=this.supplierStatement(su.id).filter(x=>x.kind==='settlement'&&x.sourceType!=='purchase').reduce((a,x)=>a+Number((x.amountNumber??x.amount)||0),0);
      const expected=Math.max(0,Number(su.openingBalance||0)+purchasesDebit-laterPayments);
      const actual=Math.max(0,Number(su.balance||0));
      if(Math.abs(expected-actual)>0.01)issues.push({type:'supplier',id:su.id,name:su.name,expected,actual,difference:actual-expected});
    });
    return {ok:issues.length===0,issues,checkedAt:new Date().toISOString()};
  },

  customerAccountRows(id){
    const c=(State.customers||[]).find(x=>x.id===id); if(!c) return [];
    const rows=[];
    const opening=Number(c.openingBalance||0), openingAdvance=Number(c.openingAdvance||0);
    if(opening||openingAdvance) rows.push({date:'0000-00-00',createdAt:'',type:'Opening',reference:'Opening balance',debit:opening,credit:0,advanceCredit:openingAdvance,advanceDebit:0});
    (State.sales||[]).filter(s=>s.customerId===id&&s.status!=='void').forEach(s=>{
      const total=Number(s.total||0), excess=Number(s.excessPayment||0);
      rows.push({date:s.date||'',createdAt:s.createdAt||'',type:'Sale',reference:s.transactionId||s.id||'',debit:total,credit:0,advanceCredit:0,advanceDebit:0});
      const p=(State.paymentLedger||[]).filter(x=>x.status!=='void'&&x.entityType==='customer'&&x.entityId===id&&x.sourceId===s.id&&x.kind==='sale_payment').reduce((a,x)=>a+Number((x.amountNumber??x.amount)||0),0);
      const applied=Math.max(0,p-excess);
      if(applied) rows.push({date:s.date||'',createdAt:s.createdAt||'',type:'Sale payment',reference:s.transactionId||s.id||'',debit:0,credit:applied,advanceCredit:0,advanceDebit:0});
      if(excess) rows.push({date:s.date||'',createdAt:s.createdAt||'',type:'Customer advance created',reference:s.transactionId||s.id||'',debit:0,credit:0,advanceCredit:excess,advanceDebit:0});
      const used=Number(s.advanceUsed||0); if(used) rows.push({date:s.date||'',createdAt:s.createdAt||'',type:'Advance applied',reference:s.transactionId||s.id||'',debit:0,credit:0,advanceCredit:0,advanceDebit:used});
    });
    (State.paymentLedger||[]).filter(x=>x.status!=='void'&&x.entityType==='customer'&&x.entityId===id&&x.sourceType==='payment').forEach(p=>{
      const n=Number((p.amountNumber??p.amount)||0); if(!n)return;
      if(p.kind==='advance') rows.push({date:p.date||'',createdAt:p.createdAt||'',type:'Customer advance received',reference:p.reference||p.id||'',debit:0,credit:0,advanceCredit:n,advanceDebit:0});
      else if(p.kind==='settlement') rows.push({date:p.date||'',createdAt:p.createdAt||'',type:'Payment received',reference:p.reference||p.id||'',debit:0,credit:n,advanceCredit:0,advanceDebit:0});
    });
    return rows.sort(this._sort);
  },
  supplierAccountRows(id){
    const s=(State.suppliers||[]).find(x=>x.id===id); if(!s) return [];
    const rows=[];
    const opening=Number(s.openingBalance||0), openingAdvance=Number(s.openingAdvance||0);
    if(opening||openingAdvance) rows.push({date:'0000-00-00',createdAt:'',type:'Opening',reference:'Opening balance',debit:opening,credit:0,advanceCredit:openingAdvance,advanceDebit:0});
    (State.purchases||[]).filter(p=>p.supplierId===id&&p.status!=='void').forEach(p=>{
      const total=Number(p.total||0), excess=Number(p.excessPaid||0);
      rows.push({date:p.date||'',createdAt:p.createdAt||'',type:'Purchase',reference:p.transactionId||p.id||'',debit:total,credit:0,advanceCredit:0,advanceDebit:0});
      const paid=(State.paymentLedger||[]).filter(x=>x.status!=='void'&&x.entityType==='supplier'&&x.entityId===id&&x.sourceId===p.id&&x.kind==='purchase_payment').reduce((a,x)=>a+Number((x.amountNumber??x.amount)||0),0);
      const applied=Math.max(0,paid-excess);
      if(applied) rows.push({date:p.date||'',createdAt:p.createdAt||'',type:'Purchase payment',reference:p.transactionId||p.id||'',debit:0,credit:applied,advanceCredit:0,advanceDebit:0});
      if(excess) rows.push({date:p.date||'',createdAt:p.createdAt||'',type:'Supplier advance created',reference:p.transactionId||p.id||'',debit:0,credit:0,advanceCredit:excess,advanceDebit:0});
      const used=Number(p.advanceUsed||0); if(used) rows.push({date:p.date||'',createdAt:p.createdAt||'',type:'Advance applied',reference:p.transactionId||p.id||'',debit:0,credit:0,advanceCredit:0,advanceDebit:used});
    });
    (State.paymentLedger||[]).filter(x=>x.status!=='void'&&x.entityType==='supplier'&&x.entityId===id&&x.sourceType==='payment').forEach(p=>{
      const n=Number((p.amountNumber??p.amount)||0); if(!n)return;
      if(p.kind==='advance') rows.push({date:p.date||'',createdAt:p.createdAt||'',type:'Supplier advance paid',reference:p.reference||p.id||'',debit:0,credit:0,advanceCredit:n,advanceDebit:0});
      else if(p.kind==='settlement') rows.push({date:p.date||'',createdAt:p.createdAt||'',type:'Payment made',reference:p.reference||p.id||'',debit:0,credit:n,advanceCredit:0,advanceDebit:0});
    });
    return rows.sort(this._sort);
  },
  showEntityStatement(type,id){
    const entity=(type==='customer'?State.customers:State.suppliers||[]).find(x=>x.id===id); if(!entity)return Toast.error('Account not found');
    const rows=type==='customer'?this.customerAccountRows(id):this.supplierAccountRows(id);
    let bal=0,adv=0;
    let body='';
    rows.forEach(r=>{bal+=Number(r.debit||0)-Number(r.credit||0);adv+=Number(r.advanceCredit||0)-Number(r.advanceDebit||0); const net=bal-adv; body+=`<tr><td>${Helpers.formatDate(r.date)||'Opening'}</td><td>${Helpers.esc(r.type)}</td><td>${Helpers.esc(r.reference)}</td><td>${r.debit?Helpers.formatCurrency(r.debit):'—'}</td><td>${r.credit?Helpers.formatCurrency(r.credit):'—'}</td><td>${Helpers.formatCurrency(net)}</td></tr>`;});
    const current=Number(entity.balance||0), advance=Number(type==='customer'?entity.customerAdvance:entity.supplierAdvance||0);
    const status=current>0?(type==='customer'?'Owes us':'We owe'):current<0?'Credit':'Settled';
    const html=`<div class="detail-section"><h4>📒 ${type==='customer'?'Customer':'Supplier'} Statement</h4><div class="stock-summary-grid"><div class="stock-summary-item"><span class="summary-label">Current balance</span><span class="summary-value">${Helpers.formatCurrency(Math.abs(current))}</span></div><div class="stock-summary-item"><span class="summary-label">Advance</span><span class="summary-value">${Helpers.formatCurrency(advance)}</span></div><div class="stock-summary-item"><span class="summary-label">Net position</span><span class="summary-value">${Helpers.formatCurrency(Math.abs(current-advance))}</span></div><div class="stock-summary-item"><span class="summary-label">Status</span><span class="summary-value">${status}</span></div></div></div><div class="detail-section"><div style="overflow:auto"><table class="transaction-table"><thead><tr><th>Date</th><th>Type</th><th>Reference</th><th>Debit</th><th>Credit</th><th>Running Net</th></tr></thead><tbody>${body||'<tr><td colspan="6" class="empty-state">No account transactions</td></tr>'}</tbody></table></div></div>`;
    document.getElementById('detailModalContent').innerHTML=html; document.getElementById('detailModalTitle').textContent='📒 '+Helpers.esc(entity.name)+' Statement'; Modals.open('detailModal');
  },
  dashboard(){
    const s=this.summary(),r=this.reconcile();
    return `<div class="card"><div class="card-title">📒 Accounting V5</div><div class="stock-summary-grid"><div class="stock-summary-item"><span class="summary-label">Customer debt</span><span class="summary-value">${Helpers.formatCurrency(s.customerDebt)}</span></div><div class="stock-summary-item"><span class="summary-label">Supplier debt</span><span class="summary-value">${Helpers.formatCurrency(s.supplierDebt)}</span></div><div class="stock-summary-item"><span class="summary-label">Customer advances</span><span class="summary-value">${Helpers.formatCurrency(s.customerAdvances)}</span></div><div class="stock-summary-item"><span class="summary-label">Supplier advances</span><span class="summary-value">${Helpers.formatCurrency(s.supplierAdvances)}</span></div><div class="stock-summary-item"><span class="summary-label">Received</span><span class="summary-value">${Helpers.formatCurrency(s.cashReceived)}</span></div><div class="stock-summary-item"><span class="summary-label">Paid</span><span class="summary-value">${Helpers.formatCurrency(s.cashPaid)}</span></div></div><div style="margin-top:12px;padding:10px;border-radius:8px;background:${r.ok?'var(--success-bg,rgba(25,135,84,.1))':'var(--danger-bg,rgba(220,53,69,.1))'}">${r.ok?'✅ Ledger reconciliation passed':'⚠️ '+r.issues.length+' balance issue(s) detected'}</div>${r.ok?'':`<button class="btn btn-warning btn-sm" style="margin-top:8px" data-cashtracker-onclick="AccountingLedger.showReconciliation()">Review discrepancies</button>`}</div>`;
  },
  showReconciliation(){const r=this.reconcile();let html='<div class="detail-section"><h4>Ledger Reconciliation</h4>';html+=r.ok?'<p>✅ All customer and supplier balances reconcile.</p>':'<table class="transaction-table"><thead><tr><th>Type</th><th>Name</th><th>Expected</th><th>Actual</th><th>Difference</th></tr></thead><tbody>'+r.issues.map(i=>`<tr><td>${i.type}</td><td>${Helpers.esc(i.name)}</td><td>${Helpers.formatCurrency(i.expected)}</td><td>${Helpers.formatCurrency(i.actual)}</td><td>${Helpers.formatCurrency(i.difference)}</td></tr>`).join('')+'</tbody></table>';html+='</div>';document.getElementById('detailModalContent').innerHTML=html;document.getElementById('detailModalTitle').textContent='📒 Ledger Reconciliation';Modals.open('detailModal');}
};
window.AccountingLedger=A;return A;});
})();
