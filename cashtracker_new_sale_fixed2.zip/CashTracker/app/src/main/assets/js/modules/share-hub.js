// SHARE HUB: send products and balances through WhatsApp, Telegram, imo, SMS or any app
(function(){'use strict';
window.registerModule('ShareHub',function(){
const esc=s=>Helpers.esc(String(s==null?'':s));
const fmt=n=>Helpers.formatCurrency(Number(n)||0);
const store=()=>{try{return JSON.parse(localStorage.getItem('stockProfile')||'{}').storeName||'CashTracker'}catch(e){return 'CashTracker'}};
const b64=u=>{u=String(u||'');return u.indexOf('data:image')===0?u.split(',')[1]||'':''};
const CH=[['whatsapp','💬 WhatsApp'],['telegram','✈️ Telegram'],['imo','🟣 imo'],['sms','📱 SMS'],['more','📤 More…']];
function send(ch,text,phone,img){
  phone=Helpers.convertToInternational(phone||'')||'';
  if(ch==='sms'&&!phone){Toast.warning('📱 Enter a phone number for SMS');return}
  if(window.Android&&Android.share){const mode=localStorage.getItem('SP_share_mode')||'sheet';if(Android.share2)Android.share2(ch,text,phone,img?b64(img):'',mode);else Android.share(ch,text,phone,img?b64(img):'');return}
  const e=encodeURIComponent(text),d=phone.replace(/\D/g,'');
  if(ch==='whatsapp')window.open('https://wa.me/'+d+'?text='+e,'_blank');
  else if(ch==='telegram')window.open('https://t.me/share/url?url=%20&text='+e,'_blank');
  else if(ch==='sms')window.open('sms:'+phone+'?body='+e,'_blank');
  else if(navigator.share)navigator.share({text}).catch(()=>{});
  else if(navigator.clipboard)navigator.clipboard.writeText(text).then(()=>Toast.success('📋 Copied. Paste it in '+ch));
}
function productText(p){
  const st=Number(p.stock)||0;
  return '🛍️ *'+p.name+'*\n'+(p.category?p.category+'\n':'')+'💰 Price: '+fmt(p.sell)+'\n'+(st>0?'📦 In stock: '+st:'❌ Out of stock')+'\n🏪 '+store();
}
const ShareHub={
  send,productText,
  shareLog(){
    let e=[];try{e=JSON.parse(localStorage.getItem('SP_errlog')||'[]')}catch(x){}
    send('more','CashTracker SMS diagnostics\nNative bridge: '+(window.Android?'yes':'no')+'\n'+navigator.userAgent+'\n\nRecent errors:\n'+(e.join('\n')||'none'),'');
  },
  _ids:[],_i:0,_per:true,_phone:'',_photo:true,
  openProduct(id){this._i=0;this._phone='';this.openProducts([id])},
  openProducts(ids,keep){
    const ps=ids.map(i=>(State.products||[]).find(x=>x.id===i)).filter(Boolean);if(!ps.length)return;
    this._ids=ps.map(p=>p.id);if(!keep||this._i>=ps.length)this._i=0;
    const op=document.getElementById('spPhone');if(op)this._phone=op.value;
    const oi=document.getElementById('spImg');if(oi)this._photo=oi.checked;
    const per=this._per&&ps.length>1,cur=per?ps[this._i]:(ps.length===1?ps[0]:null);
    const pimg=p=>(p.images||[]).find(u=>String(u).indexOf('data:image')===0)||'';
    const img=cur?pimg(cur):'';
    let m=document.getElementById('shareProductModal');
    if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='shareProductModal';document.body.appendChild(m)}
    const custs=(State.customers||[]).filter(c=>c.contact);
    const text=cur?productText(cur):'🛍️ *Products from '+store()+'*\n\n'+ps.map(p=>'• *'+p.name+'* — '+fmt(p.sell)+((Number(p.stock)||0)>0?'':' (out of stock)')).join('\n')+'\n\nReply to order.';
    m.innerHTML=`<div class="modal" style="max-width:520px;max-height:90vh;overflow-y:auto"><button class="close-btn" data-cashtracker-onclick="Modals.close('shareProductModal')">✕</button>
    <h3>${per?'📤 Item '+(this._i+1)+' of '+ps.length:'📤 Share '+(ps.length>1?ps.length+' products':'Product')}</h3>
    <div class="detail-section">${ps.map((p,i)=>`<div style="${per&&i===this._i?'font-weight:700;':''}${per&&i<this._i?'opacity:.5;':''}">${per?(i<this._i?'✅ ':i===this._i?'👉 ':'• '):''}${esc(p.name)} · ${fmt(p.sell)} · stock ${Number(p.stock)||0}</div>`).join('')}</div>
    ${ps.length>1?`<label style="display:flex;gap:8px;align-items:center;margin:8px 0"><input type="checkbox" ${this._per?'checked':''} data-cashtracker-onchange="ShareHub.setPer(this.checked)"> 📦 Send each product as its own message</label>`:''}
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0"><button class="btn btn-outline btn-sm" data-cashtracker-onclick="ShareHub.addMore()">➕ Add / remove products</button><button class="btn btn-outline btn-sm" data-cashtracker-onclick="ShareHub.toMany()">📣 Send to many customers</button>${per?'<button class="btn btn-outline btn-sm" data-cashtracker-onclick="ShareHub.skip()">⏭ Skip this item</button>':''}</div>
    <div class="form-group"><label>👤 Send to customer (optional)</label><select class="form-control" data-cashtracker-onchange="document.getElementById('spPhone').value=this.value"><option value="">Choose in the app after tapping</option>${custs.map(c=>`<option value="${esc(c.contact)}"${c.contact===this._phone?' selected':''}>${esc(c.name)}</option>`).join('')}</select></div>
    <div class="form-group"><label>📱 Phone (optional)</label><input class="form-control" id="spPhone" type="tel" placeholder="0912345678" value="${esc(this._phone)}"></div>
    ${img?`<label style="display:flex;gap:8px;align-items:center;margin:6px 0"><input type="checkbox" id="spImg" ${this._photo?'checked':''}> 📸 Include photo</label>`:(ps.length>1&&!per?'<label style="display:flex;gap:8px;align-items:center;margin:6px 0"><input type="checkbox" id="spCat" checked> 🖼️ Include catalog picture (first 8 products)</label>':'')}
    <div class="form-group"><label>📝 Message</label><textarea class="form-control note-area" id="spText" rows="6">${esc(text)}</textarea></div>
    <div class="share-buttons" style="display:flex;gap:6px;flex-wrap:wrap">${CH.map(c=>`<button class="btn btn-primary btn-sm" data-cashtracker-onclick="ShareHub.go('${c[0]}')">${c[1]}</button>`).join('')}</div>
    ${ps.length>1?`<div class="form-group" style="margin-top:12px"><label>📸 Or send all ${Math.min(ps.length,12)} as separate pictures in one tap</label><div style="display:flex;gap:6px;flex-wrap:wrap">${[['whatsapp','💬 WhatsApp'],['telegram','✈️ Telegram'],['imo','🟣 imo'],['more','📤 More…']].map(c=>`<button class="btn btn-success btn-sm" data-cashtracker-onclick="ShareHub.goAll('${c[0]}')">${c[1]}</button>`).join('')}</div><small>Each product becomes its own picture with its name and price, so each arrives as a separate message.</small></div>`:''}
    ${per?'<small style="display:block;margin-top:8px;opacity:.75">After you send, the next product loads here automatically. Come back to this screen and tap the app again.</small>':''}</div>`;
    Modals.open('shareProductModal');
  },
  setPer(v){this._per=v;this._i=0;this.openProducts(this._ids,true)},
  skip(){if(this._i<this._ids.length-1){this._i++;this.openProducts(this._ids,true)}else Modals.close('shareProductModal')},
  addMore(){
    Modals.close('shareProductModal');
    MultiPick.open({title:'Choose products',items:(State.products||[]).map(p=>({id:p.id,label:p.name,sub:fmt(p.sell)+' · stock '+(Number(p.stock)||0)})),selected:this._ids,groups:MultiPick.catGroups(),
      onDone:ids=>{if(ids.length){this._i=0;this.openProducts(ids)}else Toast.warning('Choose at least one product')}});
  },
  toMany(){const ids=this._ids.slice();Modals.close('shareProductModal');if(window.Marketing)Marketing.preload(ids);Tabs.switchTo('marketing')},
  async goAll(ch){
    const ps=this._ids.map(i=>(State.products||[]).find(x=>x.id===i)).filter(Boolean);if(!ps.length)return;
    if(!(window.Android&&Android.shareMulti))return Toast.warning('Sending pictures needs the Android app');
    const list=ps.slice(0,12);if(ps.length>12)Toast.warning('Sending the first 12. Send the rest as a second batch.');
    Toast.success('🖼️ Preparing '+list.length+' pictures…');
    const imgs=[];for(const p of list)imgs.push((await Catalog.card(p)).split(',')[1]);
    const phone=Helpers.convertToInternational(document.getElementById('spPhone')?.value||'')||'';
    Android.shareMulti(ch,'',phone,JSON.stringify(imgs),localStorage.getItem('SP_share_mode')||'sheet');
  },
  async go(ch){
    const ps=this._ids.map(i=>(State.products||[]).find(x=>x.id===i)).filter(Boolean);if(!ps.length)return;
    const per=this._per&&ps.length>1,cur=per?ps[this._i]:(ps.length===1?ps[0]:null);
    const pimg=p=>(p.images||[]).find(u=>String(u).indexOf('data:image')===0)||'';
    let img='';
    if(cur){if(document.getElementById('spImg')?.checked){const u=pimg(cur);img=u&&window.Catalog&&Catalog.shrink?await Catalog.shrink(u):u}}
    else if(document.getElementById('spCat')?.checked&&window.Catalog){try{img=await Catalog.make(ps)}catch(e){}}
    send(ch,document.getElementById('spText').value,document.getElementById('spPhone').value,img);
    if(per){
      if(this._i<ps.length-1){this._i++;this.openProducts(this._ids,true);Toast.success('✅ Sent. Next: '+ps[this._i].name)}
      else{Toast.success('✅ All '+ps.length+' products sent');Modals.close('shareProductModal')}
    }
  }
};
function wrapCustomers(){
  if(!window.Customers||Customers._shareHub)return;Customers._shareHub=true;
  const msg=()=>document.getElementById('shareMessagePreview').textContent;
  const go=ch=>send(ch,msg(),Customers.getEffectivePhone());
  Customers.shareViaWhatsApp=()=>go('whatsapp');
  Customers.shareViaTelegram=()=>go('telegram');
  Customers.shareViaImo=()=>go('imo');
  Customers.shareViaNative=()=>go('more');
  Customers.shareViaSMS=()=>{if(!Customers.getEffectivePhone())return Toast.warning('📱 Enter a phone number');go('sms')};
  const o=Customers.openShareModal.bind(Customers);
  Customers.openShareModal=function(){o.apply(Customers,arguments);
    const row=document.querySelector('#shareModal .share-buttons');
    if(row&&!row.querySelector('.btn-imo')){const b=document.createElement('button');b.className='btn btn-outline btn-sm btn-imo';b.textContent='🟣 imo';b.onclick=Customers.shareViaImo;row.insertBefore(b,row.children[2]||null)}};
}
window.ShareHub=ShareHub;setTimeout(wrapCustomers,300);
return ShareHub;});
})();
