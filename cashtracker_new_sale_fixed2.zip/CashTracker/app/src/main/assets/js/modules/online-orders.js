// ONLINE ORDERS: orders that customers place in your Telegram shop bot arrive here. Turn one into a sale with one tap.
(function(){'use strict';
window.registerModule('OnlineOrders',function(){
const KEY='SP_online_orders';
const esc=s=>Helpers.esc(String(s==null?'':s));
const fmt=n=>Helpers.formatCurrency(Number(n)||0);
const read=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch(e){return{}}};
const write=o=>{try{localStorage.setItem(KEY,JSON.stringify(o))}catch(e){}};
const cfg=()=>{let u=(localStorage.getItem('SP_bot_url')||'').trim();try{u=new URL(u).origin}catch(e){}return{url:u,key:localStorage.getItem('SP_bot_key')||''}};
const ST={new:'🕒 waiting for you',confirmed:'✅ confirmed',ready:'📦 ready',declined:'❌ declined'};
const open=()=>Object.values(read()).filter(o=>!o.handled).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
const digits=s=>String(s||'').replace(/\D/g,'');
async function call(path,body){
  const c=cfg();if(!c.url||!c.key)return null;
  const r=await fetch(c.url+path,{method:'POST',headers:{'Content-Type':'application/json','X-Push-Key':c.key},body:JSON.stringify(body||{})});
  if(!r.ok)throw new Error('Worker answered '+r.status);return r.json();
}
let pulling=false;
async function pull(manual){
  if(pulling)return;const c=cfg();
  if(!c.url||!c.key){if(manual)Toast.warning('Set the Worker address and key in Tools first');return}
  pulling=true;
  try{
    const j=await call('/orders/pull');if(!j)return;
    const store=read();let fresh=0;const ids=[];
    (j.orders||[]).forEach(o=>{
      const old=store[o.id];
      if(!old)fresh++;
      store[o.id]=Object.assign({},old||{},o,{handled:old?old.handled:false});
      ids.push(o.id);
    });
    write(store);
    if(ids.length)await call('/orders/ack',{ids});
    if(fresh)Toast.success('🛎 '+fresh+' new online order'+(fresh>1?'s':''));
    else if(manual)Toast.success('No new orders');
    const m=document.getElementById('onlineOrdersModal');if(m&&m.classList.contains('show'))render();
    refreshBadge();
  }catch(e){if(manual)Toast.error('Could not check orders ('+((e&&e.message)||'network')+')')}
  finally{pulling=false}
}
function refreshBadge(){const n=open().filter(o=>o.status==='new'||o.status==='confirmed').length;document.querySelectorAll('.oo-count').forEach(e=>e.textContent=n)}
function render(){
  let m=document.getElementById('onlineOrdersModal');
  if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='onlineOrdersModal';document.body.appendChild(m)}
  const list=open();
  m.innerHTML=`<div class="modal" style="max-width:560px;max-height:90vh;overflow-y:auto"><button class="close-btn" data-cashtracker-onclick="Modals.close('onlineOrdersModal')">✕</button><h3>🛎 Online orders</h3>
  <small>Orders from your Telegram shop. Confirm or decline them in Telegram; customers are told automatically. Tap <b>Create sale</b> when the customer pays or collects.</small>
  <div style="margin:8px 0"><button class="btn btn-outline btn-sm" data-cashtracker-onclick="OnlineOrders.pull(true)">🔄 Check now</button></div>
  ${list.length?list.map(o=>`<div class="card" style="margin:8px 0;padding:10px"><div class="flex-between"><b>#${esc(o.id)} · ${esc(o.name)}</b><span>${ST[o.status]||esc(o.status)}</span></div>
  <small>${esc(o.phone)}${o.username?' · @'+esc(o.username):''} · ${esc(String(o.createdAt||'').slice(0,16).replace('T',' '))}</small>
  <div style="margin:6px 0">${(o.items||[]).map(i=>'• '+esc(i.n)+' × '+i.q+' = '+fmt(i.amt)).join('<br>')}</div><b>Total ${fmt(o.total)}</b>
  <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px">${o.status!=='declined'?`<button class="btn btn-success btn-sm" data-cashtracker-onclick="OnlineOrders.toSale('${esc(o.id)}')">🧾 Create sale</button>`:''}<button class="btn btn-outline btn-sm" data-cashtracker-onclick="OnlineOrders.done('${esc(o.id)}')">✔ Done / hide</button></div></div>`).join(''):'<div class="empty-state">No open online orders</div>'}</div>`;
  Modals.open('onlineOrdersModal');
}
const OnlineOrders={
  pull,
  open(){render();pull(false)},
  count(){return open().filter(o=>o.status==='new'||o.status==='confirmed').length},
  done(id){const s=read();if(s[id]){s[id].handled=true;write(s)}render();refreshBadge()},
  toSale(id){
    const o=read()[id];if(!o)return;
    if(!window.Sales||!Sales.openSellModal)return Toast.error('Sales module not ready');
    const missing=[];
    Modals.close('onlineOrdersModal');
    Sales.openSellModal();
    setTimeout(()=>{
      try{
        const body=document.getElementById('sellItemsBody');if(body)body.innerHTML='';
        (o.items||[]).forEach(it=>{
          const p=(State.products||[]).find(x=>x.id===it.id);
          if(!p){missing.push(it.n);return}
          Sales.addSellItem();
          const rows=document.querySelectorAll('#sellItemsBody .sell-item-row'),row=rows[rows.length-1];
          const sel=row.querySelector('.sell-product-select');sel.value=p.id;sel.dispatchEvent(new Event('change',{bubbles:true}));
          const q=row.querySelector('.sell-qty');q.value=it.q;q.dispatchEvent(new Event('input',{bubbles:true}));
          const pr=row.querySelector('.sell-price');if(pr&&!Number(pr.value)){pr.value=p.sell;pr.dispatchEvent(new Event('input',{bubbles:true}))}
        });
        // match the customer by phone number (last 9 digits)
        const d=digits(o.phone).slice(-9),c=d&&(State.customers||[]).find(x=>digits(x.contact).slice(-9)===d);
        const cs=document.getElementById('sellCustomerId');if(c&&cs){cs.value=c.id;cs.dispatchEvent(new Event('change',{bubbles:true}))}
        if(window.Sales.updateSellTotal)Sales.updateSellTotal();
        Toast.info?Toast.info('Order #'+o.id+' loaded. Check the details, then save the sale.'):Toast.success('Order #'+o.id+' loaded');
        if(missing.length)Toast.warning('Not found in your products: '+missing.join(', '));
        const s=read();if(s[id]){s[id].saleStarted=true;write(s)}
      }catch(e){console.error(e);Toast.error('Could not fill the sale form: '+(e.message||e))}
    },250);
  }
};
window.OnlineOrders=OnlineOrders;
setTimeout(()=>pull(false),9000);
setInterval(()=>{if(!document.hidden)pull(false)},2*60*1000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)pull(false)});
setTimeout(refreshBadge,1500);
return OnlineOrders;});
})();
