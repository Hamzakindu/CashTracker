// CashTracker V5.10.26 - People Money: WebView-safe people and money entry
(function(){'use strict';
window.PeopleMoney={
 init(){
  State.peopleMoney=Array.isArray(State.peopleMoney)?State.peopleMoney:[];State.peopleMoneyTx=Array.isArray(State.peopleMoneyTx)?State.peopleMoneyTx:[];
 },
 people(){return (State.peopleMoney||[]).filter(p=>p.active!==false)},
 person(id){return this.people().find(p=>p.id===id)},
 balance(id){let b=0;(State.peopleMoneyTx||[]).filter(t=>t.status!=='void'&&t.personId===id).forEach(t=>{let n=+t.amount||0;if(t.kind==='credit'||t.kind==='payment_to_person')b+=n;else if(t.kind==='debit'||t.kind==='payment_from_person')b-=n});return b},
 bindModal(id){
  const m=document.getElementById(id); if(!m||m.dataset.bound==='1')return; m.dataset.bound='1';
  m.addEventListener('click',e=>{if(e.target===m)this.closeModal(id)});
 },
 closeModal(id){const m=document.getElementById(id);if(window.Modals&&Modals.close)Modals.close(id);else if(m){m.classList.remove('show');m.style.display='none'}else return;if(m){m.classList.remove('show');m.style.display='none'}},
 showModal(id){if(window.Modals&&Modals.open)Modals.open(id);else{const m=document.getElementById(id);if(m)m.style.display='flex'}},
 addPerson(){
  let n=(document.getElementById('pmName')?.value||'').trim();
  if(!n)return Toast.warning('Enter person name');
  State.peopleMoney.unshift({id:Helpers.uid(),name:n,phone:(document.getElementById('pmPhone')?.value||'').trim(),note:(document.getElementById('pmNote')?.value||'').trim(),createdAt:new Date().toISOString(),active:true});
  Storage.save('peopleMoney',State.peopleMoney);EntryDrafts.markSaved('pmPersonModal');this.closeModal('pmPersonModal');this.render();Toast.success('Person added');
 },
 openPerson(){
  let m=document.getElementById('pmPersonModal');
  if(!m){
   m=document.createElement('div');m.className='modal-overlay';m.id='pmPersonModal';
   m.innerHTML='<div class="modal"><button type="button" class="close-btn" data-pm-close="pmPersonModal">✕</button><h3>👥 Add Person</h3><div class="form-group"><label>Name</label><input class="form-control" id="pmName"></div><div class="form-group"><label>Phone</label><input class="form-control" id="pmPhone"></div><div class="form-group"><label>Note</label><input class="form-control" id="pmNote"></div><button type="button" class="btn btn-success" id="pmSavePerson">Save Person</button></div>';
   document.body.appendChild(m);
   m.querySelector('[data-pm-close]').addEventListener('click',()=>this.closeModal('pmPersonModal'));
   m.querySelector('#pmSavePerson').addEventListener('click',()=>this.addPerson());
   this.bindModal('pmPersonModal');
  }
  ['pmName','pmPhone','pmNote'].forEach(id=>document.getElementById(id).value='');
  const modal=document.getElementById('pmPersonModal');
  if(modal){ modal.classList.add('show'); modal.style.display='flex'; }
  this.showModal('pmPersonModal');
 },
 addEntry(){
  const pid=document.getElementById('pmPerson')?.value||'';
  const k=document.getElementById('pmKind')?.value||'';
  const a=Number(document.getElementById('pmAmount')?.value)||0;
  const d=document.getElementById('pmDate')?.value||Helpers.getToday();
  const note=(document.getElementById('pmNote2')?.value||'').trim();
  const acct=document.getElementById('pmAccount')?.value||'';
  if(!pid)return Toast.warning('Choose a person');
  if(!['credit','debit','payment_from_person','payment_to_person'].includes(k))return Toast.warning('Choose entry type');
  if(a<=0)return Toast.warning('Enter an amount greater than zero');
  if((k==='payment_from_person'||k==='payment_to_person')&&!acct)return Toast.warning('Choose the cash or bank account');
  const t={id:Helpers.uid(),personId:pid,kind:k,amount:a,date:d,note,status:'posted',createdAt:new Date().toISOString()};
  State.peopleMoneyTx.unshift(t);
  if((k==='payment_from_person'||k==='payment_to_person')&&window.CashBanks){
   CashBanks.init();CashBanks.link(acct,a,k==='payment_from_person'?'in':'out',{date:d,note,sourceType:'people_money',sourceId:t.id,personId:pid});
  }
  Storage.save('peopleMoneyTx',State.peopleMoneyTx);EntryDrafts.markSaved('pmTxModal');if(window.EntryMemory)EntryMemory.remember('peopleMoney',{personId:pid,entryKind:k,accountId:acct,date:d});this.closeModal('pmTxModal');this.render();if(window.CashBanks)CashBanks.render();Toast.success('Money entry recorded');
 },
 updateEntryUI(){
  const k=document.getElementById('pmKind')?.value;
  const accountGroup=document.getElementById('pmAccountGroup');
  const isPayment=k==='payment_from_person'||k==='payment_to_person';
  if(accountGroup)accountGroup.style.display=isPayment?'block':'none';
 },
 openEntry(){
  if(!this.people().length){
   Toast.warning('Please add a person first');
   return this.openPerson();
  }
  let m=document.getElementById('pmTxModal');
  if(!m){
   m=document.createElement('div');m.className='modal-overlay';m.id='pmTxModal';
   m.innerHTML='<div class="modal"><button type="button" class="close-btn" data-pm-close="pmTxModal">✕</button><h3>💵 Add Money Entry</h3><div class="form-group"><label>Person</label><select class="form-control" id="pmPerson"></select></div><div class="form-group"><label>Entry</label><select class="form-control" id="pmKind"><option value="credit">Credit — person owes us</option><option value="debit">Debit — we owe person</option><option value="payment_from_person">Payment received from person</option><option value="payment_to_person">Payment given to person</option></select></div><div class="form-group"><label>Amount</label><input class="form-control" id="pmAmount" type="number" inputmode="decimal" min="0.01" step="0.01"></div><div class="form-group"><label>Date</label><input class="form-control" id="pmDate" type="date"></div><div class="form-group" id="pmAccountGroup"><label>Cash / Bank account</label><select class="form-control" id="pmAccount"></select></div><div class="form-group"><label>Note</label><input class="form-control" id="pmNote2"></div><div style="display:flex;gap:6px;flex-wrap:wrap"><button type="button" class="btn btn-outline btn-sm" data-cashtracker-onclick="EntryMemory&&EntryMemory.apply(\"peopleMoney\")">↻ Same as last time</button><button type="button" class="btn btn-success" id="pmSaveEntry">Save Money Entry</button></div></div>';
   document.body.appendChild(m);
   m.querySelector('[data-pm-close]').addEventListener('click',()=>this.closeModal('pmTxModal'));
   m.querySelector('#pmSaveEntry').addEventListener('click',()=>this.addEntry());
   m.querySelector('#pmKind').addEventListener('change',()=>this.updateEntryUI());
   this.bindModal('pmTxModal');
  }
  document.getElementById('pmPerson').innerHTML=this.people().map(p=>'<option value="'+Helpers.esc(p.id)+'">'+Helpers.esc(p.name)+'</option>').join('');
  document.getElementById('pmKind').value='credit';document.getElementById('pmDate').value=Helpers.getToday();document.getElementById('pmAmount').value='';document.getElementById('pmNote2').value='';if(window.EntryMemory)EntryMemory.apply('peopleMoney');
  if(window.CashBanks){CashBanks.init();document.getElementById('pmAccount').innerHTML=CashBanks.selectOptions('')}else document.getElementById('pmAccount').innerHTML='<option value="">No cash/bank account available</option>';
  this.updateEntryUI();
  const modal=document.getElementById('pmTxModal');
  if(modal){ modal.classList.add('show'); modal.style.display='flex'; }
  this.showModal('pmTxModal');
 },
 render(){
  this.init();let pane=document.getElementById('tab-peoplemoney');if(!pane)return;
  let rows=this.people().map(p=>({p,b:this.balance(p.id)})),rec=rows.filter(x=>x.b>0).reduce((s,x)=>s+x.b,0),pay=rows.filter(x=>x.b<0).reduce((s,x)=>s-x.b,0);
  pane.innerHTML='<div class="card"><div class="flex-between"><div><div class="card-title">👥 People Money</div><small>Manage people who owe you and people you owe.</small></div><div><button type="button" class="btn btn-success btn-sm" id="pmAddPersonBtn">➕ Person</button> <button type="button" class="btn btn-primary btn-sm" id="pmAddEntryBtn">💵 Add Money</button></div></div><div class="stock-summary-grid"><div class="stock-summary-item"><span class="summary-label">People owe us</span><span class="summary-value">'+Helpers.formatCurrency(rec)+'</span></div><div class="stock-summary-item"><span class="summary-label">We owe people</span><span class="summary-value">'+Helpers.formatCurrency(pay)+'</span></div><div class="stock-summary-item"><span class="summary-label">Net</span><span class="summary-value">'+Helpers.formatCurrency(rec-pay)+'</span></div></div></div><div class="card"><div class="card-title">Balances</div><div style="overflow-x:auto"><table class="transaction-table"><thead><tr><th>Person</th><th>Phone</th><th>People owe us</th><th>We owe</th><th>Net</th></tr></thead><tbody>'+rows.map(x=>'<tr><td><b>'+Helpers.esc(x.p.name)+'</b></td><td>'+Helpers.esc(x.p.phone||'')+'</td><td>'+Helpers.formatCurrency(Math.max(x.b,0))+'</td><td>'+Helpers.formatCurrency(Math.max(-x.b,0))+'</td><td><b>'+Helpers.formatCurrency(x.b)+'</b></td></tr>').join('')+'</tbody></table></div></div><div class="card"><div class="card-title">Recent entries</div><div style="overflow-x:auto"><table class="transaction-table"><thead><tr><th>Date</th><th>Person</th><th>Entry</th><th>Amount</th><th>Note</th></tr></thead><tbody>'+(Helpers.sortByOccurrence((State.peopleMoneyTx||[]).filter(t=>t.status!=='void'), true).slice(0,100).map(t=>'<tr><td>'+Helpers.formatDate(t.date)+'</td><td>'+Helpers.esc(this.person(t.personId)?.name||'Unknown')+'</td><td>'+t.kind.replaceAll('_',' ')+'</td><td>'+Helpers.formatCurrency(t.amount)+'</td><td>'+Helpers.esc(t.note||'')+'</td></tr>').join(''))+'</tbody></table></div></div>';
  const personBtn=document.getElementById('pmAddPersonBtn');
  const entryBtn=document.getElementById('pmAddEntryBtn');
  if(personBtn) personBtn.onclick=(e)=>{e.preventDefault();e.stopPropagation();this.openPerson();};
  if(entryBtn) entryBtn.onclick=(e)=>{e.preventDefault();e.stopPropagation();this.openEntry();};
 }
};
// Initialized by app bootstrap after State.init()/loadAllData.
})();
