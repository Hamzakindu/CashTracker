// LOYALTY: points from what customers spend, tiers, redeeming and sharing points
(function(){'use strict';
window.registerModule('Loyalty',function(){
const CFG='SP_loyalty_cfg',USED='SP_loyalty_used';
const esc=s=>Helpers.esc(String(s==null?'':s));
const fmt=n=>Helpers.formatCurrency(Number(n)||0);
const store=()=>{try{return JSON.parse(localStorage.getItem('stockProfile')||'{}').storeName||'CashTracker'}catch(e){return 'CashTracker'}};
const rd=(k,d)=>{try{return JSON.parse(localStorage.getItem(k)||'null')||d}catch(e){return d}};
const cfg=()=>Object.assign({per:100,value:1,silver:5000,gold:20000},rd(CFG,{}));
const CH=[['whatsapp','💬'],['telegram','✈️'],['imo','🟣'],['sms','📱'],['more','📤']];
function stats(){
  const c=cfg(),u=rd(USED,{}),sp={};
  (State.sales||[]).forEach(s=>{if(!s.customerId||s.customerId==='walkin'||s.voided||s.status==='void')return;sp[s.customerId]=(sp[s.customerId]||0)+(Number(s.total)||0)});
  return (State.customers||[]).filter(x=>sp[x.id]>0).map(x=>{
    const spent=sp[x.id],earned=Math.floor(spent/c.per),used=u[x.id]||0;
    return{c:x,spent,earned,used,avail:Math.max(0,earned-used),tier:spent>=c.gold?'🥇 Gold':spent>=c.silver?'🥈 Silver':'🥉 Bronze'};
  }).sort((a,b)=>b.avail-a.avail||b.spent-a.spent);
}
function render(){
  const p=document.getElementById('tab-loyalty');if(!p)return;const c=cfg(),l=stats();
  p.innerHTML=`<div class="card"><div class="card-title">⭐ Loyalty</div><p>1 point for every ${fmt(c.per)} spent. 1 point = ${fmt(c.value)} discount. Silver from ${fmt(c.silver)}, Gold from ${fmt(c.gold)}.</p>
  <button class="btn btn-outline btn-sm" data-cashtracker-onclick="Loyalty.rules()">✏️ Change rules</button>
  <small style="display:block;margin-top:6px;opacity:.75">Points come from each customer's sales history. When a customer redeems points, give the discount on their next sale yourself.</small></div>
  ${l.map(x=>`<div class="card" style="margin:8px 0;padding:10px"><div class="flex-between"><b>${esc(x.c.name)}</b><span>${x.tier}</span></div>
  <small>Spent ${fmt(x.spent)} · earned ${x.earned} · used ${x.used}</small><div style="font-size:18px;margin:4px 0"><b>${x.avail}</b> points = ${fmt(x.avail*c.value)}</div>
  <div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn btn-success btn-sm" data-cashtracker-onclick="Loyalty.redeem('${esc(x.c.id)}')">🎁 Redeem</button>${CH.map(h=>`<button class="btn btn-primary btn-sm" data-cashtracker-onclick="Loyalty.share('${esc(x.c.id)}','${h[0]}')">${h[1]}</button>`).join('')}</div></div>`).join('')||'<div class="empty-state">No customer purchases yet. Points appear after you sell to a named customer.</div>'}`;
}
const Loyalty={
  render,
  rules(){
    const c=cfg(),a=prompt('Spend per point, and discount value per point (example: 100,1)',c.per+','+c.value);if(a==null)return;
    const [per,value]=a.split(',').map(x=>parseFloat(x));if(!(per>0)||!(value>0))return Toast.warning('Use two numbers like 100,1');
    const b=prompt('Spend needed for Silver and Gold (example: 5000,20000)',c.silver+','+c.gold);if(b==null)return;
    const [silver,gold]=b.split(',').map(x=>parseFloat(x));if(!(silver>0)||!(gold>silver))return Toast.warning('Use two numbers like 5000,20000');
    localStorage.setItem(CFG,JSON.stringify({per,value,silver,gold}));Toast.success('Rules saved');render();
  },
  redeem(id){
    const x=stats().find(y=>y.c.id===id);if(!x||x.avail<1)return Toast.warning('No points to redeem');
    const a=prompt('Points to redeem for '+x.c.name+' (available '+x.avail+')',String(x.avail));if(a==null)return;
    const n=parseInt(a);if(!(n>=1)||n>x.avail)return Toast.warning('Enter a number from 1 to '+x.avail);
    const u=rd(USED,{});u[id]=(u[id]||0)+n;localStorage.setItem(USED,JSON.stringify(u));
    Toast.success('🎁 Give '+x.c.name+' a discount of '+fmt(n*cfg().value));render();
  },
  share(id,ch){
    const x=stats().find(y=>y.c.id===id);if(!x||!window.ShareHub)return;
    if(ch==='sms'&&!x.c.contact)return Toast.warning('📱 No phone number saved for '+x.c.name);
    ShareHub.send(ch,'Hello '+x.c.name+', you have '+x.avail+' loyalty points ('+fmt(x.avail*cfg().value)+' discount) at '+store()+'. Level: '+x.tier+'. Thank you for shopping with us! ⭐',x.c.contact);
  }
};
window.Loyalty=Loyalty;return Loyalty;});
})();
