// PAYMENTS V4 - money ledger, customer/supplier advances, payment methods
(function(){'use strict';
window.registerModule('Payments',function(){
const Payments={
 openModal(type,id){
  let m=document.getElementById('paymentModal');
  if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='paymentModal';m.innerHTML=`
  <div class="modal" style="max-width:460px"><button class="close-btn" data-cashtracker-onclick="Modals.close('paymentModal')">✕</button>
  <h3 id="paymentModalTitle">Payment</h3><input type="hidden" id="paymentEntityId"><input type="hidden" id="paymentEntityType">
  <div class="form-group"><label>Date</label><input class="form-control" type="date" id="paymentDate"></div>
  <div class="form-group"><label>Amount</label><input class="form-control" id="paymentAmount" type="number" min="0.01" step=".01"></div>
  <div class="form-group"><label>Payment method</label><select class="form-control" id="paymentMethod"><option>Cash</option><option>Bank</option><option>Telebirr</option><option>CBE Birr</option><option>Other</option></select></div>
  <div class="form-group"><label>Money account</label><select class="form-control" id="paymentMoneyAccount"></select></div>
  <div class="form-group"><label>Reference / note</label><input class="form-control" id="paymentReference" placeholder="Optional"></div>
  <div class="form-group"><label style="display:flex;gap:8px"><input type="checkbox" id="paymentAsAdvance"><span>Prepayment / advance</span></label></div>
  <button class="btn btn-success" data-cashtracker-onclick="Payments.submit()">Record Payment</button></div>`;document.body.appendChild(m)}
  document.getElementById('paymentEntityId').value=id;document.getElementById('paymentEntityType').value=type;
  document.getElementById('paymentDate').value=Storage.getSetting('lastTransactionDate',Helpers.getToday());
  document.getElementById('paymentAmount').value='';document.getElementById('paymentReference').value='';document.getElementById('paymentMethod').value='Cash';
  document.getElementById('paymentAsAdvance').checked=false;if(window.CashBanks){CashBanks.init();document.getElementById('paymentMoneyAccount').innerHTML=CashBanks.selectOptions();}document.getElementById('paymentModalTitle').textContent=type==='customer'?'Customer Payment / Advance':'Supplier Payment / Advance';
  Modals.open('paymentModal');
 },
 submit(){
  const type=document.getElementById('paymentEntityType').value,id=document.getElementById('paymentEntityId').value;
  const amount=Number(document.getElementById('paymentAmount').value),date=document.getElementById('paymentDate').value||Helpers.getToday();
  const method=document.getElementById('paymentMethod').value,reference=document.getElementById('paymentReference').value.trim(),advance=document.getElementById('paymentAsAdvance').checked;
  if(!Number.isFinite(amount)||amount<=0)return Toast.warning('Enter a valid positive amount');
  try{State.saveUndoState('Payment '+Helpers.formatCurrency(amount));State.runAtomic('Record payment',()=>{
   const e=(type==='customer'?State.customers:State.suppliers).find(x=>x.id===id);if(!e)throw Error('Entity not found');
   if(type==='customer'){
    e.customerAdvance=Number(e.customerAdvance||0);e.balance=Number(e.balance||0);
    if(advance){e.customerAdvance+=amount;} else {const used=Math.min(amount,e.balance);e.balance-=used;e.customerAdvance+=amount-used;}
   }else{
    e.supplierAdvance=Number(e.supplierAdvance||0);e.balance=Number(e.balance||0);
    if(advance)e.supplierAdvance+=amount;else{const used=Math.min(amount,e.balance);e.balance-=used;e.supplierAdvance+=amount-used;}
   }
   State.paymentLedger=State.paymentLedger||[];State.paymentLedger.unshift({id:Helpers.uid(),entityType:type,entityId:id,entityName:e.name,amount,amountNumber:amount,method,reference,date,kind:advance?'advance':'settlement',sourceType:'payment',createdAt:new Date().toISOString(),status:'posted'}); const accountId=document.getElementById('paymentMoneyAccount')?.value;if(accountId&&window.CashBanks)CashBanks.link(accountId,amount,type==='customer'?'in':'out',{date,sourceType:'payment',sourceId:id,note:reference||e.name,paymentId:State.paymentLedger[0]?.id});
  });Storage.setSetting('lastTransactionDate',date);Toast.success('Payment recorded');EntryDrafts.markSaved('paymentModal');Modals.close('paymentModal');type==='customer'?Customers.render():Suppliers.render();Dashboard.update();
  }catch(e){Toast.error('Payment failed: '+(e.message||e))}
 },
 openAdjustBalance(type,id){
  let m=document.getElementById('adjustBalanceModal');if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='adjustBalanceModal';m.innerHTML=`<div class="modal"><button class="close-btn" data-cashtracker-onclick="Modals.close('adjustBalanceModal')">✕</button><h3>Balance Adjustment</h3><input type="hidden" id="adjustEntityId"><input type="hidden" id="adjustEntityType"><input class="form-control" id="adjustAmount" type="number" step=".01"><button class="btn btn-success" data-cashtracker-onclick="Payments.submitAdjust()">Save</button></div>`;document.body.appendChild(m)}
  document.getElementById('adjustEntityId').value=id;document.getElementById('adjustEntityType').value=type;document.getElementById('adjustAmount').value='';Modals.open('adjustBalanceModal');
 },
 submitAdjust(){const type=document.getElementById('adjustEntityType').value,id=document.getElementById('adjustEntityId').value,a=Number(document.getElementById('adjustAmount').value);if(!Number.isFinite(a)||a===0)return Toast.warning('Enter adjustment amount');try{State.saveUndoState('Balance adjustment');State.runAtomic('Balance adjustment',()=>{const e=(type==='customer'?State.customers:State.suppliers).find(x=>x.id===id);if(!e)throw Error('Entity not found');e.balance=(e.balance||0)+a;if(e.balance<0){if(type==='customer')e.customerAdvance=(e.customerAdvance||0)+Math.abs(e.balance);else e.supplierAdvance=(e.supplierAdvance||0)+Math.abs(e.balance);e.balance=0;} if(window.AccountingLedger&&AccountingLedger.audit) AccountingLedger.audit('user','balance_adjustment',type,{entityId:id,amount:a});});Toast.success('Balance adjusted');EntryDrafts.markSaved('adjustBalanceModal'); Modals.close('adjustBalanceModal');type==='customer'?Customers.render():Suppliers.render();Dashboard.update()}catch(e){Toast.error('Adjustment failed: '+e.message)}}
};window.Payments=Payments;return Payments;});})();
