// DAY ACTIVITY
// 1) Any date shown anywhere in the app becomes tappable and opens everything that happened that day.
// 2) Customer / supplier detail screens get a full "All activity" timeline.
(function () {
'use strict';
window.registerModule('DayActivity', function () {

const A = s => Helpers.esc(String(s == null ? '' : s));
const fmt = n => Helpers.formatCurrency(Number(n) || 0);
const num = n => Number(n) || 0;
const ISO_RE = /^\d{4}-\d{2}-\d{2}$/;
const dkey = r => { const v = String((r && (r.date || r.createdAt || r.timestamp)) || '').slice(0, 10); return ISO_RE.test(v) ? v : ''; };
const enc = id => encodeURIComponent(String(id)).replace(/['()*!~]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase());
const sales = () => (State.activeSales ? State.activeSales() : (State.sales || []));
const live = r => r && r.status !== 'void' && r.status !== 'voided' && r.status !== 'cancelled';
const clip = (s, n) => { s = String(s || ''); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
const itemsText = items => {
    const list = (items || []).map(i => (i.productName || i.name || 'Item') + (i.quantity != null ? ' ×' + i.quantity : ''));
    return clip(list.slice(0, 3).join(', ') + (list.length > 3 ? ' +' + (list.length - 3) + ' more' : ''), 80);
};

// ---------- tappable pieces ----------
function link(type, id, label) {
    if (!id || id === 'walkin') return A(label);
    return `<span class="ct-link" data-cashtracker-onclick="DayActivity.open('${type}','${enc(id)}')">${A(label)}</span>`;
}
function rowAttr(type, id) {
    return id ? ` class="ct-row" data-cashtracker-onclick="DayActivity.open('${type}','${enc(id)}')"` : '';
}

// ---------- gather everything that happened on one date ----------
function gather(iso) {
    const daySales = sales().filter(s => dkey(s) === iso);
    const dayPurchases = (State.purchases || []).filter(p => dkey(p) === iso);
    const saleIds = new Set(daySales.map(s => s.id));
    const purIds = new Set(dayPurchases.map(p => p.id));
    const ledger = (State.paymentLedger || []).filter(p => dkey(p) === iso && live(p));
    const inline = p => /^(sale|purchase)_payment$/.test(p.kind || '') && (saleIds.has(p.sourceId) || purIds.has(p.sourceId));
    const person = id => ((State.peopleMoney || []).find(x => x.id === id) || {}).name || 'Person';
    return {
        sales: daySales.slice().sort((a, b) => String(a.createdAt || '').localeCompare(String(b.createdAt || ''))),
        purchases: dayPurchases,
        payments: ledger.filter(p => !inline(p)),
        ledger,
        returns: (State.returns || []).filter(r => dkey(r) === iso && live(r)),
        expenses: (State.directExpenses || []).filter(e => dkey(e) === iso && live(e)),
        advances: (State.supplierAdvances || []).filter(a => dkey(a) === iso),
        moves: (State.moneyTransactions || []).filter(m => dkey(m) === iso && live(m) && !m.paymentId && m.sourceType !== 'expense'),
        people: (State.peopleMoneyTx || []).filter(t => dkey(t) === iso && live(t)).map(t => Object.assign({ personName: person(t.personId) }, t)),
        sessions: (State.cashierSessions || []).filter(s => dkey(s) === iso),
        stock: (State.stockHistory || []).filter(h => dkey(h) === iso),
        audit: (State.auditLog || []).filter(a => dkey(a) === iso)
    };
}

function table(head, rows) {
    return `<table class="transaction-table"><thead><tr>${head.map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table>`;
}
function section(title, count, body) {
    return `<div class="detail-section"><h4>${title} (${count})</h4><div style="overflow-x:auto;">${body}</div></div>`;
}
function more(total, shown) { return total > shown ? `<div style="font-size:.75rem;color:var(--text2);margin-top:6px;">…and ${total - shown} more</div>` : ''; }

function dayHtml(iso) {
    const g = gather(iso);
    const sum = (arr, f) => arr.reduce((t, x) => t + num(f(x)), 0);
    const salesTotal = sum(g.sales, s => s.total), salesDue = sum(g.sales, s => s.debitRemaining);
    const purTotal = sum(g.purchases, p => p.total), purDue = sum(g.purchases, p => p.debit);
    const moneyIn = sum(g.ledger.filter(p => p.entityType === 'customer'), p => p.amountNumber || p.amount);
    const supOut = sum(g.ledger.filter(p => p.entityType === 'supplier'), p => p.amountNumber || p.amount);
    const expTotal = sum(g.expenses, e => e.amount);
    const total = g.sales.length + g.purchases.length + g.payments.length + g.returns.length + g.expenses.length +
        g.advances.length + g.moves.length + g.people.length + g.sessions.length + g.stock.length + g.audit.length;

    const prev = shiftDay(iso, -1), next = shiftDay(iso, 1);
    let h = `<div style="display:flex;justify-content:space-between;gap:8px;margin-bottom:10px;">
        <button class="btn btn-outline btn-sm" data-cashtracker-onclick="DayActivity.show('${prev}')">◀ ${prev}</button>
        <button class="btn btn-outline btn-sm" data-cashtracker-onclick="DayActivity.show('${next}')">${next} ▶</button></div>`;
    if (!total) return h + '<div class="detail-section"><div class="empty-state">No recorded activity on this date.</div></div>';

    h += `<div class="detail-section"><h4>📊 Day summary</h4><div class="stock-summary-grid">
        <div class="stock-summary-item"><span class="summary-label">Sales (${g.sales.length})</span><span class="summary-value text-primary">${fmt(salesTotal)}</span></div>
        <div class="stock-summary-item"><span class="summary-label">Purchases (${g.purchases.length})</span><span class="summary-value text-primary">${fmt(purTotal)}</span></div>
        <div class="stock-summary-item"><span class="summary-label">Money received</span><span class="summary-value text-success">${fmt(moneyIn)}</span></div>
        <div class="stock-summary-item"><span class="summary-label">Paid to suppliers</span><span class="summary-value text-danger">${fmt(supOut)}</span></div>
        <div class="stock-summary-item"><span class="summary-label">Expenses</span><span class="summary-value text-danger">${fmt(expTotal)}</span></div>
        <div class="stock-summary-item"><span class="summary-label">Unpaid on credit</span><span class="summary-value">${fmt(salesDue)} / ${fmt(purDue)}</span></div>
        </div><div style="font-size:.72rem;color:var(--text2);margin-top:6px;">Unpaid on credit: customers owe / we owe suppliers, from this day's sales and purchases.</div></div>`;

    if (g.sales.length) h += section('💰 Sales', g.sales.length, table(['Customer', 'Items', 'Total', 'Balance'],
        g.sales.map(s => `<tr${rowAttr('sale', s.id)}><td>${link('customer', s.customerId, s.customer || 'Customer')}</td><td>${A(itemsText(s.items))}</td><td>${fmt(s.total)}</td><td>${fmt(s.debitRemaining)}</td></tr>`)));
    if (g.purchases.length) h += section('📥 Purchases', g.purchases.length, table(['Supplier', 'Items', 'Total', 'Balance'],
        g.purchases.map(p => `<tr${rowAttr('purchase', p.id)}><td>${link('supplier', p.supplierId, p.supplier || 'Supplier')}</td><td>${A(itemsText(p.items))}</td><td>${fmt(p.total)}</td><td>${fmt(p.debit)}</td></tr>`)));
    if (g.payments.length) h += section('💳 Payments', g.payments.length, table(['Who', 'Method', 'Type', 'Amount'],
        g.payments.map(p => `<tr><td>${link(p.entityType, p.entityId, p.entityName || p.entityType)}</td><td>${A(p.method || '')}</td><td>${A((p.entityType === 'supplier' ? 'Paid out' : 'Received') + (p.kind ? ' · ' + String(p.kind).replace(/_/g, ' ') : ''))}</td><td>${fmt(p.amountNumber || p.amount)}</td></tr>`)));
    if (g.returns.length) h += section('↩️ Returns', g.returns.length, table(['Product', 'Qty', 'Refund', 'Method'],
        g.returns.map(r => `<tr${rowAttr('return', r.id)}><td>${A(r.productName || '')}</td><td>${A(r.quantity)}</td><td>${fmt(r.totalRefund)}</td><td>${A(r.refundMethod || '')}</td></tr>`)));
    if (g.expenses.length) h += section('🧾 Expenses', g.expenses.length, table(['Type', 'Reason', 'Amount'],
        g.expenses.map(e => `<tr><td>${A(e.typeName || '')}</td><td>${A(e.reason || '')}</td><td>${fmt(e.amount)}</td></tr>`)));
    if (g.advances.length) h += section('🏦 Supplier advances', g.advances.length, table(['Supplier', 'Type', 'Amount'],
        g.advances.map(a => `<tr><td>${link('supplier', a.supplierId, a.supplier || 'Supplier')}</td><td>${A(a.type || '')}</td><td>${fmt(a.amount)}</td></tr>`)));
    if (g.people.length) h += section('👥 People money', g.people.length, table(['Person', 'Kind', 'Note', 'Amount'],
        g.people.map(t => `<tr><td>${A(t.personName)}</td><td>${A(t.kind || '')}</td><td>${A(clip(t.note, 40))}</td><td>${fmt(t.amount)}</td></tr>`)));
    if (g.moves.length) h += section('💵 Other cash movements', g.moves.length, table(['Note', 'In/Out', 'Amount'],
        g.moves.map(m => `<tr><td>${A(clip(m.note || m.sourceType || '', 50))}</td><td>${A(m.type || '')}</td><td>${fmt(m.amount)}</td></tr>`)));
    if (g.sessions.length) h += section('🔐 Cashier sessions', g.sessions.length, table(['Status', 'Opening', 'Closing'],
        g.sessions.map(s => `<tr><td>${A(s.status || '')}</td><td>${fmt(s.opening)}</td><td>${s.closing != null ? fmt(s.closing) : '—'}</td></tr>`)));
    if (g.stock.length) { const cap = 40; h += section('📦 Stock movements', g.stock.length, table(['Product', 'Change', 'Reason'],
        g.stock.slice(0, cap).map(x => `<tr><td>${A(x.productName || '')}</td><td>${A(x.change)}</td><td>${A(clip(x.reason, 40))}</td></tr>`)) + more(g.stock.length, cap)); }
    if (g.audit.length) { const cap = 30; h += section('🗒️ Activity log', g.audit.length, table(['Action', 'Item', 'By'],
        g.audit.slice(0, cap).map(a => `<tr><td>${A(String(a.action || '').replace(/_/g, ' '))}</td><td>${A(a.entityType || '')}</td><td>${A(a.actor || '')}</td></tr>`)) + more(g.audit.length, cap)); }
    return h;
}

function shiftDay(iso, delta) {
    const d = new Date(iso + 'T00:00:00Z');
    d.setUTCDate(d.getUTCDate() + delta);
    return d.toISOString().slice(0, 10);
}

// ---------- the day modal ----------
function ensureModal() {
    let m = document.getElementById('dayActivityModal');
    if (m) return m;
    m = document.createElement('div');
    m.className = 'modal-overlay';
    m.id = 'dayActivityModal';
    m.style.zIndex = '10001';
    m.innerHTML = '<div class="modal" style="max-width:650px;"><button class="close-btn" data-cashtracker-onclick="Modals.close(\'dayActivityModal\')">✕</button>' +
        '<h3 id="dayActivityTitle" data-no-date-link="1">📅 Day activity</h3><div id="dayActivityContent"></div></div>';
    m.addEventListener('click', e => { if (e.target === m) Modals.close('dayActivityModal'); });
    document.body.appendChild(m);
    return m;
}

function show(iso) {
    iso = String(iso || '').slice(0, 10);
    if (!ISO_RE.test(iso)) return;
    try {
        ensureModal();
        const weekday = new Date(iso + 'T00:00:00').toLocaleDateString('en-US', { weekday: 'long' });
        document.getElementById('dayActivityTitle').textContent = '📅 ' + weekday + ', ' + Helpers.formatDate(iso);
        document.getElementById('dayActivityContent').innerHTML = dayHtml(iso);
        Modals.open('dayActivityModal');
        const box = document.getElementById('dayActivityModal').querySelector('.modal');
        if (box) box.scrollTop = 0;
    } catch (e) {
        console.error('DayActivity.show error:', e);
        Toast.error('Could not load this day: ' + e.message);
    }
}

// Tapping a row in the day modal opens that record (the day modal closes first so it is not in the way).
function open(type, encId) {
    let id = encId;
    try { id = decodeURIComponent(encId); } catch (e) {}
    Modals.close('dayActivityModal');
    if (window.TransactionDetail) TransactionDetail.show(type, id);
}

// ---------- full timeline for a customer / supplier ----------
function timelineItems(type, id) {
    const out = [];
    if (type === 'customer') {
        const own = sales().filter(s => s.customerId === id);
        const saleDate = {};
        own.forEach(s => {
            saleDate[s.id] = dkey(s);
            out.push({ date: dkey(s), ts: s.createdAt || '', icon: '💰', title: 'Sale', desc: itemsText(s.items), amount: s.total,
                extra: 'Paid ' + fmt(s.paymentReceived) + ' · Balance ' + fmt(s.debitRemaining), open: ['sale', s.id] });
        });
        (State.paymentLedger || []).filter(p => p.entityType === 'customer' && p.entityId === id && live(p)).forEach(p => {
            if (p.kind === 'sale_payment' && saleDate[p.sourceId] === dkey(p)) return; // already part of the sale row
            out.push({ date: dkey(p), ts: p.createdAt || '', icon: '💳', title: 'Payment received', desc: [p.method, p.reference].filter(Boolean).join(' · '), amount: p.amountNumber || p.amount, open: null });
        });
        (State.returns || []).filter(r => r.customerId === id && live(r)).forEach(r => {
            out.push({ date: dkey(r), ts: r.createdAt || '', icon: '↩️', title: 'Return', desc: (r.productName || '') + (r.quantity != null ? ' ×' + r.quantity : ''), amount: r.totalRefund, open: ['return', r.id] });
        });
    } else {
        const own = (State.purchases || []).filter(p => p.supplierId === id);
        const purDate = {};
        own.forEach(p => {
            purDate[p.id] = dkey(p);
            out.push({ date: dkey(p), ts: p.createdAt || '', icon: '📥', title: 'Purchase', desc: itemsText(p.items), amount: p.total,
                extra: 'Paid ' + fmt(p.paid) + ' · Balance ' + fmt(p.debit), open: ['purchase', p.id] });
        });
        (State.paymentLedger || []).filter(p => p.entityType === 'supplier' && p.entityId === id && live(p)).forEach(p => {
            if (p.kind === 'purchase_payment' && purDate[p.sourceId] === dkey(p)) return;
            out.push({ date: dkey(p), ts: p.createdAt || '', icon: '💸', title: 'Payment made', desc: [p.method, p.reference].filter(Boolean).join(' · '), amount: p.amountNumber || p.amount, open: null });
        });
        (State.supplierAdvances || []).filter(a => a.supplierId === id).forEach(a => {
            out.push({ date: dkey(a), ts: a.createdAt || '', icon: '🏦', title: 'Advance ' + (a.type || ''), desc: '', amount: a.amount, open: null });
        });
    }
    out.sort((a, b) => (b.date || '').localeCompare(a.date || '') || String(b.ts).localeCompare(String(a.ts)));
    return out;
}

function timelineHtml(type, id) {
    try {
        const items = timelineItems(type, id), cap = 150;
        if (!items.length) return '<div class="detail-section"><h4>🧭 All activity (0)</h4><div class="empty-state">No sales, purchases or payments recorded yet.</div></div>';
        const rows = items.slice(0, cap).map(i => `<tr${i.open ? rowAttr(i.open[0], i.open[1]) : ''}>
            <td>${A(i.date)}</td><td>${i.icon} ${A(i.title)}${i.desc ? '<div style="font-size:.72rem;color:var(--text2);">' + A(i.desc) + '</div>' : ''}${i.extra ? '<div style="font-size:.72rem;color:var(--text2);">' + A(i.extra) + '</div>' : ''}</td><td>${fmt(i.amount)}</td></tr>`);
        return `<div class="detail-section"><h4>🧭 All activity (${items.length})</h4>
            <div style="font-size:.72rem;color:var(--text2);margin-bottom:6px;">Tap a date to see everything that happened that day. Tap a sale or purchase for its details.</div>
            <div style="max-height:340px;overflow:auto;">${table(['Date', 'Activity', 'Amount'], rows)}</div>${more(items.length, cap)}</div>`;
    } catch (e) {
        console.error('timelineHtml error:', e);
        return '';
    }
}

// ---------- make every date on screen tappable ----------
const MON = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
// "Oct 25, 2026" (optionally followed by the Ethiopian date in brackets) or "2026-10-25"
const DATE_SRC = '\\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\\.? (\\d{1,2}), (\\d{4})(?: \\(\\d{1,2}\\/\\d{1,2}\\/\\d{3,4} \\u12d3\\.\\u121d\\))?|';
let DATE_RE;
try { DATE_RE = new RegExp(DATE_SRC + '(?<!\\d)(\\d{4})-(\\d{2})-(\\d{2})(?!\\d)', 'g'); }   // also matches 2026-10-22T07:40
catch (e) { DATE_RE = new RegExp(DATE_SRC + '\\b(\\d{4})-(\\d{2})-(\\d{2})\\b', 'g'); }      // older WebView without lookbehind

function toISO(y, m, d) {
    if (y < 1990 || y > 2100 || m < 1 || m > 12 || d < 1 || d > 31) return '';
    const t = new Date(Date.UTC(y, m - 1, d));
    if (t.getUTCFullYear() !== y || t.getUTCMonth() !== m - 1 || t.getUTCDate() !== d) return '';
    return t.toISOString().slice(0, 10);
}

// Pure function: split text into plain and date segments.
function splitDates(text) {
    const parts = [];
    let last = 0, m;
    DATE_RE.lastIndex = 0;
    while ((m = DATE_RE.exec(text))) {
        const iso = m[1] ? toISO(+m[3], MON[m[1].toLowerCase()], +m[2]) : toISO(+m[4], +m[5], +m[6]);
        if (!iso) continue;
        if (m.index > last) parts.push({ type: 'text', s: text.slice(last, m.index) });
        parts.push({ type: 'date', s: m[0], iso });
        last = m.index + m[0].length;
    }
    if (last < text.length) parts.push({ type: 'text', s: text.slice(last) });
    return parts;
}

const SKIP = '[data-no-date-link],.ct-date,button,a,select,textarea,input,option,script,style,svg,noscript,[contenteditable="true"]';
const okParent = el => !!el && el.nodeType === 1 && !el.closest(SKIP);

function wrapTextNode(node) {
    const text = node.nodeValue;
    if (!text || text.length < 8 || !/\d/.test(text) || !okParent(node.parentNode)) return;
    const parts = splitDates(text);
    if (!parts.some(p => p.type === 'date')) return;
    const frag = document.createDocumentFragment();
    parts.forEach(p => {
        if (p.type === 'text') frag.appendChild(document.createTextNode(p.s));
        else {
            const sp = document.createElement('span');
            sp.className = 'ct-date';
            sp.setAttribute('data-ct-date', p.iso);
            sp.textContent = p.s;
            frag.appendChild(sp);
        }
    });
    node.parentNode.replaceChild(frag, node);
}

function scan(root) {
    if (!root) return;
    if (root.nodeType === 3) { wrapTextNode(root); return; }
    if (root.nodeType !== 1 || !okParent(root)) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    const nodes = [];
    for (let n = walker.nextNode(); n; n = walker.nextNode()) nodes.push(n);
    nodes.forEach(wrapTextNode);
}

let observer = null, timer = null;
const pending = new Set();
function flush() {
    timer = null;
    const items = Array.from(pending);
    pending.clear();
    if (observer) observer.disconnect();
    try { items.forEach(n => { if (n.isConnected !== false) scan(n); }); }
    catch (e) { console.warn('date linking skipped:', e); }
    finally { if (observer) observer.observe(document.body, { childList: true, subtree: true, characterData: true }); }
}
function startLinking() {
    if (typeof MutationObserver === 'undefined' || !document.body) return;
    const style = document.createElement('style');
    style.textContent = '.ct-date{text-decoration:underline dotted;text-underline-offset:3px;cursor:pointer;}' +
        '.ct-link{color:var(--primary);text-decoration:underline dotted;text-underline-offset:3px;cursor:pointer;}' +
        '.ct-row{cursor:pointer;}';
    document.head.appendChild(style);
    observer = new MutationObserver(muts => {
        muts.forEach(m => {
            if (m.type === 'childList') m.addedNodes.forEach(n => pending.add(n));
            else if (m.type === 'characterData' && m.target.parentNode) pending.add(m.target.parentNode);
        });
        if (!timer) timer = setTimeout(flush, 60);
    });
    pending.add(document.body);
    flush();
}

// Window capture runs before the app's own click handler, so a tapped date wins over the row it sits in.
window.addEventListener('click', e => {
    const el = e.target && e.target.closest ? e.target.closest('.ct-date') : null;
    if (!el) return;
    const iso = el.getAttribute('data-ct-date');
    if (!iso) return;
    e.stopPropagation();
    e.preventDefault();
    show(iso);
}, true);

window.DayActivity = { show, open, gather, splitDates, timelineHtml, timelineItems, dayHtml, scan, startLinking };
startLinking();

});
})();
