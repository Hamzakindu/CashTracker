// VOID RESTORE: helpers used to bring a voided sale/purchase back.
(function () {
'use strict';
window.registerModule('VoidRestore', function () {
    const t = x => Date.parse(x.createdAt || x.date || '') || 0;
    const VoidRestore = {
        newBatch() { return 'v' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); },

        // Mark the live entries of a sale/purchase as void and remember which void did it.
        voidEntries(list, sourceId, batch) {
            (list || []).forEach(x => { if (x.sourceId === sourceId && x.status !== 'void') { x.status = 'void'; x.voidBatch = batch; } });
        },

        // Bring back the entries that this void switched off. Entries that were voided earlier by an edit
        // stay void. For voids made before batches existed, pick the newest set of entries whose amounts
        // match what the record itself says was paid (expected = { cash, advance }).
        reactivate(list, sourceId, batch, expected) {
            const mine = (list || []).filter(x => x.sourceId === sourceId && x.status === 'void');
            const amt = x => Number(x.amountNumber != null ? x.amountNumber : x.amount) || 0;
            let chosen = [];
            if (batch) {
                chosen = mine.filter(x => x.voidBatch === batch);
            } else {
                const clusters = [];
                mine.slice().sort((a, b) => t(b) - t(a)).forEach(x => {
                    const c = clusters.find(k => Math.abs(k.t - t(x)) <= 60000);
                    if (c) c.items.push(x); else clusters.push({ t: t(x), items: [x] });
                });
                if (!expected) {
                    chosen = clusters.length ? clusters[0].items : [];
                } else {
                    const sum = (items, adv) => items.filter(x => (x.method === 'Customer Advance') === adv).reduce((a, x) => a + amt(x), 0);
                    for (const c of clusters) {
                        const cashOk = Math.abs(sum(c.items, false) - (Number(expected.cash) || 0)) < 0.005;
                        const advOk = expected.advance == null || Math.abs(sum(c.items, true) - (Number(expected.advance) || 0)) < 0.005;
                        if (cashOk && advOk) { chosen = c.items; break; }
                    }
                }
            }
            chosen.forEach(x => { x.status = 'posted'; delete x.voidBatch; });
            return chosen.length;
        },

        // Keep a short history of earlier voids on the record itself.
        archiveVoid(rec) {
            rec.voidHistory = (rec.voidHistory || []).concat([{ voidedAt: rec.voidedAt || '', reason: rec.voidReason || '', restoredAt: new Date().toISOString() }]);
            rec.voided = false;
            delete rec.status;
            delete rec.voidedAt;
            delete rec.voidReason;
            delete rec.voidBatch;
            delete rec.financialTransactionsVoided;
        }
    };
    window.VoidRestore = VoidRestore;
});
})();
