// CSP-safe replacement for legacy inline event-handler attributes.
(function(){'use strict';
function splitArgs(s){const out=[];let q='',d=0,start=0;for(let i=0;i<s.length;i++){const c=s[i];if(q){if(c==='\\')i++;else if(c===q)q='';continue}if(c==='"'||c==="'"){q=c;continue}if(c==='('||c==='['||c==='{')d++;else if(c===')'||c===']'||c==='}')d--;else if(c===','&&d===0){out.push(s.slice(start,i).trim());start=i+1}}out.push(s.slice(start).trim());return out.filter(Boolean)}
function callExpr(expr,el,event){expr=expr.trim();if(!expr)return; if(expr.includes('&&')){for(const part of expr.split('&&')){const v=resolve(part,el,event);if(v===undefined||v===null||v===false||v==='')return;}return;}
 if(expr==='event.stopPropagation()'){event.stopPropagation();return} if(expr==='event.preventDefault()'){event.preventDefault();return}
 if(expr==='window.print()'){window.print();return}
 const m=expr.match(/^([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)(?:\((.*)\))?$/s);if(!m)return;
 const path=m[1].split('.');let obj=path[0]==='window'?window:(path[0]==='document'?document:(path[0]==='this'?el:window[path[0]]));
 if(path[0]==='this')path.shift();else path.shift();
 for(const k of path){if(obj==null)return;obj=obj[k]}
 if(typeof obj!=='function')return;
 const args=m[2]==null?[]:splitArgs(m[2]).map(x=>resolve(x,el,event));
 let owner=path.length?null:null;
 // Resolve the callable owner again so `this` inside methods is correct.
 let target=path.length?null:null; const root=m[1].split('.'); let ownerObj=root[0]==='window'?window:root[0]==='document'?document:root[0]==='this'?el:window[root[0]]; for(let i=1;i<root.length-1;i++)ownerObj=ownerObj?.[root[i]];
 return obj.apply(ownerObj,args);
}
function resolve(x,el,event){x=x.trim();if(/^['"]/.test(x)){const q=x[0],z=x.endsWith(q)?x.slice(1,-1):x.slice(1);return z.replace(/\\(['"])/g,'$1')}if(x==='this')return el;if(x==='event')return event;if(x==='true')return true;if(x==='false')return false;if(x==='null')return null;if(/^-?\d+(?:\.\d+)?$/.test(x))return Number(x);
 let m=x.match(/^this\.(value|checked|id|name|type)$/);if(m)return el[m[1]];if(x==='this.parentElement')return el.parentElement;if(x.startsWith('this.closest(')){const mm=x.match(/^this\.closest\(([\'\"])(.*?)\1\)$/);if(mm)return el.closest(mm[2])}
 m=x.match(/^document\.getElementById\((['"])(.*?)\1\)\.(value|checked|textContent)$/);if(m){const e=document.getElementById(m[2]);return e?e[m[3]]:undefined}
 if(/\(.*\)$/.test(x))return callExpr(x,el,event);
 const root=x.split('.');let v=root[0]==='window'?window:root[0]==='document'?document:root[0]==='this'?el:window[root[0]];for(let i=1;i<root.length;i++){if(v==null)return undefined;v=v[root[i]]}return v}
function run(code,el,event){for(const part of splitStatements(code)){try{callExpr(part,el,event)}catch(e){console.warn('CSP event handler failed:',part,e)}}}
function splitStatements(s){const out=[];let q='',d=0,start=0;for(let i=0;i<s.length;i++){const c=s[i];if(q){if(c==='\\')i++;else if(c===q)q='';continue}if(c==='"'||c==="'"){q=c;continue}if(c==='('||c==='['||c==='{')d++;else if(c===')'||c===']'||c==='}')d--;else if(c===';'&&d===0){out.push(s.slice(start,i));start=i+1}}out.push(s.slice(start));return out.filter(x=>x.trim())}
function attr(el,type){return el.getAttribute('data-cashtracker-'+type)}
function handler(type,e){let el=e.target.closest('[data-cashtracker-'+type+']');if(!el)return;const code=attr(el,type);if(code){run(code,el,e)}}
['click','change','input'].forEach(type=>document.addEventListener(type,e=>handler('on'+type,e),true));
})();
