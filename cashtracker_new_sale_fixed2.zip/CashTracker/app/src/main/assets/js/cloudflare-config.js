// Cloudflare CashTracker API configuration.
// Set the Worker URL in Settings -> Cloud. No Firebase configuration is required.
window.CASH_TRACKER_CLOUDFLARE = {
    WORKER_URL: localStorage.getItem('cashtracker_cloudflare_worker_url') || ''
};
