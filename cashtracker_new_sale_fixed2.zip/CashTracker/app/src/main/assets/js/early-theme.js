(function(){try{var t=localStorage.getItem('stockTheme');
    if(t==='dark'||(!t&&window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches)){
      document.documentElement.setAttribute('data-theme','dark');
      var m=document.querySelector('meta[name="theme-color"]');if(m)m.content='#0a0f1a';
    }}catch(e){}})();
