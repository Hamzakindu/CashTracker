// ============================================
// BACKUP SYSTEM
// ============================================
const Backup = {
    timer: null,

    // Manual backup to localStorage
    manualBackup() {
        try {
            const data = {
                exportedAt: new Date().toISOString(),
                profileId: State.currentProfileId,
                appVersion: CONFIG.VERSION,
                format: 'StockPro',
                schemaVersion: 3,
                products: State.products,
                sales: State.sales,
                purchases: State.purchases,
                customers: State.customers,
                suppliers: State.suppliers,
                supplierAdvances: State.supplierAdvances,
                paymentLedger: State.paymentLedger,
                expenseTypes: State.expenseTypes,
                directExpenses: State.directExpenses,
                returns: State.returns,
                calculations: State.calculations,
                stockHistory: State.stockHistory,
                auditLog: State.auditLog,
                accountingMeta: State.accountingMeta,
                cashAccounts: State.cashAccounts,
                moneyTransactions: State.moneyTransactions,
                peopleMoney: State.peopleMoney,
                peopleMoneyTx: State.peopleMoneyTx,
                cashierSessions: State.cashierSessions,
                cashCounts: State.cashCounts,
                cashReconciliations: State.cashReconciliations || [],
                branches: State.branches,
                staffUsers: State.staffUsers,
                branchAccessMeta: State.branchAccessMeta
            };

            const backupKey = 'ab_' + State.currentProfileId;
            localStorage.setItem(backupKey, JSON.stringify(data));
            Storage.setSetting('labt', new Date().toISOString());

            const lastBackupEl = document.getElementById('lastAutoBackup');
            if (lastBackupEl) {
                lastBackupEl.textContent = new Date().toLocaleString();
            }

            Toast.success('✅ Backup completed!');
            return true;
        } catch (error) {
            console.error('Backup error:', error);
            Toast.error('❌ Backup failed: ' + error.message);
            return false;
        }
    },

    // Export backup as downloadable JSON file
    exportBackup() {
        try {
            const data = {
                exportedAt: new Date().toISOString(),
                profileId: State.currentProfileId,
                appVersion: CONFIG.VERSION,
                format: 'StockPro',
                schemaVersion: 3,
                products: State.products,
                sales: State.sales,
                purchases: State.purchases,
                customers: State.customers,
                suppliers: State.suppliers,
                supplierAdvances: State.supplierAdvances,
                paymentLedger: State.paymentLedger,
                expenseTypes: State.expenseTypes,
                directExpenses: State.directExpenses,
                returns: State.returns,
                calculations: State.calculations,
                stockHistory: State.stockHistory,
                auditLog: State.auditLog,
                accountingMeta: State.accountingMeta,
                cashAccounts: State.cashAccounts,
                moneyTransactions: State.moneyTransactions,
                peopleMoney: State.peopleMoney,
                peopleMoneyTx: State.peopleMoneyTx,
                cashierSessions: State.cashierSessions,
                cashCounts: State.cashCounts,
                cashReconciliations: State.cashReconciliations || [],
                branches: State.branches,
                staffUsers: State.staffUsers,
                branchAccessMeta: State.branchAccessMeta
            };

            const json = JSON.stringify(data, null, 2);
            const filename = `stockpro-backup-${State.currentProfileId}-${new Date().toISOString().slice(0, 10)}.json`;
            
            // Create downloadable file
            const blob = new Blob([json], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            Toast.success('✅ Backup downloaded!');
        } catch (error) {
            console.error('Export error:', error);
            Toast.error('❌ Export failed: ' + error.message);
        }
    },

    // Import backup from file — supports CashTracker 5.x and AppMint wrapped backups
    importBackup() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json,.txt,application/json,text/plain';
        input.onchange = async (e) => {
            const file = e.target.files && e.target.files[0];
            if (!file) return;
            try {
                if (file.size > 50 * 1024 * 1024) throw new Error('Backup file is larger than the 50 MB safety limit.');
                let text = await this.readFileAsText(file);
                text = String(text || '').replace(/^\uFEFF/, '').trim();
                if (!text) throw new Error('The backup file is empty.');
                let data = JSON.parse(text);
                // Some backup tools save JSON as a JSON string.
                if (typeof data === 'string') data = JSON.parse(data);
                // Support {data:{...}}, {db:{...}}, and {backup:{...}} wrappers.
                if (data && data.data && typeof data.data === 'object' && !Array.isArray(data.data)) data = Object.assign({}, data.data, { exportedAt: data.exportedAt || data.data.exportedAt, appVersion: data.appVersion || data.data.appVersion });
                else if (data && data.db && typeof data.db === 'object' && !Array.isArray(data.db)) data = Object.assign({}, data.db, { exportedAt: data.exportedAt || data.db.exportedAt, appVersion: data.appVersion || data.db.appVersion });
                else if (data && data.backup && typeof data.backup === 'object' && !Array.isArray(data.backup)) data = Object.assign({}, data.backup, { exportedAt: data.exportedAt || data.backup.exportedAt, appVersion: data.appVersion || data.backup.appVersion });
                if (!this.validateBackupData(data)) throw new Error('Invalid backup format. Expected CashTracker product, sales, purchase, customer, or supplier data.');

                const backupDate = data.exportedAt ? new Date(data.exportedAt).toLocaleString() : 'Unknown date';
                const productCount = Array.isArray(data.products) ? data.products.length : 0;
                const salesCount = Array.isArray(data.sales) ? data.sales.length : 0;
                const purchaseCount = Array.isArray(data.purchases) ? data.purchases.length : 0;
                const customerCount = Array.isArray(data.customers) ? data.customers.length : 0;
                const supplierCount = Array.isArray(data.suppliers) ? data.suppliers.length : 0;
                const version = data.appVersion || 'Unknown';
                const allStores = ['products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger','expenseTypes','directExpenses','returns','calculations','stockHistory','auditLog','accountingMeta','cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','branches','staffUsers','branchAccessMeta'];
                const omittedStores = allStores.filter(key => !Object.prototype.hasOwnProperty.call(data, key));
                const omissionNote = omittedStores.length ? `\n\nThis backup omits ${omittedStores.length} newer/optional data stores. Those stores will remain unchanged, so the result will combine backup data with existing data.` : '';
                if (!confirm(`⚠️ RESTORE BACKUP?\n\nVersion: ${version}\nBackup Date: ${backupDate}\nProducts: ${productCount}\nSales: ${salesCount}\nPurchases: ${purchaseCount}\nCustomers: ${customerCount}\nSuppliers: ${supplierCount}${omissionNote}\n\nIncluded stores will OVERWRITE their current data.\n\nClick OK to proceed.`)) return;

                State.saveUndoState('Before file restore');
                const stores = ['products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger','expenseTypes','directExpenses','returns','calculations','stockHistory','auditLog','accountingMeta','cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','branches','staffUsers','branchAccessMeta'];
                // Capture exact current values so a quota/write error can roll back this restore.
                const before = {};
                stores.forEach(store => { try { const raw = localStorage.getItem(Storage.getKey(store)); before[store] = raw === null ? null : raw; } catch (_) { before[store] = null; } });
                const prepared = {};
                for (const store of stores) if (data[store] !== undefined) prepared[store] = data[store];
                // Legacy 5.9.6 backups may contain paymentReceived instead of paid.
                if (Array.isArray(prepared.sales)) prepared.sales = prepared.sales.map(x => {
                    const y = Object.assign({}, x);
                    if (y.paid === undefined && y.paymentReceived !== undefined) y.paid = Number(y.paymentReceived) || 0;
                    if (!Array.isArray(y.lines) && Array.isArray(y.items)) y.lines = y.items;
                    return y;
                });
                let restoredCount = 0;
                try {
                    for (const store of Object.keys(prepared)) {
                        if (!Storage.save(store, prepared[store])) throw new Error('Storage write failed for ' + store + '. Device storage may be full.');
                        restoredCount++;
                    }
                } catch (writeError) {
                    for (const store of stores) {
                        try { const key = Storage.getKey(store); if (before[store] === null) localStorage.removeItem(key); else localStorage.setItem(key, before[store]); } catch (rollbackError) { console.error('Restore rollback failed for', store, rollbackError); }
                    }
                    throw new Error(writeError.message + ' The app attempted to restore the previous data. Please reopen CashTracker and check your records.');
                }
                // A successful restore is now the authoritative initialized state.
                if (Storage.setSetting) Storage.setSetting('stockpro_initialized_v2','true');
                Toast.success('✅ Backup imported. Reloading...', 2500);
                setTimeout(async () => {
                    await State.loadAllData();
                    App.populateDropdowns(); Dashboard.update(); Products.render(); Sales.render(); Purchases.render(); Customers.render(); Suppliers.render(); Expenses.renderTypes(); Expenses.renderDirect(); Returns.render();
                    Tabs.switchTo('dashboard');
                    Toast.success(`✅ Restored ${restoredCount} data stores: ${productCount} products, ${salesCount} sales, ${purchaseCount} purchases.`, 3500);
                }, 300);
            } catch (error) {
                console.error('Import error:', error);
                Toast.error('❌ Backup import failed: ' + (error.message || 'unknown file format'), 6000);
            }
        };
        input.click();
    },

    // Recover the immutable pre-update safety snapshot.
    // This is intentionally separate from normal backup restore.
    recoverSafetySnapshot() {
        try {
            const snap = Storage.getSafetySnapshot ? Storage.getSafetySnapshot() : null;
            if (!snap) return Toast.warning('No pre-update safety snapshot is available.');
            const when = snap.snapshotAt ? new Date(snap.snapshotAt).toLocaleString() : 'unknown time';
            const stores = snap.stores ? Object.keys(snap.stores).length : 0;
            if (!confirm(`\u26a0\ufe0f RECOVER PRE-UPDATE DATA?\n\nSnapshot: ${when}\nVersion: ${snap.appVersion || 'unknown'}\nStores: ${stores}\n\nCurrent data will be replaced by this recovery snapshot.\n\nClick OK only if you need to undo a bad update.`)) return;
            if (State && State.saveUndoState) State.saveUndoState('Before safety recovery');
            const result = Storage.restoreSafetySnapshot();
            if (!result.ok) throw new Error(result.error || 'Recovery failed');
            Toast.success('\u2705 Safety snapshot restored. Reloading...', 3000);
            setTimeout(()=>location.reload(),400);
        } catch(e) { console.error('Safety recovery error:',e); Toast.error('\u274c Safety recovery failed: '+e.message,6000); }
    },

    // Restore from cloud/localStorage backup
    restoreFromCloud() {
        const backupKey = 'ab_' + State.currentProfileId;
        const backupData = localStorage.getItem(backupKey);
        
        if (!backupData) {
            return Toast.warning('⚠️ No cloud backup found. Use "Import Backup" to restore from a file, or "Backup Now" to create one first.');
        }

        try {
            let data;
            try {
                data = JSON.parse(backupData);
            } catch (parseError) {
                throw new Error('Cloud backup data is corrupted.');
            }
            
            if (!this.validateBackupData(data)) {
                throw new Error('Invalid cloud backup data.');
            }

            const backupDate = data.exportedAt ? new Date(data.exportedAt).toLocaleString() : 'Unknown date';
            const productCount = data.products ? data.products.length : 0;
            
            if (!confirm(
                `⚠️ RESTORE CLOUD BACKUP?\n\n` +
                `Backup Date: ${backupDate}\n` +
                `Products: ${productCount}\n\n` +
                `This will OVERWRITE all current data!\n\n` +
                `Click OK to proceed.`
            )) {
                return;
            }

            State.saveUndoState('Before cloud restore');

            const stores = ['products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger','expenseTypes','directExpenses','returns','calculations','stockHistory','auditLog','accountingMeta','cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','branches','staffUsers','branchAccessMeta'];
            const before = {};
            stores.forEach(store => { try { const raw = localStorage.getItem(Storage.getKey(store)); before[store] = raw === null ? null : raw; } catch (_) { before[store] = null; } });
            let restoredCount = 0;
            try {
                for (const store of stores) {
                    if (data[store] !== undefined) {
                        if (!Storage.save(store, data[store])) throw new Error('Storage write failed for ' + store + '. Device storage may be full.');
                        restoredCount++;
                    }
                }
            } catch (writeError) {
                for (const store of stores) { try { const key = Storage.getKey(store); if (before[store] === null) localStorage.removeItem(key); else localStorage.setItem(key, before[store]); } catch (rollbackError) { console.error('Cloud restore rollback failed for', store, rollbackError); } }
                throw new Error(writeError.message + ' The app attempted to restore the previous data. Please reopen CashTracker and check your records.');
            }

            Toast.success('✅ Cloud backup restored! Reloading...', 4000);

            setTimeout(async () => {
                await State.loadAllData();
                App.populateDropdowns();
                Dashboard.update();
                Products.render();
                Sales.render();
                Purchases.render();
                Customers.render();
                Suppliers.render();
                Expenses.renderTypes();
                Expenses.renderDirect();
                Returns.render();
                Tabs.switchTo('dashboard');
                Toast.success('✅ Ready! ' + restoredCount + ' stores loaded.', 2000);
            }, 500);

        } catch (error) {
            console.error('Cloud restore error:', error);
            Toast.error('❌ ' + error.message, 5000);
        }
    },

    // Validate backup data structure
    // Older exports wrote the two "meta" stores as an empty list ([]). Convert them so the backup can be restored.
    normalizeMetaStores(data) {
        if (!data || typeof data !== 'object' || Array.isArray(data)) return data;
        if (Array.isArray(data.branchAccessMeta)) data.branchAccessMeta = { version: 1, activeBranchId: 'main', currentStaffId: '' };
        if (Array.isArray(data.accountingMeta)) delete data.accountingMeta;
        return data;
    },

    validateBackupData(data) {
        this.normalizeMetaStores(data);
        if (!data || typeof data !== 'object' || Array.isArray(data)) return false;
        if (data.format && String(data.format).toLowerCase() !== 'stockpro') return false;
        const knownStores = ['products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger','expenseTypes','directExpenses','returns','calculations','stockHistory','auditLog','accountingMeta','cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','branches','staffUsers','branchAccessMeta'];
        const hasAnyStore = knownStores.some(key => Object.prototype.hasOwnProperty.call(data, key));
        if (!hasAnyStore) return false;
        // If a store is present it must have the expected container type. Reject malformed
        // backups before changing a single persisted value.
        for (const key of knownStores) {
            if (!Object.prototype.hasOwnProperty.call(data, key)) continue;
            const value = data[key];
            if (['accountingMeta','branchAccessMeta'].includes(key)) {
                if (value !== null && (typeof value !== 'object' || Array.isArray(value))) return false;
            } else if (!Array.isArray(value)) return false;
        }
        // A full CashTracker backup must include the five primary collections. Reject
        // partial exports here so they cannot masquerade as a complete restore.
        return ['products','sales','purchases','customers','suppliers'].every(key => Array.isArray(data[key]));
    },

    // Read file as text (Promise wrapper)
    readFileAsText(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    resolve(e.target.result);
                } catch (error) {
                    reject(new Error('Failed to read file contents'));
                }
            };
            reader.onerror = (e) => {
                reject(new Error('Failed to read file. It may be corrupted or inaccessible.'));
            };
            reader.readAsText(file);
        });
    },

    // Start auto backup
    startAuto() {
        this.stopAuto();
        
        const freq = parseInt(Storage.getSetting('autoBackupFrequency', CONFIG.DEFAULT_BACKUP_FREQUENCY.toString()));
        
        if (freq > 0) {
            this.timer = setInterval(() => {
                if (navigator.onLine) {
                    console.log('Auto-backup triggered');
                    this.manualBackup();
                }
            }, freq * 3600000);
            
            console.log(`Auto-backup started: every ${freq} hours`);
        }
    },

    // Stop auto backup
    stopAuto() {
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
            console.log('Auto-backup stopped');
        }
    },

    // Toggle auto backup
    toggleAuto() {
        const enabledEl = document.getElementById('autoBackupEnabled');
        if (!enabledEl) return;
        
        const enabled = enabledEl.value === 'enabled';
        Storage.setSetting('autoBackupEnabled', enabled ? 'enabled' : 'disabled');
        
        if (enabled) {
            this.startAuto();
            Toast.success('✅ Auto-backup enabled');
        } else {
            this.stopAuto();
            Toast.info('⏸️ Auto-backup disabled');
        }
    }
};

// ============================================
// AUTO-BACKUP EVENT LISTENERS
// ============================================

// Auto-backup when coming back online
window.addEventListener('online', () => {
    const enabled = Storage.getSetting('autoBackupEnabled', 'enabled');
    if (enabled === 'enabled') {
        const lastBackup = Storage.getSetting('labt');
        const oneHour = 3600000;
        
        if (!lastBackup || (new Date().getTime() - new Date(lastBackup).getTime()) > oneHour) {
            console.log('Online: triggering auto-backup');
            setTimeout(() => Backup.manualBackup(), 5000);
        }
    }
});