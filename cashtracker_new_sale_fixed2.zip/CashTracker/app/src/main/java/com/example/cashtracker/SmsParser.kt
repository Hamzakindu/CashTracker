package com.example.cashtracker

import org.json.JSONObject
import java.util.Locale

/** Kotlin-first bank SMS parser. JS keeps a fallback for browser/PWA use. */
object SmsParser {
    private val currency = Regex("(?:etb|birr|br|usd|eur|gbp|kes|sar|aed|inr|rs|[$€£₹])", RegexOption.IGNORE_CASE)
    private val reference = Regex("(?:ref(?:erence)?|txn(?:\\.?|\\s*id)?|transaction\\s*id|trx)\\s*[:#-]?\\s*([A-Za-z0-9-]{4,40})", RegexOption.IGNORE_CASE)
    private val amountLabel = Regex("(?:amount|amt|transaction\\s+amount|debit(?:ed)?|credit(?:ed)?|spent|paid|received|withdrawn|sent|transferred)\\s*(?:is|:|=)?\\s*(?:etb|birr|br)?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE)
    private val balance = Regex("(?:current\\s+balance|available\\s+balance|avl\\.?\\s*bal(?:ance)?|balance|bal)\\s*(?:is|:)?\\s*(?:etb|birr|br)?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE)
    private val bankNames = listOf("commercial bank of ethiopia" to "CBE", "cbe" to "CBE", "awash" to "Awash", "dashen" to "Dashen", "bank of abyssinia" to "BOA", "telebirr" to "Telebirr", "safaricom" to "Safaricom", "mpesa" to "M-Pesa")
    private val bankAmountTemplates = listOf(
        "CBE" to Regex("(?:debited|credited|transferred|paid|received).*?(?:ETB|Birr|BR)?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE),
        "Awash" to Regex("(?:amount|amt|transaction).*?(?:ETB|Birr|BR)?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE),
        "Dashen" to Regex("(?:amount|debited|credited).*?(?:ETB|Birr|BR)?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE),
        "BOA" to Regex("(?:amount|transaction amount|debited|credited).*?(?:ETB|Birr|BR)?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE),
        "Telebirr" to Regex("(?:amount|paid|received|sent).*?(?:ETB|Birr|BR)?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE)
    )

    fun parse(body: String): JSONObject? {
        val t = body.trim()
        if (t.isEmpty()) return null
        val b = t.replace(balance, " ")
        val bank = detectBank(t)
        val templateAmount = bankAmountTemplates.firstOrNull { it.first == bank }?.second?.find(b)?.groupValues?.getOrNull(1)?.replace(",", "")?.toDoubleOrNull()
        val amt = templateAmount ?: amountLabel.find(b)?.groupValues?.getOrNull(1)?.replace(",", "")?.toDoubleOrNull()
            ?: findCurrencyAmount(b)
            ?: return null
        if (amt <= 0) return null
        val lower = b.lowercase(Locale.ROOT)
        val deb = listOf("debited", "spent", "purchase", "withdrawn", "withdrawal", "paid", "payment", "sent", "charged", "deducted", "transferred", "bought", "outgoing").map { lower.indexOf(it) }.filter { it >= 0 }.minOrNull() ?: -1
        val cre = listOf("credited", "received", "deposit", "salary", "refund", "cashback", "incoming").map { lower.indexOf(it) }.filter { it >= 0 }.minOrNull() ?: -1
        val sentReceived = Regex("sent\\s+[^.]{0,80}received\\s+by", RegexOption.IGNORE_CASE).containsMatchIn(lower)
        val dir = if (sentReceived) "out" else if (cre >= 0 && (deb < 0 || cre < deb)) "in" else "out"
        val bal = balance.find(t)?.groupValues?.getOrNull(1)?.replace(",", "")?.toDoubleOrNull()
        val who = Regex("(?:\\bat\\b|\\bto\\b|\\bfrom\\b|@|towards)\\s+([A-Za-z0-9&.'\\- ]{2,40}?)(?=\\s+(?:on|using|via|ref|bal|a/c|acct|card|dated|with|your|and|txn|transaction)\\b|[.,;(]|$)", RegexOption.IGNORE_CASE).find(t)?.groupValues?.getOrNull(1)?.trim() ?: ""
        val o = JSONObject().put("amount", amt).put("dir", dir).put("who", who).put("bal", bal ?: JSONObject.NULL).put("reference", reference.find(t)?.groupValues?.getOrNull(1) ?: "").put("bankName", bank)
        return o
    }

    private fun findCurrencyAmount(s: String): Double? {
        val m1 = Regex("(?:etb|birr|br|rs|inr|usd|egp|kes|ngn|sar|aed|eur|gbp|[$€£₦₹])\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE).find(s)
        val m2 = Regex("([0-9][0-9,]*(?:\\.[0-9]+)?)\\s*(?:etb|birr|br|rs|inr|usd|egp|kes|ngn|sar|aed|eur|gbp|[$€£₦₹])", RegexOption.IGNORE_CASE).find(s)
        return (m1 ?: m2)?.groupValues?.getOrNull(1)?.replace(",", "")?.toDoubleOrNull()
    }

    private fun detectBank(t: String): String = bankNames.firstOrNull { t.lowercase(Locale.ROOT).contains(it.first) }?.second ?: ""
}
