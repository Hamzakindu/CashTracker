package com.example.cashtracker

/** Standalone CashTracker Calc: own launcher icon and task, same app data as CashTracker. */
class CalcActivity : MainActivity() {
    override val startPage = "calculator-home.html"
    override val isMain = false
}
