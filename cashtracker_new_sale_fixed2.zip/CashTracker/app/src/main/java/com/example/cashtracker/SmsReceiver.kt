package com.example.cashtracker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Persistent SMS queue. Native messages are only removed after JS explicitly acknowledges them. */
object Queue {
    private const val PREFS = "q"
    private const val KEY = "q"

    @Synchronized fun add(c: Context, item: JSONObject) {
        val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val a = JSONArray(p.getString(KEY, "[]"))
        val x = JSONObject(item.toString())
        if (!x.has("queueId")) x.put("queueId", UUID.randomUUID().toString())
        a.put(x)
        p.edit().putString(KEY, a.toString()).apply()
    }

    /** Peek only. Nothing is deleted here. */
    @Synchronized fun peek(c: Context): String {
        val p=c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old=JSONArray(p.getString(KEY,"[]")); var changed=false
        for(i in 0 until old.length()){
            val x=old.optJSONObject(i) ?: continue
            if(!x.has("queueId") || x.optString("queueId","").isBlank()){
                x.put("queueId", "legacy-"+UUID.randomUUID().toString()); changed=true
            }
        }
        if(changed) p.edit().putString(KEY,old.toString()).apply()
        return old.toString()
    }

    /** Delete only the queue entries explicitly acknowledged by JS after persistence. */
    @Synchronized fun ack(c: Context, ids: Set<String>): Int {
        if (ids.isEmpty()) return 0
        val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = JSONArray(p.getString(KEY, "[]"))
        val keep = JSONArray()
        var removed = 0
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i)
            val id = item?.optString("queueId", "") ?: ""
            if (id.isNotEmpty() && ids.contains(id)) removed++ else if (item != null) keep.put(item)
        }
        p.edit().putString(KEY, keep.toString()).apply()
        return removed
    }
}

class SmsReceiver : BroadcastReceiver() {
    // Keep likely bank messages. Non-bank SMS can still be retained if they look like a transaction.
    private val money = Regex(
        "debited|credited|spent|paid|received|withdrawn|purchase|deposit|balance|transferred|transfer|sent",
        RegexOption.IGNORE_CASE
    )

    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val m = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (m.isEmpty()) return
        val body = m.joinToString("") { it.messageBody ?: "" }
        if (!money.containsMatchIn(body)) return
        Queue.add(
            c,
            JSONObject()
                .put("body", body)
                .put("ts", m.minOfOrNull { it.timestampMillis } ?: System.currentTimeMillis())
                .put("from", m[0].originatingAddress ?: "")
        )
    }
}
