# CashTracker Cloudflare Sync

This Worker is a **separate backend from the existing Telegram bot Worker**. Do not replace the Telegram Worker with this one.

## 1. Create D1

```bash
npx wrangler d1 create cashtracker
```

Copy the returned `database_id` into `wrangler.toml`.

## 2. Apply schema

```bash
npx wrangler d1 execute cashtracker --remote --file=./schema.sql
```

## 3. Deploy

From `cloudflare/worker`:

```bash
npx wrangler deploy
```

The resulting `https://...workers.dev` URL is entered in CashTracker → Cloud.

## 4. Security model

- HTTPS is required by the app.
- Account passwords are verified using PBKDF2-SHA256 on the Worker.
- Sessions are random bearer tokens stored only for the active app session.
- CashTracker business data is encrypted in the app with AES-GCM before upload.
- Cloudflare D1 stores only encrypted store payloads, not readable business records.
- The Cloudflare Worker never needs the CashTracker encryption passphrase after login.

## 5. Telegram compatibility

The existing `BotSync` Telegram integration uses its own Worker URL and `X-Push-Key`. **Keep that Worker and its configuration unchanged.** This sync Worker is only for CashTracker multi-device cloud synchronization.
