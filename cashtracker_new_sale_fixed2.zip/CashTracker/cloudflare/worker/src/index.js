const ALLOWED_STORES = new Set([
  'products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger','expenseTypes','directExpenses','returns','calculations','stockHistory','auditLog','accountingMeta','cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','branches','staffUsers','branchAccessMeta'
]);
const MAX_CHUNK = 700000;
const SESSION_MS = 30 * 24 * 60 * 60 * 1000;
const PBKDF2_ITERATIONS = 120000;

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, OPTIONS',
    'Cache-Control': 'no-store'
  };
}
function json(data, status=200) {
  return new Response(JSON.stringify(data), { status, headers: { ...corsHeaders(), 'Content-Type':'application/json; charset=utf-8' } });
}
function bad(message, status=400){ return json({error:message},status); }
function b64(bytes){ let s=''; const a=new Uint8Array(bytes); for(let i=0;i<a.length;i+=0x8000)s+=String.fromCharCode(...a.subarray(i,i+0x8000)); return btoa(s); }
function unb64(s){ const raw=atob(s); const a=new Uint8Array(raw.length); for(let i=0;i<raw.length;i++)a[i]=raw.charCodeAt(i); return a; }
function randomId(bytes=32){ return b64(crypto.getRandomValues(new Uint8Array(bytes))).replace(/[^A-Za-z0-9_-]/g,''); }
async function digestHex(bytes){ const d=await crypto.subtle.digest('SHA-256',bytes); return [...new Uint8Array(d)].map(x=>x.toString(16).padStart(2,'0')).join(''); }
async function hashToken(token){ return digestHex(new TextEncoder().encode(token)); }
async function passwordHash(password,salt){
  const base=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),{name:'PBKDF2'},false,['deriveBits']);
  const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations:PBKDF2_ITERATIONS,hash:'SHA-256'},base,256);
  return new Uint8Array(bits);
}
async function verifyPassword(password,saltB64,hashB64){
  const actual=await passwordHash(password,unb64(saltB64));
  const expected=unb64(hashB64);
  if(actual.length!==expected.length)return false;
  let diff=0; for(let i=0;i<actual.length;i++)diff|=actual[i]^expected[i]; return diff===0;
}
function emailOf(v){ return String(v||'').trim().toLowerCase(); }
function profileOf(v){ const p=String(v||'default'); return p.length<=100 && /^[A-Za-z0-9._:-]+$/.test(p) ? p : null; }
function storeOf(v){ const s=String(v||''); return ALLOWED_STORES.has(s)?s:null; }
async function body(request){ try{return await request.json();}catch(e){throw new Error('Invalid JSON body.');} }
async function auth(request,env){
  const h=request.headers.get('Authorization')||''; if(!h.startsWith('Bearer '))return null;
  const token=h.slice(7).trim(); if(!token)return null;
  const hash=await hashToken(token); const now=Date.now();
  const row=await env.DB.prepare('SELECT user_id, expires_at FROM sessions WHERE token_hash=?').bind(hash).first();
  if(!row||Number(row.expires_at)<now)return null;
  return row.user_id;
}
async function newSession(env,userId){
  const token=randomId(32), hash=await hashToken(token), now=Date.now();
  await env.DB.prepare('INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)').bind(hash,userId,now+SESSION_MS,now).run();
  return token;
}

export default {
  async fetch(request, env) {
    if(request.method==='OPTIONS')return new Response(null,{status:204,headers:corsHeaders()});
    const u=new URL(request.url);
    try {
      if(u.pathname==='/api/health'&&request.method==='GET')return json({ok:true,service:'cashtracker-sync',time:new Date().toISOString()});
      if(u.pathname==='/api/register'&&request.method==='POST'){
        const b=await body(request), email=emailOf(b.email), password=String(b.password||'');
        if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email))return bad('Invalid email address.');
        if(password.length<8)return bad('Password must be at least 8 characters.');
        const exists=await env.DB.prepare('SELECT id FROM users WHERE email=?').bind(email).first();
        if(exists)return bad('An account already exists for this email.',409);
        const id=randomId(16), salt=crypto.getRandomValues(new Uint8Array(16));
        const hash=await passwordHash(password,salt); const now=Date.now();
        await env.DB.prepare('INSERT INTO users(id,email,password_salt,password_hash,created_at) VALUES(?,?,?,?,?)').bind(id,email,b64(salt),b64(hash),now).run();
        const token=await newSession(env,id); return json({ok:true,token,email});
      }
      if(u.pathname==='/api/login'&&request.method==='POST'){
        const b=await body(request), email=emailOf(b.email), password=String(b.password||'');
        const row=await env.DB.prepare('SELECT id,email,password_salt,password_hash FROM users WHERE email=?').bind(email).first();
        if(!row||!(await verifyPassword(password,row.password_salt,row.password_hash)))return bad('Email or password is incorrect.',401);
        const token=await newSession(env,row.id); return json({ok:true,token,email:row.email});
      }
      const userId=await auth(request,env);
      if(u.pathname==='/api/me'&&request.method==='GET')return userId?json({ok:true}):bad('Not signed in.',401);
      if(!userId)return bad('Not signed in.',401);
      if(u.pathname==='/api/logout'&&request.method==='POST'){
        const h=request.headers.get('Authorization')||'', token=h.slice(7).trim();
        if(token)await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await hashToken(token)).run();
        return json({ok:true});
      }
      const m=u.pathname.match(/^\/api\/stores\/([^/]+)\/([^/]+)$/);
      if(m){
        const profile=profileOf(decodeURIComponent(m[1])), store=storeOf(decodeURIComponent(m[2]));
        if(!profile||!store)return bad('Invalid profile or store.');
        if(request.method==='GET'){
          const rows=await env.DB.prepare('SELECT chunk_index,chunk_data,chunk_count,updated_at FROM stores WHERE user_id=? AND profile_id=? AND store_name=? ORDER BY chunk_index').bind(userId,profile,store).all();
          const result=rows.results||[]; if(!result.length)return json({exists:false});
          return json({exists:true,chunks:result.map(r=>r.chunk_data),chunkCount:Number(result[0].chunk_count||result.length),updatedAt:Number(result[0].updated_at||0)});
        }
        if(request.method==='PUT'){
          const b=await body(request), chunks=Array.isArray(b.chunks)?b.chunks:[];
          if(!chunks.length)return bad('No encrypted data supplied.');
          if(chunks.length>100)return bad('Encrypted store is too large. Export a local backup or split the store.');
          for(const c of chunks){if(typeof c!=='string'||c.length>MAX_CHUNK)return bad('Invalid encrypted chunk.');}
          const now=Date.now();
          const statements=[env.DB.prepare('DELETE FROM stores WHERE user_id=? AND profile_id=? AND store_name=?').bind(userId,profile,store)];
          chunks.forEach((chunk,i)=>statements.push(env.DB.prepare('INSERT INTO stores(user_id,profile_id,store_name,chunk_index,chunk_data,chunk_count,updated_at,device_id,app_version) VALUES(?,?,?,?,?,?,?,?,?)').bind(userId,profile,store,i,chunk,chunks.length,now,String(b.deviceId||''),String(b.appVersion||''))));
          await env.DB.batch(statements);
          return json({ok:true,store,chunkCount:chunks.length,updatedAt:now});
        }
      }
      return bad('Not found.',404);
    } catch(e){ console.error(e); return json({error:'Server error.'},500); }
  }
};
