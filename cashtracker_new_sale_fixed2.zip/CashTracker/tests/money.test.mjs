import test from 'node:test';
import assert from 'node:assert/strict';
globalThis.window = globalThis;
await import('../app/src/main/assets/js/utils/money.js');
const Money=globalThis.Money;
test('real money code uses integer minor units',()=>{assert.equal(Money.minor(12.345),1235);assert.equal(Money.major(1235),12.35)});
test('real money addition is integer-safe',()=>assert.equal(Money.add(0.1,0.2,0.3),0.6));
test('real money multiplication rounds to cents',()=>assert.equal(Money.mul(12.345,2),24.70));
