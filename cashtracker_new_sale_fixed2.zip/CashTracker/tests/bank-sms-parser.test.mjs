import test from 'node:test';
import assert from 'node:assert/strict';
globalThis.window = globalThis;
await import('../app/src/main/assets/js/utils/sms-parser.js');
const {parse} = globalThis.BankSmsParser;
test('real parser detects outgoing CBE sent/received wording',()=>{const p=parse('CBE: Amount debited 1,250 ETB. Sent to ABEBE, received by ABEBE');assert.equal(p.amount,1250);assert.equal(p.dir,'out');assert.equal(p.bankName,'CBE')});
test('real parser detects incoming credit',()=>assert.equal(parse('Amount credited: 850 ETB received from ABEBE').dir,'in'));
test('real parser uses labelled amount before balance',()=>assert.equal(parse('CBE Amount debited 1250 ETB. Current balance 99,999 ETB').amount,1250));
test('real parser identifies bank template',()=>assert.equal(parse('Telebirr: Amount received 500 ETB').bankName,'Telebirr'));
