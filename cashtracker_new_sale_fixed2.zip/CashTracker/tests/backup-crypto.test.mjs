import test from 'node:test';
import assert from 'node:assert/strict';
globalThis.window = globalThis;
await import('../app/src/main/assets/js/utils/backup-crypto.js');
test('backup crypto uses passphrase envelope and restores JSON', async()=>{
 const original={products:[{name:'A',price:12.34}],n:7};
 const encrypted=await BackupCrypto.encryptJson(original,'correct horse battery staple');
 const env=JSON.parse(encrypted);
 assert.equal(env.v,2); assert.equal(env.kdf,'PBKDF2-SHA256'); assert.equal(env.salt.length>0,true);
 assert.deepEqual(await BackupCrypto.decryptJson(encrypted,'correct horse battery staple'),original);
});
test('plain JSON is accepted by decryptJson compatibility path',async()=>{const x={products:[],sales:[]};assert.deepEqual(await BackupCrypto.decryptJson(JSON.stringify(x),'unused-passphrase'),x)});
