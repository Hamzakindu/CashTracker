import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

// Regression test: buttons use data-cashtracker-onclick / onchange / oninput.
// A bug in csp-events.js once made every one of them do nothing.
const file = process.env.CSP_EVENTS_FILE || new URL('../app/src/main/assets/js/csp-events.js', import.meta.url);
const source = fs.readFileSync(file, 'utf8');

function load() {
  const listeners = {};
  const calls = [];
  const sandbox = {
    document: { addEventListener: (type, fn) => { listeners[type] = fn; } },
    Demo: { click: () => calls.push('click'), change: () => calls.push('change'), input: () => calls.push('input') },
    console
  };
  sandbox.window = sandbox;
  vm.runInNewContext(source, sandbox);
  const fire = (type, attr, code) => {
    const el = { getAttribute: (n) => (n === attr ? code : null), value: 'x' };
    listeners[type]({ target: { closest: () => el }, stopPropagation() {}, preventDefault() {} });
  };
  return { fire, calls };
}

test('click handlers run', () => {
  const { fire, calls } = load();
  fire('click', 'data-cashtracker-onclick', 'Demo.click()');
  assert.deepEqual(calls, ['click']);
});

test('change handlers run', () => {
  const { fire, calls } = load();
  fire('change', 'data-cashtracker-onchange', 'Demo.change()');
  assert.deepEqual(calls, ['change']);
});

test('input handlers run', () => {
  const { fire, calls } = load();
  fire('input', 'data-cashtracker-oninput', 'Demo.input()');
  assert.deepEqual(calls, ['input']);
});
