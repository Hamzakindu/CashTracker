import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(process.cwd(), 'app/src/main/assets/js');
const sales = fs.readFileSync(path.join(root, 'modules/sales.js'), 'utf8');
const storage = fs.readFileSync(path.join(root, 'utils/storage.js'), 'utf8');
const idb = fs.readFileSync(path.join(root, 'utils/indexeddb-storage.js'), 'utf8');

 test('new sale starts fresh and carries only the previous sale date', () => {
  assert.match(sales, /EntryDrafts\.clear\('sellModal'\)/);
  assert.match(sales, /const previousSale = \(State\.sales \|\| \[\]\)/);
  assert.match(sales, /previousSale\?\.date/);
  assert.doesNotMatch(sales, /if\(!calcItems\?\.length && !bankContext && window\.EntryMemory\) EntryMemory\.apply\('sale'\)/);
  assert.doesNotMatch(sales, /Same as last time/);
});

test('sale save waits for the durable mirror and verifies persistence', () => {
  assert.match(sales, /async submit\(\)/);
  assert.match(sales, /await StorageIDB\.flush\(\)/);
  assert.match(sales, /persistedSales\.some\(s => s && s\.id === saleId\)/);
});

test('localStorage is the authoritative synchronous recovery copy', () => {
  assert.match(storage, /localStorage\.setItem\(key, raw\)/);
  assert.match(storage, /const raw=localStorage\.getItem\(key\)/);
});

test('IndexedDB writes and deletes are serialized and can be flushed', () => {
  assert.match(idb, /let writeQueue=Promise\.resolve\(\)/);
  assert.match(idb, /writeQueue=job\.catch\(\(\)=>\{\}\)/);
  assert.match(idb, /async function flush\(\)/);
});

 test('State save propagates storage failure instead of silently reporting success', () => {
  const state = fs.readFileSync(path.join(root, 'state.js'), 'utf8');
  assert.match(state, /return Storage\.save\(storeName, this\[storeName\]\) === true/);
  assert.match(state, /if \(!this\.save\(store\)\) throw new Error\('Could not persist store: ' \+ store\)/);
});

test('durable atomic helper commits localStorage then waits for the IndexedDB mirror', () => {
  const state = fs.readFileSync(path.join(root, 'state.js'), 'utf8');
  assert.match(state, /async runAtomicDurable\(action, fn\)/);
  assert.match(state, /this\.saveAll\(\);\s*if \(window\.StorageIDB\?\.flush\) await StorageIDB\.flush\(\);/);
  assert.match(state, /Durable atomic operation failed/);
});
