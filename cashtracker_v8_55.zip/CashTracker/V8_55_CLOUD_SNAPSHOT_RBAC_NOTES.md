# V8.55 — cloud snapshot workspace-role verification

Version: 5.10.98 / Android versionCode 5122.

Extended deterministic tests against the actual Cloudflare Worker snapshot route. Added route-level coverage proving: (1) accountant can read a whole-workspace snapshot but cannot publish; (2) viewer cannot read or publish; and (3) a branch-scoped cashier cannot access whole-workspace snapshots. Existing two-device compare-and-swap race coverage is retained.

The tests use an in-memory D1 adapter and do not certify live Cloudflare D1, deployed authentication, real network conditions, APK compilation/signing, or physical devices.
