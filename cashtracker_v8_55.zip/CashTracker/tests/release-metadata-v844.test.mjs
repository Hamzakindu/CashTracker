import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const read = (p) => fs.readFileSync(new URL(p, import.meta.url), 'utf8');
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const json = (p) => JSON.parse(fs.readFileSync(path.join(root, p), 'utf8'));

test('V8.55 release metadata is aligned and safely upgrades the 5122 baseline', () => {
  const pkg = json('package.json');
  const appmint = json('app/src/main/assets/appmint.json');
  const manifest = json('app/src/main/assets/manifest.json');
  const props = read('../gradle.properties');
  const gradle = read('../app/build.gradle.kts');
  const config = read('../app/src/main/assets/js/config.js');

  assert.equal(pkg.version, '5.10.98');
  assert.match(props, /^VERSION_NAME=5\.10\.98$/m);
  assert.match(props, /^VERSION_CODE=5122$/m);
  assert.match(gradle, /orElse\("5122"\)/);
  assert.match(gradle, /applicationId = "com\.stockpro\.banksms"/);
  assert.equal(appmint.appId, 'com.stockpro.banksms');
  assert.equal(appmint.version, pkg.version);
  assert.equal(appmint.versionName, pkg.version);
  assert.equal(appmint.versionCode, 5122);
  assert.equal(manifest.version, pkg.version);
  assert.match(config, /VERSION: '5\.10\.98'/);
  assert.ok(appmint.versionCode > 5111, 'new APK must be installable as an upgrade over the historical 5111 build');
});

test('GitHub Actions rejects version-code regression and metadata mismatch before APK build', () => {
  const workflow = read('../.github/workflows/build.yml');
  assert.match(workflow, /BASE_VERSION_CODE >= 5122/);
  assert.match(workflow, /App\/package\/PWA version metadata is inconsistent/);
  assert.match(workflow, /applicationId = \\\"com\.stockpro\.banksms\\\"/);
});
