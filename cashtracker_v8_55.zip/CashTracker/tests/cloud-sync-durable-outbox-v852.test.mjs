import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const root=new URL('../',import.meta.url).pathname;
const client=fs.readFileSync(root+'app/src/main/assets/js/cloudflare-backend.js','utf8');

test('cloud sync persists a versioned per-profile outbox before scheduling upload',()=>{
 assert.match(client,/queueJournalKey\(\)[\s\S]*cashtracker_cloud_sync_outbox_v1_/);
 assert.match(client,/persistDurableQueue\(extra=\{\}\)[\s\S]*localStorage\.setItem\(key,JSON\.stringify\(journal\)\)/);
 assert.match(client,/queueStore\(name\)[\s\S]*this\.persistDurableQueue\(\)[\s\S]*this\.scheduleFlush\(2500\)/);
});
test('cloud sync restores queued store names after app restart and validates allowed stores',()=>{
 assert.match(client,/restoreDurableQueue\(\)[\s\S]*journal\.stores[\s\S]*STORE_NAMES\.includes\(name\)/);
 assert.match(client,/this\.patchStorage\(\); this\.restoreDurableQueue\(\)/);
 assert.match(client,/this\.queue\.size\)this\.scheduleFlush\(0\)/);
});
test('cloud sync retry uses persisted exponential backoff and retains outbox on failure',()=>{
 assert.match(client,/attempt=Math\.min\(12/);
 assert.match(client,/Math\.min\(900000,5000\*Math\.pow\(2/);
 assert.match(client,/nextAttemptAt:Date\.now\(\)\+delay/);
 assert.match(client,/retry scheduled/);
});
test('successful upload clears durable outbox only when no newer local change arrived',()=>{
 assert.match(client,/if\(this\.changeSeq===sequenceAtCapture\)[\s\S]*localStorage\.removeItem\(this\.queueJournalKey\(\)\)/);
 assert.match(client,/else this\.persistDurableQueue\(\{attempt:0,nextAttemptAt:0,lastError:''\}\)/);
});
test('cloud revision conflicts remain blocked and do not trigger automatic retry',()=>{
 assert.match(client,/this\.syncBlocked=true;this\.setStatus\('⚠️ Cloud conflict: another device has newer data\.'/);
 assert.match(client,/if\(this\.ready&&!this\.syncBlocked&&this\.queue\.size\)/);
});
