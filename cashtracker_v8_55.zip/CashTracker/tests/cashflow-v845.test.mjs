import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

function loadStatements(movements=[]) {
  const window={};
  const context={window,State:{moneyTransactions:movements},Helpers:{esc:x=>String(x),formatCurrency:n=>Number(n||0).toFixed(2),getToday:()=> '2026-11-13'},Toast:{warning(){}}};
  vm.runInNewContext(fs.readFileSync(new URL('../app/src/main/assets/js/modules/statements.js',import.meta.url),'utf8'),context);
  window.Statements._testState=context.State;
  return window.Statements;
}

test('V8.45 cash flow counts only recognized posted movements and excludes transfers/opening balances',()=>{
  const s=loadStatements([
    {id:'1',date:'2026-11-01',type:'in',amount:100,sourceType:'sale',status:'posted'},
    {id:'2',date:'2026-11-02',type:'out',amount:30,sourceType:'expense',status:'posted'},
    {id:'3',date:'2026-11-02',type:'transfer_out',amount:20,sourceType:'transfer',status:'posted'},
    {id:'4',date:'2026-11-02',type:'transfer_in',amount:20,sourceType:'transfer',status:'posted'},
    {id:'5',date:'2026-11-01',type:'opening',amount:500,sourceType:'opening',status:'posted'},
    {id:'6',date:'2026-11-02',type:'out',amount:999,sourceType:'expense',status:'void'}
  ]);
  const r=s._cashFlowData('2026-11-01','2026-11-30', [
    {id:'1',date:'2026-11-01',type:'in',amount:100,sourceType:'sale',status:'posted'},
    {id:'2',date:'2026-11-02',type:'out',amount:30,sourceType:'expense',status:'posted'},
    {id:'3',date:'2026-11-02',type:'transfer_out',amount:20,sourceType:'transfer',status:'posted'},
    {id:'4',date:'2026-11-02',type:'transfer_in',amount:20,sourceType:'transfer',status:'posted'},
    {id:'5',date:'2026-11-01',type:'opening',amount:500,sourceType:'opening',status:'posted'},
    {id:'6',date:'2026-11-02',type:'out',amount:999,sourceType:'expense',status:'void'}
  ]);
  assert.equal(r.totalIn,100); assert.equal(r.totalOut,30); assert.equal(r.net,70);
  assert.equal(r.excludedTransfers,2); assert.equal(r.rows.length,2);
});

test('V8.45 cash flow never guesses unknown movement types as money out',()=>{
  const s=loadStatements([{id:'x',date:'2026-11-03',type:'mystery',amount:75,sourceType:'manual',status:'posted'}]);
  const r=s._cashFlowData('2026-11-01','2026-11-30',[{id:'x',date:'2026-11-03',type:'mystery',amount:75,sourceType:'manual',status:'posted'}]);
  assert.equal(r.totalIn,0); assert.equal(r.totalOut,0); assert.equal(r.issues.unknownType,1);
  s._testState.moneyTransactions=[{id:'x',date:'2026-11-03',type:'mystery',amount:75,sourceType:'manual',status:'posted'}];
  assert.match(s._cashFlowHtml('2026-11-01','2026-11-30'),/excluded from this statement/);
});

test('V8.45 cash flow excludes invalid amounts and dates and rejects reversed ranges',()=>{
  const s=loadStatements([
    {date:'2026-11-03',type:'in',amount:0,status:'posted'},
    {date:'bad-date',type:'out',amount:10,status:'posted'}
  ]);
  const r=s._cashFlowData('2026-11-01','2026-11-30',[{date:'2026-11-03',type:'in',amount:0,status:'posted'},{date:'bad-date',type:'out',amount:10,status:'posted'}]);
  assert.equal(r.issues.invalidAmount,1); assert.equal(r.issues.invalidDate,1);
  s._testState.moneyTransactions=[];
  assert.equal(s._cashFlowData('2026-11-30','2026-11-01',[]).valid,false);
  assert.match(s._cashFlowHtml('2026-11-30','2026-11-01'),/start date must not be after/);
});

test('V8.45 cash flow groups sale and purchase settlement movements without double-reading payment ledger',()=>{
  const s=loadStatements([
    {date:'2026-11-01',type:'in',amount:40,sourceType:'sale_payment',status:'posted'},
    {date:'2026-11-01',type:'out',amount:15,sourceType:'purchase_payment',status:'posted'},
    {date:'2026-11-01',type:'in',amount:10,sourceType:'payment',status:'posted'}
  ]);
  const r=s._cashFlowData('2026-11-01','2026-11-01',[{date:'2026-11-01',type:'in',amount:40,sourceType:'sale_payment',status:'posted'},{date:'2026-11-01',type:'out',amount:15,sourceType:'purchase_payment',status:'posted'},{date:'2026-11-01',type:'in',amount:10,sourceType:'payment',status:'posted'}]);
  assert.deepEqual(Array.from(r.rows.map(x=>x.source)).sort(),['Customer / supplier payments','Purchases','Sales'].sort());
  assert.equal(r.totalIn,50); assert.equal(r.totalOut,15);
});

test('V8.45 cash flow screen offers CSV export using the same filtered calculation',()=>{
  const src=fs.readFileSync(new URL('../app/src/main/assets/js/modules/statements.js',import.meta.url),'utf8');
  assert.match(src,/Statements\.exportCashFlow\(\)/);
  assert.match(src,/cashtracker-cash-flow\.csv/);
});


test('V8.45 distinguishes supplier refunds from customer refunds and reports People Money',()=>{
  const s=loadStatements();
  const r=s._cashFlowData('2026-11-01','2026-11-30',[
    {date:'2026-11-01',type:'in',amount:25,sourceType:'return',status:'posted',note:'Supplier refund'},
    {date:'2026-11-02',type:'out',amount:10,sourceType:'return',status:'posted',note:'Customer refund'},
    {date:'2026-11-03',type:'in',amount:5,sourceType:'people_money',status:'posted'}
  ]);
  assert.equal(r.rows.find(x=>x.source==='Supplier refunds').in,25);
  assert.equal(r.rows.find(x=>x.source==='Customer refunds').out,10);
  assert.equal(r.rows.find(x=>x.source==='People Money').in,5);
});
