import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(new URL('../app/src/main/assets/js/cloudflare-backend.js',import.meta.url),'utf8');
function boot(seed={}){
 const data=new Map(Object.entries(seed));
 const store={getItem:k=>data.has(k)?data.get(k):null,setItem:(k,v)=>data.set(k,String(v)),removeItem:k=>data.delete(k)};
 const listeners={};
 const window={addEventListener:(n,fn)=>listeners[n]=fn};
 const document={addEventListener:()=>{},getElementById:()=>null};
 const context={window,document,localStorage:store,sessionStorage:store,console:{error(){},warn(){}},URL,Date,Math,JSON,Set,Map,Array,Object,Number,String,Promise,Error,fetch:async()=>{throw Error('offline')},setTimeout:()=>1,clearTimeout:()=>{},Toast:{error(){},success(){},info(){}},State:{currentProfileId:'p1'},Storage:{},BackupCrypto:{},CONFIG:{VERSION:'5.10.96'},confirm:()=>true,prompt:()=>''};
 vm.runInNewContext(source,context);
 return {cloud:window.CloudSync,store,data,context};
}
test('runtime harness restores only valid stores from a persisted outbox after restart',()=>{
 const key='cashtracker_cloud_sync_outbox_v1_p1';
 const {cloud}=boot({[key]:JSON.stringify({version:1,profileId:'p1',stores:['sales','bogus','products'],attempt:2,nextAttemptAt:0})});
 assert.equal(cloud.restoreDurableQueue(),true);
 assert.deepEqual([...cloud.queue].sort(),['products','sales']);
});
test('runtime harness persists queued changes before any upload can run',()=>{
 const {cloud,store}=boot(); cloud.scheduleFlush=()=>{}; cloud.queueStore('purchases');
 const j=JSON.parse(store.getItem(cloud.queueJournalKey()));
 assert.deepEqual(j.stores,['purchases']); assert.equal(j.profileId,'p1');
 assert.equal(store.getItem('cashtracker_cloud_sync_pending_p1'),'1');
});
test('runtime harness keeps outbox and increments bounded retry after transient failure',async()=>{
 const {cloud,store}=boot(); cloud.ready=true; cloud.queue.add('sales'); cloud.persistDurableQueue();
 cloud.uploadSnapshot=async()=>{throw Error('network offline')}; cloud.scheduleFlush=()=>{};
 await cloud.flushQueue(); const j=JSON.parse(store.getItem(cloud.queueJournalKey()));
 assert.equal(j.attempt,1); assert.match(j.lastError,/offline/); assert.ok(j.nextAttemptAt>Date.now());
 assert.equal(cloud.queue.has('sales'),true);
});
test('runtime harness blocks revision conflicts without treating them as transient retries',async()=>{
 const {cloud,store}=boot(); cloud.ready=true; cloud.queue.add('sales'); cloud.persistDurableQueue();
 cloud.uploadSnapshot=async()=>{throw Error('revision changed on another device')}; cloud.scheduleFlush=()=>{};
 await cloud.flushQueue(); const j=JSON.parse(store.getItem(cloud.queueJournalKey()));
 assert.equal(cloud.syncBlocked,true); assert.equal(j.attempt,0); assert.match(j.lastError,/revision/);
});
test('runtime harness retains newer local changes that arrive during a successful upload',async()=>{
 const {cloud,store}=boot(); cloud.ready=true; cloud.queue.add('sales'); cloud.changeSeq=1; cloud.persistDurableQueue();
 cloud.uploadSnapshot=async()=>{cloud.changeSeq++; cloud.queue.add('products'); return {revision:2}}; cloud.scheduleFlush=()=>{};
 await cloud.flushQueue();
 assert.equal(cloud.queue.has('products'),true);
 assert.ok(store.getItem(cloud.queueJournalKey()));
});
