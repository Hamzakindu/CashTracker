import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(new URL('../app/src/main/assets/js/modules/transaction-integrity.js',import.meta.url),'utf8');
function audit(data){const ctx={globalThis:{},Date};vm.runInNewContext(source,ctx);return ctx.globalThis.TransactionIntegrity.audit(data);}
test('integrity audit accepts fully reconciled sale and purchase',()=>{
 const r=audit({sales:[{id:'s1',paymentReceived:50}],purchases:[{id:'p1',paid:30}],paymentLedger:[{id:'l1',sourceId:'s1',sourceType:'sale',amount:50},{id:'l2',sourceId:'p1',sourceType:'purchase',amount:30}],moneyTransactions:[{id:'m1',sourceId:'s1',sourceType:'sale_payment',amount:50},{id:'m2',sourceId:'p1',sourceType:'purchase_payment',amount:30}]});
 assert.equal(r.ok,true);assert.equal(r.findings.length,0);assert.equal(r.sourcesChecked,2);
});
test('integrity audit identifies missing and mismatched payment/account movements',()=>{
 const r=audit({sales:[{id:'s1',paymentReceived:80}],paymentLedger:[{id:'l1',sourceId:'s1',sourceType:'sale',amount:70}],moneyTransactions:[{id:'m1',sourceId:'s1',sourceType:'sale_payment',amount:60}]});
 assert.deepEqual(Array.from(r.findings,x=>x.code).sort(),['ACCOUNT_MOVEMENT_MISMATCH','PAYMENT_TOTAL_MISMATCH']);
});
test('integrity audit identifies orphaned payments and duplicate IDs, excluding void transactions',()=>{
 const r=audit({sales:[{id:'s1',status:'void'},{id:'s2',paymentReceived:0},{id:'s2',paymentReceived:0}],paymentLedger:[{id:'l1',sourceId:'gone',sourceType:'sale',amount:5},{id:'l1',sourceId:'s2',sourceType:'sale',amount:5}]});
 assert.ok(r.findings.some(x=>x.code==='ORPHAN_PAYMENT'));
 assert.ok(r.findings.some(x=>x.code==='DUPLICATE_RECORD_ID'&&x.store==='sales'));
 assert.ok(r.findings.some(x=>x.code==='DUPLICATE_RECORD_ID'&&x.store==='paymentLedger'));
});
test('integrity audit is read-only',()=>{const data={sales:[{id:'s1',paymentReceived:5}]};const before=JSON.stringify(data);audit(data);assert.equal(JSON.stringify(data),before);});
