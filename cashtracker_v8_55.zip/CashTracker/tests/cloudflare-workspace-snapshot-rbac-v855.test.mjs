import test from 'node:test';
import assert from 'node:assert/strict';
import {webcrypto,createHash} from 'node:crypto';
import worker from '../cloudflare/worker/src/index.js';

globalThis.crypto ||= webcrypto;
function tokenHash(token){return createHash('sha256').update(token).digest('hex');}
function memoryD1(){
 const sessions=new Map(),members=new Map(),snapshots=new Map(),chunks=new Map(),heads=new Map();let batchTail=Promise.resolve();
 const db={
  prepare(sql){let values=[];return {bind(...v){values=v;return this;},async first(){
   if(sql.includes('SELECT user_id, expires_at FROM sessions'))return sessions.get(values[0])||null;
   if(sql.includes('SELECT user_id,workspace_owner_id,role,branch_ids,active FROM workspace_members'))return members.get(values[0]+'|'+values[1])||null;
   if(sql.includes('SELECT h.revision,h.snapshot_id,h.updated_at,s.chunk_count,s.device_id,s.app_version')){const h=heads.get(values[0]+'|'+values[1]);if(!h)return null;const s=snapshots.get(h.snapshot_id);return s?{...h,...s}:null;}
   if(sql.includes('SELECT revision FROM cloud_snapshot_heads'))return heads.get(values[0]+'|'+values[1])||null;
   return null;
  },async all(){
   if(sql.includes('SELECT chunk_index,chunk_data FROM cloud_snapshot_chunks'))return {results:(chunks.get(values[0])||[]).map((chunk_data,chunk_index)=>({chunk_index,chunk_data}))};
   if(sql.includes('SELECT snapshot_id FROM cloud_snapshots'))return {results:[]};
   return {results:[]};
  },async run(){return execute(sql,values);}};},
  async batch(stmts){let release;const prior=batchTail;batchTail=new Promise(r=>release=r);await prior;try{const out=[];for(const s of stmts)out.push(await s.run());return out;}finally{release();}}
 };
 function execute(sql,v){
  if(sql.includes('INSERT INTO cloud_snapshots(')){snapshots.set(v[0],{user_id:v[1],profile_id:v[2],revision:v[3],device_id:v[4],app_version:v[5],created_at:v[6],chunk_count:v[7]});return {meta:{changes:1}};}
  if(sql.includes('INSERT INTO cloud_snapshot_chunks')){const a=chunks.get(v[0])||[];a[v[1]]=v[2];chunks.set(v[0],a);return {meta:{changes:1}};}
  if(sql.includes('INSERT INTO cloud_snapshot_heads')){const k=v[0]+'|'+v[1],old=heads.get(k);if((old?.revision||0)===v[5]){heads.set(k,{user_id:v[0],profile_id:v[1],revision:v[2],snapshot_id:v[3],updated_at:v[4]});return {meta:{changes:1}};}return {meta:{changes:0}};}
  if(sql.includes('DELETE FROM cloud_snapshot_chunks')){chunks.delete(v[0]);return {meta:{changes:1}};}
  if(sql.includes('DELETE FROM cloud_snapshots')){snapshots.delete(v[0]);return {meta:{changes:1}};}
  return {meta:{changes:1}};
 }
 db.seed=(profile,user,token,role='owner',branchIds='*')=>{sessions.set(tokenHash(token),{user_id:user,expires_at:Date.now()+3600000});members.set(profile+'|'+user,{user_id:user,workspace_owner_id:user,role,branch_ids:branchIds,active:1});};return db;
}
const req=(token,method='GET',body)=>new Request('https://worker.test/api/snapshots/shop',{method,headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});
test('real Worker snapshot endpoint allows only one of two stale concurrent device writes',async()=>{
 const DB=memoryD1();DB.seed('shop','owner','device-A');const env={DB};
 const first=await worker.fetch(req('device-A','PUT',{expectedRevision:0,chunks:['encrypted-A'],deviceId:'A',appVersion:'5.10.98'}),env);
 const firstBody=await first.json();assert.equal(first.status,200,JSON.stringify(firstBody));assert.equal(firstBody.revision,1);
 const [a,b]=await Promise.all([
  worker.fetch(req('device-A','PUT',{expectedRevision:1,chunks:['encrypted-B'],deviceId:'A',appVersion:'5.10.98'}),env),
  worker.fetch(req('device-A','PUT',{expectedRevision:1,chunks:['encrypted-C'],deviceId:'B',appVersion:'5.10.98'}),env)
 ]);
 const statuses=[a.status,b.status].sort();assert.deepEqual(statuses,[200,409]);
 const conflict= a.status===409?await a.json():await b.json();assert.equal(conflict.conflict,true);assert.equal(conflict.currentRevision,2);
 const head=await worker.fetch(req('device-A'),env);const saved=await head.json();assert.equal(saved.revision,2);assert.equal(saved.chunks.length,1);assert.ok(['encrypted-B','encrypted-C'].includes(saved.chunks[0]));
});


test('snapshot endpoint enforces read-only workspace roles on real Worker route',async()=>{
 const DB=memoryD1();DB.seed('shop','accountant','acct-token','accountant');DB.seed('shop','viewer','viewer-token','viewer');const env={DB};
 const read=await worker.fetch(req('acct-token'),env);assert.equal(read.status,200);assert.equal((await read.json()).exists,false);
 const accountantWrite=await worker.fetch(req('acct-token','PUT',{expectedRevision:0,chunks:['cipher']}),env);assert.equal(accountantWrite.status,403);
 const viewerRead=await worker.fetch(req('viewer-token'),env);assert.equal(viewerRead.status,403);
 const viewerWrite=await worker.fetch(req('viewer-token','PUT',{expectedRevision:0,chunks:['cipher']}),env);assert.equal(viewerWrite.status,403);
});

test('branch-scoped workspace member cannot access whole-workspace snapshots',async()=>{
 const DB=memoryD1();DB.seed('shop','cashier','cashier-token','cashier','["branch-1"]');const env={DB};
 const read=await worker.fetch(req('cashier-token'),env);assert.equal(read.status,403);
 const write=await worker.fetch(req('cashier-token','PUT',{expectedRevision:0,chunks:['cipher']}),env);assert.equal(write.status,403);
});
