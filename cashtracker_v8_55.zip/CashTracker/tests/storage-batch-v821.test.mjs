import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const source = readFileSync(new URL('../app/src/main/assets/js/utils/storage.js', import.meta.url), 'utf8');
function harness({ failKey = null, silentKey = null, corruptKey = null } = {}) {
  const data = new Map([['currentProfileId', 'shop-a'], ['SMDB_shop-a_products', '[{"id":"old"}]']]);
  const localStorage = {
    getItem: k => data.has(k) ? data.get(k) : null,
    setItem(k, v) { if (k === failKey) throw new Error('simulated quota failure'); if (k === silentKey) return; data.set(k, k === corruptKey ? String(v) + ' ' : String(v)); },
    removeItem: k => data.delete(k),
    get length() { return data.size; },
    key(i) { return [...data.keys()][i] ?? null; }
  };
  const window = { Money: null, StorageIDB: { putMany: async () => true, checkAndWarn: async () => true } };
  vm.runInNewContext(source, { window, localStorage, console, Toast: null, JSON, Date, Object, String, Error });
  return { Storage: window.Storage, data };
}

test('multi-store save commits every local store and queues one IndexedDB batch', () => {
  const { Storage, data } = harness();
  assert.equal(Storage.saveBatch({ products: [{ id: 'p1' }], sales: [{ id: 's1' }] }), true);
  assert.deepEqual(JSON.parse(data.get('SMDB_shop-a_products')), [{ id: 'p1' }]);
  assert.deepEqual(JSON.parse(data.get('SMDB_shop-a_sales')), [{ id: 's1' }]);
});

test('multi-store save rolls back earlier local writes when a later write fails', () => {
  const { Storage, data } = harness({ failKey: 'SMDB_shop-a_sales' });
  const before = data.get('SMDB_shop-a_products');
  assert.equal(Storage.saveBatch({ products: [{ id: 'new' }], sales: [{ id: 's1' }] }), false);
  assert.equal(data.get('SMDB_shop-a_products'), before);
  assert.equal(data.has('SMDB_shop-a_sales'), false);
});

test('batch serialization rejects oversized stores before changing any persisted value', () => {
  const { Storage, data } = harness();
  const before = data.get('SMDB_shop-a_products');
  const oversized = 'x'.repeat(4 * 1024 * 1024 + 1);
  assert.equal(Storage.saveBatch({ products: [{ id: 'new' }], sales: oversized }), false);
  assert.equal(data.get('SMDB_shop-a_products'), before);
});


test('multi-store save rejects a silent localStorage write and restores prior stores', () => {
  const { Storage, data } = harness({ silentKey: 'SMDB_shop-a_sales' });
  const before = data.get('SMDB_shop-a_products');
  assert.equal(Storage.saveBatch({ products: [{ id: 'new' }], sales: [{ id: 's1' }] }), false);
  assert.equal(data.get('SMDB_shop-a_products'), before);
  assert.equal(data.has('SMDB_shop-a_sales'), false);
});

test('multi-store save rejects a corrupted read-back and restores prior stores', () => {
  const { Storage, data } = harness({ corruptKey: 'SMDB_shop-a_sales' });
  const before = data.get('SMDB_shop-a_products');
  assert.equal(Storage.saveBatch({ products: [{ id: 'new' }], sales: [{ id: 's1' }] }), false);
  assert.equal(data.get('SMDB_shop-a_products'), before);
  assert.equal(data.has('SMDB_shop-a_sales'), false);
});
