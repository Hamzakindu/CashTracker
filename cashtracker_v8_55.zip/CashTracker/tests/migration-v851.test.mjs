import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const source = readFileSync(new URL('../app/src/main/assets/js/backup.js', import.meta.url), 'utf8');
const fixture = JSON.parse(readFileSync(new URL('./fixtures/v7-shaped-anonymized-backup.json', import.meta.url), 'utf8'));
function makeBackup() {
  const context = {
    console,
    State: { currentProfileId: 'fixture-shop', sales: [], purchases: [], directExpenses: [], returns: [], paymentLedger: [], moneyTransactions: [], peopleMoneyTx: [], stockHistory: [] },
    Storage: { getSetting() { return 'false'; } },
    window: { addEventListener() {} },
    setTimeout() {}
  };
  vm.runInNewContext(source + '\n;globalThis.__BackupForTest = Backup;', context);
  return context.__BackupForTest;
}

test('synthetic anonymized V7-shaped fixture is accepted as a complete legacy core backup', () => {
  const backup = makeBackup();
  assert.equal(backup.validateBackupData(structuredClone(fixture)), true);
});

test('migration report identifies legacy schema, omitted stores and compatibility rows without mutating fixture', () => {
  const backup = makeBackup();
  const original = JSON.stringify(fixture);
  const report = backup.getMigrationReport(fixture);
  assert.equal(report.sourceSchemaVersion, 1);
  assert.equal(report.sourceLabel, 'legacy schema v1');
  assert.equal(report.legacySaleRows, 1);
  assert.ok(report.missingStoreCount > 0);
  assert.ok(report.missingStores.includes('paymentLedger'));
  assert.equal(JSON.stringify(fixture), original);
});

test('legacy sale aliases are normalized losslessly on a cloned restore payload', () => {
  const backup = makeBackup();
  const original = fixture.sales[0];
  const prepared = backup.prepareRestorePayload({ sales: fixture.sales, branches: fixture.branches });
  assert.equal(prepared.sales[0].paid, 100);
  assert.deepEqual(JSON.parse(JSON.stringify(prepared.sales[0].lines)), JSON.parse(JSON.stringify(original.items)));
  assert.equal(original.paid, undefined);
  assert.equal(original.lines, undefined);
  assert.equal(prepared.sales[0].notes, 'synthetic fixture');
});

test('legacy meta-store array shapes are normalized safely', () => {
  const backup = makeBackup();
  const prepared = backup.prepareRestorePayload({ sales: [], branchAccessMeta: [], accountingMeta: [] });
  assert.deepEqual(JSON.parse(JSON.stringify(prepared.branchAccessMeta)), { version: 1, activeBranchId: 'main', currentStaffId: '' });
  assert.equal(Object.hasOwn(prepared, 'accountingMeta'), false);
});

test('partial backups missing a primary collection are rejected before restore', () => {
  const backup = makeBackup();
  const partial = { products: [], sales: [], purchases: [], customers: [] };
  assert.equal(backup.validateBackupData(partial), false);
});


test('restore preview displays migration findings before the first overwrite confirmation', () => {
  assert.match(source, /const migration = this\.getMigrationReport\(data\)/);
  assert.match(source, /MIGRATION ANALYSIS:/);
  assert.match(source, /MIGRATION WARNING:/);
  assert.ok(source.indexOf('MIGRATION ANALYSIS:') < source.indexOf('BACKUP PREVIEW — REVIEW BEFORE RESTORE'));
});
