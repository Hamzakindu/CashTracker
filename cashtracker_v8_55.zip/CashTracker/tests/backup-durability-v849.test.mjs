import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const source = readFileSync(new URL('../app/src/main/assets/js/backup.js', import.meta.url), 'utf8');

test('both backup export paths include branch stock opening balances', () => {
  assert.equal((source.match(/branchStockOpening: State\.branchStockOpening \|\| \[\]/g) || []).length, 2);
});

test('file and cloud restore share the durable batch commit path', () => {
  assert.match(source, /await this\.persistRestoreStores\(prepared, stores, before\)/);
  assert.match(source, /Storage\.saveBatch\(prepared\)/);
  assert.match(source, /Restore read-back verification failed for/);
  assert.match(source, /await StorageIDB\.flush\(\)/);
});

test('restore batch verifies writes and rolls back the local authoritative store on failure', async () => {
  const values = new Map([['SMDB_shop_products', JSON.stringify([{ id: 'old' }])]]);
  const localStorage = {
    getItem: k => values.has(k) ? values.get(k) : null,
    setItem: (k, v) => values.set(k, String(v)),
    removeItem: k => values.delete(k)
  };
  let flushCount = 0;
  const window = {
    Money: { encode: x => x },
    StorageIDB: {
      async flush() { flushCount++; if (flushCount === 1) throw new Error('mirror failed'); return { ok: true }; },
      async putMany() {}, async remove() {}
    },
    addEventListener() {}
  };
  const Storage = {
    getKey: name => 'SMDB_shop_' + name,
    saveBatch(batch) { for (const [name, value] of Object.entries(batch)) localStorage.setItem(this.getKey(name), JSON.stringify(value)); return true; }
  };
  const context = { window, Money: window.Money, StorageIDB: window.StorageIDB, Storage, localStorage, console, setTimeout, clearTimeout, Date, JSON, Object, Array, String, Number, Math, Promise };
  vm.runInNewContext(source + '\n;globalThis.__BackupForTest = Backup;', context);
  const backup = context.__BackupForTest;
  const before = { products: localStorage.getItem('SMDB_shop_products') };
  await assert.rejects(() => backup.persistRestoreStores({ products: [{ id: 'new' }] }, ['products'], before), /mirror failed/);
  assert.equal(localStorage.getItem('SMDB_shop_products'), before.products);
  assert.equal(flushCount, 2);
});
