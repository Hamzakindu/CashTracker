import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const source=fs.readFileSync(new URL('../app/src/main/assets/js/modules/finance-control.js',import.meta.url),'utf8');
test('V8.48 financial audit UI exposes severity summary and searchable filtering',()=>{
 assert.match(source,/integritySeverity\(issue\)/);
 assert.match(source,/integrityRows\(\)/);
 assert.match(source,/setIntegrityFilter\('severity'/);
 assert.match(source,/Search issue, name or ID/);
 assert.match(source,/High priority/);
});
test('V8.48 financial audit exports filtered findings without mutating records',()=>{
 assert.match(source,/exportIntegrityCSV\(\)/);
 assert.match(source,/cashtracker-integrity-audit\.csv/);
 assert.match(source,/No records were changed/);
 assert.match(source,/read-only/);
});
const appSource=fs.readFileSync(new URL('../app/src/main/assets/js/app.js',import.meta.url),'utf8');
test('download helper reports whether the browser download was started',()=>{
 assert.match(appSource,/a\.click\(\);[\s\S]*return true;/);
 assert.match(appSource,/catch\(e\)[\s\S]*return false;/);
});
