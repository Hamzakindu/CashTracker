/* CashTracker V8.47: read-only cross-store transaction integrity audit.
 * It never edits or repairs business records. Findings are diagnostics only.
 */
(function (root) {
  'use strict';
  function list(value) { return Array.isArray(value) ? value : []; }
  function active(row) { return !!row && row.voided !== true && row.status !== 'void'; }
  function amount(value) { const n = Number(value); return Number.isFinite(n) ? n : 0; }
  function audit(state) {
    state = state || {};
    const findings = [];
    const sales = list(state.sales).filter(active);
    const purchases = list(state.purchases).filter(active);
    const ledger = list(state.paymentLedger).filter(x => x && x.status !== 'void' && x.status !== 'reversed');
    const movements = list(state.moneyTransactions).filter(x => x && x.status !== 'void' && x.status !== 'reversed');
    const stock = list(state.stockHistory).filter(x => x && x.status !== 'void' && x.status !== 'reversed');
    const sources = [...sales.map(x => ({ row:x, type:'sale', expected:amount(x.paymentReceived), movementType:'sale_payment' })),
      ...purchases.map(x => ({ row:x, type:'purchase', expected:amount(x.paid), movementType:'purchase_payment' }))];
    const sourceIds = new Set(sources.map(x => String(x.row.id || x.row.transactionId || '')).filter(Boolean));
    for (const {row,type,expected,movementType} of sources) {
      const id = String(row.id || row.transactionId || '');
      if (!id) { findings.push({code:'SOURCE_ID_MISSING',severity:'critical',sourceType:type,sourceId:null,message:'Active '+type+' has no stable ID.'}); continue; }
      const payments = ledger.filter(x => String(x.sourceId || '') === id && x.sourceType === type);
      const paid = payments.reduce((s,x)=>s+amount(x.amount),0);
      if (expected > 0 && payments.length === 0) findings.push({code:'PAYMENT_LEDGER_MISSING',severity:'high',sourceType:type,sourceId:id,expected,actual:0,message:'Paid '+type+' has no linked payment-ledger entry.'});
      else if (payments.length && Math.abs(paid-expected) > 0.01) findings.push({code:'PAYMENT_TOTAL_MISMATCH',severity:'high',sourceType:type,sourceId:id,expected,actual:paid,message:'Linked payment-ledger total differs from source payment amount.'});
      if (expected > 0) {
        const linkedMoves = movements.filter(x => String(x.sourceId || '') === id && x.sourceType === movementType);
        const moved = linkedMoves.reduce((s,x)=>s+amount(x.amount),0);
        if (!linkedMoves.length) findings.push({code:'ACCOUNT_MOVEMENT_MISSING',severity:'high',sourceType:type,sourceId:id,expected,actual:0,message:'Paid '+type+' has no linked cash/bank movement.'});
        else if (Math.abs(moved-expected) > 0.01) findings.push({code:'ACCOUNT_MOVEMENT_MISMATCH',severity:'high',sourceType:type,sourceId:id,expected,actual:moved,message:'Linked cash/bank movement total differs from source payment amount.'});
      }
    }
    for (const p of ledger) if ((p.sourceType === 'sale' || p.sourceType === 'purchase') && p.sourceId && !sourceIds.has(String(p.sourceId)))
      findings.push({code:'ORPHAN_PAYMENT',severity:'high',sourceType:p.sourceType,sourceId:String(p.sourceId),message:'Payment ledger points to a missing or void source transaction.'});
    for (const [name,rows] of [['sales',list(state.sales)],['purchases',list(state.purchases)],['paymentLedger',list(state.paymentLedger)],['moneyTransactions',list(state.moneyTransactions)],['stockHistory',list(state.stockHistory)]]) {
      const seen = new Set();
      for (const row of rows) { if (!row || !row.id) continue; const id=String(row.id); if(seen.has(id)) findings.push({code:'DUPLICATE_RECORD_ID',severity:'critical',store:name,recordId:id,message:'Duplicate record ID found in '+name+'.'}); else seen.add(id); }
    }
    const counts = findings.reduce((out,x)=>{out[x.severity]=(out[x.severity]||0)+1;return out;},{critical:0,high:0,warning:0});
    return {ok:findings.length===0,checkedAt:new Date().toISOString(),sourcesChecked:sources.length,paymentsChecked:ledger.length,movementsChecked:movements.length,stockMovementsChecked:stock.length,counts,findings};
  }
  root.TransactionIntegrity = Object.freeze({ audit });
})(typeof window !== 'undefined' ? window : globalThis);
