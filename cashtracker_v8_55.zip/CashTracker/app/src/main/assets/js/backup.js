// ============================================
// BACKUP SYSTEM
// ============================================
const Backup = {
    timer: null,

    // Manual backup to localStorage
    manualBackup() {
        try {
            const data = {
                exportedAt: new Date().toISOString(),
                profileId: State.currentProfileId,
                appVersion: CONFIG.VERSION,
                format: 'StockPro',
                schemaVersion: 3,
                products: State.products,
                sales: State.sales,
                purchases: State.purchases,
                customers: State.customers,
                suppliers: State.suppliers,
                supplierAdvances: State.supplierAdvances,
                paymentLedger: State.paymentLedger,
                expenseTypes: State.expenseTypes,
                directExpenses: State.directExpenses,
                returns: State.returns,
                calculations: State.calculations,
                stockHistory: State.stockHistory,
                branchStockOpening: State.branchStockOpening || [],
                auditLog: State.auditLog,
                accountingMeta: State.accountingMeta,
                cashAccounts: State.cashAccounts,
                moneyTransactions: State.moneyTransactions,
                peopleMoney: State.peopleMoney,
                peopleMoneyTx: State.peopleMoneyTx,
                cashierSessions: State.cashierSessions,
                cashCounts: State.cashCounts,
                cashReconciliations: State.cashReconciliations || [],
                periodClosures: State.periodClosures || [],
                branches: State.branches,
                staffUsers: State.staffUsers,
                branchAccessMeta: State.branchAccessMeta
            };

            const backupKey = 'ab_' + State.currentProfileId;
            localStorage.setItem(backupKey, JSON.stringify(data));
            Storage.setSetting('labt', new Date().toISOString());

            const lastBackupEl = document.getElementById('lastAutoBackup');
            if (lastBackupEl) {
                lastBackupEl.textContent = new Date().toLocaleString();
            }

            Toast.success('✅ Local safety copy saved inside CashTracker on this device. This is NOT a file in Downloads.');
            return true;
        } catch (error) {
            console.error('Backup error:', error);
            Toast.error('❌ Backup failed: ' + error.message);
            return false;
        }
    },

    // Export backup as downloadable JSON file
    async exportBackup() {
        try {
            const data = {
                exportedAt: new Date().toISOString(),
                profileId: State.currentProfileId,
                appVersion: CONFIG.VERSION,
                format: 'StockPro',
                schemaVersion: 3,
                products: State.products,
                sales: State.sales,
                purchases: State.purchases,
                customers: State.customers,
                suppliers: State.suppliers,
                supplierAdvances: State.supplierAdvances,
                paymentLedger: State.paymentLedger,
                expenseTypes: State.expenseTypes,
                directExpenses: State.directExpenses,
                returns: State.returns,
                calculations: State.calculations,
                stockHistory: State.stockHistory,
                branchStockOpening: State.branchStockOpening || [],
                auditLog: State.auditLog,
                accountingMeta: State.accountingMeta,
                cashAccounts: State.cashAccounts,
                moneyTransactions: State.moneyTransactions,
                peopleMoney: State.peopleMoney,
                peopleMoneyTx: State.peopleMoneyTx,
                cashierSessions: State.cashierSessions,
                cashCounts: State.cashCounts,
                cashReconciliations: State.cashReconciliations || [],
                periodClosures: State.periodClosures || [],
                branches: State.branches,
                staffUsers: State.staffUsers,
                branchAccessMeta: State.branchAccessMeta
            };

            // Add a SHA-256 integrity seal without changing the legacy JSON layout.
            // Older backups without this field remain importable.
            data.backupIntegrity = await this.createIntegritySeal(data);
            // Export portable encrypted backups by default. The passphrase is never
            // written into the file or localStorage; users must keep it separately.
            if (typeof BackupCrypto === 'undefined' || !BackupCrypto.encryptJson) {
                throw new Error('Backup encryption is unavailable. Update/reopen CashTracker before exporting.');
            }
            const passphrase = await BackupCrypto.getPassphrase(true);
            const json = await BackupCrypto.encryptJson(data, passphrase);
            const filename = `cashtracker-encrypted-backup-${State.currentProfileId}-${new Date().toISOString().slice(0, 10)}.json`;

            // On Android this resolves only after MediaStore confirms the file write.
            // Do not display a success message before the native callback arrives.
            const result = await Helpers.downloadFile(json, filename, 'application/json');
            if (!result || result.ok !== true) throw new Error('The download was not confirmed.');
            if (result.confirmed) {
                Toast.success('✅ Backup saved to Downloads: ' + filename + '. Please verify the file is visible.');
            } else {
                Toast.info('Download requested: ' + filename + '. The browser has not confirmed the save; check its Downloads list.');
            }
            return result;
        } catch (error) {
            console.error('Export error:', error);
            Toast.error('❌ Backup export failed: ' + (error.message || error));
            return { ok: false, error: error.message || String(error) };
        }
    },

    // Import backup from file — supports CashTracker 5.x and AppMint wrapped backups
    importBackup() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json,.txt,application/json,text/plain';
        input.onchange = async (e) => {
            const file = e.target.files && e.target.files[0];
            if (!file) return;
            try {
                if (file.size > 50 * 1024 * 1024) throw new Error('Backup file is larger than the 50 MB safety limit.');
                let text = await this.readFileAsText(file);
                text = String(text || '').replace(/^\uFEFF/, '').trim();
                if (!text) throw new Error('The backup file is empty.');
                let data = JSON.parse(text);
                // Some backup tools save JSON as a JSON string.
                if (typeof data === 'string') data = JSON.parse(data);
                // Decrypt portable V2 envelopes before preview/validation. Plain legacy
                // JSON remains supported, but requires an explicit compatibility choice.
                if (typeof BackupCrypto !== 'undefined' && BackupCrypto.isEncrypted && BackupCrypto.isEncrypted(data)) {
                    const passphrase = await BackupCrypto.getPassphrase(false);
                    data = await BackupCrypto.decryptJson(data, passphrase);
                } else {
                    if (!confirm('⚠️ This is an older UNENCRYPTED backup. Anyone who obtains the file may read its business data. Continue importing it? For new backups, use the encrypted Backup now option.')) return;
                }
                // Support {data:{...}}, {db:{...}}, and {backup:{...}} wrappers.
                if (data && data.data && typeof data.data === 'object' && !Array.isArray(data.data)) data = Object.assign({}, data.data, { exportedAt: data.exportedAt || data.data.exportedAt, appVersion: data.appVersion || data.data.appVersion });
                else if (data && data.db && typeof data.db === 'object' && !Array.isArray(data.db)) data = Object.assign({}, data.db, { exportedAt: data.exportedAt || data.db.exportedAt, appVersion: data.appVersion || data.db.appVersion });
                else if (data && data.backup && typeof data.backup === 'object' && !Array.isArray(data.backup)) data = Object.assign({}, data.backup, { exportedAt: data.exportedAt || data.backup.exportedAt, appVersion: data.appVersion || data.backup.appVersion });
                await this.verifyIntegritySeal(data);
                if (!this.validateBackupData(data)) throw new Error('Invalid backup format. Expected CashTracker product, sales, purchase, customer, or supplier data.');

                const preview = this.getBackupPreview(data);
                const migration = this.getMigrationReport(data);
                const backupDate = preview.backupDateLabel;
                const productCount = preview.counts.products;
                const salesCount = preview.counts.sales;
                const purchaseCount = preview.counts.purchases;
                const customerCount = preview.counts.customers;
                const supplierCount = preview.counts.suppliers;
                const version = data.appVersion || 'Unknown';
                const allStores = ['products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger','expenseTypes','directExpenses','returns','calculations','stockHistory','branchStockOpening','auditLog','accountingMeta','cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','periodClosures','branches','staffUsers','branchAccessMeta'];
                const omittedStores = allStores.filter(key => !Object.prototype.hasOwnProperty.call(data, key));
                const omissionNote = omittedStores.length ? `\n\nMIGRATION WARNING: This older backup omits ${omittedStores.length} stores (${omittedStores.join(', ')}). They will remain unchanged, so the restored profile will combine historical backup data with current-device data. Review this carefully.` : '';
                const migrationNote = `\n\nMIGRATION ANALYSIS: ${migration.sourceLabel}; ${migration.presentStoreCount} stores present; ${migration.missingStoreCount} stores absent; ${migration.legacySaleRows} sale rows need payment/items compatibility handling. This analysis does not modify your backup.`;
                const staleNote = preview.isOlderThanCurrent
                    ? `\n\n⚠️ OLDER BACKUP WARNING: Current records contain activity newer than this backup. Restoring may permanently remove newer transactions unless you have another backup.`
                    : '';
                const profileNote = preview.profileMismatch
                    ? `\n\n⚠️ PROFILE MISMATCH: This file belongs to profile ${preview.backupProfileId}, but the active profile is ${preview.currentProfileId}. Restoring can mix or replace the wrong business data.`
                    : '';
                if (!confirm(`🔎 BACKUP PREVIEW — REVIEW BEFORE RESTORE\n\nVersion: ${version}\nBackup Date: ${backupDate}\nProducts: ${productCount}\nSales: ${salesCount}\nPurchases: ${purchaseCount}\nCustomers: ${customerCount}\nSuppliers: ${supplierCount}\nLatest backup activity: ${preview.backupLatestActivityLabel}\nLatest current activity: ${preview.currentLatestActivityLabel}${staleNote}${profileNote}${migrationNote}${omissionNote}\n\nIncluded stores will OVERWRITE their current data.\n\nClick OK to continue to the final confirmation.`)) return;
                if ((preview.isOlderThanCurrent || preview.profileMismatch) && !confirm(`🚨 FINAL SAFETY CHECK\n\n${preview.isOlderThanCurrent ? 'This backup is older than your current records. ' : ''}${preview.profileMismatch ? 'The backup profile does not match the active profile. ' : ''}You are choosing to continue.\n\nA recovery snapshot will be created first. Continue with restore?`)) return;

                // Persist a separate pre-restore recovery point before touching any store.
                // A browser/app crash during restore can therefore be recovered later.
                if (Storage.createSafetySnapshot) {
                    const safety = Storage.createSafetySnapshot('pre-restore-' + new Date().toISOString());
                    if (safety && safety.error) throw new Error('Could not create a pre-restore safety snapshot: ' + safety.error + '. No data was changed.');
                    if (safety && safety.empty) console.warn('Pre-restore snapshot skipped because this profile has no stored records yet.');
                    else if (safety && safety.created !== true) throw new Error('Could not confirm a pre-restore recovery snapshot. No data was changed.');
                }
                State.saveUndoState('Before file restore');
                const stores = ['products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger','expenseTypes','directExpenses','returns','calculations','stockHistory','branchStockOpening','auditLog','accountingMeta','cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','periodClosures','branches','staffUsers','branchAccessMeta'];
                // Capture exact current values so a quota/write error can roll back this restore.
                const before = {};
                stores.forEach(store => { try { const raw = localStorage.getItem(Storage.getKey(store)); before[store] = raw === null ? null : raw; } catch (_) { before[store] = null; } });
                const prepared = {};
                for (const store of stores) if (data[store] !== undefined) prepared[store] = data[store];
                // Apply only documented, lossless legacy field aliases after preview.
                const normalizedPayload = this.prepareRestorePayload(prepared);
                Object.keys(prepared).forEach(key => { delete prepared[key]; });
                Object.assign(prepared, normalizedPayload);
                let restoredCount = 0;
                try {
                    await this.persistRestoreStores(prepared, stores, before);
                    restoredCount = Object.keys(prepared).length;
                } catch (writeError) {
                    throw new Error(writeError.message + ' Restore was rolled back where possible. Please reopen CashTracker and verify your records before continuing.');
                }
                // A successful restore is now the authoritative initialized state.
                if (Storage.setSetting) Storage.setSetting('stockpro_initialized_v2','true');
                Toast.success('✅ Backup imported. Reloading...', 2500);
                setTimeout(async () => {
                    await State.loadAllData();
                    App.populateDropdowns(); Dashboard.update(); Products.render(); Sales.render(); Purchases.render(); Customers.render(); Suppliers.render(); Expenses.renderTypes(); Expenses.renderDirect(); Returns.render();
                    Tabs.switchTo('dashboard');
                    Toast.success(`✅ Restored ${restoredCount} data stores: ${productCount} products, ${salesCount} sales, ${purchaseCount} purchases.`, 3500);
                }, 300);
            } catch (error) {
                console.error('Import error:', error);
                Toast.error('❌ Backup import failed: ' + (error.message || 'unknown file format'), 6000);
            }
        };
        input.click();
    },

    // Recover the immutable pre-update safety snapshot.
    // This is intentionally separate from normal backup restore.
    recoverSafetySnapshot() {
        try {
            const snap = Storage.getSafetySnapshot ? Storage.getSafetySnapshot() : null;
            if (!snap) return Toast.warning('No pre-update safety snapshot is available.');
            const when = snap.snapshotAt ? new Date(snap.snapshotAt).toLocaleString() : 'unknown time';
            const stores = snap.stores ? Object.keys(snap.stores).length : 0;
            if (!confirm(`\u26a0\ufe0f RECOVER PRE-UPDATE DATA?\n\nSnapshot: ${when}\nVersion: ${snap.appVersion || 'unknown'}\nStores: ${stores}\n\nCurrent data will be replaced by this recovery snapshot.\n\nClick OK only if you need to undo a bad update.`)) return;
            if (State && State.saveUndoState) State.saveUndoState('Before safety recovery');
            const result = Storage.restoreSafetySnapshot();
            if (!result.ok) throw new Error(result.error || 'Recovery failed');
            Toast.success('\u2705 Safety snapshot restored. Reloading...', 3000);
            setTimeout(()=>location.reload(),400);
        } catch(e) { console.error('Safety recovery error:',e); Toast.error('\u274c Safety recovery failed: '+e.message,6000); }
    },

    // Restore from cloud/localStorage backup
    async restoreFromCloud() {
        const backupKey = 'ab_' + State.currentProfileId;
        const backupData = localStorage.getItem(backupKey);
        
        if (!backupData) {
            return Toast.warning('⚠️ No cloud backup found. Use "Import Backup" to restore from a file, or "Backup Now" to create one first.');
        }

        try {
            let data;
            try {
                data = JSON.parse(backupData);
            } catch (parseError) {
                throw new Error('Cloud backup data is corrupted.');
            }
            
            if (!this.validateBackupData(data)) {
                throw new Error('Invalid cloud backup data.');
            }

            const backupDate = data.exportedAt ? new Date(data.exportedAt).toLocaleString() : 'Unknown date';
            const productCount = data.products ? data.products.length : 0;
            
            if (!confirm(
                `⚠️ RESTORE CLOUD BACKUP?\n\n` +
                `Backup Date: ${backupDate}\n` +
                `Products: ${productCount}\n\n` +
                `This will OVERWRITE all current data!\n\n` +
                `Click OK to proceed.`
            )) {
                return;
            }

            State.saveUndoState('Before cloud restore');

            const stores = ['products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger','expenseTypes','directExpenses','returns','calculations','stockHistory','branchStockOpening','auditLog','accountingMeta','cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','periodClosures','branches','staffUsers','branchAccessMeta'];
            const before = {};
            stores.forEach(store => { try { const raw = localStorage.getItem(Storage.getKey(store)); before[store] = raw === null ? null : raw; } catch (_) { before[store] = null; } });
            let restoredCount = 0;
            try {
                const prepared = {};
                for (const store of stores) if (data[store] !== undefined) prepared[store] = data[store];
                await this.persistRestoreStores(prepared, stores, before);
                restoredCount = Object.keys(prepared).length;
            } catch (writeError) {
                throw new Error(writeError.message + ' Restore was rolled back where possible. Please reopen CashTracker and verify your records before continuing.');
            }

            Toast.success('✅ Cloud backup restored! Reloading...', 4000);

            setTimeout(async () => {
                await State.loadAllData();
                App.populateDropdowns();
                Dashboard.update();
                Products.render();
                Sales.render();
                Purchases.render();
                Customers.render();
                Suppliers.render();
                Expenses.renderTypes();
                Expenses.renderDirect();
                Returns.render();
                Tabs.switchTo('dashboard');
                Toast.success('✅ Ready! ' + restoredCount + ' stores loaded.', 2000);
            }, 500);

        } catch (error) {
            console.error('Cloud restore error:', error);
            Toast.error('❌ ' + error.message, 5000);
        }
    },

    // Commit a restore as one local batch, verify every authoritative value, and
    // wait for the IndexedDB mirror. localStorage remains authoritative when IDB is unavailable.
    async persistRestoreStores(prepared, stores, capturedBefore) {
        const before = capturedBefore || {};
        for (const store of stores) {
            if (Object.prototype.hasOwnProperty.call(before, store)) continue;
            const key = Storage.getKey(store);
            before[store] = localStorage.getItem(key);
        }
        const rollback = async () => {
            const mirrorWrites = [];
            for (const store of stores) {
                const key = Storage.getKey(store);
                const raw = before[store];
                try {
                    if (raw === null || raw === undefined) localStorage.removeItem(key);
                    else localStorage.setItem(key, raw);
                    if (raw !== null && raw !== undefined) mirrorWrites.push({ key, value: JSON.parse(raw) });
                } catch (e) { console.error('Restore rollback failed for', store, e); }
            }
            try {
                if (window.StorageIDB?.putMany && mirrorWrites.length) await StorageIDB.putMany(mirrorWrites);
                for (const store of stores) if (before[store] === null || before[store] === undefined) {
                    try { await StorageIDB?.remove?.(Storage.getKey(store)); } catch (e) { console.warn('IndexedDB rollback delete failed', store, e); }
                }
                if (window.StorageIDB?.flush) await StorageIDB.flush();
            } catch (e) { console.error('Restore mirror rollback could not be confirmed:', e); }
        };
        try {
            if (!Storage.saveBatch || !Storage.saveBatch(prepared)) throw new Error('Storage batch write failed. Device storage may be full.');
            for (const store of Object.keys(prepared)) {
                const key = Storage.getKey(store);
                const encoded = window.Money?.encode ? Money.encode(prepared[store]) : prepared[store];
                const expected = JSON.stringify(encoded);
                if (localStorage.getItem(key) !== expected) throw new Error('Restore read-back verification failed for ' + store + '.');
            }
            if (window.StorageIDB?.flush) await StorageIDB.flush();
            return { ok: true, count: Object.keys(prepared).length };
        } catch (error) {
            await rollback();
            throw error;
        }
    },

    // Describe legacy migration without mutating the imported payload or current state.
    // schemaVersion 3 is the current portable backup schema; older/unspecified versions
    // are treated conservatively as legacy rather than guessed to be a specific V7 build.
    getMigrationReport(data) {
        const stores = ['products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger','expenseTypes','directExpenses','returns','calculations','stockHistory','branchStockOpening','auditLog','accountingMeta','cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','periodClosures','branches','staffUsers','branchAccessMeta'];
        const present = stores.filter(key => Object.prototype.hasOwnProperty.call(data || {}, key));
        const missing = stores.filter(key => !Object.prototype.hasOwnProperty.call(data || {}, key));
        const legacySaleRows = (Array.isArray(data && data.sales) ? data.sales : []).filter(row => row && ((row.paid === undefined && row.paymentReceived !== undefined) || (!Array.isArray(row.lines) && Array.isArray(row.items)))).length;
        const schema = Number(data && data.schemaVersion);
        const isCurrent = Number.isFinite(schema) && schema >= 3;
        return {
            sourceSchemaVersion: Number.isFinite(schema) && schema > 0 ? schema : null,
            sourceLabel: isCurrent ? `schema v${schema}` : (schema > 0 ? `legacy schema v${schema}` : 'legacy/unspecified schema'),
            presentStoreCount: present.length,
            missingStoreCount: missing.length,
            presentStores: present,
            missingStores: missing,
            legacySaleRows,
            requiresCompatibilityHandling: !isCurrent || legacySaleRows > 0
        };
    },

    // Clone the restore payload and apply known legacy aliases without changing the
    // source object. Unknown fields are retained for forward/backward compatibility.
    prepareRestorePayload(payload) {
        const prepared = Object.assign({}, payload || {});
        if (Array.isArray(prepared.sales)) prepared.sales = prepared.sales.map(row => {
            const next = Object.assign({}, row);
            if (next.paid === undefined && next.paymentReceived !== undefined) next.paid = Number(next.paymentReceived) || 0;
            if (!Array.isArray(next.lines) && Array.isArray(next.items)) next.lines = next.items.map(line => Object.assign({}, line));
            return next;
        });
        if (Array.isArray(prepared.branchAccessMeta)) prepared.branchAccessMeta = { version: 1, activeBranchId: 'main', currentStaffId: '' };
        if (Array.isArray(prepared.accountingMeta)) delete prepared.accountingMeta;
        return prepared;
    },

    // Build a read-only restore preview and detect backups that would roll data backwards.
    getBackupPreview(data) {
        const count = (key) => Array.isArray(data && data[key]) ? data[key].length : 0;
        const activityStores = ['sales','purchases','directExpenses','returns','paymentLedger','moneyTransactions','peopleMoneyTx','stockHistory'];
        const latest = (source) => {
            let max = 0;
            for (const key of activityStores) {
                const rows = Array.isArray(source && source[key]) ? source[key] : [];
                for (const row of rows) {
                    const candidates = row ? [row.createdAt, row.timestamp, row.date] : [];
                    let value = 0;
                    for (const raw of candidates) { const parsed = raw ? Date.parse(raw) : 0; if (Number.isFinite(parsed) && parsed > 0) { value = parsed; break; } }
                    if (value > max) max = value;
                }
            }
            return max;
        };
        const current = {};
        activityStores.forEach(key => { current[key] = Array.isArray(State && State[key]) ? State[key] : []; });
        const backupLatest = latest(data);
        const currentLatest = latest(current);
        const fmt = value => value ? new Date(value).toLocaleString() : 'No dated activity found';
        const backupProfileId = data && data.profileId != null ? String(data.profileId) : '';
        const currentProfileId = State && State.currentProfileId != null ? String(State.currentProfileId) : '';
        return {
            counts: { products: count('products'), sales: count('sales'), purchases: count('purchases'), customers: count('customers'), suppliers: count('suppliers') },
            backupDateLabel: data && data.exportedAt && !Number.isNaN(Date.parse(data.exportedAt)) ? new Date(data.exportedAt).toLocaleString() : 'Unknown date',
            backupLatestActivity: backupLatest,
            currentLatestActivity: currentLatest,
            backupLatestActivityLabel: fmt(backupLatest),
            currentLatestActivityLabel: fmt(currentLatest),
            isOlderThanCurrent: !!(currentLatest && (!backupLatest || currentLatest > backupLatest + 60000)),
            backupProfileId,
            currentProfileId,
            profileMismatch: !!(backupProfileId && currentProfileId && backupProfileId !== currentProfileId)
        };
    },

    // Seal the complete backup payload (excluding the seal itself) so accidental
    // truncation or modification is detected before any restore writes occur.
    async createIntegritySeal(data) {
        try {
            if (!globalThis.crypto || !crypto.subtle || typeof TextEncoder === 'undefined') return null;
            const payload = Object.assign({}, data);
            delete payload.backupIntegrity;
            const bytes = new TextEncoder().encode(JSON.stringify(payload));
            const digest = await crypto.subtle.digest('SHA-256', bytes);
            const hex = Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('');
            return { algorithm: 'SHA-256', digest: hex, payloadBytes: bytes.length };
        } catch (error) {
            console.warn('Backup integrity seal unavailable:', error);
            return null;
        }
    },

    async verifyIntegritySeal(data) {
        const seal = data && data.backupIntegrity;
        if (!seal) return true; // compatibility with older, unsealed JSON backups
        if (!seal || seal.algorithm !== 'SHA-256' || !/^[a-f0-9]{64}$/i.test(String(seal.digest || ''))) {
            throw new Error('Backup integrity information is invalid. No data was changed.');
        }
        const actual = await this.createIntegritySeal(data);
        if (!actual || actual.digest.toLowerCase() !== seal.digest.toLowerCase() || Number(actual.payloadBytes) !== Number(seal.payloadBytes)) {
            throw new Error('Backup integrity check failed. The file may be incomplete or modified. No data was changed.');
        }
        return true;
    },

    // Validate backup data structure
    // Older exports wrote the two "meta" stores as an empty list ([]). Convert them so the backup can be restored.
    normalizeMetaStores(data) {
        if (!data || typeof data !== 'object' || Array.isArray(data)) return data;
        if (Array.isArray(data.branchAccessMeta)) data.branchAccessMeta = { version: 1, activeBranchId: 'main', currentStaffId: '' };
        if (Array.isArray(data.accountingMeta)) delete data.accountingMeta;
        return data;
    },

    validateBackupData(data) {
        this.normalizeMetaStores(data);
        if (!data || typeof data !== 'object' || Array.isArray(data)) return false;
        if (data.format && String(data.format).toLowerCase() !== 'stockpro') return false;
        const knownStores = ['products','sales','purchases','customers','suppliers','supplierAdvances','paymentLedger','expenseTypes','directExpenses','returns','calculations','stockHistory','branchStockOpening','auditLog','accountingMeta','cashAccounts','moneyTransactions','peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','periodClosures','branches','staffUsers','branchAccessMeta'];
        const hasAnyStore = knownStores.some(key => Object.prototype.hasOwnProperty.call(data, key));
        if (!hasAnyStore) return false;
        // If a store is present it must have the expected container type. Reject malformed
        // backups before changing a single persisted value.
        for (const key of knownStores) {
            if (!Object.prototype.hasOwnProperty.call(data, key)) continue;
            const value = data[key];
            if (['accountingMeta','branchAccessMeta'].includes(key)) {
                if (value !== null && (typeof value !== 'object' || Array.isArray(value))) return false;
            } else if (!Array.isArray(value)) return false;
        }
        // A full CashTracker backup must include the five primary collections. Reject
        // partial exports here so they cannot masquerade as a complete restore.
        return ['products','sales','purchases','customers','suppliers'].every(key => Array.isArray(data[key]));
    },

    // Read file as text (Promise wrapper)
    readFileAsText(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    resolve(e.target.result);
                } catch (error) {
                    reject(new Error('Failed to read file contents'));
                }
            };
            reader.onerror = (e) => {
                reject(new Error('Failed to read file. It may be corrupted or inaccessible.'));
            };
            reader.readAsText(file);
        });
    },

    // Start auto backup
    startAuto() {
        this.stopAuto();
        
        const freq = parseInt(Storage.getSetting('autoBackupFrequency', CONFIG.DEFAULT_BACKUP_FREQUENCY.toString()));
        
        if (freq > 0) {
            this.timer = setInterval(() => {
                if (navigator.onLine) {
                    console.log('Auto-backup triggered');
                    this.manualBackup();
                }
            }, freq * 3600000);
            
            console.log(`Auto-backup started: every ${freq} hours`);
        }
    },

    // Stop auto backup
    stopAuto() {
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
            console.log('Auto-backup stopped');
        }
    },

    // Toggle auto backup
    toggleAuto() {
        const enabledEl = document.getElementById('autoBackupEnabled');
        if (!enabledEl) return;
        
        const enabled = enabledEl.value === 'enabled';
        Storage.setSetting('autoBackupEnabled', enabled ? 'enabled' : 'disabled');
        
        if (enabled) {
            this.startAuto();
            Toast.success('✅ Auto-backup enabled');
        } else {
            this.stopAuto();
            Toast.info('⏸️ Auto-backup disabled');
        }
    }
};

// ============================================
// AUTO-BACKUP EVENT LISTENERS
// ============================================

// Auto-backup when coming back online
window.addEventListener('online', () => {
    const enabled = Storage.getSetting('autoBackupEnabled', 'enabled');
    if (enabled === 'enabled') {
        const lastBackup = Storage.getSetting('labt');
        const oneHour = 3600000;
        
        if (!lastBackup || (new Date().getTime() - new Date(lastBackup).getTime()) > oneHour) {
            console.log('Online: triggering auto-backup');
            setTimeout(() => Backup.manualBackup(), 5000);
        }
    }
});