# CashTracker V8.51 — Legacy backup migration preview and fixture validation

**App version:** 5.10.94  
**Android versionCode:** 5118  
**Application ID:** `com.stockpro.banksms`

## Delivered

- Added a read-only migration report to the file-restore preview. It identifies the source schema label, present/missing stores and sales rows requiring known legacy compatibility handling.
- Made the restore preview explicitly warn when an older backup omits newer stores. Existing behavior is preserved: omitted stores remain unchanged, and the preview explains that the result will combine backup data with current-device data.
- Extracted known lossless legacy field handling into `prepareRestorePayload()` so it can be tested independently. It maps sale `paymentReceived` to `paid`, `items` to `lines`, normalizes legacy `branchAccessMeta` arrays, and drops the obsolete array-shaped `accountingMeta` placeholder.
- Added a synthetic anonymized V7-shaped fixture with products, sales, purchases, parties, expenses and stock history. The fixture contains no real customer or supplier information.
- Added tests for fixture acceptance, migration report accuracy, lossless sale alias conversion, metadata normalization, and rejection of incomplete primary-store backups.

## Important limitations

- The fixture is synthetic and representative of the documented legacy shapes; it is not a copy of the user's live V7 backup. Exact migration certification still requires a copy of the actual V7 export, preferably anonymized, and a restore into a disposable profile/device.
- The migration preview does not automatically clear stores missing from an older backup. It explicitly warns that those stores remain unchanged, to avoid silently deleting current records.
- This release does not claim full V7-to-V8 migration certification, nor does it change the encrypted backup format or existing signing configuration.

## Verification

- Automated test suite includes six new migration regression tests.
- Final automated test result: 293 passed, 0 failed.
- `npm run typecheck` passed.
- `npm run build:android-assets` passed.
- JavaScript syntax, JSON/XML/YAML parsing passed.
- Source syntax, typecheck, Android asset build, metadata, workflow and ZIP integrity must pass before release handoff.
- Android APK build/signature, live backup restore and physical-device checks remain external release gates.
