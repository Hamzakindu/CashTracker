# CashTracker V8.44 — Android upgrade-safety correction

**App version:** 5.10.88  
**Android baseline versionCode:** 5112  
**Application ID:** `com.stockpro.banksms` (preserved)

## Why this correction was necessary
The V8.43 release candidate had reset the Android baseline version code to `87`. The earlier CashTracker release requirement recorded by the project owner was `5111`. Android requires a higher version code to install an update over an existing installation, so `87` could be rejected as a downgrade.

## Changes
- Set the next Android baseline version code to `5112`.
- Set the app/package version to `5.10.88` consistently in Gradle, package metadata, JavaScript configuration, AppMint metadata and PWA manifest.
- Preserve the existing `applicationId` `com.stockpro.banksms`; no package identity migration is attempted.
- Preserve the release signing configuration and keystore alias handling; no new signing key is generated.
- Add regression tests that require the version code to exceed the historical `5111` baseline and check metadata consistency.
- Add a CI preflight guard to reject a release ZIP that accidentally regresses the Android version code.

## Verification
- Node tests: **268 passed, 0 failed**.
- TypeScript typecheck: **passed**.
- TypeScript Android asset compilation: **passed**.
- JavaScript syntax checks: **passed**.
- JSON and Android manifest parsing: **passed**.
- GitHub Actions YAML parse: **passed**.
- Vite production bundle: **not run**; dependency installation timed out in this environment.
- Android Gradle APK build and signature verification: **not run**; Android SDK/Gradle are unavailable here.
- Upgrade installation against the owner's existing APK: **not verified**; requires the actual installed APK and matching signing key.

## Release decision
This is an upgrade-safety source update, not a device-certified production release. Back up business data before installing any test APK. Do not change the application ID or signing key during this update.
