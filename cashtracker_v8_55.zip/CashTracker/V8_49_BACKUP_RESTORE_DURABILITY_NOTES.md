# V8.49 Backup and Restore Durability

- Both backup payload builders now include `branchStockOpening`, which was previously included in the recognized restore-store list but omitted from the exported payload.
- File restore and local cloud-backup restore use `Storage.saveBatch` rather than sequential per-store saves.
- Each restored localStorage store is read back and compared with its serialized expected value.
- The IndexedDB write queue is flushed before the restore proceeds to app reload. IndexedDB-unavailable fallback remains allowed because localStorage is the authoritative synchronous store.
- If batch persistence or IndexedDB flush fails, the routine attempts to roll localStorage back to captured raw values and re-queues prior values/deletions in IndexedDB.
- No restore path silently merges omitted stores; existing behavior remains that omitted optional stores are left unchanged, with the existing preview warning.
- The change does not prove an Android APK can compile or that a particular phone's Downloads folder behaves correctly; those require CI/device verification.
