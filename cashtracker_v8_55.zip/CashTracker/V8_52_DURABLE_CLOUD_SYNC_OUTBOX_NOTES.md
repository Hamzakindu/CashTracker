# V8.52 — Durable Cloud Sync Outbox

Version: 5.10.95 (Android versionCode 5119)

## Existing architecture retained

V8.52 extends the existing Cloudflare encrypted whole-profile snapshot synchronization. It does not introduce a second per-record API, alter server snapshot formats, bypass revision checks, or weaken branch/workspace permissions.

## Changes

- Persist the set of changed store names in a versioned, profile-scoped localStorage outbox before scheduling a cloud upload.
- Restore valid pending store names during CloudSync initialization.
- Resume queued synchronization after successful session restoration or sign-in.
- Persist retry attempt, next retry time, and a bounded error summary.
- Retry transient failures with exponential backoff capped at 15 minutes.
- Keep revision conflicts blocked for explicit restore/review; do not automatically overwrite newer cloud data.
- Clear the durable outbox only after a successful snapshot upload and only if no newer local change arrived during the upload.
- Preserve compatibility with the previous pending flag by queueing a full-profile snapshot when the flag exists but no outbox is present.

## Limits and safety

This is a durable *store-level coalescing queue*, not a per-transaction event log. The existing server-side optimistic revision check remains the concurrency control. Multi-device merge remains a user-reviewed operation where revisions conflict. localStorage persistence is subject to browser/device storage eviction and does not replace encrypted backups.

## Verification

Automated regression tests assert queue persistence, restart recovery, retry backoff, safe clearing and conflict blocking. Android APK compilation, live Cloudflare deployment, network fault injection and two-device end-to-end testing are not claimed by source tests.

Automated verification result: 298 tests passed, 0 failed; TypeScript typecheck passed; Android asset TypeScript compilation passed; JavaScript syntax, JSON, Android manifest XML, GitHub Actions YAML and archive integrity checks passed. No Gradle APK build or live Cloudflare/device test was performed.
