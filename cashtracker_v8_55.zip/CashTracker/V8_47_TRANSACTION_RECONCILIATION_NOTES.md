# CashTracker V8.47 — read-only transaction integrity audit

## Delivered
- Added `TransactionIntegrity.audit(state)` as a read-only diagnostic across active sales/purchases, payment ledger, cash/bank movements, and record IDs.
- Detects missing stable source IDs, missing payment ledger entries, payment amount mismatches, missing or mismatched cash/bank movements, orphan payment entries, and duplicate IDs in key transaction stores.
- Excludes void/reversed payment and movement records from active reconciliation; excludes void source transactions.
- Returns structured findings with severity, code, source/store identifiers, expected/actual amounts where applicable, and summary counts.
- Added the script to the Android WebView app load order.
- Added tests for clean reconciliation, mismatches, orphan/duplicate records, void filtering and read-only behavior.

## Important limitations
- This audit diagnoses only; it does not modify or automatically repair business data.
- It does not yet reconcile customer/supplier running balances, advances, stock quantities/valuation, returns, opening balances, or branch-level partitions.
- Amounts are compared with a 0.01 tolerance. Any legacy source schema differences should be reviewed before using findings for a financial adjustment.
- No Android APK compile, signing, installation, or real-device validation is claimed.
