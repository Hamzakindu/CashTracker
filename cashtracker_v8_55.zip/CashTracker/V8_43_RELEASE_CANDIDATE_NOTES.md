# CashTracker V8.43 — Release-candidate hardening

**App version:** 5.10.87  
**Android baseline versionCode:** 87 (superseded by V8.44 upgrade-safety correction)

## Changes
- Corrected the GitHub Actions version override: CI derives the base app version and version code from `gradle.properties`, then adds the workflow run number.
- Android project discovery searches nested ZIP directories, validates the app Gradle file and manifest, and fails safely if multiple Android projects are found.
- Aligned package, Gradle, app metadata and JavaScript version values at 5.10.87.

## Historical verification
- Node automated tests: 267 passed, 0 failed.
- TypeScript typecheck and Android TypeScript asset compilation passed.
- Android APK build and physical-device regression were not performed.

## Superseded
The version code `87` was below the project's historical `5111` release baseline. V8.44 corrects this to `5112`; do not use V8.43 for an in-place upgrade over a 5111 installation.
