# CashTracker V8.46 — transaction integrity

## Change delivered

`Storage.saveBatch()` now verifies every committed localStorage value by reading it back and comparing the exact serialized payload before reporting success or queueing the IndexedDB mirror. A silent/no-op write or corrupted read-back is treated as a failed batch; the existing rollback restores all earlier keys in the batch.

## Regression coverage

- Successful multi-store local commit and IndexedDB batch queue.
- Rollback after a later localStorage write throws.
- Preflight rejection of oversized stores without partial writes.
- Detection and rollback of silent/no-op writes.
- Detection and rollback of corrupted read-back values.

## Important boundary

This strengthens the synchronous localStorage commit path. IndexedDB remains a mirror and is not promoted to the source of truth. This does not yet prove end-to-end transaction recovery across process termination, device power loss, cloud sync conflicts, or real Android WebView storage behavior. Those require device and integration tests.
