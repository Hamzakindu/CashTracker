# CashTracker V8.53 — Cloud Sync Runtime Harness

Version: 5.10.96 (Android versionCode 5120)

## Scope
This release adds a deterministic Node.js VM harness that executes the actual CloudSync client module with isolated localStorage/sessionStorage and controlled network behavior. It does not add a second sync engine or alter the Cloudflare API.

## Runtime scenarios exercised
- Restart recovery restores only allow-listed store names from the persisted profile outbox.
- Queue writes persist before upload scheduling.
- Transient upload failure retains queued stores and records retry metadata.
- Revision conflicts block synchronization without increasing transient retry attempts.
- Changes arriving while an upload is in flight remain queued after that upload completes.

## Verification boundary
The harness tests the client module in a simulated browser environment. It does not prove live Cloudflare Worker/D1 behavior, real multi-phone concurrency, Android lifecycle behavior, or release APK correctness. Those require deployed-worker and physical-device tests.
