# CashTracker release status

Current source release: V8.55 (5.10.98 / Android versionCode 5122).

V8.55 adds real Worker-route authorization tests for whole-workspace snapshots: accountant read-only access, viewer denial, and branch-scoped cashier denial. It retains the V8.54 two-device stale-writer race test, which verifies HTTP 409 conflict handling and preservation of the winning snapshot. See `V8_55_CLOUD_SNAPSHOT_RBAC_NOTES.md`.

Automated tests use an in-memory D1 adapter. They do not certify live Cloudflare D1, deployed authentication, two physical devices, APK compilation/signing, or production readiness.
