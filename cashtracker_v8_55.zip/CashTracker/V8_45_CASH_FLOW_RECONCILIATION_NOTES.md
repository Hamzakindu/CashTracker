# CashTracker V8.45 — cash-flow statement reliability

**App version:** 5.10.89  
**Android versionCode:** 5113  
**Application ID:** `com.stockpro.banksms` (unchanged)

## Changes
- Cash-flow reporting now uses posted cash/bank movement records as its single source; it does not add payment-ledger rows a second time.
- Recognized inflow and outflow types are explicitly enumerated. Unknown types are excluded and disclosed instead of silently being treated as money out.
- Invalid/non-positive amounts and invalid calendar dates are excluded and counted in a visible data-quality warning.
- Opening balances and internal transfers are excluded from operating cash-flow totals.
- Sale and purchase settlement movements are grouped with their source transactions; standalone customer/supplier payments remain separately grouped.
- Added CSV export using the same filtered calculation as the on-screen statement.
- Removed generic PDF/Excel toolbar from cash-flow view because it could export a previously selected report rather than the cash-flow statement.
- No source records are changed by report generation or export.

## Verification
- Node regression suite: **275 passed, 0 failed**.
- TypeScript typecheck: passed.
- Android TypeScript asset generation: passed.
- JavaScript syntax checks: passed.
- JSON metadata parsing: passed.
- GitHub Actions workflow YAML parsing: passed.
- Vite production bundle: not verified; `vite` was not installed and `npm install` timed out in this environment.
- Android Gradle build/signing and physical-device testing: pending GitHub Actions and owner device.

## Release decision
Source-level cash-flow update is tested. This is not a device-certified production APK. Back up business data before installing a test build.
