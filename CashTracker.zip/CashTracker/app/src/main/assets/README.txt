StockPro All-Features AppMint Web Package V5.10.25

This is the full StockPro web implementation from the Android project, including calculator, transaction modules, accounting, finance, people money, reports, returns, cashier, cash/banks, Telegram, theme, profiles, offline storage and Android calculator shortcut bridge support.

index.html is at the root of this folder for AppMint packaging.
Backup import accepts UTF-8 BOM, normal JSON, JSON-string-wrapped files, and data/db/backup wrappers, including older StockPro 5.x backups.
