// ============================================
// REGISTER MODULE FALLBACK
// ============================================

(function() {
    'use strict';
    
    console.log('🔧 Register module fallback initializing...');
    
    // Create registerModule if it doesn't exist
    if (typeof window.registerModule === 'undefined') {
        console.warn('⚠️ module-loader.js not loaded! Creating fallback...');
        
        window.registerModule = function(name, factory) {
            console.log('⚠️ Fallback: Loading', name, 'immediately');
            try {
                factory();
                console.log('✅ Fallback loaded:', name);
                return true;
            } catch (error) {
                console.error('❌ Fallback error loading', name, ':', error);
                return false;
            }
        };
        
        console.log('✅ Register module fallback created');
    } else {
        console.log('✅ registerModule already exists, fallback not needed');
    }
})();