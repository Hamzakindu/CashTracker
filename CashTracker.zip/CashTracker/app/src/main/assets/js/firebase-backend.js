// ============================================
// STOCKPRO CLOUD BACKEND - FIREBASE
// Offline-first + authenticated Firestore backup/sync.
// ============================================
(function(){
    'use strict';

    const STORE_NAMES = [
        'products','sales','purchases','customers','suppliers','supplierAdvances',
        'paymentLedger','expenseTypes','directExpenses','returns','calculations',
        'stockHistory','auditLog','accountingMeta','cashAccounts','moneyTransactions',
        'peopleMoney','peopleMoneyTx','cashierSessions','cashCounts','cashReconciliations','branches','staffUsers','branchAccessMeta'
    ];
    const CHUNK_SIZE = 600000; // stay safely below Firestore's 1 MiB document limit
    const DEVICE_KEY = 'stockpro_cloud_device_id';
    const EMAIL_KEY = 'stockpro_cloud_email';
    const STATUS_ID = 'cloudSyncStatus';
    const CONFIG = window.STOCKPRO_FIREBASE_CONFIG;

    const CloudSync = {
        auth: null,
        db: null,
        user: null,
        ready: false,
        busy: false,
        queue: new Set(),
        timer: null,
        deviceId: null,
        initialized: false,

        init(){
            if(this.initialized) return;
            this.initialized = true;
            this.deviceId = localStorage.getItem(DEVICE_KEY) || this.makeId();
            localStorage.setItem(DEVICE_KEY, this.deviceId);
            if(!window.firebase || !CONFIG){
                this.setStatus('⚪ Cloud backend not loaded');
                return;
            }
            try {
                const app = firebase.apps && firebase.apps.length ? firebase.app() : firebase.initializeApp(CONFIG);
                this.auth = firebase.auth(app);
                this.db = firebase.firestore(app);
                try {
                    this.db.enablePersistence({synchronizeTabs:true}).catch(()=>{});
                } catch(e) {}
                this.auth.onAuthStateChanged(async user=>{
                    this.user = user || null;
                    this.ready = !!user;
                    this.updateHeader();
                    if(user){
                        localStorage.setItem(EMAIL_KEY, user.email || '');
                        this.setStatus('☁️ Signed in: ' + (user.email || ''));
                    } else {
                        this.setStatus('☁️ Not signed in');
                    }
                });
                this.patchStorage();
                this.updateHeader();
                this.setStatus('☁️ Firebase ready');
            } catch(e){
                console.error('Firebase initialization error', e);
                this.setStatus('❌ Firebase error');
            }
        },

        makeId(){ return 'dev_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,10); },
        profilePath(){ return this.db.collection('users').doc(this.user.uid).collection('profiles').doc(State.currentProfileId || 'default'); },

        patchStorage(){
            if(!window.Storage || Storage.__cloudPatched) return;
            const originalSave = Storage.save.bind(Storage);
            const originalRemove = Storage.remove.bind(Storage);
            Storage.save = function(storeName, data){
                const ok = originalSave(storeName, data);
                if(ok && window.CloudSync && CloudSync.ready && STORE_NAMES.indexOf(storeName)>=0) CloudSync.queueStore(storeName);
                return ok;
            };
            Storage.remove = function(storeName){
                const ok = originalRemove(storeName);
                if(ok && window.CloudSync && CloudSync.ready && STORE_NAMES.indexOf(storeName)>=0) CloudSync.queueStore(storeName);
                return ok;
            };
            Storage.__cloudPatched = true;
        },

        queueStore(storeName){
            this.queue.add(storeName);
            clearTimeout(this.timer);
            this.timer = setTimeout(()=>this.flushQueue(), 2500);
        },

        async flushQueue(){
            if(!this.ready || this.busy || !this.queue.size) return;
            const stores = Array.from(this.queue);
            this.queue.clear();
            this.busy = true;
            try {
                for(const store of stores) await this.uploadStore(store);
                this.setStatus('☁️ Synced ' + stores.length + ' store' + (stores.length===1?'':'s'));
            } catch(e){
                console.error('Cloud sync error', e);
                stores.forEach(s=>this.queue.add(s));
                this.setStatus('⚠️ Cloud sync pending');
            } finally { this.busy=false; }
        },

        async uploadStore(storeName){
            if(!this.ready) throw new Error('Sign in first');
            const data = State[storeName] !== undefined ? State[storeName] : Storage.load(storeName);
            const json = JSON.stringify(data === undefined ? [] : data);
            const ref = this.profilePath().collection('stores').doc(storeName);
            const chunks = [];
            for(let i=0;i<json.length;i+=CHUNK_SIZE) chunks.push(json.slice(i,i+CHUNK_SIZE));
            const existing = await ref.collection('chunks').get();
            const batch = this.db.batch();
            existing.forEach(doc=>batch.delete(doc.ref));
            chunks.forEach((chunk,i)=>batch.set(ref.collection('chunks').doc(String(i).padStart(6,'0')),{chunk,index:i,data:chunk,updatedAt:firebase.firestore.FieldValue.serverTimestamp(),deviceId:this.deviceId}));
            batch.set(ref,{chunkCount:chunks.length,size:json.length,updatedAt:firebase.firestore.FieldValue.serverTimestamp(),deviceId:this.deviceId},{merge:true});
            await batch.commit();
            await this.profilePath().set({lastSyncAt:firebase.firestore.FieldValue.serverTimestamp(),lastSyncDevice:this.deviceId,appVersion:(window.CONFIG&&CONFIG.VERSION)||'unknown'},{merge:true});
        },

        async downloadStore(storeName){
            if(!this.ready) throw new Error('Sign in first');
            const ref = this.profilePath().collection('stores').doc(storeName);
            const snap = await ref.get();
            if(!snap.exists) return false;
            const meta = snap.data() || {};
            const q = await ref.collection('chunks').orderBy('index').get();
            let json=''; q.forEach(doc=>{ json += (doc.data().data || ''); });
            if(!json) return false;
            const parsed = JSON.parse(json);
            Storage.save(storeName, parsed);
            return {count:meta.chunkCount || q.size};
        },

        async hasCloudData(){
            if(!this.ready) return false;
            const snap = await this.profilePath().get();
            return snap.exists && !!snap.data().lastSyncAt;
        },

        async uploadAll(){
            if(!this.ready){ this.openAuth(); return false; }
            if(this.busy) return false;
            if(!confirm('Upload the current StockPro profile to Firebase?\n\nThis becomes the cloud copy for this profile.')) return false;
            this.busy=true;
            try {
                for(const store of STORE_NAMES) await this.uploadStore(store);
                Toast.success('☁️ StockPro data uploaded to Firebase');
                this.setStatus('☁️ Cloud backup complete');
                return true;
            } catch(e){ console.error(e); Toast.error('Cloud upload failed: '+e.message); return false; }
            finally { this.busy=false; }
        },

        async downloadAll(){
            if(!this.ready){ this.openAuth(); return false; }
            if(this.busy) return false;
            if(!await this.hasCloudData()) { Toast.warning('No cloud data exists for this profile yet.'); return false; }
            if(!confirm('Download the cloud copy and replace this device profile?\n\nExport a local backup first if you have unsynced changes.')) return false;
            this.busy=true;
            try {
                if(window.State && State.saveUndoState) State.saveUndoState('Before Firebase restore');
                let count=0;
                for(const store of STORE_NAMES){ const ok=await this.downloadStore(store); if(ok) count++; }
                await State.loadAllData();
                this.refreshApp();
                Toast.success('☁️ Cloud data restored ('+count+' stores)');
                this.setStatus('☁️ Cloud restore complete');
                return true;
            } catch(e){ console.error(e); Toast.error('Cloud restore failed: '+e.message); return false; }
            finally { this.busy=false; }
        },

        async signUp(email,password){
            if(!this.auth) throw new Error('Firebase is not available');
            if(!email || !password) throw new Error('Email and password are required');
            if(password.length < 6) throw new Error('Password must be at least 6 characters');
            const cred=await this.auth.createUserWithEmailAndPassword(email,password);
            this.user=cred.user; this.ready=true; this.updateHeader();
            await this.profilePath().set({profileId:State.currentProfileId||'default',createdAt:firebase.firestore.FieldValue.serverTimestamp(),createdBy:this.deviceId},{merge:true});
            Toast.success('☁️ Account created');
            return cred.user;
        },

        async signIn(email,password){
            if(!this.auth) throw new Error('Firebase is not available');
            const cred=await this.auth.signInWithEmailAndPassword(email,password);
            this.user=cred.user; this.ready=true; this.updateHeader();
            Toast.success('☁️ Signed in to StockPro Cloud');
            return cred.user;
        },

        async signOut(){ if(this.auth) await this.auth.signOut(); this.user=null; this.ready=false; this.updateHeader(); this.setStatus('☁️ Not signed in'); },

        openAuth(){
            let m=document.getElementById('cloudAuthModal');
            if(!m){
                m=document.createElement('div'); m.className='modal-overlay'; m.id='cloudAuthModal';
                m.innerHTML='<div class="modal" style="max-width:440px"><button class="close-btn" onclick="Modals.close(\'cloudAuthModal\')">✕</button><h3>☁️ StockPro Cloud</h3><p style="opacity:.75">Use your Firebase account to securely back up and restore this StockPro profile.</p><div id="cloudAuthMessage" style="margin:8px 0;font-size:.85rem"></div><div class="form-group"><label>Email</label><input id="cloudEmail" class="form-control" type="email" autocomplete="username"></div><div class="form-group"><label>Password</label><input id="cloudPassword" class="form-control" type="password" autocomplete="current-password"></div><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn-primary" onclick="CloudSync.loginFromModal()">Sign in</button><button class="btn btn-success" onclick="CloudSync.signupFromModal()">Create account</button></div><hr><button class="btn btn-outline" style="width:100%" onclick="CloudSync.passwordResetFromModal()">Send password reset email</button></div>';
                document.body.appendChild(m);
            }
            const saved=localStorage.getItem(EMAIL_KEY)||''; document.getElementById('cloudEmail').value=saved; document.getElementById('cloudPassword').value='';
            Modals.open('cloudAuthModal');
        },
        async loginFromModal(){
            try{await this.signIn(document.getElementById('cloudEmail').value.trim(),document.getElementById('cloudPassword').value);Modals.close('cloudAuthModal');}
            catch(e){document.getElementById('cloudAuthMessage').textContent='❌ '+this.authError(e);}
        },
        async signupFromModal(){
            try{await this.signUp(document.getElementById('cloudEmail').value.trim(),document.getElementById('cloudPassword').value);Modals.close('cloudAuthModal');}
            catch(e){document.getElementById('cloudAuthMessage').textContent='❌ '+this.authError(e);}
        },
        async passwordResetFromModal(){
            try{const email=document.getElementById('cloudEmail').value.trim();if(!email)throw new Error('Enter your email first');await this.auth.sendPasswordResetEmail(email);Toast.success('Password reset email sent');}
            catch(e){document.getElementById('cloudAuthMessage').textContent='❌ '+this.authError(e);}
        },
        authError(e){
            const map={'auth/invalid-email':'Invalid email address.','auth/user-not-found':'No account found for this email.','auth/wrong-password':'Incorrect password.','auth/invalid-credential':'Email or password is incorrect.','auth/email-already-in-use':'That email already has an account.','auth/weak-password':'Use a stronger password (at least 6 characters).','auth/operation-not-allowed':'Email/Password sign-in is not enabled in Firebase Console.'};
            return map[e&&e.code] || (e&&e.message) || 'Authentication failed.';
        },

        openPanel(){
            if(!this.ready) return this.openAuth();
            let m=document.getElementById('cloudPanelModal');
            if(!m){
                m=document.createElement('div');m.className='modal-overlay';m.id='cloudPanelModal';
                m.innerHTML='<div class="modal" style="max-width:460px"><button class="close-btn" onclick="Modals.close(\'cloudPanelModal\')">✕</button><h3>☁️ StockPro Cloud</h3><div id="cloudPanelUser" style="margin-bottom:12px"></div><div style="display:grid;gap:8px"><button class="btn btn-primary" onclick="CloudSync.uploadAll()">⬆️ Upload current data</button><button class="btn btn-success" onclick="CloudSync.downloadAll()">⬇️ Restore cloud data</button><button class="btn btn-outline" onclick="CloudSync.flushQueue()">🔄 Sync pending changes</button><button class="btn btn-danger" onclick="CloudSync.signOut();Modals.close(\'cloudPanelModal\')">Sign out</button></div><p style="font-size:.75rem;opacity:.7;margin-top:12px">Cloud data is separated by Firebase account and StockPro profile. Keep regular exported backups too.</p></div>';
                document.body.appendChild(m);
            }
            document.getElementById('cloudPanelUser').textContent='Signed in as: '+(this.user.email||'');Modals.open('cloudPanelModal');
        },

        setStatus(text){
            const el=document.getElementById(STATUS_ID); if(el) el.textContent=text;
        },
        updateHeader(){
            const logged=!!this.user;
            const el=document.getElementById(STATUS_ID); if(el) el.textContent=logged?'☁️ Cloud: '+(this.user.email||'Signed in'):'☁️ Cloud: Sign in';
            const btn=document.getElementById('cloudMainButton'); if(btn) btn.textContent=logged?'☁️ Cloud account':'☁️ Sign in to Cloud';
            document.querySelectorAll('.offline-badge').forEach(b=>{b.textContent=navigator.onLine?(logged?'CLOUD':'ONLINE'):'OFFLINE';});
        },
        refreshApp(){
            try{
                App.populateDropdowns(); Dashboard.update(); Products.render(); Sales.render(); Purchases.render(); Customers.render(); Suppliers.render(); Expenses.renderTypes(); Expenses.renderDirect(); Returns.render();
                if(window.CashBanks) CashBanks.render(); if(window.PeopleMoney) PeopleMoney.render(); if(window.Cashier) Cashier.render(); if(window.FinanceControl) FinanceControl.render();
            }catch(e){console.warn('Cloud UI refresh:',e);}
        }
    };

    window.CloudSync=CloudSync;
    document.addEventListener('DOMContentLoaded',()=>setTimeout(()=>CloudSync.init(),50));
    window.addEventListener('online',()=>{CloudSync.updateHeader(); if(CloudSync.ready) CloudSync.flushQueue();});
    window.addEventListener('offline',()=>CloudSync.updateHeader());
})();
