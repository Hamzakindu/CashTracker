// APP LOCK: PIN screen on start and after the app was in the background for a minute
(function(){'use strict';
var K='SP_lock',ov=null,fails=0,until=0,hiddenAt=0,enc=new TextEncoder();
function get(){try{return JSON.parse(localStorage.getItem(K)||'null')}catch(e){return null}}
async function h(pin,salt){try{var b=await crypto.subtle.digest('SHA-256',enc.encode(salt+':'+pin));return Array.from(new Uint8Array(b)).map(function(x){return x.toString(16).padStart(2,'0')}).join('')}
  catch(e){var s=salt+':'+pin,x=5381;for(var i=0;i<s.length;i++)x=((x<<5)+x+s.charCodeAt(i))|0;return 'f'+x}}
async function set(pin){var salt=Math.random().toString(36).slice(2)+Date.now().toString(36);localStorage.setItem(K,JSON.stringify({salt:salt,hash:await h(pin,salt)}))}
async function verify(pin){var d=get();return !!d&&(await h(pin,d.salt))===d.hash}
function show(){
  if(ov||!get()||!document.body)return;
  ov=document.createElement('div');ov.id='appLockOverlay';
  ov.style.cssText='position:fixed;inset:0;z-index:2147483000;background:#0d1b3d;color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:24px;text-align:center';
  ov.innerHTML='<div style="font-size:48px">🔒</div><div style="font-size:20px;font-weight:700">StockPro is locked</div><input id="lockPin" type="password" inputmode="numeric" autocomplete="off" maxlength="8" placeholder="Enter PIN" style="font-size:24px;text-align:center;padding:10px;border-radius:10px;border:0;width:200px"><div id="lockMsg" style="min-height:20px;color:#ffb4b4"></div><button id="lockBtn" style="font-size:18px;padding:10px 28px;border:0;border-radius:10px;background:#0d6efd;color:#fff">Unlock</button>';
  document.body.appendChild(ov);
  var inp=ov.querySelector('#lockPin'),msg=ov.querySelector('#lockMsg');
  var go=async function(){
    if(Date.now()<until){msg.textContent='Too many tries. Wait '+Math.ceil((until-Date.now())/1000)+'s';return}
    if(await verify(inp.value)){fails=0;ov.remove();ov=null}
    else{fails++;inp.value='';msg.textContent='Wrong PIN';if(fails>=5){until=Date.now()+30000;fails=0;msg.textContent='Too many tries. Wait 30s'}}
  };
  ov.querySelector('#lockBtn').onclick=go;
  inp.addEventListener('keydown',function(e){if(e.key==='Enter')go()});
  setTimeout(function(){inp.focus()},100);
}
document.addEventListener('visibilitychange',function(){
  if(document.hidden)hiddenAt=Date.now();else if(get()&&hiddenAt&&Date.now()-hiddenAt>60000)show();
});
window.AppLock={has:function(){return !!get()},set:set,verify:verify,remove:function(){localStorage.removeItem(K)},lock:show};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',show);else show();
})();
