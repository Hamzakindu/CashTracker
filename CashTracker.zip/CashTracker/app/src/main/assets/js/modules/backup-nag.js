// BACKUP REMINDER: remembers the last backup file and asks when it is overdue
(function(){'use strict';
const K='SP_last_file_backup',N='SP_backup_nag';
function wrap(){
  if(typeof Backup==='undefined'||!Backup.exportBackup||Backup._nag)return;Backup._nag=true;
  const o=Backup.exportBackup.bind(Backup);
  Backup.exportBackup=function(){localStorage.setItem(K,new Date().toISOString());return o.apply(Backup,arguments)};
}
setTimeout(function(){
  wrap();
  try{
    const has=(State.products||[]).length||(State.sales||[]).length;if(!has)return;
    const last=localStorage.getItem(K),days=last?Math.floor((Date.now()-new Date(last))/864e5):null;
    const today=new Date().toISOString().slice(0,10);
    if((days===null||days>=7)&&localStorage.getItem(N)!==today){
      localStorage.setItem(N,today);
      if(confirm('💾 '+(days===null?'You have not saved a backup file yet.':'Your last backup was '+days+' days ago.')+'\nBack up now? The file is saved to Downloads.'))Backup.exportBackup();
    }
  }catch(e){}
},7000);
})();
