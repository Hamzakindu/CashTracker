// ============================================
// RETURNS MODULE
// ============================================

(function() {
    'use strict';
    
    const MODULE_NAME = 'Returns';
    
    console.log('📦 Registering ' + MODULE_NAME + '...');
    
    window.registerModule(MODULE_NAME, function() {
        console.log('✅ ' + MODULE_NAME + ' initializing...');
        
        const Returns = {
            openModal() {
                let modal = document.getElementById('returnModal');
                if (!modal) {
                    modal = document.createElement('div');
                    modal.className = 'modal-overlay';
                    modal.id = 'returnModal';
                    modal.innerHTML = `
                        <div class="modal" style="max-width:450px;">
                            <button class="close-btn" onclick="Modals.close('returnModal')">✕</button>
                            <h3>↩️ Process Return</h3>
                            <div class="form-group"><label>Date</label><input class="form-control" type="date" id="returnDate"></div>
                            <div class="form-group"><label>Product</label><select class="form-control" id="returnProductId"><option value="">-- Select --</option></select></div>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                                <div class="form-group"><label>Quantity</label><input class="form-control" id="returnQty" type="number" min="1" value="1"></div>
                                <div class="form-group"><label>Refund/unit</label><input class="form-control" id="returnRefund" type="number" step="0.01" placeholder="0"></div>
                            </div>
                            <button class="btn btn-warning" onclick="Returns.submit()">↩️ Process Return</button>
                        </div>
                    `;
                    document.body.appendChild(modal);
                }

                document.getElementById('returnDate').value = Helpers.getToday();
                document.getElementById('returnQty').value = '1';
                document.getElementById('returnRefund').value = '';
                
                App.populateDropdowns();
                Modals.open('returnModal');
            },

            submit() {
                const productId = document.getElementById('returnProductId').value;
                const qty = Number(document.getElementById('returnQty').value);
                if (!productId || !Number.isFinite(qty) || qty <= 0) return Toast.warning('Select product and valid quantity');
                const refund = Number(document.getElementById('returnRefund').value) || 0;
                if (refund < 0) return Toast.warning('Refund cannot be negative');
                const product = State.products.find(p => p.id === productId);
                if (!product) return Toast.warning('Product not found');
                const date = document.getElementById('returnDate').value || Helpers.getToday();
                try {
                    State.saveUndoState(`Return: ${product.name} x${qty}`);
                    State.runAtomic('Process return', () => {
                        product.stock += qty;
                        if (window.StockHistory) StockHistory.recordChange(product.id, product.name, qty, 'Stock return', 'return');
                        State.returns.push({ id: Helpers.uid(), productId, productName: product.name, quantity: qty, refundPerUnit: refund, totalRefund: refund * qty, date, createdAt: new Date().toISOString() });
                    });
                    Toast.success(`Return processed: ${product.name} x${qty}`); Modals.close('returnModal'); this.render(); Products.render(); Dashboard.update();
                } catch (error) { Toast.error('Return failed: ' + (error.message || error)); }
            },

            render() {
                const container = document.getElementById('returnList');
                if (!container) return;

                if (!State.returns.length) {
                    container.innerHTML = '<div class="empty-state">No returns recorded</div>';
                    return;
                }

                const sorted = State.returns
                    .slice()
                    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

                container.innerHTML = sorted.map(r => `
                   <div class="list-item" onclick=" showDetail('return', '${r.id}')" style="cursor:pointer;">
                        <div class="info">
                            <span class="title">${Helpers.esc(r.productName)} x${r.quantity}</span>
                            <span class="meta">${Helpers.formatDate(r.date)}</span>
                        </div>
                        <div>Refund: ${Helpers.formatCurrency(r.totalRefund || 0)}</div>
                    </div>
                `).join('');
            }
        };
        
        window.Returns = Returns;
        console.log('✅ ' + MODULE_NAME + ' loaded successfully');
        return Returns;
    });
    
})();