/* StockPro V5.10.36 — Global Search and Transaction 360 entry point.
   Read-only navigation layer: does not modify business records. */
(function(){
  'use strict';
  const collections = [
    {key:'products', label:'Product', icon:'📦', detail:'product', fields:['name','barcode','sku','category','notes','id']},
    {key:'customers', label:'Customer', icon:'👤', detail:'customer', fields:['name','contact','phone','address','id']},
    {key:'suppliers', label:'Supplier', icon:'🏢', detail:'supplier', fields:['name','contact','phone','address','id']},
    {key:'sales', label:'Sale', icon:'💰', detail:'sale', fields:['id','invoiceNo','number','customer','customerName','date','total','paid','debit','notes']},
    {key:'purchases', label:'Purchase', icon:'📥', detail:'purchase', fields:['id','invoiceNo','number','supplier','supplierName','date','total','paid','debit','notes']},
    {key:'returns', label:'Return', icon:'↩️', detail:'return', fields:['id','type','customer','supplier','productName','date','amount','total','notes']},
    {key:'directExpenses', label:'Expense', icon:'💸', detail:null, fields:['id','name','type','category','date','amount','paid','notes','description']},
    {key:'paymentLedger', label:'Payment', icon:'💳', detail:null, fields:['id','type','sourceType','entityName','customerName','supplierName','date','amount','method','reference','notes']},
    {key:'moneyTransactions', label:'Cash/Bank movement', icon:'🏦', detail:null, fields:['id','type','accountName','description','date','amount','reference','notes']},
    {key:'peopleMoney', label:'People Money', icon:'👥', detail:null, fields:['id','name','contact','phone','address','notes']}
  ];
  function esc(v){ return String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function val(o, keys){ for(const k of keys){ if(o && o[k]!==undefined && o[k]!==null && typeof o[k]!=='object' && String(o[k]).trim()!=='') return o[k]; } return ''; }
  function flatten(o, depth){ if(o==null||depth>3)return ''; if(typeof o!=='object')return String(o); return Object.keys(o).map(k=>k+' '+flatten(o[k],depth+1)).join(' '); }
  function money(o){const n=Number(val(o,['total','amount','grandTotal','paid','debit','balance'])); return Number.isFinite(n)&&n?('ETB '+n.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})):'';}
  function date(o){return val(o,['date','createdAt','timestamp','time']);}
  function open(){
    if(typeof State==='undefined'){alert('StockPro is still loading. Please try again.');return;}
    let modal=document.getElementById('globalSearchModal');
    if(!modal){
      modal=document.createElement('div'); modal.id='globalSearchModal'; modal.className='modal-overlay';
      modal.style.zIndex='10050';
      modal.innerHTML='<div class="modal" style="max-width:900px;width:96%;max-height:88vh;overflow:auto"><button class="close-btn" id="globalSearchClose">✕</button><h3>🔎 Global Search & Transaction 360°</h3><p style="color:var(--text2)">Search products, people, sales, purchases, returns, expenses and payments. This view is read-only.</p><input id="globalSearchInput" type="search" autocomplete="off" placeholder="Name, phone, barcode, invoice, date, amount, notes…" style="width:100%;box-sizing:border-box;padding:13px;border:1px solid var(--border);border-radius:9px;background:var(--card);color:var(--text);font-size:16px"><div id="globalSearchHint" style="margin:10px 0;color:var(--text2)">Type at least 2 characters.</div><div id="globalSearchResults"></div></div>';
      document.body.appendChild(modal);
      modal.addEventListener('click',e=>{if(e.target===modal)modal.style.display='none';});
      modal.querySelector('#globalSearchClose').addEventListener('click',()=>modal.style.display='none');
      modal.querySelector('#globalSearchInput').addEventListener('input',()=>{clearTimeout(window.__stockProSearchTimer);window.__stockProSearchTimer=setTimeout(render,120);});
      modal.querySelector('#globalSearchInput').addEventListener('keydown',e=>{if(e.key==='Escape')modal.style.display='none';});
    }
    modal.style.display='flex';
    const input=modal.querySelector('#globalSearchInput'); input.value=''; modal.querySelector('#globalSearchResults').innerHTML=''; modal.querySelector('#globalSearchHint').textContent='Type at least 2 characters.'; setTimeout(()=>input.focus(),50);
  }
  function render(){
    const modal=document.getElementById('globalSearchModal'); if(!modal)return;
    const q=modal.querySelector('#globalSearchInput').value.trim().toLocaleLowerCase();
    const out=modal.querySelector('#globalSearchResults'), hint=modal.querySelector('#globalSearchHint');
    if(q.length<2){hint.textContent='Type at least 2 characters.';out.innerHTML='';return;}
    const found=[];
    collections.forEach(c=>{
      const arr=Array.isArray(State[c.key])?State[c.key]:[];
      arr.forEach((record,index)=>{
        if(!record||typeof record!=='object')return;
        if(flatten(record,0).toLocaleLowerCase().includes(q)){
          found.push({c,record,index,name:val(record,['name','productName','customerName','supplierName','entityName','description','invoiceNo','number','reference'])||c.label+' #'+(index+1),id:record.id,dt:date(record),amount:money(record)});
        }
      });
    });
    const limited=found.slice(0,100);
    hint.textContent=found.length+' result(s)'+(found.length>100?' — showing first 100':'')+'. Select a result to inspect it.';
    if(!limited.length){out.innerHTML='<div style="padding:18px;text-align:center;color:var(--text2)">No matching records found.</div>';return;}
    out.innerHTML='<div style="display:grid;gap:8px">'+limited.map((r,i)=>'<button type="button" data-result-index="'+i+'" style="text-align:left;padding:12px;border:1px solid var(--border);border-radius:9px;background:var(--card);color:var(--text);cursor:pointer"><div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><strong>'+r.c.icon+' '+esc(r.name)+'</strong><span style="font-size:12px;padding:2px 7px;border-radius:20px;background:var(--bg);border:1px solid var(--border)">'+esc(r.c.label)+'</span><span style="margin-left:auto;color:var(--text2);font-size:12px">'+esc(r.dt)+'</span></div><div style="margin-top:5px;color:var(--text2);font-size:13px">'+esc(val(r.record,['contact','phone','barcode','invoiceNo','reference','category','type','notes','address']))+(r.amount?' · '+esc(r.amount):'')+'</div></button>').join('')+'</div>';
    out.querySelectorAll('[data-result-index]').forEach(btn=>btn.addEventListener('click',()=>{
      const r=limited[Number(btn.getAttribute('data-result-index'))]; modal.style.display='none';
      if(r.c.detail && r.id!=null && window.TransactionDetail && typeof TransactionDetail.show==='function'){
        TransactionDetail.show(r.c.detail,r.id);
      } else {
        const detail=document.getElementById('detailModalContent'), title=document.getElementById('detailModalTitle');
        if(detail&&title&&window.Modals){title.textContent=r.c.icon+' '+r.c.label+' — '+r.name;detail.innerHTML='<div class="detail-section"><h4>Record details (read-only)</h4>'+Object.keys(r.record).map(k=>'<div class="detail-row"><span class="detail-label">'+esc(k)+'</span><span class="detail-value" style="overflow-wrap:anywhere">'+esc(typeof r.record[k]==='object'?JSON.stringify(r.record[k]):r.record[k])+'</span></div>').join('')+'</div>';Modals.open('detailModal');}
        else alert(r.c.label+': '+r.name+'\n'+JSON.stringify(r.record,null,2));
      }
    }));
  }
  function attach(){
    const headers=document.querySelectorAll('.header .header-item');
    headers.forEach(h=>{if(h.querySelector('.logo')&&!h.querySelector('[data-global-search]')){const b=document.createElement('button');b.type='button';b.setAttribute('data-global-search','1');b.textContent='🔎 Search';b.title='Global search (Ctrl+K)';b.style.cssText='margin-left:8px;padding:7px 10px;border:1px solid var(--border);border-radius:8px;background:var(--card);color:var(--text);cursor:pointer';b.addEventListener('click',open);h.appendChild(b);}});
  }
  window.StockProGlobalSearch={open};
  document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();open();}});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',attach);else attach();
})();
