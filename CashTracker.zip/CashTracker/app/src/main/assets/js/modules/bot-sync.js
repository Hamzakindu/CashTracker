// BOT SYNC: sends a summary of your data to your Cloudflare Telegram bot so it can answer commands
(function(){'use strict';
window.registerModule('BotSync',function(){
const URLK='SP_bot_url',KEYK='SP_bot_key',LASTK='SP_bot_last';
const store=()=>{try{return JSON.parse(localStorage.getItem('stockProfile')||'{}').storeName||'StockPro'}catch(e){return 'StockPro'}};
const num=v=>Number(v)||0;
function snapshot(){
  CashBanks.init();const t=Helpers.getToday();
  const sales=(State.sales||[]).filter(s=>String(s.date||'').slice(0,10)===t&&!s.voided&&s.status!=='void');
  const exps=(State.directExpenses||[]).filter(e=>String(e.date||'').slice(0,10)===t);
  const min=p=>(p.minStock!=null&&p.minStock!=='')?num(p.minStock):5;
  const byBal=(a,b)=>b.bal-a.bal;
  return{v:1,ts:new Date().toISOString(),store:store(),
    today:{sales:sales.reduce((a,s)=>a+num(s.total),0),count:sales.length,expenses:exps.reduce((a,e)=>a+num(e.amount),0)},
    accounts:CashBanks.accounts().map(a=>({name:a.name,bal:CashBanks.balance(a.id)})),
    owed:(State.customers||[]).filter(c=>num(c.balance)>0).map(c=>({name:c.name,bal:num(c.balance)})).sort(byBal),
    owe:(State.suppliers||[]).filter(s=>num(s.balance)>0).map(s=>({name:s.name,bal:num(s.balance)})).sort(byBal),
    low:(State.products||[]).filter(p=>num(p.stock)<=min(p)).map(p=>({name:p.name,stock:num(p.stock),min:min(p)})).slice(0,60),
    products:(State.products||[]).slice(0,2000).map(p=>({n:p.name,p:num(p.sell),s:num(p.stock),c:p.category||''})),
    customers:(State.customers||[]).slice(0,2000).map(c=>({n:c.name,b:num(c.balance)}))};
}
async function push(manual){
  const url=(localStorage.getItem(URLK)||'').trim().replace(/\/+$/,''),key=localStorage.getItem(KEYK)||'';
  if(!url||!key){if(manual)Toast.warning('Enter the Worker address and the key first');return false}
  try{
    const body=JSON.stringify(snapshot());
    const r=await fetch(url+'/snapshot',{method:'POST',keepalive:body.length<60000,headers:{'Content-Type':'application/json','X-Push-Key':key},body});
    if(r.ok){localStorage.setItem(LASTK,new Date().toISOString());if(manual)Toast.success('✅ Bot data updated');return true}
    if(manual)Toast.error(r.status===403?'The key does not match the one in your Worker':'The Worker answered '+r.status);
    return false;
  }catch(e){if(manual)Toast.error('Could not reach the Worker. Check the address and internet.');return false}
}
const BotSync={
  snapshot,
  push,
  lastText(){const v=localStorage.getItem(LASTK);return v?new Date(v).toLocaleString():'never'},
  save(){
    const u=(document.getElementById('botUrl')?.value||'').trim(),k=(document.getElementById('botKey')?.value||'').trim();
    if(!/^https:\/\//.test(u))return Toast.warning('The address must start with https://');
    if(k.length<12)return Toast.warning('Use a longer key (at least 12 characters)');
    localStorage.setItem(URLK,u);localStorage.setItem(KEYK,k);Toast.success('Saved');push(true).then(()=>{if(window.Tools)Tools.render()});
  },
  now(){push(true).then(()=>{if(window.Tools)Tools.render()})},
  url(){return localStorage.getItem(URLK)||''},
  key(){return localStorage.getItem(KEYK)||''},
  clear(){localStorage.removeItem(URLK);localStorage.removeItem(KEYK);Toast.success('Bot connection removed');if(window.Tools)Tools.render()}
};
window.BotSync=BotSync;
// Send to the bot soon after any change that affects prices, stock or balances
const WATCH=['products','sales','returns','purchases','customers','suppliers','supplierAdvances','paymentLedger','directExpenses','cashAccounts','moneyTransactions'];
let dirty=false,timer=null,lastAt=0;
function later(){
  dirty=true;clearTimeout(timer);
  const wait=Math.max(4000,20000-(Date.now()-lastAt));
  timer=setTimeout(flush,wait);
}
async function flush(){
  if(!dirty)return;
  if(!(localStorage.getItem(URLK)||'').trim()||!localStorage.getItem(KEYK))return;
  dirty=false;lastAt=Date.now();
  const ok=await push(false);
  if(!ok){dirty=true;clearTimeout(timer);timer=setTimeout(flush,60000)}
}
try{
  if(window.Storage&&!Storage.__botPatched){
    const orig=Storage.save.bind(Storage);
    Storage.save=function(name,data){const ok=orig(name,data);if(ok&&WATCH.indexOf(name)>=0)later();return ok};
    Storage.__botPatched=true;
  }
}catch(e){}
setTimeout(()=>push(false),8000);
setInterval(()=>{if(!document.hidden)push(false)},10*60*1000);
// Send when the app comes back, when it goes to the background, and when the internet returns
document.addEventListener('visibilitychange',()=>{if(document.hidden){if(dirty)flush()}else push(false)});
window.addEventListener('pagehide',()=>{if(dirty)flush()});
window.addEventListener('online',()=>push(false));
return BotSync;});
})();
