// BANK SMS INBOX: captured bank/wallet SMS -> review -> post into Cash & Banks (and Expenses)
(function(){'use strict';
window.registerModule('BankSMS',function(){
const KEY='bankSmsInbox';let items=[],view='pending';
const DEB=/debited|spent|purchase|withdrawn|withdrawal|paid|payment|sent|charged|deducted|transferred|bought/i;
const CRE=/credited|received|deposit|salary|refund|cashback/i;
const num=s=>parseFloat(String(s).replace(/,/g,''));
const esc=s=>Helpers.esc(String(s==null?'':s));
const fmt=n=>Helpers.formatCurrency(Number(n)||0);
const warn=m=>window.Toast&&Toast.warning?Toast.warning(m):alert(m);
const hash=s=>{let h=5381;for(let i=0;i<s.length;i++)h=((h<<5)+h+s.charCodeAt(i))|0;return String(h)};
const ymd=ts=>{const d=new Date(ts),p=n=>String(n).padStart(2,'0');return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())};
const load=()=>{try{const v=Storage.load(KEY);items=Array.isArray(v)?v:[]}catch(e){items=[]}};
const save=()=>{if(items.length>400){const k=items.filter(x=>x.status==='pending');items=k.concat(items.filter(x=>x.status!=='pending').slice(0,Math.max(0,400-k.length))).sort((a,b)=>b.ts-a.ts)}Storage.save(KEY,items)};
function parse(body){
  let t=String(body||''),bal=null,b=t;
  const bm=t.match(/\b(?:current balance|available balance|avl\.?\s*bal(?:ance)?|balance|bal)\s*(?:is|:)?\s*(?:etb|birr|br|[A-Za-z$€£₹₦]{0,3}\.?)\s*(\d[\d,]*(?:\.\d+)?)/i);
  if(bm){bal=num(bm[1]);b=t.replace(bm[0],' ')}
  let m=b.match(/(?:\b(?:etb|birr|br|rs\.?|inr|usd|egp|kes|ngn|sar|aed|eur|gbp)|[$€£₦₹])\s*(\d[\d,]*(?:\.\d+)?)/i)
     ||b.match(/(\d[\d,]*(?:\.\d+)?)\s*(?:etb|birr|br|rs|inr|usd|egp|kes|ngn|sar|aed|eur|gbp|[$€£₦₹])(?![a-z])/i)
     ||b.match(/(?:debited|credited|spent|paid|received|withdrawn|sent|transferred|amount|amt)\D{0,15}(\d[\d,]*(?:\.\d+)?)/i);
  if(!m)return null;const amt=num(m[1]);if(!(amt>0))return null;
  const d=b.search(DEB),c=b.search(CRE),dir=c>=0&&(d<0||c<d)?'in':'out';
  const mm=b.match(/(?:\bat|\bto|\bfrom|@|towards)\s+([A-Za-z0-9&.'\- ]{2,30}?)(?=\s+(?:on|using|via|ref|bal|a\/c|acct|card|dated|with|your|and)\b|[.,;(]|$)/i);
  return{amount:amt,dir,who:mm?mm[1].trim():'',bal};
}
function ingest(list){
  load();let added=0;
  (list||[]).forEach((m,i)=>{try{
    const body=String(m.body||'').trim();if(!body)return;
    const ts=m.ts||Date.now()+i,h=hash(m.paste?body:body+'|'+ts);
    if(items.some(x=>x.hash===h))return;
    const p=parse(body);
    items.unshift(Object.assign({id:'s'+Date.now().toString(36)+Math.random().toString(36).slice(2,6),hash:h,ts,date:ymd(ts),from:m.from||'',raw:body.slice(0,240),status:p?'pending':'unparsed'},p||{amount:0,dir:'out',who:'',bal:null}));
    added++;
  }catch(e){console.error('SMS ingest',e)}});
  if(added){items.sort((a,b)=>b.ts-a.ts);save();badge();if(isActive())render()}
  return added;
}
function pull(){
  try{if(!window.Android||!Android.drain)return 0;
    const n=ingest(JSON.parse(Android.drain()||'[]'));
    if(n&&window.Toast&&Toast.success)Toast.success(n+' new bank SMS');return n;
  }catch(e){console.error(e);return 0}
}
const isActive=()=>document.getElementById('tab-banksms')?.classList.contains('active');
function badge(){
  const n=items.filter(x=>x.status==='pending').length,b=document.querySelector('.tab-btn[data-tab="banksms"]');
  if(b)b.textContent='📩 Bank SMS'+(n?' ('+n+')':'');
}
function guessAccount(it){
  const accs=CashBanks.accounts().filter(a=>a.type!=='cash'),low=(it.raw+' '+(it.from||'')).toLowerCase();
  const a=accs.find(a=>{const n=String(a.accountNumber||'');return n.length>=4&&low.includes(n.slice(-4))})
    ||accs.find(a=>a.bankName&&low.includes(String(a.bankName).toLowerCase().split(/\s+/)[0]))
    ||accs.find(a=>a.name&&low.includes(String(a.name).toLowerCase()));
  return (a||accs[0]||{}).id||'';
}
function guessType(it){
  const low=((it.who||'')+' '+it.raw).toLowerCase();
  const t=(State.expenseTypes||[]).find(e=>String(e.name||'').toLowerCase().split(/\s+/).some(w=>w.length>=4&&low.includes(w)));
  return t?t.id:'';
}
function card(it){
  const accs=CashBanks.accounts(),isIn=it.dir==='in',acc=it.accountId||guessAccount(it),typ=it.typeId||guessType(it)||'direct';
  const types=[{id:'direct',name:'General Expense'}].concat(State.expenseTypes||[]);
  return `<div class="card" style="margin:8px 0;padding:10px">
  <div class="flex-between"><b style="font-size:17px;color:${isIn?'#198754':'#dc3545'}">${isIn?'+':'−'} ${fmt(it.amount)}</b><small>${esc(it.date)}</small></div>
  <div>${esc(it.who||'Bank SMS')}${it.bal!=null?' · bank balance '+fmt(it.bal):''}</div>
  <small style="opacity:.7;display:block;margin:4px 0">${esc(it.raw)}</small>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
   <select class="form-control" onchange="BankSMS.set('${it.id}','dir',this.value)"><option value="in"${isIn?' selected':''}>Money in</option><option value="out"${isIn?'':' selected'}>Money out</option></select>
   <select class="form-control" onchange="BankSMS.set('${it.id}','accountId',this.value)"><option value="">-- Account --</option>${accs.map(a=>`<option value="${esc(a.id)}"${a.id===acc?' selected':''}>${esc(a.name)}</option>`).join('')}</select>
   ${isIn?'':`<select class="form-control" style="grid-column:1/-1" onchange="BankSMS.set('${it.id}','typeId',this.value)">${types.map(e=>`<option value="${esc(e.id)}"${e.id===typ?' selected':''}>${esc(e.name)}</option>`).join('')}</select>`}
  </div>
  <div style="margin-top:8px;display:flex;gap:8px"><button class="btn btn-success btn-sm" onclick="BankSMS.post('${it.id}')">✓ Post</button><button class="btn btn-outline btn-sm" onclick="BankSMS.ignore('${it.id}')">✕ Ignore</button></div></div>`;
}
function groups(){
  const g={};let tin=0,tout=0;
  items.filter(x=>x.status==='posted').forEach(x=>{const k=x.category||(x.dir==='in'?'Money received':'Other');(g[k]=g[k]||{n:0,t:0,dir:x.dir});g[k].n++;g[k].t+=x.amount;x.dir==='in'?tin+=x.amount:tout+=x.amount});
  const rows=Object.entries(g).sort((a,b)=>b[1].t-a[1].t);
  if(!rows.length)return '<div class="empty-state">Nothing posted yet. Posted SMS are grouped here by category.</div>';
  return `<div class="card"><div class="flex-between"><b style="color:#198754">In ${fmt(tin)}</b><b style="color:#dc3545">Out ${fmt(tout)}</b></div>
  <div style="overflow:auto"><table class="transaction-table"><thead><tr><th>Category</th><th>Count</th><th>Total</th></tr></thead><tbody>${rows.map(([k,v])=>`<tr><td>${esc(k)}</td><td>${v.n}</td><td style="color:${v.dir==='in'?'#198754':'#dc3545'}"><b>${fmt(v.t)}</b></td></tr>`).join('')}</tbody></table></div></div>`;
}
function history(){
  const rows=items.filter(x=>x.status!=='pending').slice(0,100);
  if(!rows.length)return '<div class="empty-state">No history yet.</div>';
  const lab={posted:'✅ Posted',ignored:'🚫 Ignored',unparsed:'❓ Not understood'};
  return rows.map(x=>`<div class="list-item"><div class="info"><span class="title">${x.status==='unparsed'?'':(x.dir==='in'?'+':'−')+' '+fmt(x.amount)+' · '}${lab[x.status]||x.status}</span><span class="meta">${esc(x.date)} · ${esc(x.category||x.who||'')}<br>${esc(x.raw)}</span></div></div>`).join('');
}
function render(){
  const p=document.getElementById('tab-banksms');if(!p)return;CashBanks.init();
  const pend=items.filter(x=>x.status==='pending'),bt=(v,l)=>`<button class="btn ${view===v?'btn-primary':'btn-outline'} btn-sm" onclick="BankSMS.setView('${v}')">${l}</button>`;
  p.innerHTML=`<div class="card"><div class="flex-between"><div><div class="card-title">📩 Bank SMS</div><small>Bank and wallet messages are captured automatically. Review, then post them into Cash &amp; Banks.</small></div><button class="btn btn-outline btn-sm" onclick="BankSMS.refresh()">🔄</button></div>
  <div style="display:flex;gap:6px;margin-top:10px;flex-wrap:wrap">${bt('pending','Pending ('+pend.length+')')}${bt('groups','Groups')}${bt('history','History')}${pend.length>1&&view==='pending'?'<button class="btn btn-success btn-sm" onclick="BankSMS.postAll()">✓ Post all</button>':''}</div></div>
  ${view==='pending'?(pend.map(card).join('')||'<div class="empty-state">No pending SMS.</div>')+`<div class="card"><textarea class="form-control" id="smsPaste" rows="3" placeholder="Or paste bank SMS here (blank line between messages)"></textarea><button class="btn btn-primary btn-sm" style="margin-top:6px" onclick="BankSMS.addPasted()">Add pasted SMS</button></div>`:view==='groups'?groups():history()}<div class="card" style="margin-top:10px"><small>🛠 Something wrong?</small> <button class="btn btn-outline btn-sm" onclick="ShareHub.shareLog()">Share error log</button></div>`;
}
function postOne(it){
  const accId=it.accountId||guessAccount(it);
  if(!accId)throw new Error('Choose an account first (add a bank account in Cash & Banks)');
  if(it.dir==='out'){
    const typeId=it.typeId||guessType(it)||'direct',typeName=typeId==='direct'?'General Expense':((State.expenseTypes||[]).find(e=>e.id===typeId)||{}).name||'';
    State.runAtomic('Bank SMS expense',()=>{
      const e={id:Helpers.uid(),date:it.date,typeId,typeName,amount:it.amount,accountId:accId,reason:it.who||'Bank SMS',source:'bank-sms',createdAt:new Date().toISOString()};
      State.directExpenses.push(e);
      CashBanks.link(accId,it.amount,'out',{date:it.date,sourceType:'expense',sourceId:e.id,note:'Bank SMS: '+(it.who||typeName)});
    });
    it.category=typeName;
  }else{
    State.runAtomic('Bank SMS income',()=>{CashBanks.link(accId,it.amount,'in',{date:it.date,sourceType:'manual',note:'Bank SMS: '+(it.who||'money received')})});
    it.category='Money received';
  }
  it.status='posted';it.accountId=accId;it.postedAt=new Date().toISOString();
}
function after(){save();badge();render();if(window.Dashboard&&Dashboard.update)try{Dashboard.update()}catch(e){}}
const BankSMS={
  render,pull,ingest,
  refresh(){pull();render()},
  setView(v){view=v;render()},
  set(id,k,v){const it=items.find(x=>x.id===id);if(!it)return;it[k]=v;save();if(k==='dir')render()},
  post(id){const it=items.find(x=>x.id===id);if(!it||it.status!=='pending')return;
    try{State.saveUndoState('Bank SMS');postOne(it)}catch(e){return warn(e.message||'Could not post')}after()},
  postAll(){let n=0;State.saveUndoState('Bank SMS (all)');
    items.filter(x=>x.status==='pending').forEach(it=>{try{postOne(it);n++}catch(e){}});
    if(!n)warn('Choose accounts first');after()},
  ignore(id){const it=items.find(x=>x.id===id);if(it){it.status='ignored';after()}},
  addPasted(){const v=(document.getElementById('smsPaste')?.value||'').trim();if(!v)return;
    let parts=v.split(/\n\s*\n/).map(s=>s.trim()).filter(Boolean);
    if(parts.length===1&&v.includes('\n'))parts=v.split('\n').map(s=>s.trim()).filter(s=>s.length>15);
    const n=ingest(parts.map(b=>({body:b,ts:Date.now(),paste:true})));
    if(!n)warn('Nothing new found in that text');render()}
};
window.BankSMS=BankSMS;load();
setTimeout(()=>{badge();pull()},1500);
document.addEventListener('visibilitychange',()=>{if(!document.hidden){pull();if(isActive())render()}});
return BankSMS;});
})();
