// ============================================
// EXPORT MODULE
// ============================================

(function() {
    'use strict';
    
    const MODULE_NAME = 'Export';
    
    console.log('📦 Registering ' + MODULE_NAME + '...');
    
    window.registerModule(MODULE_NAME, function() {
        console.log('✅ ' + MODULE_NAME + ' initializing...');
        
        const Export = {
            // Export all data to JSON
            exportAllJSON() {
                const data = {
                    exportedAt: new Date().toISOString(),
                    appVersion: CONFIG.VERSION,
                    profileId: State.currentProfileId,
                    products: State.products,
                    sales: State.sales,
                    purchases: State.purchases,
                    customers: State.customers,
                    suppliers: State.suppliers,
                    expenseTypes: State.expenseTypes,
                    directExpenses: State.directExpenses,
                    returns: State.returns
                };
                
                const json = JSON.stringify(data, null, 2);
                const filename = `stockpro-full-backup-${new Date().toISOString().slice(0, 10)}.json`;
                Helpers.downloadFile(json, filename, 'application/json');
                Toast.success('✅ Full backup exported');
            },
            
            // Export to CSV
            exportCSV() {
                let csv = '';
                
                // Products
                csv += '=== PRODUCTS ===\nName,Category,Buy Price,Sell Price,Stock\n';
                State.products.forEach(p => {
                    csv += `"${p.name}","${p.category || ''}",${p.buy || 0},${p.sell || 0},${p.stock || 0}\n`;
                });
                
                // Customers
                csv += '\n=== CUSTOMERS ===\nName,Phone,Address,Balance\n';
                State.customers.forEach(c => {
                    csv += `"${c.name}","${c.contact || ''}","${c.address || ''}",${c.balance || 0}\n`;
                });
                
                // Suppliers
                csv += '\n=== SUPPLIERS ===\nName,Phone,Address,Balance\n';
                State.suppliers.forEach(s => {
                    csv += `"${s.name}","${s.contact || ''}","${s.address || ''}",${s.balance || 0}\n`;
                });
                
                // Sales
                csv += '\n=== SALES ===\nDate,Customer,Total,Paid,Balance,Profit\n';
                State.sales.forEach(s => {
                    csv += `"${s.date}","${s.customer || ''}",${s.total || 0},${s.paymentReceived || 0},${s.debitRemaining || 0},${s.profit || 0}\n`;
                });
                
                // Purchases
                csv += '\n=== PURCHASES ===\nDate,Supplier,Total,Paid,Balance\n';
                State.purchases.forEach(p => {
                    csv += `"${p.date}","${p.supplier || ''}",${p.total || 0},${p.paid || 0},${p.debit || 0}\n`;
                });
                
                // Expenses
                csv += '\n=== EXPENSES ===\nDate,Type,Amount,Reason\n';
                State.directExpenses.forEach(e => {
                    csv += `"${e.date}","${e.typeName || ''}",${e.amount || 0},"${e.reason || ''}"\n`;
                });
                
                Helpers.downloadFile(csv, `stockpro-data-${new Date().toISOString().slice(0, 10)}.csv`);
                Toast.success('✅ Data exported to CSV');
            }
        };
        
        window.Export = Export;
        console.log('✅ ' + MODULE_NAME + ' loaded successfully');
        return Export;
    });
    
})();