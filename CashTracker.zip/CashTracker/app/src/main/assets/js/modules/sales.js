// ============================================
// SALES MODULE - COMPLETE FIXED
// ============================================

(function() {
    'use strict';
    
    const MODULE_NAME = 'Sales';
    
    console.log('📦 Registering ' + MODULE_NAME + '...');
    
    // ✅ Register the module
    window.registerModule(MODULE_NAME, function() {
        console.log('✅ ' + MODULE_NAME + ' initializing...');
        
        const Sales = {
            init() {
                console.log('📊 Sales.init() called');
                const container = document.getElementById('tab-sales');
                if (!container) {
                    console.error('❌ Sales container not found!');
                    return;
                }

                // ✅ Only render if empty
                if (container.innerHTML.trim() === '') {
                    container.innerHTML = `
                        <div class="card">
                            <div class="flex-between">
                                <div class="card-title">💰 Sales History</div>
                                <button class="btn btn-success btn-sm" onclick="Sales.openSellModal()">➕ New Sale</button>
                            </div>
                            <div id="salesList"></div>
                        </div>
                    `;
                }
                
                this.render();
                console.log('✅ Sales.init() complete');
            },

            openSellModal(productId) {
                console.log('💰 Opening sell modal...', productId);
                
                let modal = document.getElementById('sellModal');
                if (!modal) {
                    modal = document.createElement('div');
                    modal.className = 'modal-overlay';
                    modal.id = 'sellModal';
                    modal.innerHTML = `
                        <div class="modal">
                            <button class="close-btn" onclick="Modals.close('sellModal')">✕</button>
                            <h3>💰 Sell Products</h3>
                            <button class="btn btn-sm btn-outline" onclick="Sales.addSellItem()" style="margin-bottom:8px;">➕ Add Item</button>
                            <table class="transaction-table">
                                <thead><tr><th>Product</th><th>Qty</th><th>Price</th><th>Amount</th><th></th></tr></thead>
                                <tbody id="sellItemsBody"></tbody>
                            </table>
                            <div style="display:flex;justify-content:space-between;margin:10px 0;font-weight:700;">
                                <span>Total:</span>
                                <span id="sellTotalDisplay">ETB 0.00</span>
                            </div>
                            <div class="form-group"><label>Date</label><input class="form-control" type="date" id="sellDate"></div>
                            <div class="form-group"><label>Customer</label><input class="form-control" id="sellCustomerSearch" list="sellCustomerOptions" placeholder="🔍 Search customer"><datalist id="sellCustomerOptions"></datalist><select class="form-control" id="sellCustomerId" style="margin-top:6px;"><option value="">-- Select --</option></select></div>
                            <div class="form-group"><label>Payment Received Now</label><input class="form-control" id="sellPayment" type="number" min="0" step="0.01" placeholder="0"></div>
                            <div class="form-group"><label>Payment Method</label><select class="form-control" id="sellPaymentMethod"><option>Cash</option><option>Bank</option><option>Telebirr</option><option>CBE Birr</option><option>Other</option></select></div><div class="form-group"><label>Money account</label><select class="form-control" id="sellMoneyAccount"></select></div>
                            <div class="form-group"><label style="display:flex;gap:8px"><input type="checkbox" id="sellUseAdvance"><span>Use customer advance</span></label><small id="sellAdvanceInfo">Available advance: ETB 0.00</small></div>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                                <div class="form-group"><label>Expense Type</label><select class="form-control" id="sellExpenseId"><option value="">-- None --</option></select></div>
                                <div class="form-group"><label>Expense Amount</label><input class="form-control" id="sellExpenseAmount" type="number" step="0.01" placeholder="0"></div>
                            </div>
                            <div class="form-group"><label>📝 Notes</label><textarea class="form-control" id="sellNotes" placeholder="Optional notes about this sale..." style="min-height:50px;"></textarea></div>
                            <button class="btn btn-success" id="sellSubmitBtn">💳 Complete Sale</button>
                        </div>
                    `;
                    document.body.appendChild(modal);
                    
                    // ✅ Set submit handler
                    document.getElementById('sellSubmitBtn').onclick = function() {
                        Sales.submit();
                    };
                }

                // Reset form
                document.getElementById('sellItemsBody').innerHTML = '';
                document.getElementById('sellDate').value = Storage.getSetting('lastTransactionDate', Helpers.getToday());
                document.getElementById('sellPayment').value = '';
                document.getElementById('sellPaymentMethod').value = 'Cash'; if(window.CashBanks){CashBanks.init();document.getElementById('sellMoneyAccount').innerHTML=CashBanks.selectOptions();}
                document.getElementById('sellUseAdvance').checked = false;
                document.getElementById('sellAdvanceInfo').textContent = 'Available advance: ETB 0.00';
                const customerSearch = document.getElementById('sellCustomerSearch'); if (customerSearch) customerSearch.value = 'Walk-in Customer';
                document.getElementById('sellExpenseAmount').value = '';
                document.getElementById('sellNotes').value = '';
                document.getElementById('sellSubmitBtn').textContent = '💳 Complete Sale';

                // Populate dropdowns
                if (typeof App !== 'undefined' && App.populateDropdowns) { App.populateDropdowns(); }
                const cs=document.getElementById('sellCustomerId'); const csearch=document.getElementById('sellCustomerSearch');
                if(cs&&csearch){ cs.onchange=()=>{ const c=State.customers.find(x=>x.id===cs.value); if(csearch) csearch.value=c?.name||''; const pay=document.getElementById('sellPayment'); const adv=document.getElementById('sellUseAdvance'); if(cs.value==='walkin'){pay.value=document.getElementById('sellTotalDisplay')?.textContent.replace(/[^0-9.-]/g,'')||''; pay.readOnly=true; adv.checked=false; adv.disabled=true;} else {pay.readOnly=false;adv.disabled=false;} document.getElementById('sellAdvanceInfo').textContent='Available advance: '+Helpers.formatCurrency(c?.customerAdvance||0); }; }

                const cs0=document.getElementById('sellCustomerId'); if(cs0){cs0.value='walkin'; cs0.dispatchEvent(new Event('change'));}
                // Add items
                if (productId) {
                    this.addSellItem(productId);
                } else {
                    this.addSellItem();
                }

                Modals.open('sellModal');
            },

            addSellItem(productId) {
                const tbody = document.getElementById('sellItemsBody');
                if (!tbody) {
                    console.warn('⚠️ sellItemsBody not found');
                    return;
                }

                const row = document.createElement('tr');
                row.className = 'sell-item-row';
                row.innerHTML = `
                    <td><input class="form-control sell-product-search" list="sellProductOptions" placeholder="🔍 Search"><datalist id="sellProductOptions"></datalist><select class="form-control sell-product-select" style="margin-top:5px;"><option value="">-- Select --</option></select></td>
                    <td><input class="form-control sell-qty" type="number" min="1" value="1" oninput="Sales.updateSellRow(this)"></td>
                    <td><input class="form-control sell-price" type="number" step="0.01" value="0" oninput="Sales.updateSellRow(this)"></td>
                    <td><input class="form-control sell-amount" type="number" readonly value="0"></td>
                    <td><button class="row-delete" onclick="this.closest('tr').remove();Sales.updateSellTotal()" style="background:none;border:none;color:var(--danger);cursor:pointer;font-size:1.2rem;">✕</button></td>
                `;
                tbody.appendChild(row);

                const select = row.querySelector('.sell-product-select');
                if (typeof Helpers !== 'undefined' && Helpers.getSorted) {
                    Helpers.getSorted(State.products).forEach(p => {
                        const option = document.createElement('option');
                        option.value = p.id;
                        option.textContent = p.name + ' (' + (p.stock || 0) + ')';
                        select.appendChild(option);
                    });
                } else {
                    // Fallback
                    (State.products || []).forEach(p => {
                        const option = document.createElement('option');
                        option.value = p.id;
                        option.textContent = p.name + ' (' + (p.stock || 0) + ')';
                        select.appendChild(option);
                    });
                }

                const search = row.querySelector('.sell-product-search');
                const datalist = row.querySelector('#sellProductOptions');
                if (datalist) { datalist.innerHTML=''; (State.products||[]).forEach(p=>{ const o=document.createElement('option'); o.value=p.name; o.label='Stock: '+(p.stock||0); o.dataset.id=p.id; datalist.appendChild(o); }); }
                if (search) search.oninput=function(){ const p=(State.products||[]).find(x=>x.name.toLowerCase()===this.value.trim().toLowerCase()); if(p){select.value=p.id; select.dispatchEvent(new Event('change'));} };
                select.onchange = function() {
                    const product = State.products.find(p => p.id === this.value);
                    if (product) {
                        row.querySelector('.sell-price').value = product.sell || 0;
                        Sales.updateSellRow(row.querySelector('.sell-price'));
                    }
                };

                if (productId) {
                    select.value = productId;
                    const product = State.products.find(p => p.id === productId);
                    if (product) {
                        row.querySelector('.sell-price').value = product.sell || 0;
                        Sales.updateSellRow(row.querySelector('.sell-price'));
                    }
                }

                this.updateSellTotal();
            },

            updateSellRow(el) {
                const row = el.closest('tr');
                const qty = +row.querySelector('.sell-qty').value || 0;
                const price = +row.querySelector('.sell-price').value || 0;
                row.querySelector('.sell-amount').value = (qty * price).toFixed(2);
                this.updateSellTotal();
            },

            updateSellTotal() {
                let total = 0;
                document.querySelectorAll('.sell-item-row').forEach(row => {
                    total += +row.querySelector('.sell-amount').value || 0;
                });
                const display = document.getElementById('sellTotalDisplay');
                if (display) display.textContent = Helpers.formatCurrency(total);
                const cs=document.getElementById('sellCustomerId'), pay=document.getElementById('sellPayment'); if(cs&&pay&&cs.value==='walkin'){pay.value=total.toFixed(2);pay.readOnly=true;}
            },

            submit() {
                const items = [];
                document.querySelectorAll('.sell-item-row').forEach(row => {
                    const productId = row.querySelector('.sell-product-select').value;
                    const qty = Number(row.querySelector('.sell-qty').value);
                    const price = Number(row.querySelector('.sell-price').value);
                    if (productId && Number.isFinite(qty) && qty > 0 && Number.isFinite(price) && price > 0) {
                        const product = State.products.find(p => p.id === productId);
                        if (product) items.push({ productId, productName: product.name, quantity: qty, price, amount: qty * price });
                    }
                });
                if (!items.length) return Toast.warning('Add at least one valid item');
                const customerId = document.getElementById('sellCustomerId').value || 'walkin';
                const customer = State.customers.find(c => c.id === customerId);
                if (!customer) return Toast.warning('Customer not found');
                const total = items.reduce((sum, item) => sum + item.amount, 0);
                let payment = Number(document.getElementById('sellPayment').value || 0);
                if (!Number.isFinite(payment) || payment < 0) return Toast.warning('Payment cannot be negative');
                if (customerId === 'walkin') payment = total;
                const useAdvance = customerId !== 'walkin' && !!document.getElementById('sellUseAdvance')?.checked;
                const customerAdvance = Number(customer.customerAdvance || 0);
                const advanceUsed = useAdvance ? Math.min(customerAdvance, total) : 0;
                const remaining = total - advanceUsed;
                const excessPayment = customerId === 'walkin' ? 0 : Math.max(0, payment - remaining);
                const debit = customerId === 'walkin' ? 0 : Math.max(0, remaining - payment);
                const expenseAmount = Number(document.getElementById('sellExpenseAmount').value) || 0;
                if (expenseAmount < 0) return Toast.warning('Expense cannot be negative');
                const date = document.getElementById('sellDate').value || Storage.getSetting('lastTransactionDate', Helpers.getToday());
                const notes = document.getElementById('sellNotes').value.trim();
                const expenseTypeId = document.getElementById('sellExpenseId').value;
                const saleId = Helpers.uid();
                try {
                    State.saveUndoState('Sale: ' + Helpers.formatCurrency(total));
                    State.runAtomic('Create sale', () => {
                        let cost = 0;
                        items.forEach(item => {
                            const product = State.products.find(p => p.id === item.productId);
                            if (!product) throw new Error('Product not found: ' + item.productId);
                            const costPrice = Number(product.buy) || 0;
                            item.costPriceAtSale = costPrice;
                            item.costAmount = costPrice * item.quantity;
                            product.stock -= item.quantity;
                            cost += item.costAmount;
                            if (window.StockHistory) StockHistory.recordChange(item.productId, product.name, -Number(item.quantity), 'Sale completed', 'sale');
                        });
                        customer.balance = (customer.balance || 0) + debit;
                        customer.customerAdvance = Number(customer.customerAdvance || 0) - advanceUsed + excessPayment;
                        State.paymentLedger = State.paymentLedger || [];
                        if (payment > 0) { const aid=document.getElementById('sellMoneyAccount')?.value; if(!aid) throw new Error('Select the cash/bank account receiving the payment'); const ledgerId=Helpers.uid(); const ledger={id:ledgerId,entityType:'customer',entityId:customerId,entityName:customer.name,amount:payment,method:document.getElementById('sellPaymentMethod').value,accountId:aid,reference:'Sale',sourceId:saleId,sourceType:'sale',date,kind:'sale_payment',createdAt:new Date().toISOString(),status:'posted'}; State.paymentLedger.unshift(ledger); if(window.CashBanks) CashBanks.link(aid,payment,'in',{date,sourceType:'sale_payment',sourceId:saleId,note:'Sale payment',paymentId:ledgerId}); }
                        if (advanceUsed > 0) State.paymentLedger.unshift({id:Helpers.uid(),entityType:'customer',entityId:customerId,entityName:customer.name,amount:advanceUsed,method:'Customer Advance',reference:'Sale',sourceId:saleId,sourceType:'sale',date,kind:'advance_applied',createdAt:new Date().toISOString(),status:'posted'});
                        State.sales.unshift({ id: saleId, transactionId: saleId, sourceType: 'sale', items, customer: customer.name || '', customerId, total, cost, profit: total - cost - expenseAmount, paymentReceived: payment, advanceUsed, excessPayment, debitRemaining: debit, date, notes, createdAt: new Date().toISOString(), expenses: { amount: expenseAmount, reason: State.expenseTypes.find(e => e.id === expenseTypeId)?.name || '' } });
                    });
                    Storage.setSetting('lastTransactionDate', date);
                    Toast.success(`Sale completed: ${Helpers.formatCurrency(total)}`);
                    Modals.close('sellModal'); App.populateDropdowns(); Products.render(); this.render(); Dashboard.update();
                } catch (error) { Toast.error('Sale failed: ' + (error.message || error)); }
            },

            render() {
                const container = document.getElementById('salesList');
                if (!container) {
                    console.warn('⚠️ salesList not found');
                    return;
                }

                if (!State.sales || State.sales.length === 0) {
                    container.innerHTML = '<div class="empty-state">No sales recorded</div>';
                    return;
                }

                const sorted = State.sales
                    .slice()
                    .sort((a, b) => {
                        const dateA = a.createdAt || a.date || '1970-01-01';
                        const dateB = b.createdAt || b.date || '1970-01-01';
                        return new Date(dateB).getTime() - new Date(dateA).getTime();
                    })
                    .slice(0, 50);

                container.innerHTML = sorted.map(sale => {
                    const items = (sale.items || []).map(i => Helpers.esc(i.productName) + ' x' + i.quantity).join(', ');
                    const cls = (sale.debitRemaining || 0) > 0 ? 'balance-positive' : 'balance-zero';
                    const status = (sale.debitRemaining || 0) > 0 ? 'Debit' : 'Paid';

                    return `
                        <div class="list-item" onclick="TransactionDetail.show('sale', '${sale.id}')">
                            <div class="info">
                                <span class="title">${items}</span>
                                <span class="meta">${Helpers.formatDate(sale.date)} | ${Helpers.esc(sale.customer || 'Walk-in')}</span>
                            </div>
                            <div>
                                ${Helpers.formatCurrency(sale.total)}
                                <span class="balance-badge ${cls}">${status} ${Helpers.formatCurrency(Math.abs(sale.debitRemaining || 0))}</span>
                            </div>
                            <div class="actions" onclick="event.stopPropagation();">
                                <button class="btn btn-warning btn-sm" onclick="Sales.edit('${sale.id}')">✏️</button>
                                <button class="btn btn-danger btn-sm" onclick="Sales.delete('${sale.id}')">🗑️</button>
                            </div>
                        </div>
                    `;
                }).join('');
            },

            viewSale(id) {
                try {
                    const sale = State.sales.find(s => s.id === id);
                    if (!sale) {
                        Toast.error('Sale not found');
                        return;
                    }

                    const cls = (sale.debitRemaining || 0) > 0 ? 'balance-positive' : 'balance-zero';

                    const itemsHtml = (sale.items || []).map(item => `
                        <tr onclick="TransactionDetail.show('product', '${item.productId}')" style="cursor:pointer;">
                            <td style="color:var(--primary);">${Helpers.esc(item.productName)}</td>
                            <td>${item.quantity}</td>
                            <td>${Helpers.formatCurrency(item.price)}</td>
                            <td>${Helpers.formatCurrency(item.amount)}</td>
                        </tr>
                    `).join('');

                    const html = `
                        <div class="detail-section">
                            <h4>💰 Sale #${sale.id ? sale.id.slice(0, 8) : 'N/A'}</h4>
                            <div class="detail-row"><span class="detail-label">Date:</span><span class="detail-value">${Helpers.formatDate(sale.date)}</span></div>
                            <div class="detail-row"><span class="detail-label">Customer:</span><span class="detail-value">${Helpers.esc(sale.customer || 'Walk-in')}</span></div>
                            <div class="detail-row"><span class="detail-label">Total:</span><span class="detail-value">${Helpers.formatCurrency(sale.total)}</span></div>
                            <div class="detail-row"><span class="detail-label">Paid:</span><span class="detail-value">${Helpers.formatCurrency(sale.paymentReceived)}</span></div>
                            <div class="detail-row">
                                <span class="detail-label">Balance:</span>
                                <span class="detail-value"><span class="balance-badge ${cls}">${Helpers.formatCurrency(Math.abs(sale.debitRemaining || 0))}</span></span>
                            </div>
                            <div class="detail-row"><span class="detail-label">Profit:</span><span class="detail-value">${Helpers.formatCurrency(sale.profit)}</span></div>
                            ${sale.notes ? `<div class="detail-row"><span class="detail-label">📝 Notes:</span><span class="detail-value">${Helpers.esc(sale.notes)}</span></div>` : ''}
                            ${sale.expenses?.amount ? `<div class="detail-row"><span class="detail-label">Expense:</span><span class="detail-value">${Helpers.formatCurrency(sale.expenses.amount)} ${sale.expenses.reason ? '(' + Helpers.esc(sale.expenses.reason) + ')' : ''}</span></div>` : ''}
                        </div>
                        <div class="detail-section">
                            <h4>📦 Items</h4>
                            <table class="transaction-table">
                                <thead><tr><th>Product</th><th>Qty</th><th>Price</th><th>Amount</th></tr></thead>
                                <tbody>${itemsHtml}</tbody>
                            </table>
                        </div>
                        <div class="detail-section">
                            <h4>⚡ Quick Actions</h4>
                            <div style="display:flex;gap:8px;flex-wrap:wrap;">
                                <button class="btn btn-info btn-sm" onclick="Sales.printReceipt('${sale.id}')">🖨️ Print Receipt</button>
                                <button class="btn btn-warning btn-sm" onclick="Sales.edit('${sale.id}')">✏️ Edit</button>
                                ${sale.customerId ? `<button class="btn btn-success btn-sm" onclick="TransactionDetail.show('customer', '${sale.customerId}')">👤 View Customer</button>` : ''}
                            </div>
                        </div>
                    `;

                    document.getElementById('detailModalContent').innerHTML = html;
                    document.getElementById('detailModalTitle').textContent = '💰 Sale Details';
                    Modals.open('detailModal');
                    
                } catch (error) {
                    console.error('viewSale error:', error);
                    Toast.error('Error loading sale details');
                }
            },

            printReceipt(id) {
                const sale = State.sales.find(s => s.id === id);
                if (!sale) return Toast.error('Sale not found');

                const profile = (State.profiles || []).find(p => p.id === State.currentProfileId) || {};
                const shopName = profile.name || (window.CONFIG && CONFIG.APP_NAME) || 'StockPro';
                const itemsRows = (sale.items || []).map(item => `
                    <tr>
                        <td style="text-align:left;padding:4px 0;">${Helpers.esc(item.productName)}</td>
                        <td style="text-align:center;">${item.quantity}</td>
                        <td style="text-align:right;">${Number(item.price).toFixed(2)}</td>
                        <td style="text-align:right;">${Number(item.amount).toFixed(2)}</td>
                    </tr>
                `).join('');

                const w = window.open('', '_blank', 'width=360,height=640');
                if (!w) return Toast.warning('Please allow pop-ups to print receipt');

                w.document.write(`<!DOCTYPE html><html><head><title>Receipt</title>
                <style>
                    body{font-family:monospace,system-ui;font-size:13px;margin:12px;color:#000;background:#fff;}
                    h2{text-align:center;margin:0 0 4px;font-size:16px;}
                    .meta{text-align:center;font-size:11px;margin-bottom:10px;}
                    table{width:100%;border-collapse:collapse;margin:8px 0;}
                    th,td{padding:3px 2px;}
                    th{border-bottom:1px dashed #000;text-align:left;}
                    .totals td{padding-top:6px;}
                    .footer{text-align:center;margin-top:14px;font-size:11px;border-top:1px dashed #000;padding-top:8px;}
                    @media print{body{margin:0;} .no-print{display:none;}}
                </style></head><body>
                <h2>${Helpers.esc(shopName)}</h2>
                <div class="meta">Sale Receipt<br>${Helpers.formatDate(sale.date)} · #${(sale.id||'').slice(0,8)}</div>
                <div>Customer: ${Helpers.esc(sale.customer || 'Walk-in')}</div>
                <table>
                    <thead><tr><th>Item</th><th style="text-align:center;">Qty</th><th style="text-align:right;">Price</th><th style="text-align:right;">Amt</th></tr></thead>
                    <tbody>${itemsRows}</tbody>
                </table>
                <table class="totals">
                    <tr><td>Total</td><td style="text-align:right;font-weight:bold;">ETB ${Number(sale.total||0).toFixed(2)}</td></tr>
                    <tr><td>Paid</td><td style="text-align:right;">ETB ${Number(sale.paymentReceived||0).toFixed(2)}</td></tr>
                    ${(sale.debitRemaining||0) > 0 ? `<tr><td>Balance Due</td><td style="text-align:right;">ETB ${Number(sale.debitRemaining).toFixed(2)}</td></tr>` : ''}
                </table>
                ${sale.notes ? `<div style="margin-top:8px;font-size:11px;">Note: ${Helpers.esc(sale.notes)}</div>` : ''}
                <div class="footer">Thank you!<br>Powered by StockPro</div>
                <div class="no-print" style="text-align:center;margin-top:16px;">
                    <button onclick="window.print()" style="padding:8px 16px;font-size:14px;">Print</button>
                    <button onclick="window.close()" style="padding:8px 16px;font-size:14px;margin-left:8px;">Close</button>
                </div>
                <script>setTimeout(function(){window.print();},300);</script>
                </body></html>`);
                w.document.close();
            },

            delete(id) {
                if (!confirm('Delete this sale? Stock will be restored.')) return;
                const sale = State.sales.find(s => s.id === id);
                if (!sale) return;
                try {
                    State.saveUndoState('Delete sale: ' + Helpers.formatCurrency(sale.total));
                    State.runAtomic('Delete sale', () => {
                        (sale.items || []).forEach(item => {
                            const product = State.products.find(p => p.id === item.productId);
                            if (!product) throw new Error('Product not found: ' + item.productId);
                            product.stock += Number(item.quantity);
                            if (window.StockHistory) StockHistory.recordChange(item.productId, product.name, Number(item.quantity), 'Sale deleted', 'sale-delete');
                        });
                        (State.paymentLedger||[]).forEach(x=>{if(x.sourceId===id&&x.status!=='void')x.status='void';});
                        (State.moneyTransactions||[]).forEach(x=>{if(x.sourceId===id&&x.status!=='void')x.status='void';});
                        if (sale.customerId && sale.customerId !== 'walkin') {
                            const customer = State.customers.find(c => c.id === sale.customerId);
                            if (!customer) throw new Error('Customer not found: ' + sale.customerId);
                            customer.balance = (customer.balance || 0) - (sale.debitRemaining || 0);
                            customer.customerAdvance = Number(customer.customerAdvance||0) + Number(sale.advanceUsed||0) - Number(sale.excessPayment||0);
                        }
                        State.sales = State.sales.filter(s => s.id !== id);
                        Security?.audit('delete','sale',id,{total:sale.total,financialTransactionsVoided:true});
                    });
                    Toast.success('Sale deleted and stock restored'); Products.render(); this.render(); Dashboard.update();
                } catch (error) { Toast.error('Sale deletion failed: ' + (error.message || error)); }
            },

            edit(id) {
                const sale = State.sales.find(s => s.id === id);
                if (!sale) return;

                this.openSellModal();
                
                document.getElementById('sellItemsBody').innerHTML = '';
                (sale.items || []).forEach(item => {
                    this.addSellItem(item.productId);
                    const rows = document.querySelectorAll('.sell-item-row');
                    const lastRow = rows[rows.length - 1];
                    if (lastRow) {
                        lastRow.querySelector('.sell-qty').value = item.quantity;
                        lastRow.querySelector('.sell-price').value = item.price;
                        this.updateSellRow(lastRow.querySelector('.sell-price'));
                    }
                });

                document.getElementById('sellDate').value = sale.date;
                document.getElementById('sellCustomerId').value = sale.customerId || '';
                document.getElementById('sellPayment').value = sale.paymentReceived || 0;
                document.getElementById('sellExpenseAmount').value = sale.expenses?.amount || 0;
                document.getElementById('sellNotes').value = sale.notes || '';

                if (sale.expenses?.reason) {
                    const expenseType = State.expenseTypes.find(e => e.name === sale.expenses.reason);
                    if (expenseType) document.getElementById('sellExpenseId').value = expenseType.id;
                }

                if (typeof App !== 'undefined' && App.populateDropdowns) {
                    App.populateDropdowns();
                }
                const oldMoney=(State.moneyTransactions||[]).find(t=>t.sourceId===sale.id&&t.status!=='void');
                if(oldMoney&&document.getElementById('sellMoneyAccount')) document.getElementById('sellMoneyAccount').value=oldMoney.accountId||'';
                const oldPay=(State.paymentLedger||[]).find(t=>t.sourceId===sale.id&&t.status!=='void'&&t.kind==='sale_payment');
                if(oldPay&&document.getElementById('sellPaymentMethod')) document.getElementById('sellPaymentMethod').value=oldPay.method||'Cash';
                
                const submitBtn = document.getElementById('sellSubmitBtn');
                submitBtn.textContent = '💾 Update Sale';
                submitBtn.onclick = () => Sales.update(id);
            },

            update(id) {
                const sale = State.sales.find(s => s.id === id);
                if (!sale) return;
                const items = [];
                document.querySelectorAll('.sell-item-row').forEach(row => {
                    const productId = row.querySelector('.sell-product-select').value;
                    const qty = Number(row.querySelector('.sell-qty').value);
                    const price = Number(row.querySelector('.sell-price').value);
                    if (productId && Number.isFinite(qty) && qty > 0 && Number.isFinite(price) && price > 0) {
                        const product = State.products.find(p => p.id === productId);
                        if (product) items.push({ productId, productName: product.name, quantity: qty, price, amount: qty * price });
                    }
                });
                if (!items.length) return Toast.warning('Add at least one valid item');
                const customerId = document.getElementById('sellCustomerId').value || 'walkin';
                const customer = State.customers.find(c => c.id === customerId);
                if (!customer) return Toast.warning('Customer not found');
                const total = items.reduce((sum, item) => sum + item.amount, 0);
                let payment = Number(document.getElementById('sellPayment').value || 0);
                if (!Number.isFinite(payment) || payment < 0) return Toast.warning('Payment cannot be negative');
                if (customerId === 'walkin') payment = total;
                const useAdvance = customerId !== 'walkin' && !!document.getElementById('sellUseAdvance')?.checked;
                const customerAdvance = Number(customer.customerAdvance || 0);
                const advanceUsed = useAdvance ? Math.min(customerAdvance, total) : 0;
                const remaining = total - advanceUsed;
                const excessPayment = customerId === 'walkin' ? 0 : Math.max(0, payment - remaining);
                const debit = customerId === 'walkin' ? 0 : Math.max(0, remaining - payment);
                const expenseAmount = Number(document.getElementById('sellExpenseAmount').value) || 0;
                if (expenseAmount < 0) return Toast.warning('Expense cannot be negative');
                const date = document.getElementById('sellDate').value || Storage.getSetting('lastTransactionDate', Helpers.getToday());
                const notes = document.getElementById('sellNotes').value.trim();
                const expenseTypeId = document.getElementById('sellExpenseId').value;
                try {
                    State.saveUndoState('Update sale: ' + Helpers.formatCurrency(total));
                    State.runAtomic('Update sale', () => {
                        (State.paymentLedger||[]).forEach(x=>{if(x.sourceId===sale.id&&x.status!=='void')x.status='void';});
                        (State.moneyTransactions||[]).forEach(x=>{if(x.sourceId===sale.id&&x.status!=='void')x.status='void';});
                        (sale.items || []).forEach(old => {
                            const product = State.products.find(p => p.id === old.productId);
                            if (!product) throw new Error('Old product not found: ' + old.productId);
                            product.stock += Number(old.quantity);
                            if (window.StockHistory) StockHistory.recordChange(old.productId, product.name, Number(old.quantity), 'Sale updated - old quantity reversed', 'sale-reversal');
                        });
                        if (sale.customerId && sale.customerId !== 'walkin') {
                            const oldCustomer = State.customers.find(c => c.id === sale.customerId);
                            if (!oldCustomer) throw new Error('Old customer not found: ' + sale.customerId);
                            oldCustomer.balance = (oldCustomer.balance || 0) - (sale.debitRemaining || 0);
                            oldCustomer.customerAdvance = Number(oldCustomer.customerAdvance||0) + Number(sale.advanceUsed||0) - Number(sale.excessPayment||0);
                        }
                        let cost = 0;
                        items.forEach(item => {
                            const product = State.products.find(p => p.id === item.productId);
                            if (!product) throw new Error('Product not found: ' + item.productId);
                            const costPrice = Number(product.buy) || 0;
                            item.costPriceAtSale = costPrice;
                            item.costAmount = costPrice * item.quantity;
                            product.stock -= item.quantity;
                            cost += item.costAmount;
                            if (window.StockHistory) StockHistory.recordChange(item.productId, product.name, -Number(item.quantity), 'Sale updated', 'sale');
                        });
                        customer.balance = (customer.balance || 0) + debit;
                        customer.customerAdvance = Number(customer.customerAdvance||0) - advanceUsed + excessPayment;
                        if(payment>0){ const aid=document.getElementById('sellMoneyAccount')?.value || (State.moneyTransactions||[]).find(t=>t.sourceId===sale.id&&t.status==='void')?.accountId; if(!aid) throw new Error('Select the cash/bank account receiving the payment'); const ledgerId=Helpers.uid(); State.paymentLedger.unshift({id:ledgerId,entityType:'customer',entityId:customerId,entityName:customer.name,amount:payment,method:document.getElementById('sellPaymentMethod').value,accountId:aid,reference:'Sale',sourceId:sale.id,sourceType:'sale',date,kind:'sale_payment',createdAt:new Date().toISOString(),status:'posted'}); if(window.CashBanks)CashBanks.link(aid,payment,'in',{date,sourceType:'sale_payment',sourceId:sale.id,note:'Sale payment (edited)',paymentId:ledgerId}); }
                        if(advanceUsed>0) State.paymentLedger.unshift({id:Helpers.uid(),entityType:'customer',entityId:customerId,entityName:customer.name,amount:advanceUsed,method:'Customer Advance',reference:'Sale',sourceId:sale.id,sourceType:'sale',date,kind:'advance_applied',createdAt:new Date().toISOString(),status:'posted'});
                        Object.assign(sale, { items, customer: customer.name || '', customerId, total, cost, profit: total - cost - expenseAmount, paymentReceived: payment, advanceUsed, excessPayment, debitRemaining: debit, date, notes, expenses: { amount: expenseAmount, reason: State.expenseTypes.find(e => e.id === expenseTypeId)?.name || '' }, updatedAt: new Date().toISOString() });
                        Security?.audit('update','sale',sale.id,{total, payment, accountId:(State.paymentLedger||[]).find(x=>x.sourceId===sale.id&&x.status==='posted'&&x.kind==='sale_payment')?.accountId});
                    });
                    Storage.setSetting('lastTransactionDate', date);
                    Toast.success(`Sale updated: ${Helpers.formatCurrency(total)}`); Modals.close('sellModal'); App.populateDropdowns(); Products.render(); this.render(); Dashboard.update();
                } catch (error) { Toast.error('Sale update failed: ' + (error.message || error)); }
            },
        };
        
        // ✅ Expose globally
        window.Sales = Sales;
        console.log('✅ ' + MODULE_NAME + ' loaded successfully');
        return Sales;
    });
    
})();