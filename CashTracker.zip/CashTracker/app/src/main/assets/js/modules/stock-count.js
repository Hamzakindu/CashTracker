// STOCK COUNT: type what you counted on the shelf, review the differences, then apply
(function(){'use strict';
window.registerModule('StockCount',function(){
const KEY='SP_count_draft';
const esc=s=>Helpers.esc(String(s==null?'':s));
let counts={},q='';
try{counts=JSON.parse(localStorage.getItem(KEY)||'{}')}catch(e){}
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(counts))}catch(e){}};
const sys=p=>Number(p.stock)||0;
const has=p=>counts[p.id]!==undefined&&counts[p.id]!==''&&!isNaN(Number(counts[p.id]));
const diffs=()=>(State.products||[]).filter(p=>has(p)&&Number(counts[p.id])!==sys(p));
function dtxt(p){if(!has(p))return '';const d=Number(counts[p.id])-sys(p);return d===0?'✅ matches':(d>0?'+'+d:String(d))}
function dcol(p){if(!has(p))return '';const d=Number(counts[p.id])-sys(p);return d===0?'#198754':d>0?'#0d6efd':'#dc3545'}
function info(){
  const e=document.getElementById('scInfo');if(!e)return;
  const c=(State.products||[]).filter(has).length,d=diffs(),plus=d.reduce((a,p)=>a+Math.max(0,Number(counts[p.id])-sys(p)),0),minus=d.reduce((a,p)=>a+Math.max(0,sys(p)-Number(counts[p.id])),0);
  e.innerHTML=`<small><b>${c}</b> counted · <b>${d.length}</b> differences (+${plus} / −${minus} units)</small>`;
}
function rows(){
  return (State.products||[]).filter(x=>!q||String(x.name).toLowerCase().includes(q)||String(x.category||'').toLowerCase().includes(q)).map(p=>
    `<div class="card" style="margin:8px 0;padding:10px"><div class="flex-between"><b>${esc(p.name)}</b><small>System: ${sys(p)}</small></div>
    <div style="display:flex;gap:8px;align-items:center;margin-top:6px"><input type="number" inputmode="numeric" min="0" class="form-control" style="width:120px" placeholder="Counted" value="${has(p)?esc(counts[p.id]):''}" oninput="StockCount.set('${esc(p.id)}',this.value)"><b id="scd_${esc(p.id)}" style="color:${dcol(p)}">${dtxt(p)}</b></div></div>`).join('')||'<div class="empty-state">No products found.</div>';
}
function render(){
  const p=document.getElementById('tab-stockcount');if(!p)return;
  p.innerHTML=`<div class="card"><div class="card-title">📋 Stock Count</div><small>Count what is on the shelf and type it in. Leave a product blank if you did not count it. Nothing changes until you tap Apply. Your counts are saved if you leave this screen.</small>
  <input class="form-control" style="margin-top:8px" placeholder="🔍 Search product" value="${esc(q)}" oninput="StockCount.search(this.value)">
  <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px"><button class="btn btn-success btn-sm" onclick="StockCount.apply()">✓ Apply differences</button><button class="btn btn-outline btn-sm" onclick="StockCount.share()">📤 Share report</button><button class="btn btn-outline btn-sm" onclick="StockCount.clear()">🗑 Clear counts</button></div><div id="scInfo" style="margin-top:6px"></div></div><div id="scList">${rows()}</div>`;
  info();
}
const StockCount={
  render,
  search(v){q=String(v||'').toLowerCase().trim();const l=document.getElementById('scList');if(l)l.innerHTML=rows()},
  set(id,v){
    if(v==='')delete counts[id];else counts[id]=v;save();
    const p=(State.products||[]).find(x=>x.id===id),e=document.getElementById('scd_'+id);
    if(p&&e){e.textContent=dtxt(p);e.style.color=dcol(p)}info();
  },
  apply(){
    const d=diffs();if(!d.length)return Toast.warning('No differences to apply');
    const plus=d.reduce((a,p)=>a+Math.max(0,Number(counts[p.id])-sys(p)),0),minus=d.reduce((a,p)=>a+Math.max(0,sys(p)-Number(counts[p.id])),0);
    if(!confirm('Apply '+d.length+' stock adjustment(s)?\n+'+plus+' units, −'+minus+' units.\nThis changes your stock quantities.'))return;
    State.saveUndoState('Stock count ('+d.length+' items)');
    State.runAtomic('Stock count',()=>{d.forEach(p=>{const nv=Number(counts[p.id]),delta=nv-sys(p);p.stock=nv;if(window.StockHistory)StockHistory.recordChange(p.id,p.name,delta,'Stock count','adjustment')})});
    counts={};save();Toast.success('✅ '+d.length+' product(s) adjusted');render();
    if(window.Dashboard&&Dashboard.update)try{Dashboard.update()}catch(e){}
  },
  share(){
    const d=diffs();if(!d.length)return Toast.warning('Nothing to share yet');
    const store=(()=>{try{return JSON.parse(localStorage.getItem('stockProfile')||'{}').storeName||'StockPro'}catch(e){return 'StockPro'}})();
    const t='📋 Stock count · '+store+' · '+Helpers.getToday()+'\n\n'+d.map(p=>'• '+p.name+': system '+sys(p)+', counted '+counts[p.id]+' ('+dtxt(p)+')').join('\n');
    if(window.ShareHub)ShareHub.send('more',t,'');
  },
  clear(){if(!confirm('Clear all counts you typed?'))return;counts={};save();render()}
};
window.StockCount=StockCount;return StockCount;});
})();
