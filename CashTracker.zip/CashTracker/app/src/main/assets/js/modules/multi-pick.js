// MULTI PICK: reusable "tick several items" screen with search, All and None
(function(){'use strict';
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let sel=new Set(),cb=null;
function count(){const e=document.getElementById('mpCount');if(e)e.textContent=sel.size+' selected'}
function open(o){
  sel=new Set(o.selected||[]);cb=o.onDone;
  let m=document.getElementById('multiPickModal');
  if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='multiPickModal';document.body.appendChild(m)}
  m.style.zIndex='100000';
  m.innerHTML=`<div class="modal" style="max-width:520px;max-height:90vh;display:flex;flex-direction:column"><button class="close-btn" onclick="MultiPick.cancel()">✕</button><h3>${esc(o.title||'Choose')}</h3>
  <input class="form-control" id="mpSearch" placeholder="🔍 Search" oninput="MultiPick.filter()">
  <div style="display:flex;gap:8px;align-items:center;margin:8px 0"><button class="btn btn-outline btn-sm" onclick="MultiPick.all(true)">☑ All shown</button><button class="btn btn-outline btn-sm" onclick="MultiPick.all(false)">☐ None</button><b id="mpCount" style="margin-left:auto"></b></div>
  <div id="mpList" style="overflow-y:auto;flex:1;min-height:120px">${(o.items||[]).map(i=>`<label class="mp-row" data-t="${esc((i.label+' '+(i.sub||'')).toLowerCase())}" style="display:flex;gap:10px;align-items:center;padding:8px 0;border-top:1px solid rgba(128,128,128,.25)"><input type="checkbox" data-id="${esc(i.id)}" ${sel.has(i.id)?'checked':''} onchange="MultiPick.tick(this)" style="width:20px;height:20px"><span><b>${esc(i.label)}</b>${i.sub?'<br><small>'+esc(i.sub)+'</small>':''}</span></label>`).join('')||'<p>Nothing to choose from.</p>'}</div>
  <button class="btn btn-primary" style="margin-top:10px" onclick="MultiPick.done()">✓ Done</button></div>`;
  Modals.open('multiPickModal');count();
}
window.MultiPick={open,
  tick(el){el.checked?sel.add(el.dataset.id):sel.delete(el.dataset.id);count()},
  all(v){document.querySelectorAll('#mpList .mp-row').forEach(r=>{if(r.style.display==='none')return;const c=r.querySelector('input');c.checked=v;v?sel.add(c.dataset.id):sel.delete(c.dataset.id)});count()},
  filter(){const q=document.getElementById('mpSearch').value.toLowerCase().trim();document.querySelectorAll('#mpList .mp-row').forEach(r=>{r.style.display=!q||r.dataset.t.includes(q)?'flex':'none'})},
  done(){const f=cb,ids=[...sel];Modals.close('multiPickModal');if(f)f(ids)},
  cancel(){Modals.close('multiPickModal')}
};
})();
