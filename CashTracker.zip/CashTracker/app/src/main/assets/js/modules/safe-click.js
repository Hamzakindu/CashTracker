// ============================================
// SAFE CLICK HANDLER - COMPLETE FIXED
// ============================================

(function() {
    'use strict';
    
    console.log('🛡️ Safe Click Handler initializing...');
    
    // Create global safe function
    window.showDetail = function(entityType, entityId) {
        console.log('🖱️ showDetail called:', entityType, entityId);
        
        try {
            // Try TransactionDetail first
            if (typeof TransactionDetail !== 'undefined' && TransactionDetail.show) {
                TransactionDetail.show(entityType, entityId);
                return;
            }
            
            // Fallback: Try individual modules
            console.warn('⚠️ TransactionDetail not available, using fallback...');
            
            switch(entityType) {
                case 'product':
                    if (typeof Products !== 'undefined') {
                        if (Products.showDetail) {
                            Products.showDetail(entityId);
                        } else if (Products.viewDetail) {
                            Products.viewDetail(entityId);
                        } else {
                            Toast.warning('Product details not available');
                        }
                    } else {
                        Toast.warning('Products module not loaded');
                    }
                    break;
                    
                case 'customer':
                    if (typeof Customers !== 'undefined') {
                        if (Customers.viewDetail) {
                            Customers.viewDetail(entityId);
                        } else if (Customers.showDetail) {
                            Customers.showDetail(entityId);
                        } else {
                            Toast.warning('Customer details not available');
                        }
                    } else {
                        Toast.warning('Customers module not loaded');
                    }
                    break;
                    
                case 'supplier':
                    if (typeof Suppliers !== 'undefined') {
                        if (Suppliers.viewDetail) {
                            Suppliers.viewDetail(entityId);
                        } else if (Suppliers.showDetail) {
                            Suppliers.showDetail(entityId);
                        } else {
                            Toast.warning('Supplier details not available');
                        }
                    } else {
                        Toast.warning('Suppliers module not loaded');
                    }
                    break;
                    
                case 'sale':
                    if (typeof Sales !== 'undefined') {
                        if (Sales.viewSale) {
                            Sales.viewSale(entityId);
                        } else if (Sales.showDetail) {
                            Sales.showDetail(entityId);
                        } else {
                            Toast.warning('Sale details not available');
                        }
                    } else {
                        Toast.warning('Sales module not loaded');
                    }
                    break;
                    
                case 'purchase':
                    if (typeof Purchases !== 'undefined') {
                        if (Purchases.viewDetail) {
                            Purchases.viewDetail(entityId);
                        } else if (Purchases.showDetail) {
                            Purchases.showDetail(entityId);
                        } else {
                            Toast.warning('Purchase details not available');
                        }
                    } else {
                        Toast.warning('Purchases module not loaded');
                    }
                    break;
                    
                case 'return':
                    if (typeof Returns !== 'undefined') {
                        if (Returns.viewDetail) {
                            Returns.viewDetail(entityId);
                        } else if (Returns.showDetail) {
                            Returns.showDetail(entityId);
                        } else {
                            Toast.warning('Return details not available');
                        }
                    } else {
                        Toast.warning('Returns module not loaded');
                    }
                    break;
                    
                default:
                    Toast.warning('Unknown entity type: ' + entityType);
            }
        } catch (error) {
            console.error('showDetail error:', error);
            Toast.error('Error loading details: ' + error.message);
        }
    };
    
    // If TransactionDetail is loaded later, it will override this
    console.log('✅ Safe Click Handler ready. Use showDetail() to view details.');
    
})();