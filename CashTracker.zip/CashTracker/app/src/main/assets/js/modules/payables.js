// PAYABLES: what you owe suppliers, how old it is, one-tap notices
(function(){'use strict';
window.registerModule('Payables',function(){
const TPL='SP_pay_tpl';
const DEF='Hello {name}, this is {store}. Our records show we owe you {amount}{days}. We will arrange payment soon. Thank you! 🙏';
const esc=s=>Helpers.esc(String(s==null?'':s));
const fmt=n=>Helpers.formatCurrency(Number(n)||0);
const store=()=>{try{return JSON.parse(localStorage.getItem('stockProfile')||'{}').storeName||'StockPro'}catch(e){return 'StockPro'}};
const tpl=()=>localStorage.getItem(TPL)||DEF;
const age=d=>{const t=new Date(String(d||'').slice(0,10)+'T00:00:00');return isNaN(t)?0:Math.max(0,Math.floor((Date.now()-t)/864e5))};
let minAge=0,picked=null;
function aging(s){
  let rem=Number(s.balance)||0,oldest=0;const b=[0,0,0,0];
  const ps=(State.purchases||[]).map(p=>({p,r:Number(p.debitRemaining!=null?p.debitRemaining:p.debit)||0})).filter(x=>x.p.supplierId===s.id&&x.r>0).sort((x,y)=>String(y.p.date).localeCompare(String(x.p.date)));
  for(const x of ps){if(rem<=0)break;const amt=Math.min(rem,x.r);rem-=amt;const a=age(x.p.date);oldest=Math.max(oldest,a);b[a<=30?0:a<=60?1:a<=90?2:3]+=amt}
  if(rem>0){b[3]+=rem;oldest=Math.max(oldest,91)}
  return{b,oldest};
}
const everyone=()=>(State.suppliers||[]).filter(s=>Number(s.balance)>0).map(s=>Object.assign({s},aging(s)));
const list=()=>everyone().filter(x=>x.oldest>=minAge&&(!picked||picked.includes(x.s.id))).sort((x,y)=>y.oldest-x.oldest||y.s.balance-x.s.balance);
function msg(x){const d=x.oldest>90?' (over 90 days)':x.oldest>0?' ('+x.oldest+' days)':'';return tpl().split('{name}').join(x.s.name).split('{amount}').join(fmt(x.s.balance)).split('{store}').join(store()).split('{days}').join(d)}
const CH=[['whatsapp','💬'],['telegram','✈️'],['imo','🟣'],['sms','📱'],['more','📤']];
function render(){
  const p=document.getElementById('tab-payables');if(!p)return;
  const all=everyone(),tot=all.reduce((a,x)=>a+x.s.balance,0),bk=[0,0,0,0];all.forEach(x=>x.b.forEach((v,i)=>bk[i]+=v));
  const l=list(),L=['0-30','31-60','61-90','90+'],chip=(v,t)=>`<button class="btn ${minAge===v?'btn-primary':'btn-outline'} btn-sm" onclick="Payables.setAge(${v})">${t}</button>`;
  p.innerHTML=`<div class="card"><div class="card-title">📤 Payables (you owe)</div><div class="flex-between"><span>Total owed to suppliers</span><b style="color:#dc3545">${fmt(tot)}</b></div>
  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:8px;text-align:center">${bk.map((v,i)=>`<div><small>${L[i]} d</small><br><b>${fmt(v)}</b></div>`).join('')}</div>
  <small style="opacity:.7">Ages are estimated from credit purchases. Record payments in the Suppliers tab.</small></div>
  <div class="card"><div style="display:flex;gap:6px;flex-wrap:wrap">${chip(0,'All')}${chip(31,'31+ days')}${chip(61,'61+ days')}${chip(91,'90+ days')}<button class="btn btn-outline btn-sm" onclick="Payables.pick()">☑ ${picked?'Selected ('+picked.length+')':'Choose suppliers'}</button>${picked?'<button class="btn btn-outline btn-sm" onclick="Payables.clearPick()">✕</button>':''}</div>
  <div style="margin-top:8px"><button class="btn btn-outline btn-sm" onclick="Payables.editTpl()">✏️ Edit message</button> <button class="btn btn-outline btn-sm" onclick="Payables.resetTpl()">↺ Reset</button></div></div>
  ${l.map(x=>`<div class="card" style="margin:8px 0;padding:10px"><div class="flex-between"><b>${esc(x.s.name)}</b><b style="color:#dc3545">${fmt(x.s.balance)}</b></div><small>${x.oldest>0?'Oldest about '+(x.oldest>90?'90+':x.oldest)+' days':'New'}${x.s.contact?' · '+esc(x.s.contact):' · no phone saved'}</small>
  <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap">${CH.map(c=>`<button class="btn btn-primary btn-sm" onclick="Payables.notify('${esc(x.s.id)}','${c[0]}')">${c[1]}</button>`).join('')}</div></div>`).join('')||'<div class="empty-state">You owe nobody in this range 🎉</div>'}`;
}
const Payables={
  render,
  setAge(v){minAge=v;render()},
  pick(){const a=everyone();MultiPick.open({title:'Choose suppliers',items:a.map(x=>({id:x.s.id,label:x.s.name,sub:fmt(x.s.balance)+' · '+(x.oldest>90?'90+':x.oldest)+' days'})),selected:picked||a.map(x=>x.s.id),onDone:ids=>{picked=ids.length===a.length?null:ids;render()}})},
  clearPick(){picked=null;render()},
  notify(id,ch){const x=everyone().find(y=>y.s.id===id);if(!x||!window.ShareHub)return;
    if(ch==='sms'&&!x.s.contact)return Toast.warning('📱 No phone number saved for '+x.s.name);ShareHub.send(ch,msg(x),x.s.contact)},
  editTpl(){const v=prompt('Message to suppliers. You can use {name} {amount} {store} {days}',tpl());if(v&&v.trim()){localStorage.setItem(TPL,v.trim());Toast.success('Message saved')}},
  resetTpl(){localStorage.removeItem(TPL);Toast.success('Message reset')}
};
window.Payables=Payables;return Payables;});
})();
