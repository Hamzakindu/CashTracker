// MARKETING: pick a customer group, write an offer, send it one customer at a time
(function(){'use strict';
window.registerModule('Marketing',function(){
const TPL='SP_promo_tpl',LOGK='SP_promo_log';
const DEF='Hello {name}, we have new offers at {store}! Visit us or reply to order. 🛍️';
const esc=s=>Helpers.esc(String(s==null?'':s));
const store=()=>{try{return JSON.parse(localStorage.getItem('stockProfile')||'{}').storeName||'StockPro'}catch(e){return 'StockPro'}};
const SEG=[['all','All customers'],['top','Top 10 buyers'],['recent','Bought in last 30 days'],['inactive','Not bought in 30+ days'],['debtors','Owe money']];
const CH=[['whatsapp','💬 WhatsApp'],['telegram','✈️ Telegram'],['imo','🟣 imo'],['sms','📱 SMS']];
let seg='all',prod='',photo=true,text=localStorage.getItem(TPL)||DEF;
const days=d=>{const t=new Date(String(d||'').slice(0,10)+'T00:00:00');return isNaN(t)?9999:Math.floor((Date.now()-t)/864e5)};
const readLog=()=>{try{return JSON.parse(localStorage.getItem(LOGK)||'{}')}catch(e){return{}}};
const key=()=>seg+'|'+prod+'|'+text.slice(0,60);
function people(){
  const st={};(State.sales||[]).forEach(s=>{if(!s.customerId||s.customerId==='walkin')return;const o=st[s.customerId]||(st[s.customerId]={total:0,last:''});o.total+=Number(s.total)||0;if(String(s.date)>o.last)o.last=String(s.date)});
  let l=(State.customers||[]).filter(c=>c.contact).map(c=>Object.assign({c},st[c.id]||{total:0,last:''}));
  if(seg==='top')l=l.filter(x=>x.total>0).sort((a,b)=>b.total-a.total).slice(0,10);
  else if(seg==='recent')l=l.filter(x=>x.last&&days(x.last)<=30);
  else if(seg==='inactive')l=l.filter(x=>!x.last||days(x.last)>30);
  else if(seg==='debtors')l=l.filter(x=>Number(x.c.balance)>0);
  return l;
}
function msg(x){
  let t=text.split('{name}').join(x.c.name).split('{store}').join(store());
  const p=(State.products||[]).find(v=>v.id===prod);
  if(p&&window.ShareHub)t+='\n\n'+ShareHub.productText(p);
  return t;
}
function render(){
  const p=document.getElementById('tab-marketing');if(!p)return;
  const list=people(),sent=readLog()[key()]||{},left=list.filter(x=>!sent[x.c.id]).length;
  const prods=(State.products||[]).filter(v=>(Number(v.stock)||0)>0);
  const pr=(State.products||[]).find(v=>v.id===prod),hasImg=pr&&(pr.images||[]).some(u=>String(u).indexOf('data:image')===0);
  p.innerHTML=`<div class="card"><div class="card-title">📣 Marketing</div><small>Send an offer to a group of customers, one by one, through your favourite app. Only customers with a phone number are included.</small>
  <div class="form-group" style="margin-top:8px"><label>👥 Who</label><select class="form-control" onchange="Marketing.setSeg(this.value)">${SEG.map(s=>`<option value="${s[0]}"${s[0]===seg?' selected':''}>${s[1]}</option>`).join('')}</select></div>
  <div class="form-group"><label>🛍️ Add a product (optional)</label><select class="form-control" onchange="Marketing.setProd(this.value)"><option value="">None</option>${prods.map(v=>`<option value="${esc(v.id)}"${v.id===prod?' selected':''}>${esc(v.name)}</option>`).join('')}</select></div>
  ${hasImg?`<label style="display:flex;gap:8px;align-items:center;margin:6px 0"><input type="checkbox" ${photo?'checked':''} onchange="Marketing.setPhoto(this.checked)"> 📸 Include photo</label>`:''}
  <div class="form-group"><label>📝 Message ({name} and {store} are filled in)</label><textarea class="form-control note-area" rows="4" oninput="Marketing.setText(this.value)">${esc(text)}</textarea></div></div>
  <div class="card"><b>${list.length}</b> customers in this group · <b>${left}</b> still to send
  <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px">${CH.map(c=>`<button class="btn btn-primary btn-sm" onclick="Marketing.next('${c[0]}')">▶ ${c[1]}</button>`).join('')}<button class="btn btn-outline btn-sm" onclick="Marketing.reset()">↺ Start over</button></div>
  <small style="opacity:.7;display:block;margin-top:6px">Tap a button to open the app for the next customer. Come back and tap again for the following one.</small></div>
  ${list.map(x=>`<div class="list-item"><div class="info"><span class="title">${sent[x.c.id]?'✅ ':''}${esc(x.c.name)}</span><span class="meta">${esc(x.c.contact)}${x.last?' · last bought '+esc(x.last.slice(0,10)):' · never bought'}</span></div></div>`).join('')||'<div class="empty-state">No customers with a phone number in this group.</div>'}`;
}
const Marketing={
  render,
  setSeg(v){seg=v;render()},
  setProd(v){prod=v;render()},
  setPhoto(v){photo=v},
  setText(v){text=v;localStorage.setItem(TPL,v)},
  next(ch){
    if(!window.ShareHub)return Toast.error('Share module not loaded');
    const lg=readLog(),k=key(),sent=lg[k]||{},x=people().find(y=>!sent[y.c.id]);
    if(!x)return Toast.success('✅ Everyone in this group has been sent the offer');
    const pr=(State.products||[]).find(v=>v.id===prod),img=photo&&pr?((pr.images||[]).find(u=>String(u).indexOf('data:image')===0)||''):'';
    ShareHub.send(ch,msg(x),x.c.contact,img);
    sent[x.c.id]=1;lg[k]=sent;localStorage.setItem(LOGK,JSON.stringify(lg));render();
  },
  reset(){const lg=readLog();delete lg[key()];localStorage.setItem(LOGK,JSON.stringify(lg));render()}
};
window.Marketing=Marketing;return Marketing;});
})();
