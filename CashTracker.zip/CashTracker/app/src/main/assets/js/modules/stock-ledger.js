// ============================================
// STOCK LEDGER & VALUATION - V5.10.30
// Additive module: preserves existing stock history and UI.
// ============================================
(function(){
'use strict';
const MODULE_NAME='StockLedger';
window.registerModule(MODULE_NAME,function(){
 const num=v=>Number(v)||0;
 const dateOf=x=>x?.date||x?.createdAt?.slice?.(0,10)||'';
 const sortAsc=(a,b)=>String(a.date||'').localeCompare(String(b.date||''))||String(a.timestamp||'').localeCompare(String(b.timestamp||''));
 const esc=s=>window.Helpers?.esc?Helpers.esc(s):String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
 const cur=n=>window.Helpers?.formatCurrency?Helpers.formatCurrency(num(n)):'ETB '+num(n).toFixed(2);
 const StockLedger={
   _unitCostFor(h,productId){
     const type=String(h.type||'');
     const reason=String(h.reason||'').toLowerCase();
     if(type==='purchase' || type==='purchase-reversal'){
       const sign=type==='purchase-reversal'?-1:1;
       const ps=(State.purchases||[]).filter(p=>dateOf(p)===h.date);
       for(const p of ps){for(const i of (p.items||[])){if(i.productId===productId){const q=num(i.quantity); if(q && Math.sign(num(h.change))===sign) return num(i.price??i.costPrice??State.products.find(x=>x.id===productId)?.buy);}}}
     }
     if(type==='sale' || type==='sale-reversal'){
       const sign=type==='sale-reversal'?1:-1;
       const ss=(State.sales||[]).filter(s=>dateOf(s)===h.date);
       for(const s of ss){for(const i of (s.items||[])){if(i.productId===productId){const q=num(i.quantity); if(q && Math.sign(num(h.change))===sign) return num(i.costPriceAtSale??i.cost??State.products.find(x=>x.id===productId)?.buy);}}}
     }
     if(type==='return' || reason.includes('return')) return num(State.products.find(x=>x.id===productId)?.buy);
     return num(State.products.find(x=>x.id===productId)?.buy);
   },
   movements(productId,from,to){
     const hs=(State.stockHistory||[]).filter(h=>h.productId===productId && (!from||String(dateOf(h))>=String(from)) && (!to||String(dateOf(h))<=String(to))).map(h=>({
       id:h.id,date:dateOf(h),timestamp:h.timestamp||'',type:h.type||'adjustment',reason:h.reason||'',change:num(h.change),previousStock:num(h.previousStock),newStock:num(h.newStock),unitCost:this._unitCostFor(h,productId),user:h.user||'System'
     }));
     return hs.sort(sortAsc);
   },
   ledger(productId,from,to){
     const product=(State.products||[]).find(p=>p.id===productId); if(!product)return [];
     let rows=this.movements(productId,from,to);
     if(!rows.length && num(product.initialStock)!==0){
       rows=[{id:'opening-'+productId,date:dateOf(product)||'',timestamp:product.createdAt||'',type:'opening',reason:'Opening stock',change:num(product.initialStock),previousStock:0,newStock:num(product.initialStock),unitCost:num(product.buy),user:'System'}];
     }
     let balance=0, value=0;
     rows=rows.map(r=>{
       const q=num(r.change), cost=num(r.unitCost||product.buy);
       const before=balance; balance+=q;
       if(q>0)value+=q*cost;
       else if(q<0){ const remove=Math.min(Math.abs(q),Math.max(0,before)); value-=remove*cost; if(Math.abs(q)>remove)value+=-(Math.abs(q)-remove)*cost; }
       return Object.assign({},r,{runningStock:balance,runningValue:value,unitCost:cost,movementValue:q*cost});
     });
     // Current product stock is authoritative. If history is truncated (max 1000), expose the gap rather than rewriting it.
     if(rows.length && Math.abs(balance-num(product.stock))>1e-9){
       rows.push({id:'current-reconciliation',date:Helpers.getToday(),timestamp:new Date().toISOString(),type:'reconciliation',reason:'Current stock reconciliation (history may be truncated)',change:num(product.stock)-balance,previousStock:balance,newStock:num(product.stock),unitCost:num(product.buy),runningStock:num(product.stock),runningValue:value+(num(product.stock)-balance)*num(product.buy),movementValue:(num(product.stock)-balance)*num(product.buy),user:'System'});
     }
     return rows;
   },
   valuation(productId){
     const p=(State.products||[]).find(x=>x.id===productId); if(!p)return null;
     const rows=this.ledger(productId); const stock=num(p.stock);
     let avg=num(p.buy), value=stock*avg;
     // Weighted-average valuation from purchase inflows; sales/returns consume current average.
     let q=0,v=0;
     rows.forEach(r=>{const ch=num(r.change); if(ch>0){v+=ch*num(r.unitCost);q+=ch;} else if(ch<0){const take=Math.min(-ch,q); if(take>0){v-=take*(q?v/q:avg);q-=take;} if(-ch>take){/* negative stock: keep average cost */}}});
     if(q>0)avg=v/q;
     value=stock*avg;
     return {productId,stock,averageCost:avg,stockValue:value,retailValue:stock*num(p.sell),potentialMargin:(num(p.sell)-avg)*stock,rows:rows.length};
   },
   summary(productId){
     const rows=this.movements(productId); const p=(State.products||[]).find(x=>x.id===productId); if(!p)return null;
     return {opening:num(p.initialStock),purchased:rows.filter(r=>r.change>0&&(r.type==='purchase'||r.type==='purchase-reversal')).reduce((a,r)=>a+Math.max(0,r.change),0),sold:rows.filter(r=>r.change<0&&String(r.type).startsWith('sale')).reduce((a,r)=>a+Math.abs(r.change),0),returned:rows.filter(r=>r.change>0&&r.type==='return').reduce((a,r)=>a+r.change,0),adjusted:rows.filter(r=>r.type==='adjustment').reduce((a,r)=>a+r.change,0),current:num(p.stock)};
   },
   show(productId){
     const p=(State.products||[]).find(x=>x.id===productId); if(!p)return Toast.error('Product not found');
     const rows=this.ledger(productId); const val=this.valuation(productId); const s=this.summary(productId);
     let body=rows.slice().reverse().slice(0,200).map(r=>`<tr><td>${Helpers.formatDate(r.date)}</td><td>${esc(r.type)}</td><td>${esc(r.reason)}</td><td>${r.change>0?'+':''}${r.change}</td><td>${r.runningStock}</td><td>${cur(r.unitCost)}</td><td>${cur(r.movementValue)}</td></tr>`).join('');
     const html=`<div class="detail-section"><h4>📚 Stock Ledger</h4><div class="stock-summary-grid"><div class="stock-summary-item"><span class="summary-label">Current stock</span><span class="summary-value">${s.current}</span></div><div class="stock-summary-item"><span class="summary-label">Purchased</span><span class="summary-value">+${s.purchased}</span></div><div class="stock-summary-item"><span class="summary-label">Sold</span><span class="summary-value">-${s.sold}</span></div><div class="stock-summary-item"><span class="summary-label">Returned</span><span class="summary-value">+${s.returned}</span></div></div></div><div class="detail-section"><h4>💰 Valuation</h4><div class="stock-summary-grid"><div class="stock-summary-item"><span class="summary-label">Average cost</span><span class="summary-value">${cur(val.averageCost)}</span></div><div class="stock-summary-item"><span class="summary-label">Stock value</span><span class="summary-value">${cur(val.stockValue)}</span></div><div class="stock-summary-item"><span class="summary-label">Retail value</span><span class="summary-value">${cur(val.retailValue)}</span></div><div class="stock-summary-item"><span class="summary-label">Potential margin</span><span class="summary-value">${cur(val.potentialMargin)}</span></div></div><div style="font-size:.78rem;color:var(--text2);margin-top:8px">Weighted-average cost based on recorded stock inflows. Existing stock history is preserved; no historical records are rewritten.</div></div><div class="detail-section"><h4>📋 Movements</h4><div style="overflow:auto"><table class="transaction-table"><thead><tr><th>Date</th><th>Type</th><th>Reason</th><th>Change</th><th>Balance</th><th>Unit cost</th><th>Value</th></tr></thead><tbody>${body||'<tr><td colspan="7" class="empty-state">No stock movements recorded</td></tr>'}</tbody></table></div>${rows.length>200?'<div style="text-align:center;padding:8px;color:var(--text2)">Showing latest 200 movements</div>':''}</div>`;
     const c=document.getElementById('detailModalContent'); if(c)c.insertAdjacentHTML('beforeend',html);
   },
   audit(){
     const issues=[];(State.products||[]).forEach(p=>{const h=(State.stockHistory||[]).filter(x=>x.productId===p.id); if(h.length){const latest=h.slice().sort((a,b)=>new Date(b.timestamp||b.date)-new Date(a.timestamp||a.date))[0]; if(Math.abs(num(latest.newStock)-num(p.stock))>0.000001)issues.push({productId:p.id,name:p.name,current:num(p.stock),historyLatest:num(latest.newStock)});}}); return {ok:issues.length===0,issues};
   }
 };
 window.StockLedger=StockLedger; console.log('✅ StockLedger loaded'); return StockLedger;
});
})();
