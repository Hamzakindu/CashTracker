// ============================================
// BULK IMPORT/EXPORT MODULE
// ============================================

(function() {
    'use strict';
    
    const MODULE_NAME = 'BulkImport';
    
    console.log('📦 Registering ' + MODULE_NAME + '...');
    
    window.registerModule(MODULE_NAME, function() {
        console.log('✅ ' + MODULE_NAME + ' initializing...');
        
        const BulkImport = {
            // Export all data
            exportAll() {
                const data = {
                    exportedAt: new Date().toISOString(),
                    appVersion: CONFIG.VERSION,
                    profileId: State.currentProfileId,
                    products: State.products,
                    sales: State.sales,
                    purchases: State.purchases,
                    customers: State.customers,
                    suppliers: State.suppliers,
                    expenseTypes: State.expenseTypes,
                    directExpenses: State.directExpenses,
                    returns: State.returns,
                calculations: State.calculations,
                stockHistory: State.stockHistory
                };
                
                const json = JSON.stringify(data, null, 2);
                const filename = `stockpro-full-backup-${new Date().toISOString().slice(0, 10)}.json`;
                Helpers.downloadJSON(json, filename);
                Toast.success('✅ Full backup exported');
            },
            
            // Export to Excel (CSV format)
            exportToExcel() {
                let csv = '=== PRODUCTS ===\nName,Category,Buy Price,Sell Price,Stock\n';
                State.products.forEach(p => {
                    csv += `"${p.name}","${p.category || ''}",${p.buy},${p.sell},${p.stock}\n`;
                });
                
                csv += '\n=== CUSTOMERS ===\nName,Phone,Address,Balance\n';
                State.customers.forEach(c => {
                    csv += `"${c.name}","${c.contact || ''}","${c.address || ''}",${c.balance || 0}\n`;
                });
                
                csv += '\n=== SUPPLIERS ===\nName,Phone,Address,Balance\n';
                State.suppliers.forEach(s => {
                    csv += `"${s.name}","${s.contact || ''}","${s.address || ''}",${s.balance || 0}\n`;
                });
                
                csv += '\n=== SALES ===\nDate,Customer,Total,Payment,Balance\n';
                State.sales.forEach(s => {
                    csv += `"${s.date}","${s.customer || ''}",${s.total},${s.paymentReceived || 0},${s.debitRemaining || 0}\n`;
                });
                
                Helpers.downloadFile(csv, `stockpro-data-${new Date().toISOString().slice(0, 10)}.csv`);
                Toast.success('✅ Data exported to CSV');
            },
            
            // Import from JSON
            importJSON() {
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = '.json';
                input.onchange = async (e) => {
                    const file = e.target.files[0];
                    if (!file) return;
                    
                    try {
                        const text = await this.readFileAsText(file);
                        const data = JSON.parse(text);
                        
                        if (!confirm('⚠️ This will REPLACE all current data! Continue?')) return;
                        
                        State.saveUndoState('Before bulk import');
                        
                        const stores = ['products', 'sales', 'purchases', 'customers', 'suppliers', 
                                      'expenseTypes', 'directExpenses', 'returns', 'calculations', 'stockHistory'];
                        let count = 0;
                        
                        for (const store of stores) {
                            if (data[store] && Array.isArray(data[store])) {
                                State[store] = data[store];
                                Storage.save(store, data[store]);
                                count++;
                            }
                        }
                        
                        Toast.success(`✅ Imported ${count} data stores! Reloading...`, 4000);
                        setTimeout(() => location.reload(), 1500);
                        
                    } catch (error) {
                        Toast.error('❌ Import failed: ' + error.message);
                    }
                };
                input.click();
            },
            
            readFileAsText(file) {
                return new Promise((resolve, reject) => {
                    const reader = new FileReader();
                    reader.onload = (e) => resolve(e.target.result);
                    reader.onerror = reject;
                    reader.readAsText(file);
                });
            }
        };
        
        window.BulkImport = BulkImport;
        console.log('✅ ' + MODULE_NAME + ' loaded successfully');
        return BulkImport;
    });
    
})();