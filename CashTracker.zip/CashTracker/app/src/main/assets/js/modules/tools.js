// TOOLS: app lock (PIN), quick backup, diagnostics
(function(){'use strict';
window.registerModule('Tools',function(){
function lastBackup(){try{const k=localStorage.getItem('SP_last_file_backup');if(k)return new Date(k).toLocaleString();const v=Storage.getSetting('labt');if(!v)return 'never';const d=new Date(v);return isNaN(d)?String(v):d.toLocaleString()}catch(e){return 'unknown'}}
function lockOn(){try{const a=window.AppLock;if(!a)return false;if(typeof a.has==='function')return !!a.has();if(typeof a.isEnabled==='function')return !!a.isEnabled()}catch(e){}return false}
function render(){
  const p=document.getElementById('tab-tools');if(!p)return;const has=lockOn();
  p.innerHTML=`${window.Roles?Roles.cardHtml():''}<div class="card"><div class="card-title">📊 Share balances &amp; summary</div><p>Send today's sales, expenses, account balances and what people owe to yourself or a partner.</p><button class="btn btn-primary btn-sm" onclick="Summary.open()">📤 Share now</button></div>
  <div class="card"><div class="card-title">🔒 App Lock</div>
  <p>${has?'A PIN is set. The app asks for it on start and after a minute in the background.':'No PIN set. Anyone who opens the app can see your business data.'}</p>
  <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn-primary btn-sm" onclick="Tools.setPin()">${has?'Change PIN':'Set PIN'}</button>${has?'<button class="btn btn-outline btn-sm" onclick="Tools.lockNow()">Lock now</button><button class="btn btn-outline btn-sm" onclick="Tools.removePin()">Remove PIN</button>':''}</div>
  <small style="display:block;margin-top:8px;opacity:.75">⚠️ If you forget the PIN it can't be recovered, so keep a backup. The lock hides the app; it does not encrypt the data.</small></div>
  <div class="card"><div class="card-title">📷 Barcode</div><p>Scan a product barcode to open that product.</p><button class="btn btn-primary btn-sm" onclick="Scan.find()">📷 Scan product</button></div>
  <div class="card"><div class="card-title">💾 Backup</div><p>Last backup: <b>${lastBackup()}</b></p>
  <button class="btn btn-success btn-sm" onclick="Backup.exportBackup()">📤 Backup now</button>
  <small style="display:block;margin-top:8px;opacity:.75">The file is saved to your Downloads folder. Copy it to Google Drive or send it to yourself on Telegram. Back up at least weekly.</small></div>
  <div class="card"><div class="card-title">🤖 Telegram bot (Cloudflare)</div>
  <p>Lets your bot answer commands like /summary, /balance, /owed, /low and /stock in Telegram. The app sends a summary of your data to your Worker.</p>
  <div class="form-group"><label>Worker address</label><input class="form-control" id="botUrl" type="url" placeholder="https://yourbot.yourname.workers.dev" value="${BotSync.url()}"></div>
  <div class="form-group"><label>Key (the same as PUSH_KEY in the Worker)</label><input class="form-control" id="botKey" type="password" autocomplete="off" value="${BotSync.key()}"></div>
  <div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn btn-primary btn-sm" onclick="BotSync.save()">Save &amp; send now</button><button class="btn btn-outline btn-sm" onclick="BotSync.now()">Send data to bot now</button>${BotSync.url()?'<button class="btn btn-outline btn-sm" onclick="BotSync.clear()">Disconnect</button>':''}</div>
  <small style="display:block;margin-top:8px;opacity:.75">Last sent: <b>${BotSync.lastText()}</b>. Data is sent when you open the app and every 10 minutes while it is open. It includes names, balances, prices and stock, but no phone numbers.</small></div>
  <div class="card"><div class="card-title">📤 Sharing method</div><p>If WhatsApp or Telegram do not open properly, try another method. Current: <b>${Tools.modeLabel()}</b></p>
  <div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn btn-primary btn-sm" onclick="Tools.setMode('sheet')">Share sheet</button><button class="btn btn-outline btn-sm" onclick="Tools.setMode('deep')">Chat links</button><button class="btn btn-outline btn-sm" onclick="Tools.setMode('direct')">Direct to app</button></div>
  <small style="display:block;margin-top:8px;opacity:.75"><b>Share sheet</b> shows your phone's normal app list, so you pick WhatsApp or Telegram there. It is the most reliable. <b>Chat links</b> and <b>Direct to app</b> are faster when your phone allows them. imo always opens directly.</small></div>
  <div class="card"><div class="card-title">🐞 Diagnostics</div><p>If something breaks, send the error log to your developer.</p>
  <button class="btn btn-outline btn-sm" onclick="ShareHub.shareLog()">Share error log</button></div>`;
}
const MODES={sheet:'Share sheet',deep:'Chat links',direct:'Direct to app'};
const Tools={
  render,
  modeLabel(){return MODES[localStorage.getItem('SP_share_mode')||'sheet']||'Share sheet'},
  setMode(m){localStorage.setItem('SP_share_mode',m);Toast.success('Sharing method: '+MODES[m]);render()},
  lockNow(){try{if(AppLock.lock)AppLock.lock();else if(AppLock.showOverlay)AppLock.showOverlay()}catch(e){}},
  async setPin(){
    if(!AppLock.set&&AppLock.openSettings)return AppLock.openSettings();
    if(AppLock.has()){const c=prompt('Enter your current PIN');if(c==null)return;if(!(await AppLock.verify(c)))return Toast.error('Wrong PIN')}
    const a=prompt('New PIN (4 to 8 digits)');if(a==null)return;if(!/^\d{4,8}$/.test(a))return Toast.warning('PIN must be 4 to 8 digits');
    if(a!==prompt('Repeat the PIN'))return Toast.warning("The PINs don't match");
    await AppLock.set(a);Toast.success('🔒 PIN saved');render();
  },
  async removePin(){
    if(!AppLock.remove&&AppLock.openSettings)return AppLock.openSettings();
    const c=prompt('Enter your PIN to remove the lock');if(c==null)return;
    if(!(await AppLock.verify(c)))return Toast.error('Wrong PIN');AppLock.remove();Toast.success('Lock removed');render();
  }
};
setTimeout(()=>{try{const v=Storage.getSetting('labt'),d=new Date(v);if(v&&!isNaN(d)&&Date.now()-d>7*864e5)Toast.warning('💾 Your last backup was over a week ago. Open Tools to back up.')}catch(e){}},4000);
window.Tools=Tools;return Tools;});
})();
