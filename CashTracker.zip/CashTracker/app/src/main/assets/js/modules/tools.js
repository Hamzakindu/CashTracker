// TOOLS: app lock (PIN), quick backup, diagnostics
(function(){'use strict';
window.registerModule('Tools',function(){
function lastBackup(){try{const k=localStorage.getItem('SP_last_file_backup');if(k)return new Date(k).toLocaleString();const v=Storage.getSetting('labt');if(!v)return 'never';const d=new Date(v);return isNaN(d)?String(v):d.toLocaleString()}catch(e){return 'unknown'}}
function render(){
  const p=document.getElementById('tab-tools');if(!p)return;const has=window.AppLock&&AppLock.has();
  p.innerHTML=`<div class="card"><div class="card-title">📊 Share balances &amp; summary</div><p>Send today's sales, expenses, account balances and what people owe to yourself or a partner.</p><button class="btn btn-primary btn-sm" onclick="Summary.open()">📤 Share now</button></div>
  <div class="card"><div class="card-title">🔒 App Lock</div>
  <p>${has?'A PIN is set. The app asks for it on start and after a minute in the background.':'No PIN set. Anyone who opens the app can see your business data.'}</p>
  <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn-primary btn-sm" onclick="Tools.setPin()">${has?'Change PIN':'Set PIN'}</button>${has?'<button class="btn btn-outline btn-sm" onclick="AppLock.lock()">Lock now</button><button class="btn btn-outline btn-sm" onclick="Tools.removePin()">Remove PIN</button>':''}</div>
  <small style="display:block;margin-top:8px;opacity:.75">⚠️ If you forget the PIN it can't be recovered, so keep a backup. The lock hides the app; it does not encrypt the data.</small></div>
  <div class="card"><div class="card-title">📷 Barcode</div><p>Scan a product barcode to open that product.</p><button class="btn btn-primary btn-sm" onclick="Scan.find()">📷 Scan product</button></div>
  <div class="card"><div class="card-title">💾 Backup</div><p>Last backup: <b>${lastBackup()}</b></p>
  <button class="btn btn-success btn-sm" onclick="Backup.exportBackup()">📤 Backup now</button>
  <small style="display:block;margin-top:8px;opacity:.75">The file is saved to your Downloads folder. Copy it to Google Drive or send it to yourself on Telegram. Back up at least weekly.</small></div>
  <div class="card"><div class="card-title">🐞 Diagnostics</div><p>If something breaks, send the error log to your developer.</p>
  <button class="btn btn-outline btn-sm" onclick="ShareHub.shareLog()">Share error log</button></div>`;
}
const Tools={
  render,
  async setPin(){
    if(AppLock.has()){const c=prompt('Enter your current PIN');if(c==null)return;if(!(await AppLock.verify(c)))return Toast.error('Wrong PIN')}
    const a=prompt('New PIN (4 to 8 digits)');if(a==null)return;if(!/^\d{4,8}$/.test(a))return Toast.warning('PIN must be 4 to 8 digits');
    if(a!==prompt('Repeat the PIN'))return Toast.warning("The PINs don't match");
    await AppLock.set(a);Toast.success('🔒 PIN saved');render();
  },
  async removePin(){
    const c=prompt('Enter your PIN to remove the lock');if(c==null)return;
    if(!(await AppLock.verify(c)))return Toast.error('Wrong PIN');AppLock.remove();Toast.success('Lock removed');render();
  }
};
setTimeout(()=>{try{const v=Storage.getSetting('labt'),d=new Date(v);if(v&&!isNaN(d)&&Date.now()-d>7*864e5)Toast.warning('💾 Your last backup was over a week ago. Open Tools to back up.')}catch(e){}},4000);
window.Tools=Tools;return Tools;});
})();
