// STOCKPRO V5.2 - CASH, BANKS & MONEY CONTROL
(function(){
'use strict';
window.registerModule('CashBanks', function(){
const CashBanks={
  init(){
    State.cashAccounts=Array.isArray(State.cashAccounts)?State.cashAccounts:[];
    State.moneyTransactions=Array.isArray(State.moneyTransactions)?State.moneyTransactions:[];
    State.cashReconciliations=Array.isArray(State.cashReconciliations)?State.cashReconciliations:[];
    if(!State.cashAccounts.length){
      State.cashAccounts=[{id:'cash_main',name:'Cash',type:'cash',bankName:'',accountNumber:'',openingBalance:0,openingDate:Helpers.getToday(),active:true,createdAt:new Date().toISOString()}];
      Storage.save('cashAccounts',State.cashAccounts); Storage.save('moneyTransactions',State.moneyTransactions);
    }
  },
  accounts(){this.init();return State.cashAccounts.filter(a=>a.active!==false);},
  get(id){return this.accounts().find(a=>a.id===id);},
  balance(id){
    const a=this.get(id); if(!a)return 0;
    let b=Number(a.openingBalance||0);
    const today=Helpers.getToday();
    State.moneyTransactions.filter(t=>t.status!=='void'&&t.accountId===id&&(!t.date||t.date<=today)).forEach(t=>{
      const n=Number(t.amount||0);
      // openingBalance is already the account's opening snapshot; opening
      // transactions are audit records and must not be counted again.
      if(t.type==='opening') return;
      if(['in','income','transfer_in','adjustment_in'].includes(t.type))b+=n;
      else if(['out','expense','transfer_out','adjustment_out'].includes(t.type))b-=n;
    });
    return b;
  },
  totals(){
    const rows=this.accounts().map(a=>({a,b:this.balance(a.id)}));
    return {cash:rows.filter(x=>x.a.type==='cash').reduce((n,x)=>n+x.b,0),
      bank:rows.filter(x=>x.a.type==='bank').reduce((n,x)=>n+x.b,0),
      wallet:rows.filter(x=>x.a.type==='wallet').reduce((n,x)=>n+x.b,0),
      total:rows.reduce((n,x)=>n+x.b,0),rows};
  },
  balanceAsOf(id,date){
    const a=this.get(id);if(!a)return 0;let b=Number(a.openingBalance||0);
    (State.moneyTransactions||[]).filter(t=>t.status!=='void'&&t.accountId===id&&(!t.date||String(t.date)<=String(date))).forEach(t=>{
      const n=Number(t.amount||0);if(t.type==='opening')return;
      if(['in','income','transfer_in','adjustment_in'].includes(t.type))b+=n;
      else if(['out','expense','transfer_out','adjustment_out'].includes(t.type))b-=n;
    });return b;
  },
  reconcile(){
    this.init();
    const rows=this.totals().rows;
    const unassigned=(State.paymentLedger||[]).filter(p=>p.status!=='void'&&!p.accountId);
    return {rows,unassigned,history:(State.cashReconciliations||[]).slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)))};
  },
  saveReconciliation(){
    const accountId=document.getElementById('crAccount')?.value,date=document.getElementById('crDate')?.value||Helpers.getToday();
    const actual=Number(document.getElementById('crActual')?.value);
    const note=(document.getElementById('crNote')?.value||'').trim();
    if(!accountId||!Number.isFinite(actual)||actual<0)return Toast.warning('Choose an account and enter a valid counted/statement balance');
    const account=this.get(accountId);if(!account)return Toast.warning('Account not found');
    const expected=this.balanceAsOf(accountId,date),difference=actual-expected;
    State.saveUndoState('Cash/bank reconciliation');
    State.cashReconciliations.unshift({id:Helpers.uid(),accountId,accountName:account.name,date,expectedBalance:expected,actualBalance:actual,difference,note,status:Math.abs(difference)<0.005?'matched':'difference',createdAt:new Date().toISOString()});
    State.save('cashReconciliations');
    if(typeof Security!=='undefined'&&Security.audit)Security.audit('cash_reconciled','cash_account',accountId,{date,expected,actual,difference});
    this.render();Toast.success(Math.abs(difference)<0.005?'Reconciliation matched':'Difference recorded; no automatic adjustment made');
  },
  selectOptions(selected=''){
    return this.accounts().map(a=>`<option value="${Helpers.esc(a.id)}" ${a.id===selected?'selected':''}>${Helpers.esc(a.name)}${a.bankName?' — '+Helpers.esc(a.bankName):''}</option>`).join('');
  },
  addAccount(){
    const name=document.getElementById('cbName').value.trim(),type=document.getElementById('cbType').value,
      bank=document.getElementById('cbBank').value.trim(),num=document.getElementById('cbNum').value.trim(),
      opening=Number(document.getElementById('cbOpening').value||0),date=document.getElementById('cbDate').value||Helpers.getToday();
    if(!name)return Toast.warning('Enter account name');
    if(type==='bank'&&!bank)return Toast.warning('Enter bank name');
    if(!Number.isFinite(opening)||opening<0)return Toast.warning('Opening balance must be zero or more');
    State.saveUndoState('Add money account');
    State.runAtomic('Add money account',()=>{
      const id=Helpers.uid();State.cashAccounts.unshift({id,name,type,bankName:bank,accountNumber:num,openingBalance:opening,openingDate:date,active:true,createdAt:new Date().toISOString()});
      if(opening)State.moneyTransactions.unshift({id:Helpers.uid(),accountId:id,type:'opening',amount:opening,date,note:'Opening balance',sourceType:'opening',status:'posted',createdAt:new Date().toISOString()});
    });
    Modals.close('cashAccountModal');this.render();Toast.success('Account added');
  },
  openAccountModal(){
    let m=document.getElementById('cashAccountModal');
    if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='cashAccountModal';m.innerHTML=`
    <div class="modal"><button class="close-btn" onclick="Modals.close('cashAccountModal')">✕</button><h3>🏦 Add Cash / Bank Account</h3>
    <div class="form-group"><label>Name</label><input class="form-control" id="cbName" placeholder="Main Cash / CBE Account"></div>
    <div class="form-group"><label>Type</label><select class="form-control" id="cbType" onchange="CashBanks.toggleBank()"><option value="cash">Cash</option><option value="bank">Bank</option><option value="wallet">Mobile Wallet</option></select></div>
    <div class="form-group" id="cbBankWrap" style="display:none"><label>Bank</label><input class="form-control" id="cbBank" placeholder="CBE / Awash / Dashen"></div>
    <div class="form-group"><label>Account number / identifier</label><input class="form-control" id="cbNum"></div>
    <div class="form-group"><label>Opening balance</label><input class="form-control" id="cbOpening" type="number" min="0" step=".01" value="0"></div>
    <div class="form-group"><label>Opening date</label><input class="form-control" id="cbDate" type="date"></div>
    <button class="btn btn-success" onclick="CashBanks.addAccount()">Save</button></div>`;document.body.appendChild(m);}
    document.getElementById('cbName').value='';document.getElementById('cbType').value='cash';document.getElementById('cbBank').value='';document.getElementById('cbNum').value='';
    document.getElementById('cbOpening').value='0';document.getElementById('cbDate').value=Helpers.getToday();this.toggleBank();Modals.open('cashAccountModal');
  },
  toggleBank(){const e=document.getElementById('cbBankWrap');if(e)e.style.display=document.getElementById('cbType')?.value==='bank'?'block':'none';},
  movement(){
    const aid=document.getElementById('cmAccount').value,type=document.getElementById('cmType').value,amt=Number(document.getElementById('cmAmount').value),
      date=document.getElementById('cmDate').value||Helpers.getToday(),note=document.getElementById('cmNote').value.trim(),to=document.getElementById('cmTo').value;
    if(!aid||!Number.isFinite(amt)||amt<=0)return Toast.warning('Enter account and positive amount');
    if((type==='out'||type==='transfer_out')&&this.balance(aid)<amt)return Toast.warning('Insufficient available balance');
    if(type==='transfer_out'&&(!to||to===aid))return Toast.warning('Choose another destination account');
    State.saveUndoState('Money movement');State.runAtomic('Money movement',()=>{
      State.moneyTransactions.unshift({id:Helpers.uid(),accountId:aid,type,amount:amt,date,note,sourceType:'manual',status:'posted',createdAt:new Date().toISOString()});
      if(type==='transfer_out')State.moneyTransactions.unshift({id:Helpers.uid(),accountId:to,type:'transfer_in',amount:amt,date,note,sourceType:'transfer',status:'posted',createdAt:new Date().toISOString()});
    });
    Modals.close('cashMovementModal');this.render();Toast.success('Money movement recorded');
  },
  openMovement(){
    if(!this.accounts().length)return this.openAccountModal();
    let m=document.getElementById('cashMovementModal');
    if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='cashMovementModal';m.innerHTML=`
    <div class="modal"><button class="close-btn" onclick="Modals.close('cashMovementModal')">✕</button><h3>💵 Money Movement</h3>
    <div class="form-group"><label>Date</label><input class="form-control" id="cmDate" type="date"></div>
    <div class="form-group"><label>Type</label><select class="form-control" id="cmType" onchange="CashBanks.toggleTransfer()"><option value="in">Money received</option><option value="out">Money paid</option><option value="transfer_out">Transfer to another account</option></select></div>
    <div class="form-group"><label>Account</label><select class="form-control" id="cmAccount"></select></div>
    <div class="form-group" id="cmToWrap" style="display:none"><label>To account</label><select class="form-control" id="cmTo"></select></div>
    <div class="form-group"><label>Amount</label><input class="form-control" id="cmAmount" type="number" min=".01" step=".01"></div>
    <div class="form-group"><label>Reference / note</label><input class="form-control" id="cmNote"></div>
    <button class="btn btn-success" onclick="CashBanks.movement()">Save</button></div>`;document.body.appendChild(m);}
    document.getElementById('cmDate').value=Helpers.getToday();document.getElementById('cmAmount').value='';document.getElementById('cmNote').value='';
    document.getElementById('cmAccount').innerHTML=this.selectOptions();document.getElementById('cmTo').innerHTML=this.selectOptions();document.getElementById('cmType').value='in';this.toggleTransfer();Modals.open('cashMovementModal');
  },
  toggleTransfer(){const yes=document.getElementById('cmType')?.value==='transfer_out',w=document.getElementById('cmToWrap');if(w)w.style.display=yes?'block':'none';},
  link(accountId,amount,direction,meta={}){
    if(!accountId||Number(amount)<=0)return;
    const tx={id:Helpers.uid(),accountId,type:direction==='in'?'in':'out',amount:Number(amount),date:meta.date||Helpers.getToday(),note:meta.note||'',sourceType:meta.sourceType||'payment',sourceId:meta.sourceId||'',paymentId:meta.paymentId||'',status:'posted',createdAt:new Date().toISOString()};
    if(tx.amount<=0)throw new Error('Money movement must be greater than zero');
    if(!this.get(accountId))throw new Error('Money account not found');
    State.moneyTransactions.unshift(tx); Security?.audit('money_posted','cash_account',accountId,{transactionId:tx.id,type:tx.type,amount:tx.amount,sourceType:tx.sourceType,sourceId:tx.sourceId});
  },
  render(){
    this.init();const p=document.getElementById('tab-cashbanks');if(!p)return;const t=this.totals();
    p.innerHTML=`<div class="card"><div class="flex-between"><div><div class="card-title">💵 Cash & Banks</div><small>See exactly how much money is available in cash, each bank and each wallet.</small></div><div><button class="btn btn-success btn-sm" onclick="CashBanks.openAccountModal()">➕ Account</button> <button class="btn btn-primary btn-sm" onclick="CashBanks.openMovement()">💵 Movement</button></div></div>
    <div class="stock-summary-grid" style="margin-top:12px"><div class="stock-summary-item"><span class="summary-label">💵 Cash</span><span class="summary-value">${Helpers.formatCurrency(t.cash)}</span></div><div class="stock-summary-item"><span class="summary-label">🏦 Banks</span><span class="summary-value">${Helpers.formatCurrency(t.bank)}</span></div><div class="stock-summary-item"><span class="summary-label">📱 Wallets</span><span class="summary-value">${Helpers.formatCurrency(t.wallet)}</span></div><div class="stock-summary-item"><span class="summary-label">💰 Total available</span><span class="summary-value">${Helpers.formatCurrency(t.total)}</span></div></div></div>
    <div class="card"><div class="card-title">🏦 Available by account</div><div style="overflow:auto"><table class="transaction-table"><thead><tr><th>Account</th><th>Type</th><th>Bank</th><th>Account No.</th><th>Available</th></tr></thead><tbody>${t.rows.map(x=>`<tr><td><b>${Helpers.esc(x.a.name)}</b></td><td>${x.a.type}</td><td>${Helpers.esc(x.a.bankName||'')}</td><td>${Helpers.esc(x.a.accountNumber||'')}</td><td><b>${Helpers.formatCurrency(x.b)}</b></td></tr>`).join('')}</tbody></table></div></div>
    <div class="card"><div class="card-title">🧮 Reconcile cash / bank / wallet</div><small>Compare the app balance with your physical cash count, bank statement, or mobile-wallet statement. Differences are recorded for review; StockPro will not silently change your money balance.</small>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-top:10px"><div class="form-group"><label>Account</label><select class="form-control" id="crAccount">${this.selectOptions()}</select></div><div class="form-group"><label>Statement/count date</label><input class="form-control" id="crDate" type="date" value="${Helpers.getToday()}"></div><div class="form-group"><label>Actual counted/statement balance</label><input class="form-control" id="crActual" type="number" min="0" step="0.01" placeholder="0.00"></div><div class="form-group"><label>Note</label><input class="form-control" id="crNote" placeholder="Statement ref / difference reason"></div></div><button class="btn btn-primary btn-sm" onclick="CashBanks.saveReconciliation()">Save reconciliation</button></div>
    <div class="card"><div class="card-title">📋 Reconciliation history</div>${this.reconciliationTable()}</div>
    <div class="card"><div class="card-title">🧾 Recent money movements</div>${this.txTable()}</div>`;
  },
  reconciliationTable(){
    const rows=(State.cashReconciliations||[]).slice().sort((a,b)=>String(b.date).localeCompare(String(a.date))).slice(0,100);
    if(!rows.length)return '<div class="empty-state">No reconciliations recorded yet.</div>';
    return `<div style="overflow:auto"><table class="transaction-table"><thead><tr><th>Date</th><th>Account</th><th>App balance</th><th>Actual balance</th><th>Difference</th><th>Status / note</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${Helpers.formatDate(r.date)}</td><td>${Helpers.esc(r.accountName||this.get(r.accountId)?.name||'Account')}</td><td>${Helpers.formatCurrency(r.expectedBalance)}</td><td>${Helpers.formatCurrency(r.actualBalance)}</td><td><b>${Helpers.formatCurrency(r.difference)}</b></td><td>${r.status==='matched'?'✅ Matched':'⚠️ Review'} ${Helpers.esc(r.note||'')}</td></tr>`).join('')}</tbody></table></div>`;
  },
  txTable(){
    const tx=State.moneyTransactions.filter(x=>x.status!=='void').slice(0,100);if(!tx.length)return '<div class="empty-state">No money movements yet.</div>';
    return `<div style="overflow:auto"><table class="transaction-table"><thead><tr><th>Date</th><th>Account</th><th>Type</th><th>Amount</th><th>Reference</th></tr></thead><tbody>${tx.map(x=>{const a=this.get(x.accountId),pos=['in','opening','transfer_in','adjustment_in'].includes(x.type);return `<tr><td>${Helpers.formatDate(x.date)}</td><td>${Helpers.esc(a?.name||'Unknown')}</td><td>${x.type.replace('_',' ')}</td><td>${pos?'+':'-'} ${Helpers.formatCurrency(x.amount)}</td><td>${Helpers.esc(x.note||x.sourceType||'')}</td></tr>`}).join('')}</tbody></table></div>`;
  }
};
window.CashBanks=CashBanks;return CashBanks;});
})();
