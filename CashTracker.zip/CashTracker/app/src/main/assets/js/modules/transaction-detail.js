// ============================================
// UNIVERSAL TRANSACTION DETAIL VIEWER - COMPLETE FIXED
// ============================================

(function() {
    'use strict';
    
    const MODULE_NAME = 'TransactionDetail';
    
    console.log('📦 Registering ' + MODULE_NAME + '...');
    
    window.registerModule(MODULE_NAME, function() {
        console.log('✅ ' + MODULE_NAME + ' initializing...');
        
        // ============================================
        // SAFE HELPER FUNCTIONS - No dependency on EthiopianDate
        // ============================================
        
        function safeFormatDate(dateStr) {
            if (!dateStr) return '';
            try {
                const date = new Date(dateStr + 'T00:00:00');
                if (isNaN(date.getTime())) return dateStr;
                return date.toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                });
            } catch(e) {
                return dateStr;
            }
        }
        
        function safeFormatCurrency(amount) {
            if (amount === undefined || amount === null) return 'ETB 0.00';
            return 'ETB ' + (amount || 0).toFixed(2);
        }
        
        function safeEscape(str) {
            if (!str) return '';
            try {
                const div = document.createElement('div');
                div.textContent = str;
                return div.innerHTML;
            } catch(e) {
                return str || '';
            }
        }
        
        function safeGetToday() {
            try {
                return new Date().toISOString().slice(0, 10);
            } catch(e) {
                return '';
            }
        }
        
        // Try to use global Helpers, fallback to safe functions
        function formatDate(dateStr) {
            try {
                if (typeof Helpers !== 'undefined' && Helpers.formatDate) {
                    return Helpers.formatDate(dateStr);
                }
                return safeFormatDate(dateStr);
            } catch(e) {
                return safeFormatDate(dateStr);
            }
        }
        
        function formatCurrency(amount) {
            try {
                if (typeof Helpers !== 'undefined' && Helpers.formatCurrency) {
                    return Helpers.formatCurrency(amount);
                }
                return safeFormatCurrency(amount);
            } catch(e) {
                return safeFormatCurrency(amount);
            }
        }
        
        function escapeHtml(str) {
            try {
                if (typeof Helpers !== 'undefined' && Helpers.esc) {
                    return Helpers.esc(str);
                }
                return safeEscape(str);
            } catch(e) {
                return safeEscape(str);
            }
        }
        
        // ============================================
        // TRANSACTION DETAIL OBJECT
        // ============================================
        
        const TransactionDetail = {
            // Show detail with error handling
            show(entityType, entityId) {
                console.log('🔍 Showing detail:', entityType, entityId);
                
                try {
                    // ✅ Check if State is loaded
                    if (typeof State === 'undefined') {
                        Toast.error('System not ready. Please refresh.');
                        return;
                    }
                    
                    switch(entityType) {
                        case 'product':
                            this.showProductDetail(entityId);
                            break;
                        case 'customer':
                            this.showCustomerDetail(entityId);
                            break;
                        case 'supplier':
                            this.showSupplierDetail(entityId);
                            break;
                        case 'sale':
                            this.showSaleDetail(entityId);
                            break;
                        case 'purchase':
                            this.showPurchaseDetail(entityId);
                            break;
                        case 'return':
                            this.showReturnDetail(entityId);
                            break;
                        default:
                            Toast.error('Unknown entity type: ' + entityType);
                    }
                } catch (error) {
                    console.error('TransactionDetail error:', error);
                    Toast.error('Error loading details: ' + error.message);
                }
            },

            showProductDetail(id) {
                console.log('📦 Showing product detail:', id);
                try {
                    const product = State.products.find(p => p.id === id);
                    if (!product) { Toast.error('Product not found'); return; }

                    const transactions = this.getAllProductTransactions(id);
                    const stock = Number(product.stock || 0);
                    let status = '✅ In Stock', statusClass = 'status-good';
                    if (stock < 0) { status = '❌ Negative'; statusClass = 'status-negative'; }
                    else if (stock <= 0) { status = '❌ Out of Stock'; statusClass = 'status-out'; }
                    else if (stock <= Number(product.minStock ?? 5)) { status = '⚠️ Low Stock'; statusClass = 'status-low'; }
                    else if (stock <= 15) { status = '⚡ Medium'; statusClass = 'status-medium'; }

                    const margin = product.sell && product.buy ? ((product.sell-product.buy)/product.sell*100).toFixed(1) : '?';
                    const totalSold = transactions.sales.reduce((a,s)=>a+s.qty,0);
                    const totalRevenue = transactions.sales.reduce((a,s)=>a+s.amount,0);
                    const totalProfit = transactions.sales.reduce((a,s)=>a+s.profit,0);
                    const totalPurchased = transactions.purchases.reduce((a,p)=>a+p.qty,0);
                    const totalCost = transactions.purchases.reduce((a,p)=>a+p.costAmount,0);
                    const totalReturned = transactions.returns.reduce((a,r)=>a+r.qty,0);
                    const totalRefund = transactions.returns.reduce((a,r)=>a+r.amount,0);
                    const supplierMap={};
                    transactions.purchases.forEach(p=>{
                        const key=p.supplierId||'unknown';
                        if(!supplierMap[key]) supplierMap[key]={supplierId:p.supplierId,name:p.supplier||'Unknown',qty:0,cost:0,lastDate:'',lastCost:0};
                        const x=supplierMap[key]; x.qty+=p.qty; x.cost+=p.costAmount;
                        if(!x.lastDate || new Date(p.date)>new Date(x.lastDate)){x.lastDate=p.date;x.lastCost=p.cost;}
                    });
                    const suppliers=Object.values(supplierMap).sort((a,b)=>b.qty-a.qty);
                    const similar=this.getSimilarProducts(product);

                    let html=`
                        <div class="detail-section">
                            <h4>📦 ${escapeHtml(product.name)}</h4>
                            <div class="detail-row"><span class="detail-label">Category:</span><span class="detail-value">${escapeHtml(product.category||'Uncategorized')}</span></div>
                            <div class="detail-row"><span class="detail-label">SKU / Barcode:</span><span class="detail-value">${escapeHtml(product.barcode||'—')}</span></div>
                            <div class="detail-row"><span class="detail-label">Buy / Sell:</span><span class="detail-value">${formatCurrency(product.buy||0)} / ${formatCurrency(product.sell||0)} (${margin}%)</span></div>
                            <div class="detail-row"><span class="detail-label">Available stock:</span><span class="detail-value"><span class="stock-status ${statusClass}">${status} (${stock})</span></span></div>
                            <div class="detail-row"><span class="detail-label">Stock value:</span><span class="detail-value">${formatCurrency((product.buy||0)*stock)}</span></div>
                            ${product.notes?'<div class="detail-row"><span class="detail-label">Notes:</span><span class="detail-value">'+escapeHtml(product.notes)+'</span></div>':''}
                        </div>
                        <div class="detail-section">
                            <h4>📊 Stock & Performance</h4>
                            <div class="stock-summary-grid">
                                <div class="stock-summary-item"><span class="summary-label">Purchased</span><span class="summary-value text-success">+${totalPurchased}</span></div>
                                <div class="stock-summary-item"><span class="summary-label">Sold</span><span class="summary-value text-danger">-${totalSold}</span></div>
                                <div class="stock-summary-item"><span class="summary-label">Returned</span><span class="summary-value text-warning">+${totalReturned}</span></div>
                                <div class="stock-summary-item"><span class="summary-label">Current</span><span class="summary-value text-primary">${stock}</span></div>
                            </div>
                            <div class="stock-summary-total"><span>💰 Revenue: ${formatCurrency(totalRevenue)}</span><span>📥 Cost: ${formatCurrency(totalCost)}</span><span>📈 Profit: ${formatCurrency(totalProfit)}</span><span>↩️ Refund: ${formatCurrency(totalRefund)}</span></div>
                        </div>
                    `;
                    html += this.renderProductSuppliersTable(suppliers);
                    html += this.renderSimilarProductsTable(similar);
                    html += this.renderPurchasesTable(transactions.purchases);
                    html += this.renderSalesTable(transactions.sales);
                    html += this.renderReturnsTable(transactions.returns);
                    html += `<div class="detail-section"><h4>⚡ Quick Actions</h4><div style="display:flex;gap:8px;flex-wrap:wrap;">
                        <button class="btn btn-outline btn-sm" onclick="StockLedger.show('${product.id}')">📚 Ledger</button>
                        <button class="btn btn-primary btn-sm" onclick="Sales.openSellModal('${product.id}')">💰 Sell</button>
                        <button class="btn btn-success btn-sm" onclick="Products.adjustStock('${product.id}')">➕ Add Stock</button>
                        <button class="btn btn-danger btn-sm" onclick="Products.reduceStock('${product.id}')">➖ Reduce</button>
                        <button class="btn btn-warning btn-sm" onclick="Products.edit('${product.id}')">✏️ Edit</button>
                    </div></div>`;
                    document.getElementById('detailModalContent').innerHTML=html;
                    document.getElementById('detailModalTitle').textContent='📦 '+escapeHtml(product.name);
                    Modals.open('detailModal');
                } catch(error){ console.error('showProductDetail error:',error); Toast.error('Error loading product details: '+error.message); }
            },

            showCustomerDetail(id) {
                try {
                    const customer=State.customers.find(c=>c.id===id);
                    if(!customer){Toast.error('Customer not found');return;}
                    const balance=Number(customer.balance||0), advance=Number(customer.customerAdvance||0);
                    const transactions=this.getAllCustomerTransactions(id);
                    const payments=this.getEntityPayments('customer',id);
                    const totalSales=transactions.sales.reduce((a,s)=>a+s.amount,0);
                    const totalPaid=transactions.sales.reduce((a,s)=>a+s.paid,0);
                    const totalDebit=transactions.sales.reduce((a,s)=>a+s.debit,0);
                    const totalProfit=transactions.sales.reduce((a,s)=>a+s.profit,0);
                    const lastPayment=payments[0];
                    let cls=balance>0?'balance-positive':balance<0?'balance-negative':'balance-zero';
                    let label=balance>0?'Owes us':balance<0?'Credit':'Settled';
                    const html=`
                        <div class="detail-section"><h4>👤 ${escapeHtml(customer.name)}</h4>
                            <div class="detail-row"><span class="detail-label">Phone:</span><span class="detail-value">${escapeHtml(customer.contact||'')}</span></div>
                            <div class="detail-row"><span class="detail-label">Address:</span><span class="detail-value">${escapeHtml(customer.address||'')}</span></div>
                            <div class="detail-row"><span class="detail-label">Customer owes us:</span><span class="detail-value"><span class="balance-badge ${cls}">${formatCurrency(Math.max(balance,0))}</span></span></div>
                            <div class="detail-row"><span class="detail-label">We owe customer:</span><span class="detail-value"><span class="balance-badge ${advance>0?'balance-negative':'balance-zero'}">${formatCurrency(advance)}</span></span></div>
                            <div class="detail-row"><span class="detail-label">Net position:</span><span class="detail-value"><b>${balance>=advance?formatCurrency(balance-advance)+' owed to us':formatCurrency(advance-balance)+' owed to customer'}</b></span></div>
                        </div>
                        <div class="detail-section"><h4>📊 Customer Summary</h4><div class="stock-summary-grid">
                            <div class="stock-summary-item"><span class="summary-label">Total sales</span><span class="summary-value text-primary">${formatCurrency(totalSales)}</span></div>
                            <div class="stock-summary-item"><span class="summary-label">Recorded sale payments</span><span class="summary-value text-success">${formatCurrency(totalPaid)}</span></div>
                            <div class="stock-summary-item"><span class="summary-label">Outstanding sales</span><span class="summary-value text-danger">${formatCurrency(totalDebit)}</span></div>
                            <div class="stock-summary-item"><span class="summary-label">Profit generated</span><span class="summary-value">${formatCurrency(totalProfit)}</span></div>
                        </div>
                        <div class="detail-row"><span class="detail-label">Last payment:</span><span class="detail-value">${lastPayment?formatDate(lastPayment.date):'No payment recorded'}</span></div>
                        ${lastPayment?`<div class="detail-row"><span class="detail-label">Last payment amount:</span><span class="detail-value">${formatCurrency(lastPayment.amountNumber||lastPayment.amount||0)} (${escapeHtml(lastPayment.method||'')})</span></div>`:''}
                        </div>`;
                    html+=this.renderCustomerPaymentTable(payments);
                    html+=this.renderCustomerSalesTable(transactions.sales);
                    html+=this.renderCustomerProductsTable(transactions.products);
                    html+=`<div class="detail-section"><h4>⚡ Quick Actions</h4><div style="display:flex;gap:8px;flex-wrap:wrap;"><button class="btn btn-primary btn-sm" onclick="Sales.openSellModal()">💰 New Sale</button><button class="btn btn-info btn-sm" onclick="Payments.openModal('customer','${customer.id}')">💳 Record Payment</button><button class="btn btn-success btn-sm" onclick="Customers.openShareModal('customer','${customer.id}')">📤 Share Balance</button></div></div>`;
                    document.getElementById('detailModalContent').innerHTML=html;document.getElementById('detailModalTitle').textContent='👤 '+escapeHtml(customer.name);Modals.open('detailModal');
                }catch(error){console.error('showCustomerDetail error:',error);Toast.error('Error loading customer details: '+error.message);}
            },

            showSupplierDetail(id) {
                try {
                    const supplier=State.suppliers.find(s=>s.id===id);
                    if(!supplier){Toast.error('Supplier not found');return;}
                    const balance=Number(supplier.balance||0), advance=Number(supplier.supplierAdvance||0);
                    const transactions=this.getAllSupplierTransactions(id);
                    const payments=this.getEntityPayments('supplier',id);
                    const totalPurchases=transactions.purchases.reduce((a,p)=>a+p.amount,0);
                    const totalPaid=transactions.purchases.reduce((a,p)=>a+p.paid,0);
                    const totalDebit=transactions.purchases.reduce((a,p)=>a+p.debit,0);
                    const currentStock=transactions.products.reduce((a,p)=>a+p.currentStock,0);
                    const currentStockValue=transactions.products.reduce((a,p)=>a+p.currentStockValue,0);
                    const lastPayment=payments[0];
                    const html=`
                        <div class="detail-section"><h4>🏢 ${escapeHtml(supplier.name)}</h4>
                            <div class="detail-row"><span class="detail-label">Phone:</span><span class="detail-value">${escapeHtml(supplier.contact||'')}</span></div>
                            <div class="detail-row"><span class="detail-label">Address:</span><span class="detail-value">${escapeHtml(supplier.address||'')}</span></div>
                            <div class="detail-row"><span class="detail-label">We owe supplier:</span><span class="detail-value"><span class="balance-badge ${balance>0?'balance-positive':'balance-zero'}">${formatCurrency(balance)}</span></span></div>
                            <div class="detail-row"><span class="detail-label">Supplier owes us:</span><span class="detail-value"><span class="balance-badge ${advance>0?'balance-negative':'balance-zero'}">${formatCurrency(advance)}</span></span></div>
                            <div class="detail-row"><span class="detail-label">Net position:</span><span class="detail-value"><b>${balance>=advance?formatCurrency(balance-advance)+' payable to supplier':formatCurrency(advance-balance)+' receivable from supplier'}</b></span></div>
                        </div>
                        <div class="detail-section"><h4>📊 Supplier Summary</h4><div class="stock-summary-grid">
                            <div class="stock-summary-item"><span class="summary-label">Total purchases</span><span class="summary-value text-primary">${formatCurrency(totalPurchases)}</span></div>
                            <div class="stock-summary-item"><span class="summary-label">Total paid</span><span class="summary-value text-success">${formatCurrency(totalPaid)}</span></div>
                            <div class="stock-summary-item"><span class="summary-label">Outstanding purchases</span><span class="summary-value text-danger">${formatCurrency(totalDebit)}</span></div>
                            <div class="stock-summary-item"><span class="summary-label">Current supplied-product stock</span><span class="summary-value">${currentStock}</span></div>
                        </div>
                        <div class="detail-row"><span class="detail-label">Current stock value:</span><span class="detail-value">${formatCurrency(currentStockValue)}</span></div>
                        <div class="detail-row"><span class="detail-label">Last payment:</span><span class="detail-value">${lastPayment?formatDate(lastPayment.date):'No payment recorded'}</span></div>
                        ${lastPayment?`<div class="detail-row"><span class="detail-label">Last payment amount:</span><span class="detail-value">${formatCurrency(lastPayment.amountNumber||lastPayment.amount||0)} (${escapeHtml(lastPayment.method||'')})</span></div>`:''}
                        <div style="font-size:.75rem;color:var(--text2);margin-top:8px;">ℹ️ Stock value means the current stock of products historically supplied by this supplier. It is not treated as supplier-owned stock unless consignment/ownership tracking is enabled.</div></div>`;
                    html+=this.renderSupplierPaymentTable(payments);
                    html+=this.renderSupplierPurchasesTable(transactions.purchases);
                    html+=this.renderSupplierProductsTable(transactions.products);
                    html+=`<div class="detail-section"><h4>⚡ Quick Actions</h4><div style="display:flex;gap:8px;flex-wrap:wrap;"><button class="btn btn-primary btn-sm" onclick="Purchases.openModal()">📥 New Purchase</button><button class="btn btn-info btn-sm" onclick="Payments.openModal('supplier','${supplier.id}')">💳 Record Payment</button><button class="btn btn-success btn-sm" onclick="Customers.openShareModal('supplier','${supplier.id}')">📤 Share Balance</button></div></div>`;
                    document.getElementById('detailModalContent').innerHTML=html;document.getElementById('detailModalTitle').textContent='🏢 '+escapeHtml(supplier.name);Modals.open('detailModal');
                }catch(error){console.error('showSupplierDetail error:',error);Toast.error('Error loading supplier details: '+error.message);}
            },

            showSaleDetail(id) {
                try {
                    const sale = State.sales.find(s => s.id === id);
                    if (!sale) {
                        Toast.error('Sale not found');
                        return;
                    }

                    const cls = (sale.debitRemaining || 0) > 0 ? 'balance-positive' : 'balance-zero';

                    const itemsHtml = (sale.items || []).map(item => `
                        <tr onclick="TransactionDetail.show('product', '${item.productId}')" style="cursor:pointer;">
                            <td style="color:var(--primary);">${escapeHtml(item.productName)}</td>
                            <td>${item.quantity}</td>
                            <td>${formatCurrency(item.price)}</td>
                            <td>${formatCurrency(item.amount)}</td>
                        </tr>
                    `).join('');

                    const html = `
                        <div class="detail-section">
                            <h4>💰 Sale #${sale.id ? sale.id.slice(0, 8) : 'N/A'}</h4>
                            <div class="detail-row"><span class="detail-label">Date:</span><span class="detail-value">${formatDate(sale.date)}</span></div>
                            <div class="detail-row"><span class="detail-label">Customer:</span><span class="detail-value" onclick="TransactionDetail.show('customer', '${sale.customerId || ''}')" style="cursor:pointer;color:var(--primary);text-decoration:underline;text-decoration-style:dotted;">${escapeHtml(sale.customer || 'Walk-in')}</span></div>
                            <div class="detail-row"><span class="detail-label">Total:</span><span class="detail-value">${formatCurrency(sale.total)}</span></div>
                            <div class="detail-row"><span class="detail-label">Paid:</span><span class="detail-value">${formatCurrency(sale.paymentReceived || 0)}</span></div>
                            <div class="detail-row"><span class="detail-label">Balance:</span><span class="detail-value"><span class="status-badge ${(sale.debitRemaining || 0) > 0 ? 'status-debit' : 'status-paid'}">${(sale.debitRemaining || 0) > 0 ? 'Debit: ' + formatCurrency(sale.debitRemaining) : 'Paid'}</span></span></div>
                            <div class="detail-row"><span class="detail-label">Profit:</span><span class="detail-value" style="color:${(sale.profit || 0) >= 0 ? 'var(--success)' : 'var(--danger)'}">${formatCurrency(sale.profit || 0)}</span></div>
                            ${sale.notes ? `<div class="detail-row"><span class="detail-label">📝 Notes:</span><span class="detail-value">${escapeHtml(sale.notes)}</span></div>` : ''}
                        </div>

                        <div class="detail-section">
                            <h4>📦 Items</h4>
                            <table class="transaction-table">
                                <thead><tr><th>Product</th><th>Qty</th><th>Price</th><th>Amount</th></tr></thead>
                                <tbody>${itemsHtml}</tbody>
                            </table>
                        </div>

                        <div class="detail-section">
                            <h4>⚡ Quick Actions</h4>
                            <div style="display:flex;gap:8px;flex-wrap:wrap;">
                                <button class="btn btn-info btn-sm" onclick="window.print()">🖨️ Print</button>
                                <button class="btn btn-warning btn-sm" onclick="Sales.edit('${sale.id}')">✏️ Edit</button>
                                ${sale.customerId ? `<button class="btn btn-success btn-sm" onclick="TransactionDetail.show('customer', '${sale.customerId}')">👤 View Customer</button>` : ''}
                            </div>
                        </div>
                    `;

                    document.getElementById('detailModalContent').innerHTML = html;
                    document.getElementById('detailModalTitle').textContent = '💰 Sale Details';
                    Modals.open('detailModal');
                    
                } catch (error) {
                    console.error('showSaleDetail error:', error);
                    Toast.error('Error loading sale details: ' + error.message);
                }
            },

            showPurchaseDetail(id) {
                try {
                    const purchase = State.purchases.find(p => p.id === id);
                    if (!purchase) {
                        Toast.error('Purchase not found');
                        return;
                    }

                    const itemsHtml = (purchase.items || []).map(item => `
                        <tr onclick="TransactionDetail.show('product', '${item.productId}')" style="cursor:pointer;">
                            <td style="color:var(--primary);">${escapeHtml(item.productName)}</td>
                            <td>${item.quantity}</td>
                            <td>${formatCurrency(item.cost)}</td>
                            <td>${formatCurrency(item.amount)}</td>
                        </tr>
                    `).join('');

                    const html = `
                        <div class="detail-section">
                            <h4>📥 Purchase #${purchase.id ? purchase.id.slice(0, 8) : 'N/A'}</h4>
                            <div class="detail-row"><span class="detail-label">Date:</span><span class="detail-value">${formatDate(purchase.date)}</span></div>
                            <div class="detail-row"><span class="detail-label">Supplier:</span><span class="detail-value" onclick="TransactionDetail.show('supplier', '${purchase.supplierId || ''}')" style="cursor:pointer;color:var(--primary);text-decoration:underline;text-decoration-style:dotted;">${escapeHtml(purchase.supplier || 'Unknown')}</span></div>
                            <div class="detail-row"><span class="detail-label">Total:</span><span class="detail-value">${formatCurrency(purchase.total)}</span></div>
                            <div class="detail-row"><span class="detail-label">Paid:</span><span class="detail-value">${formatCurrency(purchase.paid || 0)}</span></div>
                            <div class="detail-row"><span class="detail-label">Balance:</span><span class="detail-value"><span class="status-badge ${(purchase.debit || 0) > 0 ? 'status-debit' : 'status-paid'}">${(purchase.debit || 0) > 0 ? 'Debit: ' + formatCurrency(purchase.debit) : 'Paid'}</span></span></div>
                        </div>

                        <div class="detail-section">
                            <h4>📦 Items</h4>
                            <table class="transaction-table">
                                <thead><tr><th>Product</th><th>Qty</th><th>Cost</th><th>Amount</th></tr></thead>
                                <tbody>${itemsHtml}</tbody>
                            </table>
                        </div>

                        <div class="detail-section">
                            <h4>⚡ Quick Actions</h4>
                            <div style="display:flex;gap:8px;flex-wrap:wrap;">
                                <button class="btn btn-warning btn-sm" onclick="Purchases.edit('${purchase.id}')">✏️ Edit</button>
                                ${purchase.supplierId ? `<button class="btn btn-success btn-sm" onclick="TransactionDetail.show('supplier', '${purchase.supplierId}')">🏢 View Supplier</button>` : ''}
                            </div>
                        </div>
                    `;

                    document.getElementById('detailModalContent').innerHTML = html;
                    document.getElementById('detailModalTitle').textContent = '📥 Purchase Details';
                    Modals.open('detailModal');
                    
                } catch (error) {
                    console.error('showPurchaseDetail error:', error);
                    Toast.error('Error loading purchase details: ' + error.message);
                }
            },

            showReturnDetail(id) {
                try {
                    const returnItem = State.returns.find(r => r.id === id);
                    if (!returnItem) {
                        Toast.error('Return not found');
                        return;
                    }

                    const html = `
                        <div class="detail-section">
                            <h4>↩️ Return #${returnItem.id ? returnItem.id.slice(0, 8) : 'N/A'}</h4>
                            <div class="detail-row"><span class="detail-label">Date:</span><span class="detail-value">${formatDate(returnItem.date)}</span></div>
                            <div class="detail-row"><span class="detail-label">Product:</span><span class="detail-value" onclick="TransactionDetail.show('product', '${returnItem.productId}')" style="cursor:pointer;color:var(--primary);text-decoration:underline;text-decoration-style:dotted;">${escapeHtml(returnItem.productName)}</span></div>
                            <div class="detail-row"><span class="detail-label">Quantity:</span><span class="detail-value">${returnItem.quantity}</span></div>
                            <div class="detail-row"><span class="detail-label">Refund/Unit:</span><span class="detail-value">${formatCurrency(returnItem.refundPerUnit || 0)}</span></div>
                            <div class="detail-row"><span class="detail-label">Total Refund:</span><span class="detail-value">${formatCurrency(returnItem.totalRefund || 0)}</span></div>
                        </div>
                    `;

                    document.getElementById('detailModalContent').innerHTML = html;
                    document.getElementById('detailModalTitle').textContent = '↩️ Return Details';
                    Modals.open('detailModal');
                    
                } catch (error) {
                    console.error('showReturnDetail error:', error);
                    Toast.error('Error loading return details: ' + error.message);
                }
            },

            // ============================================
            // PROFILE / RELATIONSHIP HELPERS
            // ============================================

            getEntityPayments(entityType, entityId) {
                return (State.paymentLedger||[]).filter(p=>p.entityType===entityType&&p.entityId===entityId&&p.status!=='void')
                    .sort((a,b)=>new Date(b.date||b.createdAt)-new Date(a.date||a.createdAt));
            },

            getSimilarProducts(product) {
                const nameTokens=String(product.name||'').toLowerCase().split(/\s+/).filter(x=>x.length>2);
                return (State.products||[]).filter(p=>p.id!==product.id).map(p=>{
                    let score=0;
                    if(product.category&&p.category&&String(product.category).toLowerCase()===String(p.category).toLowerCase())score+=5;
                    const n=String(p.name||'').toLowerCase(); nameTokens.forEach(t=>{if(n.includes(t))score+=2;});
                    return {p,score};
                }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score||String(a.p.name).localeCompare(String(b.p.name))).slice(0,8).map(x=>x.p);
            },

            renderProductSuppliersTable(suppliers) {
                if(!suppliers.length)return '<div class="detail-section"><h4>🏢 Suppliers</h4><div class="empty-state">No purchase supplier history</div></div>';
                return `<div class="detail-section"><h4>🏢 Suppliers & Purchase History</h4><table class="transaction-table"><thead><tr><th>Supplier</th><th>Qty bought</th><th>Last price</th><th>Last purchase</th></tr></thead><tbody>${suppliers.map(s=>`<tr ${s.supplierId?`onclick="TransactionDetail.show('supplier','${s.supplierId}')" style="cursor:pointer;"`:''}><td style="color:var(--primary);">${escapeHtml(s.name)}</td><td>${s.qty}</td><td>${formatCurrency(s.lastCost)}</td><td>${s.lastDate?formatDate(s.lastDate):'—'}</td></tr>`).join('')}</tbody></table></div>`;
            },

            renderSimilarProductsTable(products) {
                if(!products.length)return '';
                return `<div class="detail-section"><h4>🔎 Similar Products</h4><table class="transaction-table"><thead><tr><th>Product</th><th>Category</th><th>Stock</th><th>Sell Price</th></tr></thead><tbody>${products.map(p=>`<tr onclick="TransactionDetail.show('product','${p.id}')" style="cursor:pointer;"><td style="color:var(--primary);">${escapeHtml(p.name)}</td><td>${escapeHtml(p.category||'—')}</td><td>${Number(p.stock||0)}</td><td>${formatCurrency(p.sell||0)}</td></tr>`).join('')}</tbody></table></div>`;
            },

            renderCustomerPaymentTable(payments) {
                if(!payments.length)return '<div class="detail-section"><h4>💳 Payment History</h4><div class="empty-state">No customer payments recorded</div></div>';
                return `<div class="detail-section"><h4>💳 Payment History (${payments.length})</h4><table class="transaction-table"><thead><tr><th>Date</th><th>Amount</th><th>Method</th><th>Type</th><th>Reference</th></tr></thead><tbody>${payments.slice(0,30).map(p=>`<tr><td>${formatDate(p.date)}</td><td>${formatCurrency(p.amountNumber||p.amount||0)}</td><td>${escapeHtml(p.method||'')}</td><td>${p.kind==='advance'?'Advance':'Payment'}</td><td>${escapeHtml(p.reference||'')}</td></tr>`).join('')}</tbody></table></div>`;
            },

            renderSupplierPaymentTable(payments) {
                if(!payments.length)return '<div class="detail-section"><h4>💳 Payment History</h4><div class="empty-state">No supplier payments recorded</div></div>';
                return `<div class="detail-section"><h4>💳 Payment History (${payments.length})</h4><table class="transaction-table"><thead><tr><th>Date</th><th>Amount</th><th>Method</th><th>Type</th><th>Reference</th></tr></thead><tbody>${payments.slice(0,30).map(p=>`<tr><td>${formatDate(p.date)}</td><td>${formatCurrency(p.amountNumber||p.amount||0)}</td><td>${escapeHtml(p.method||'')}</td><td>${p.kind==='advance'?'Advance':'Payment'}</td><td>${escapeHtml(p.reference||'')}</td></tr>`).join('')}</tbody></table></div>`;
            },

            // ============================================
            // HELPER FUNCTIONS
            // ============================================
            
            getAllProductTransactions(productId) {
                try {
                    const sales = [];
                    const purchases = [];
                    const returns = [];

                    if (State.sales) {
                        State.sales.forEach(sale => {
                            if (sale.items) {
                                sale.items.forEach(item => {
                                    if (item.productId === productId) {
                                        const cost = sale.items.find(i => i.productId === productId)?.cost || 0;
                                        sales.push({
                                            saleId: sale.id,
                                            date: sale.date,
                                            customer: sale.customer || 'Walk-in',
                                            customerId: sale.customerId,
                                            qty: item.quantity,
                                            price: item.price,
                                            amount: item.amount,
                                            profit: (item.price - cost) * item.quantity || 0,
                                            status: (sale.debitRemaining || 0) > 0 ? 'Debit' : 'Paid'
                                        });
                                    }
                                });
                            }
                        });
                    }

                    if (State.purchases) {
                        State.purchases.forEach(purchase => {
                            if (purchase.items) {
                                purchase.items.forEach(item => {
                                    if (item.productId === productId) {
                                        purchases.push({
                                            date: purchase.date,
                                            supplier: purchase.supplier || 'Unknown',
                                            supplierId: purchase.supplierId,
                                            qty: item.quantity,
                                            cost: item.cost,
                                            costAmount: item.amount || ((item.cost || 0) * (item.quantity || 0)),
                                            amount: item.amount,
                                            status: (purchase.debit || 0) > 0 ? 'Debit' : 'Paid'
                                        });
                                    }
                                });
                            }
                        });
                    }

                    if (State.returns) {
                        State.returns.forEach(returnItem => {
                            if (returnItem.productId === productId) {
                                returns.push({
                                    date: returnItem.date,
                                    qty: returnItem.quantity || 0,
                                    refundPerUnit: returnItem.refundPerUnit || 0,
                                    amount: returnItem.totalRefund || 0
                                });
                            }
                        });
                    }

                    sales.sort((a, b) => new Date(b.date) - new Date(a.date));
                    purchases.sort((a, b) => new Date(b.date) - new Date(a.date));
                    returns.sort((a, b) => new Date(b.date) - new Date(a.date));

                    return { sales, purchases, returns };
                    
                } catch (error) {
                    console.error('getAllProductTransactions error:', error);
                    return { sales: [], purchases: [], returns: [] };
                }
            },

            getAllCustomerTransactions(customerId) {
                try {
                    const sales = [];
                    const productMap = {};

                    if (State.sales) {
                        State.sales.forEach(sale => {
                            if (sale.customerId === customerId) {
                                const items = (sale.items || []).map(i => i.productName + ' x' + i.quantity);
                                sales.push({
                                    saleId: sale.id,
                                    date: sale.date,
                                    items: items,
                                    amount: sale.total || 0,
                                    paid: sale.paymentReceived || 0,
                                    debit: sale.debitRemaining || 0,
                                    profit: sale.profit || 0
                                });

                                (sale.items || []).forEach(item => {
                                    if (!productMap[item.productId]) {
                                        productMap[item.productId] = {
                                            productId: item.productId,
                                            name: item.productName,
                                            totalQty: 0,
                                            totalSpent: 0
                                        };
                                    }
                                    productMap[item.productId].totalQty += item.quantity;
                                    productMap[item.productId].totalSpent += item.amount;
                                });
                            }
                        });
                    }

                    sales.sort((a, b) => new Date(b.date) - new Date(a.date));
                    const products = Object.values(productMap).sort((a, b) => b.totalSpent - a.totalSpent);

                    return { sales, products };
                    
                } catch (error) {
                    console.error('getAllCustomerTransactions error:', error);
                    return { sales: [], products: [] };
                }
            },

            getAllSupplierTransactions(supplierId) {
                try {
                    const purchases = [];
                    const productMap = {};

                    if (State.purchases) {
                        State.purchases.forEach(purchase => {
                            if (purchase.supplierId === supplierId) {
                                const items = (purchase.items || []).map(i => i.productName + ' x' + i.quantity);
                                purchases.push({
                                    date: purchase.date,
                                    items: items,
                                    amount: purchase.total || 0,
                                    paid: purchase.paid || 0,
                                    debit: purchase.debit || 0
                                });

                                (purchase.items || []).forEach(item => {
                                    if (!productMap[item.productId]) {
                                        productMap[item.productId] = {
                                            productId: item.productId,
                                            name: item.productName,
                                            totalQty: 0,
                                            totalCost: 0,
                                            currentStock: 0,
                                            currentStockValue: 0
                                        };
                                    }
                                    productMap[item.productId].totalQty += item.quantity;
                                    productMap[item.productId].totalCost += item.amount;
                                });
                            }
                        });
                    }

                    purchases.sort((a, b) => new Date(b.date) - new Date(a.date));
                    const products = Object.values(productMap).sort((a, b) => b.totalCost - a.totalCost);

                    return { purchases, products };
                    
                } catch (error) {
                    console.error('getAllSupplierTransactions error:', error);
                    return { purchases: [], products: [] };
                }
            },

            // ============================================
            // RENDER FUNCTIONS - Using safe helpers
            // ============================================
            
            renderSalesTable(sales) {
                if (!sales || !sales.length) return '<div class="detail-section"><div class="empty-state">No sales</div></div>';
                
                return `
                    <div class="detail-section">
                        <h4>💰 Sales (${sales.length})</h4>
                        <table class="transaction-table">
                            <thead><tr><th>Date</th><th>Customer</th><th>Qty</th><th>Amount</th><th>Profit</th><th>Status</th></tr></thead>
                            <tbody>
                                ${sales.map(s => `
                                    <tr onclick="TransactionDetail.show('sale', '${s.saleId || ''}')" style="cursor:pointer;">
                                        <td>${formatDate(s.date)}</td>
                                        <td onclick="event.stopPropagation();TransactionDetail.show('customer', '${s.customerId || ''}')" style="cursor:pointer;color:var(--primary);">${escapeHtml(s.customer)}</td>
                                        <td>${s.qty}</td>
                                        <td>${formatCurrency(s.amount)}</td>
                                        <td style="color:${s.profit >= 0 ? 'var(--success)' : 'var(--danger)'}">${formatCurrency(s.profit)}</td>
                                        <td><span class="status-badge ${s.status === 'Paid' ? 'status-paid' : 'status-debit'}">${s.status}</span></td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            },

            renderPurchasesTable(purchases) {
                if (!purchases || !purchases.length) return '<div class="detail-section"><div class="empty-state">No purchases</div></div>';
                
                return `
                    <div class="detail-section">
                        <h4>📥 Purchases (${purchases.length})</h4>
                        <table class="transaction-table">
                            <thead><tr><th>Date</th><th>Supplier</th><th>Qty</th><th>Cost</th><th>Total</th><th>Status</th></tr></thead>
                            <tbody>
                                ${purchases.map(p => `
                                    <tr>
                                        <td>${formatDate(p.date)}</td>
                                        <td onclick="event.stopPropagation();TransactionDetail.show('supplier', '${p.supplierId || ''}')" style="cursor:pointer;color:var(--primary);">${escapeHtml(p.supplier)}</td>
                                        <td>${p.qty}</td>
                                        <td>${formatCurrency(p.cost)}</td>
                                        <td>${formatCurrency(p.amount)}</td>
                                        <td><span class="status-badge ${p.status === 'Paid' ? 'status-paid' : 'status-debit'}">${p.status}</span></td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            },

            renderReturnsTable(returns) {
                if (!returns || !returns.length) return '<div class="detail-section"><div class="empty-state">No returns</div></div>';
                
                return `
                    <div class="detail-section">
                        <h4>↩️ Returns (${returns.length})</h4>
                        <table class="transaction-table">
                            <thead><tr><th>Date</th><th>Qty</th><th>Refund/Unit</th><th>Total Refund</th></tr></thead>
                            <tbody>
                                ${returns.map(r => `
                                    <tr>
                                        <td>${formatDate(r.date)}</td>
                                        <td>${r.qty}</td>
                                        <td>${formatCurrency(r.refundPerUnit)}</td>
                                        <td>${formatCurrency(r.amount)}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            },

            renderCustomerSalesTable(sales) {
                if (!sales || !sales.length) return '<div class="detail-section"><div class="empty-state">No sales</div></div>';
                
                return `
                    <div class="detail-section">
                        <h4>💰 Sales (${sales.length})</h4>
                        <table class="transaction-table">
                            <thead><tr><th>Date</th><th>Items</th><th>Total</th><th>Paid</th><th>Balance</th><th>Profit</th></tr></thead>
                            <tbody>
                                ${sales.map(s => `
                                    <tr onclick="TransactionDetail.show('sale', '${s.saleId || ''}')" style="cursor:pointer;">
                                        <td>${formatDate(s.date)}</td>
                                        <td>${s.items.join(', ')}</td>
                                        <td>${formatCurrency(s.amount)}</td>
                                        <td>${formatCurrency(s.paid)}</td>
                                        <td>${formatCurrency(s.debit)}</td>
                                        <td style="color:${s.profit >= 0 ? 'var(--success)' : 'var(--danger)'}">${formatCurrency(s.profit)}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            },

            renderCustomerProductsTable(products) {
                if (!products || !products.length) return '<div class="detail-section"><div class="empty-state">No products</div></div>';
                
                return `
                    <div class="detail-section">
                        <h4>📦 Products Bought</h4>
                        <table class="transaction-table">
                            <thead><tr><th>Product</th><th>Total Qty</th><th>Total Spent</th></tr></thead>
                            <tbody>
                                ${products.map(p => `
                                    <tr onclick="TransactionDetail.show('product', '${p.productId || ''}')" style="cursor:pointer;">
                                        <td style="color:var(--primary);">${escapeHtml(p.name)}</td>
                                        <td>${p.totalQty}</td>
                                        <td>${formatCurrency(p.totalSpent)}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            },

            renderSupplierPurchasesTable(purchases) {
                if (!purchases || !purchases.length) return '<div class="detail-section"><div class="empty-state">No purchases</div></div>';
                
                return `
                    <div class="detail-section">
                        <h4>📥 Purchase Orders (${purchases.length})</h4>
                        <table class="transaction-table">
                            <thead><tr><th>Date</th><th>Items</th><th>Total</th><th>Paid</th><th>Balance</th></tr></thead>
                            <tbody>
                                ${purchases.map(p => `
                                    <tr>
                                        <td>${formatDate(p.date)}</td>
                                        <td>${p.items.join(', ')}</td>
                                        <td>${formatCurrency(p.amount)}</td>
                                        <td>${formatCurrency(p.paid)}</td>
                                        <td>${formatCurrency(p.debit)}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            },

            renderSupplierProductsTable(products) {
                if (!products || !products.length) return '<div class="detail-section"><div class="empty-state">No products</div></div>';
                
                return `
                    <div class="detail-section">
                        <h4>📦 Products Supplied</h4>
                        <table class="transaction-table">
                            <thead><tr><th>Product</th><th>Total Qty</th><th>Total Cost</th></tr></thead>
                            <tbody>
                                ${products.map(p => `
                                    <tr onclick="TransactionDetail.show('product', '${p.productId || ''}')" style="cursor:pointer;">
                                        <td style="color:var(--primary);">${escapeHtml(p.name)}</td>
                                        <td>${p.totalQty}</td>
                                        <td>${formatCurrency(p.totalCost)}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            }
        };
        
        // Expose globally
        window.TransactionDetail = TransactionDetail;
        
        // Also expose showDetail directly for inline onclick
        window.showDetail = function(entityType, entityId) {
            TransactionDetail.show(entityType, entityId);
        };
        
        console.log('✅ ' + MODULE_NAME + ' loaded successfully');
        return TransactionDetail;
    });
    
})();