// SHARE HUB: send products and balances through WhatsApp, Telegram, imo, SMS or any app
(function(){'use strict';
window.registerModule('ShareHub',function(){
const esc=s=>Helpers.esc(String(s==null?'':s));
const fmt=n=>Helpers.formatCurrency(Number(n)||0);
const store=()=>{try{return JSON.parse(localStorage.getItem('stockProfile')||'{}').storeName||'StockPro'}catch(e){return 'StockPro'}};
const b64=u=>{u=String(u||'');return u.indexOf('data:image')===0?u.split(',')[1]||'':''};
const CH=[['whatsapp','💬 WhatsApp'],['telegram','✈️ Telegram'],['imo','🟣 imo'],['sms','📱 SMS'],['more','📤 More…']];
function send(ch,text,phone,img){
  phone=Helpers.convertToInternational(phone||'')||'';
  if(ch==='sms'&&!phone){Toast.warning('📱 Enter a phone number for SMS');return}
  if(window.Android&&Android.share){Android.share(ch,text,phone,img?b64(img):'');return}
  const e=encodeURIComponent(text),d=phone.replace(/\D/g,'');
  if(ch==='whatsapp')window.open('https://wa.me/'+d+'?text='+e,'_blank');
  else if(ch==='telegram')window.open('https://t.me/share/url?url=%20&text='+e,'_blank');
  else if(ch==='sms')window.open('sms:'+phone+'?body='+e,'_blank');
  else if(navigator.share)navigator.share({text}).catch(()=>{});
  else if(navigator.clipboard)navigator.clipboard.writeText(text).then(()=>Toast.success('📋 Copied. Paste it in '+ch));
}
function productText(p){
  const st=Number(p.stock)||0;
  return '🛍️ *'+p.name+'*\n'+(p.category?p.category+'\n':'')+'💰 Price: '+fmt(p.sell)+'\n'+(st>0?'📦 In stock: '+st:'❌ Out of stock')+'\n🏪 '+store();
}
const ShareHub={
  send,productText,
  shareLog(){
    let e=[];try{e=JSON.parse(localStorage.getItem('SP_errlog')||'[]')}catch(x){}
    send('more','StockPro SMS diagnostics\nNative bridge: '+(window.Android?'yes':'no')+'\n'+navigator.userAgent+'\n\nRecent errors:\n'+(e.join('\n')||'none'),'');
  },
  openProduct(id){
    const p=(State.products||[]).find(x=>x.id===id);if(!p)return;
    const img=(p.images||[]).find(u=>String(u).indexOf('data:image')===0)||'';
    let m=document.getElementById('shareProductModal');
    if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='shareProductModal';document.body.appendChild(m)}
    const custs=(State.customers||[]).filter(c=>c.contact);
    m.innerHTML=`<div class="modal" style="max-width:520px;max-height:90vh;overflow-y:auto"><button class="close-btn" onclick="Modals.close('shareProductModal')">✕</button>
    <h3>📤 Share Product</h3><div class="detail-section"><b>${esc(p.name)}</b><br>${fmt(p.sell)} · stock ${Number(p.stock)||0}</div>
    <div class="form-group"><label>👤 Send to customer (optional)</label><select class="form-control" id="spCust" onchange="document.getElementById('spPhone').value=this.value"><option value="">Choose in the app after tapping</option>${custs.map(c=>`<option value="${esc(c.contact)}">${esc(c.name)}</option>`).join('')}</select></div>
    <div class="form-group"><label>📱 Phone (optional)</label><input class="form-control" id="spPhone" type="tel" placeholder="0912345678"></div>
    ${img?'<label style="display:flex;gap:8px;align-items:center;margin:6px 0"><input type="checkbox" id="spImg" checked> 📸 Include photo</label>':''}
    <div class="form-group"><label>📝 Message</label><textarea class="form-control note-area" id="spText" rows="5">${esc(productText(p))}</textarea></div>
    <div class="share-buttons" style="display:flex;gap:6px;flex-wrap:wrap">${CH.map(c=>`<button class="btn btn-primary btn-sm" onclick="ShareHub.go('${c[0]}','${esc(p.id)}')">${c[1]}</button>`).join('')}</div></div>`;
    Modals.open('shareProductModal');
  },
  go(ch,id){
    const p=(State.products||[]).find(x=>x.id===id);if(!p)return;
    const img=(p.images||[]).find(u=>String(u).indexOf('data:image')===0)||'';
    const useImg=!!document.getElementById('spImg')?.checked;
    send(ch,document.getElementById('spText').value,document.getElementById('spPhone').value,useImg?img:'');
  }
};
function wrapCustomers(){
  if(!window.Customers||Customers._shareHub)return;Customers._shareHub=true;
  const msg=()=>document.getElementById('shareMessagePreview').textContent;
  const go=ch=>send(ch,msg(),Customers.getEffectivePhone());
  Customers.shareViaWhatsApp=()=>go('whatsapp');
  Customers.shareViaTelegram=()=>go('telegram');
  Customers.shareViaImo=()=>go('imo');
  Customers.shareViaNative=()=>go('more');
  Customers.shareViaSMS=()=>{if(!Customers.getEffectivePhone())return Toast.warning('📱 Enter a phone number');go('sms')};
  const o=Customers.openShareModal.bind(Customers);
  Customers.openShareModal=function(){o.apply(Customers,arguments);
    const row=document.querySelector('#shareModal .share-buttons');
    if(row&&!row.querySelector('.btn-imo')){const b=document.createElement('button');b.className='btn btn-outline btn-sm btn-imo';b.textContent='🟣 imo';b.onclick=Customers.shareViaImo;row.insertBefore(b,row.children[2]||null)}};
}
window.ShareHub=ShareHub;setTimeout(wrapCustomers,300);
return ShareHub;});
})();
