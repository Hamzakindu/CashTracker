// ROLES: staff PIN login, permissions that really block actions, and an audit viewer
(function(){'use strict';
window.registerModule('Roles',function(){
const USERS='SP_roles_users',SESSION='SP_roles_session',ACTOR='stockpro_actor';
const ROLES={
  owner:{label:'Owner',tabs:'*',can:['sell','stock','money','del','restore','users']},
  manager:{label:'Manager',tabs:'*',can:['sell','stock','money','del']},
  cashier:{label:'Cashier',tabs:['dashboard','sales','cashier','customers','returns','calculator','calcinbox','receivables','products','loyalty'],can:['sell']},
  inventory:{label:'Inventory clerk',tabs:['dashboard','products','purchases','suppliers','stockcount','lowstock','returns','calculator'],can:['stock']},
  accountant:{label:'Accountant',tabs:['dashboard','reports','accounting','cashbanks','banksms','expenses','finance','payables','receivables','peoplemoney','calculator'],can:['money']},
  viewer:{label:'Viewer (read only)',tabs:['dashboard','reports','products','sales','customers','suppliers','purchases','expenses','returns','accounting','cashbanks','finance','receivables','payables','peoplemoney','calculator'],can:[]}
};
const MENU_OWNER=/AppLock\.openSettings|CloudSync\.openPanel|Backup\.(restoreFromCloud|importBackup|recoverSafetySnapshot)|Profiles\.|TelegramModule\.openSettings/;
const MENU_DEL=/App\.undo|Backup\.exportBackup|TelegramModule\.backupToTelegram/;
// [Module.method, permission needed, optional [store, 'up'|'down'] so cancelled actions are not logged]
const GUARDS=[
  ['Sales.submit','sell',['sales','up']],['Sales.edit','del'],['Sales.delete','del',['sales','down']],['Returns.submit','sell',['returns','up']],
  ['Products.add','stock'],['Products.edit','stock'],['Products.saveEdit','stock'],['Products.adjustStock','stock'],['Products.applyAdjust','stock'],['Products.importCSV','stock'],['Products.removeImage','stock'],['Products.delete','del',['products','down']],
  ['Purchases.submit','stock',['purchases','up']],['Purchases.edit','del'],['Purchases.delete','del',['purchases','down']],
  ['Suppliers.save','stock'],['Suppliers.delete','del',['suppliers','down']],
  ['Customers.save','sell'],['Customers.add','sell'],['Customers.delete','del',['customers','down']],
  ['Expenses.submitDirect','money',['directExpenses','up']],['Expenses.recordExclusive','money'],['Expenses.saveType','money'],['Expenses.deleteDirect','del',['directExpenses','down']],['Expenses.deleteType','del'],
  ['CashBanks.addAccount','money'],['CashBanks.saveReconciliation','money'],['Payments.submitAdjust','money'],
  ['Backup.importBackup','restore'],['Backup.restoreFromCloud','restore'],['Backup.recoverSafetySnapshot','restore'],['CloudSync.openPanel','restore'],
  ['BankSMS.post','money'],['BankSMS.postAll','money'],['StockCount.apply','stock'],['Loyalty.redeem','sell'],
  ['App.undo','del'],['TelegramModule.backupToTelegram','del'],['TelegramModule.openSettings','users'],['AppLock.openSettings','users'],
  ['Profiles.openProfileModal','users'],['Profiles.addNewProfile','users'],['Tools.setPin','users'],['Tools.removePin','users']
];
const NOLOG=new Set(['Sales.delete','Sales.edit','Purchases.delete','Purchases.edit','BankSMS.post','BankSMS.postAll']); // these already write their own audit entries
const g=n=>{try{return (0,eval)('typeof '+n+'!=="undefined"?'+n+':undefined')}catch(e){return undefined}};
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const read=()=>{try{const v=JSON.parse(localStorage.getItem(USERS)||'[]');return Array.isArray(v)?v:[]}catch(e){return[]}};
const write=l=>localStorage.setItem(USERS,JSON.stringify(l));
const warn=m=>{try{Toast.warning(m)}catch(e){alert(m)}};
const aud=(a,et,id,d)=>{try{const S=g('Security');if(S&&S.audit)S.audit(a,et,id,d)}catch(e){}};
let cur=null,ov=null,fails=0,until=0,hiddenAt=0,fl={who:'all',range:'7',q:''};

async function hash(pin,salt){
  const enc=new TextEncoder();
  try{
    const k=await crypto.subtle.importKey('raw',enc.encode(pin),'PBKDF2',false,['deriveBits']);
    const b=await crypto.subtle.deriveBits({name:'PBKDF2',salt:enc.encode(salt),iterations:100000,hash:'SHA-256'},k,256);
    return Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('');
  }catch(e){let x=5381;const s=salt+':'+pin;for(let i=0;i<s.length;i++)x=((x<<5)+x+s.charCodeAt(i))|0;return 'f'+x}
}
async function who(pin,skipId){for(const u of read()){if(u.active===false||!u.hash||u.id===skipId)continue;if(await hash(pin,u.salt)===u.hash)return u}return null}
const active=()=>read().some(u=>u.hash&&u.active!==false);
const rl=()=>cur&&ROLES[cur.role];
const can=c=>!active()||!!(rl()&&rl().can.includes(c));
const tabOk=t=>!active()||!!(rl()&&(rl().tabs==='*'||rl().tabs.includes(t)));
const newSalt=()=>Math.random().toString(36).slice(2)+Date.now().toString(36);
const rid=()=>'u'+Date.now().toString(36)+Math.random().toString(36).slice(2,5);

function apply(){
  try{
    document.querySelectorAll('.tab-btn[data-tab]').forEach(b=>{b.style.display=tabOk(b.dataset.tab)?'':'none'});
    document.querySelectorAll('button[onclick]').forEach(b=>{
      const o=b.getAttribute('onclick')||'';
      if(MENU_OWNER.test(o))b.style.display=can('users')?'':'none';
      else if(MENU_DEL.test(o))b.style.display=can('del')?'':'none';
    });
    let bd=document.getElementById('rolesBadge');
    if(active()&&cur){
      if(!bd){bd=document.createElement('div');bd.id='rolesBadge';bd.style.cssText='position:fixed;left:8px;bottom:8px;z-index:9998;font-size:11px;padding:3px 8px;border-radius:12px;background:rgba(13,27,61,.85);color:#fff;cursor:pointer';bd.onclick=()=>Roles.logout();document.body.appendChild(bd)}
      bd.textContent='👤 '+cur.name+' · '+ROLES[cur.role].label+'  (tap to switch)';bd.style.display='';
    }else if(bd)bd.style.display='none';
  }catch(e){}
}
function firstTab(){const T=rl()&&rl().tabs;return T==='*'?'dashboard':(T&&T[0])||'dashboard'}
function goHome(){const T=g('Tabs');if(T&&T.switchTo)try{T.switchTo(tabOk('dashboard')?'dashboard':firstTab())}catch(e){}}

function showLogin(){
  if(ov||!active()||!document.body)return;
  ov=document.createElement('div');ov.id='rolesLogin';
  ov.style.cssText='position:fixed;inset:0;z-index:2147482000;background:#0d1b3d;color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:24px;text-align:center';
  ov.innerHTML='<div style="font-size:48px">🔐</div><div style="font-size:20px;font-weight:700">Sign in</div><div style="opacity:.8">Enter your personal PIN</div><input id="rlPin" type="password" inputmode="numeric" autocomplete="off" maxlength="8" placeholder="PIN" style="font-size:24px;text-align:center;padding:10px;border-radius:10px;border:0;width:200px"><div id="rlMsg" style="min-height:20px;color:#ffb4b4"></div><button id="rlBtn" style="font-size:18px;padding:10px 28px;border:0;border-radius:10px;background:#0d6efd;color:#fff">Sign in</button>';
  document.body.appendChild(ov);
  const inp=ov.querySelector('#rlPin'),msg=ov.querySelector('#rlMsg');
  const go=async()=>{
    if(Date.now()<until){msg.textContent='Too many tries. Wait '+Math.ceil((until-Date.now())/1000)+'s';return}
    const u=await who(inp.value);
    if(u){fails=0;login(u)}
    else{fails++;inp.value='';msg.textContent='Wrong PIN';aud('login_failed','session','',{});if(fails>=5){until=Date.now()+30000;fails=0;msg.textContent='Too many tries. Wait 30s'}}
  };
  ov.querySelector('#rlBtn').onclick=go;inp.addEventListener('keydown',e=>{if(e.key==='Enter')go()});
  setTimeout(()=>inp.focus(),100);
}
function login(u){
  cur=u;try{sessionStorage.setItem(SESSION,u.id);localStorage.setItem(ACTOR,u.name)}catch(e){}
  aud('login','session',u.id,{name:u.name,role:u.role});
  if(ov){ov.remove();ov=null}
  apply();goHome();
  try{Toast.success('👋 Welcome, '+u.name+' ('+ROLES[u.role].label+')')}catch(e){}
}
function install(){
  GUARDS.forEach(([path,cat,watch])=>{
    const [m,fn]=path.split('.'),o=g(m);
    if(!o||typeof o[fn]!=='function'||o[fn].__guarded)return;
    const orig=o[fn];
    const w=function(...a){
      if(!active())return orig.apply(this,a);
      if(!can(cat)){
        warn('🔒 '+(cur?ROLES[cur.role].label:'This user')+' is not allowed to do this');
        aud('denied','permission',path,{role:cur&&cur.role});return;
      }
      const st=watch&&g('State'),before=watch?(st[watch[0]]||[]).length:0;
      const done=()=>{
        if(NOLOG.has(path))return;
        if(watch){const n=(st[watch[0]]||[]).length;if(watch[1]==='up'?n<=before:n>=before)return}
        const id=typeof a[0]==='string'||typeof a[0]==='number'?String(a[0]):'';
        aud(fn,m.toLowerCase(),id,{});
      };
      const r=orig.apply(this,a);
      if(r&&typeof r.then==='function')r.then(done,()=>{});else done();
      return r;
    };
    w.__guarded=true;o[fn]=w;
  });
  const T=g('Tabs');
  if(T&&typeof T.switchTo==='function'&&!T.switchTo.__guarded){
    const o=T.switchTo,w=function(name){
      if(active()&&!tabOk(name)){warn('🔒 Not allowed for your role');return}
      return o.apply(this,arguments);
    };w.__guarded=true;T.switchTo=w;
  }
  apply();
}
// ---- audit viewer ----
const ICON={delete:'🗑️',update:'✏️',money_posted:'💰',denied:'⛔',login:'🔓',login_failed:'🚫',staff_added:'👤',cash_reconciled:'🧾'};
function logRows(){
  const L=(g('State')&&State.auditLog)||[],lim=fl.range==='all'?0:Date.now()-(+fl.range)*864e5,q=fl.q.toLowerCase();
  return L.filter(a=>(fl.who==='all'||a.actor===fl.who)&&(!lim||new Date(a.createdAt||a.date).getTime()>=lim)&&(!q||JSON.stringify(a).toLowerCase().includes(q)));
}
function line(a){return (a.createdAt?String(a.createdAt).replace('T',' ').slice(0,16):a.date)+' | '+(a.actor||'?')+' | '+a.action+' '+(a.entityType||'')+(a.entityId?' #'+String(a.entityId).slice(-8):'')+(a.details&&Object.keys(a.details).length?' | '+JSON.stringify(a.details).slice(0,120):'')}
function render(){
  const p=document.getElementById('tab-audit');if(!p)return;
  const L=(State.auditLog)||[],people=[...new Set(L.map(a=>a.actor||'?'))].sort(),rows=logRows();
  const sel=(v,c)=>v===c?' selected':'';
  p.innerHTML=`<div class="card"><div class="card-title">🧾 Audit log</div><small>Who did what and when. Deleted and changed sales and purchases, money postings, logins and blocked attempts appear here.</small>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:8px"><select class="form-control" onchange="Roles.filter('who',this.value)"><option value="all">Everyone</option>${people.map(n=>`<option value="${esc(n)}"${sel(fl.who,n)}>${esc(n)}</option>`).join('')}</select>
  <select class="form-control" onchange="Roles.filter('range',this.value)"><option value="1"${sel(fl.range,'1')}>Last 24 hours</option><option value="7"${sel(fl.range,'7')}>Last 7 days</option><option value="30"${sel(fl.range,'30')}>Last 30 days</option><option value="all"${sel(fl.range,'all')}>All</option></select></div>
  <input class="form-control" style="margin-top:6px" placeholder="🔍 Search" value="${esc(fl.q)}" oninput="Roles.filter('q',this.value,true)">
  <div style="margin-top:8px"><button class="btn btn-outline btn-sm" onclick="Roles.shareLog()">📤 Share this list</button> <small>${rows.length} entries</small></div></div>
  <div id="auditList">${rowsHtml(rows)}</div>`;
}
function rowsHtml(rows){
  return rows.slice(0,100).map(a=>`<div class="list-item"><div class="info"><span class="title">${ICON[a.action]||'•'} ${esc(a.action)} ${esc(a.entityType||'')}${a.entityId?' <small>#'+esc(String(a.entityId).slice(-8))+'</small>':''}</span><span class="meta">${esc(String(a.createdAt||a.date||'').replace('T',' ').slice(0,16))} · 👤 ${esc(a.actor||'?')}${a.details&&Object.keys(a.details).length?'<br>'+esc(JSON.stringify(a.details).slice(0,140)):''}</span></div></div>`).join('')||'<div class="empty-state">No entries for this filter.</div>';
}
// ---- staff management card (shown in Tools) ----
async function askPin(skipId){
  const a=prompt('New PIN (4 to 8 digits)');if(a==null)return null;
  if(!/^\d{4,8}$/.test(a)){warn('PIN must be 4 to 8 digits');return null}
  if(a!==prompt('Repeat the PIN')){warn("The PINs don't match");return null}
  if(await who(a,skipId)){warn('Someone else already uses that PIN. Choose another.');return null}
  return a;
}
const owners=l=>l.filter(u=>u.role==='owner'&&u.active!==false&&u.hash);
function mirror(u){try{const S=g('State');if(!S||!Array.isArray(S.staffUsers))return;S.staffUsers.push({id:u.id,name:u.name,role:u.role,branchId:(S.branches&&S.branches[0]&&S.branches[0].id)||'main',active:true,createdAt:new Date().toISOString()});const St=g('Storage');if(St)St.save('staffUsers',S.staffUsers)}catch(e){}}
const refresh=()=>{try{if(window.Tools)Tools.render()}catch(e){}};
const Roles={
  ROLES,active,can,render,install,apply,
  filter(k,v,noRender){fl[k]=v;if(noRender){const l=document.getElementById('auditList');if(l)l.innerHTML=rowsHtml(logRows())}else render()},
  shareLog(){const t='🧾 Audit log\n\n'+logRows().slice(0,150).map(line).join('\n');if(window.ShareHub)ShareHub.send('more',t,'')},
  async signIn(pin){const u=await who(pin);if(!u)return false;login(u);return true},
  logout(){cur=null;try{sessionStorage.removeItem(SESSION);localStorage.removeItem(ACTOR)}catch(e){}apply();showLogin()},
  cardHtml(){
    const l=read();
    if(!active())return `<div class="card"><div class="card-title">👥 Staff login (off)</div><p>Give each person their own PIN and role. Cashiers can sell but not delete or see the accounts. Every action is recorded in the audit log.</p><button class="btn btn-primary btn-sm" onclick="Roles.setup()">Set up (create Owner PIN)</button></div>`;
    if(!can('users'))return `<div class="card"><div class="card-title">👤 Signed in</div><p>${esc(cur?cur.name:'')} · ${cur?ROLES[cur.role].label:''}</p><button class="btn btn-outline btn-sm" onclick="Roles.logout()">Switch user</button></div>`;
    return `<div class="card"><div class="card-title">👥 Staff login (on)</div><p>You are <b>${esc(cur.name)}</b> (Owner). Each person signs in with their own PIN.</p>
    ${l.map(u=>`<div class="list-item"><div class="info"><span class="title">${esc(u.name)}${u.active===false?' (disabled)':''}</span><span class="meta">${ROLES[u.role].label}</span></div><div style="display:flex;gap:4px;flex-wrap:wrap"><button class="btn btn-outline btn-sm" onclick="Roles.setPin('${esc(u.id)}')">PIN</button><button class="btn btn-outline btn-sm" onclick="Roles.setRole('${esc(u.id)}')">Role</button><button class="btn btn-outline btn-sm" onclick="Roles.toggle('${esc(u.id)}')">${u.active===false?'Enable':'Disable'}</button></div></div>`).join('')}
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px"><button class="btn btn-primary btn-sm" onclick="Roles.addStaff()">➕ Add staff</button><button class="btn btn-outline btn-sm" onclick="Roles.logout()">Switch user</button><button class="btn btn-outline btn-sm" onclick="Roles.turnOff()">Turn off staff login</button></div>
    <small style="display:block;margin-top:8px;opacity:.75">Roles: Manager (everything except users and restore), Cashier (sales only), Inventory clerk (stock only), Accountant (money only), Viewer (read only). If the only Owner forgets the PIN it cannot be recovered, so keep a backup. This protects the app screens; it does not encrypt the data on the phone.</small></div>`;
  },
  async setup(){
    if(active())return;
    const name=(prompt('Owner name','Owner')||'').trim();if(!name)return;
    const pin=await askPin();if(!pin)return;
    const salt=newSalt(),u={id:rid(),name,role:'owner',active:true,salt,hash:await hash(pin,salt)};
    write([u]);mirror(u);aud('staff_login_enabled','security',u.id,{name});
    login(u);install();refresh();
    try{Toast.success('✅ Staff login is on. Remember your PIN.')}catch(e){}
  },
  async addStaff(){
    if(!can('users'))return;
    const name=(prompt('Staff name:')||'').trim();if(!name)return;
    const r=(prompt('Role: manager, cashier, inventory, accountant or viewer','cashier')||'').trim().toLowerCase();
    if(!ROLES[r])return warn('Unknown role');
    const pin=await askPin();if(!pin)return;
    const salt=newSalt(),u={id:rid(),name,role:r,active:true,salt,hash:await hash(pin,salt)},l=read();
    l.push(u);write(l);mirror(u);aud('staff_added','staff',u.id,{name,role:r});refresh();
  },
  async setPin(id){
    if(!can('users'))return;const l=read(),u=l.find(x=>x.id===id);if(!u)return;
    const pin=await askPin(id);if(!pin)return;
    u.salt=newSalt();u.hash=await hash(pin,u.salt);write(l);aud('pin_changed','staff',id,{name:u.name});
    try{Toast.success('PIN updated for '+u.name)}catch(e){}refresh();
  },
  setRole(id){
    if(!can('users'))return;const l=read(),u=l.find(x=>x.id===id);if(!u)return;
    const r=(prompt('New role for '+u.name+': owner, manager, cashier, inventory, accountant or viewer',u.role)||'').trim().toLowerCase();
    if(!ROLES[r]||r===u.role)return;
    if(u.role==='owner'&&owners(l).length<2)return warn('You need at least one Owner');
    u.role=r;write(l);aud('role_changed','staff',id,{name:u.name,role:r});refresh();
  },
  toggle(id){
    if(!can('users'))return;const l=read(),u=l.find(x=>x.id===id);if(!u)return;
    if(u.id===(cur&&cur.id))return warn("You can't disable yourself");
    if(u.active!==false&&u.role==='owner'&&owners(l).length<2)return warn('You need at least one Owner');
    u.active=u.active===false;write(l);aud(u.active?'staff_enabled':'staff_disabled','staff',id,{name:u.name});refresh();
  },
  async turnOff(){
    if(!can('users'))return;
    const p=prompt('Enter your PIN to turn off staff login');if(p==null)return;
    const u=await who(p);if(!u||u.role!=='owner')return warn('Wrong PIN, or not an Owner');
    aud('staff_login_disabled','security','',{by:u.name});write([]);cur=null;try{sessionStorage.removeItem(SESSION);localStorage.removeItem(ACTOR)}catch(e){}
    apply();refresh();try{Toast.success('Staff login is off')}catch(e){}
  }
};
window.Roles=Roles;
// start: restore a recent session or ask for a PIN, then guard the actions once all modules exist
(function boot(){
  const l=read();
  if(l.some(u=>u.hash&&u.active!==false)){
    let id=null;try{id=sessionStorage.getItem(SESSION)}catch(e){}
    const u=id&&l.find(x=>x.id===id&&x.active!==false&&x.hash);
    if(u){cur=u;try{localStorage.setItem(ACTOR,u.name)}catch(e){}}else{if(document.body)showLogin();else document.addEventListener('DOMContentLoaded',showLogin)}
  }
  [1200,3500,8000].forEach(t=>setTimeout(install,t));
  setInterval(apply,4000);
  document.addEventListener('visibilitychange',()=>{if(document.hidden)hiddenAt=Date.now();else if(active()&&cur&&hiddenAt&&Date.now()-hiddenAt>120000){cur=null;showLogin()}});
})();
return Roles;});
})();
