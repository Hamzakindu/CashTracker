// ============================================
// DEBUG HELPERS
// ============================================
const Debug = {
    // Check application state
    checkState() {
        console.log('=== 🔍 StockPro Debug ===');
        
        // Check State
        console.log('📦 State loaded:', typeof State !== 'undefined');
        if (typeof State !== 'undefined') {
            console.log('  Products:', State.products?.length || 0);
            console.log('  Sales:', State.sales?.length || 0);
            console.log('  Purchases:', State.purchases?.length || 0);
            console.log('  Customers:', State.customers?.length || 0);
            console.log('  Suppliers:', State.suppliers?.length || 0);
            console.log('  Current Profile:', State.currentProfileId);
        }
        
        // Check DOM
        console.log('📄 DOM Elements:');
        const tabPanes = document.querySelectorAll('.tab-pane');
        console.log('  Tab panes:', tabPanes.length);
        tabPanes.forEach(p => {
            const active = p.classList.contains('active') ? '✅' : '⬜';
            console.log(`    ${active} ${p.id}`);
        });
        
        const tabBtns = document.querySelectorAll('.tab-btn');
        console.log('  Tab buttons:', tabBtns.length);
        tabBtns.forEach(b => {
            const active = b.classList.contains('active') ? '✅' : '⬜';
            console.log(`    ${active} ${b.dataset.tab}`);
        });
        
        // Check dashboard
        const dashboard = document.getElementById('tab-dashboard');
        console.log('  Dashboard container:', dashboard ? '✅ exists' : '❌ missing');
        if (dashboard) {
            console.log('  Dashboard HTML length:', dashboard.innerHTML.length);
        }
        
        // Check modules
        console.log('📦 Modules:');
        const modules = ['Dashboard', 'Products', 'Sales', 'Purchases', 'Customers', 'Suppliers', 'Expenses', 'Returns'];
        modules.forEach(name => {
            const exists = typeof window[name] !== 'undefined';
            console.log(`  ${name}: ${exists ? '✅' : '❌'}`);
        });
        
        console.log('=== Debug complete ===');
    },
    
    // Test tab switching
    testTab(tabName) {
        console.log(`🧪 Testing tab switch to: ${tabName}`);
        if (typeof Tabs !== 'undefined' && Tabs.switchTo) {
            Tabs.switchTo(tabName);
            setTimeout(() => {
                console.log('✅ Tab switch complete');
                this.checkState();
            }, 300);
        } else {
            console.error('❌ Tabs module not available');
        }
    },
    
    // Quick fix - reinitialize dashboard
    fixDashboard() {
        console.log('🔧 Attempting to fix dashboard...');
        if (typeof Dashboard !== 'undefined') {
            Dashboard.init();
            Dashboard.update();
            console.log('✅ Dashboard reinitialized');
        } else {
            console.error('❌ Dashboard module not available');
        }
    },
    
    // Show all data
    showData() {
        console.log('📊 Current Data:');
        if (typeof State !== 'undefined') {
            console.log('Products:', State.products);
            console.log('Sales:', State.sales);
            console.log('Customers:', State.customers);
        }
    }
};

// Expose to window
window.Debug = Debug;

console.log('🛠️ Debug tools loaded. Run Debug.checkState() to test.');