// StockPro V5.10.26 - Safe initialisation guard
// Sample data creation is owned by State.init(). This file intentionally does not
// create or overwrite business data, preventing duplicate/late sample-data writes.
(function(){
  'use strict';
  try {
    if (typeof Storage !== 'undefined' && Storage.setSetting) {
      // State.init() will set this after it has inspected existing stores.
      console.log('✅ Safe init-data guard loaded; State controls first-run data creation.');
    }
  } catch(e) { console.warn('init-data guard:', e); }
})();
