// ============================================
// UTILITY HELPERS - COMPLETE FIXED
// ============================================
const Helpers = {
    // Generate unique ID
    uid() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
    },

    // Escape HTML
    esc(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    },

    // Format currency
    formatCurrency(amount) {
        return 'ETB ' + (amount || 0).toFixed(2);
    },

    // Format date
    formatDate(dateStr) {
        if (!dateStr) return '';
        try {
            const date = new Date(dateStr + 'T00:00:00');
            if (isNaN(date.getTime())) return dateStr;
            // Try to use EthiopianDate if available, otherwise use regular date
            let ethDateStr = '';
            try {
                if (typeof EthiopianDate !== 'undefined' && EthiopianDate.gregorianToEthiopian) {
                    const ethDate = EthiopianDate.gregorianToEthiopian(dateStr);
                    ethDateStr = ' (' + ethDate.formattedShort + ' ዓ.ም)';
                }
            } catch(e) {}
            return date.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric' 
            }) + ethDateStr;
        } catch(e) {
            return dateStr;
        }
    },

    // Download file
    downloadFile(content, filename, type = 'text/csv') {
        try {
            const blob = new Blob([content], { type });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        } catch(e) {
            console.error('Download error:', e);
        }
    },

    // Download JSON
    downloadJSON(content, filename) {
        try {
            const blob = new Blob([content], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        } catch(e) {
            console.error('Download JSON error:', e);
        }
    },

    // Get today's date string
    getToday() {
        try {
            return new Date().toISOString().slice(0, 10);
        } catch(e) {
            return '';
        }
    },

    // Debounce function
    debounce(func, wait = 300) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    // Sort helpers
    sortByName(array) {
        if (!array || !Array.isArray(array)) return [];
        return array.slice().sort((a, b) => (a.name || '').localeCompare(b.name || ''));
    },

    sortByRecent(array) {
        if (!array || !Array.isArray(array)) return [];
        return array.slice().sort((a, b) => 
            new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
        );
    },

    // Get sorted array based on current sort mode
    getSorted(array) {
        if (!array || !Array.isArray(array)) return [];
        try {
            const mode = localStorage.getItem('stockSortMode') || 'alphabet';
            if (mode === 'alphabet') return this.sortByName(array);
            if (mode === 'recent') return this.sortByRecent(array);
            return array;
        } catch(e) {
            return array;
        }
    },

    // Image compression - FIXED with fallback
    async compressImage(file) {
        return new Promise((resolve, reject) => {
            try {
                const reader = new FileReader();
                reader.onload = function(e) {
                    try {
                        const img = new Image();
                        img.onload = function() {
                            try {
                                // Get max dimension from CONFIG or use default
                                let maxDim = 400;
                                try {
                                    if (typeof CONFIG !== 'undefined' && CONFIG.IMAGE_MAX_DIMENSION) {
                                        maxDim = CONFIG.IMAGE_MAX_DIMENSION;
                                    }
                                } catch(e) {}
                                
                                let compression = 0.6;
                                try {
                                    if (typeof CONFIG !== 'undefined' && CONFIG.IMAGE_COMPRESSION) {
                                        compression = CONFIG.IMAGE_COMPRESSION;
                                    }
                                } catch(e) {}
                                
                                let w = img.width, h = img.height;
                                if (w > h) {
                                    if (w > maxDim) { h *= maxDim / w; w = maxDim; }
                                } else {
                                    if (h > maxDim) { w *= maxDim / h; h = maxDim; }
                                }
                                const canvas = document.createElement('canvas');
                                canvas.width = w;
                                canvas.height = h;
                                const ctx = canvas.getContext('2d');
                                ctx.drawImage(img, 0, 0, w, h);
                                resolve(canvas.toDataURL('image/jpeg', compression));
                            } catch(err) {
                                reject(err);
                            }
                        };
                        img.onerror = function() {
                            reject(new Error('Failed to load image'));
                        };
                        img.src = e.target.result;
                    } catch(err) {
                        reject(err);
                    }
                };
                reader.onerror = function() {
                    reject(new Error('Failed to read file'));
                };
                reader.readAsDataURL(file);
            } catch(err) {
                reject(err);
            }
        });
    },

    // Convert phone to international format
    convertToInternational(phone) {
        if (!phone) return '';
        try {
            let cleaned = phone.replace(/[^\d+]/g, '');
            if (/^0\d{9}$/.test(cleaned)) return '+251' + cleaned.substring(1);
            if (/^\+251\d{9}$/.test(cleaned)) return cleaned;
            return cleaned;
        } catch(e) {
            return phone;
        }
    }
};

// Expose Helpers globally
window.Helpers = Helpers;

// ✅ Signal that Helpers is ready
if (window.__notifyHelpersReady) {
    window.__notifyHelpersReady();
}

console.log('✅ Helpers loaded successfully');