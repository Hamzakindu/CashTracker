// ============================================
// ETHIOPIAN CALENDAR UTILITIES
// ============================================
const EthiopianDate = {
    MONTHS: ['መስከረም', 'ጥቅምት', 'ኅዳር', 'ታኅሣሥ', 'ጥር', 'የካቲት', 'መጋቢት', 'ሚያዝያ', 'ግንቦት', 'ሰኔ', 'ሐምሌ', 'ነሐሴ', 'ጳጉሜ'],

    // Convert Gregorian date to Ethiopian date
    gregorianToEthiopian(gDate) {
        const dt = new Date(gDate + 'T00:00:00');
        const year = dt.getFullYear();
        const month = dt.getMonth();
        const day = dt.getDate();
        
        let ethYear = (month < 8 || (month === 8 && day < 11)) ? year - 8 : year - 7;
        const ethNewYear = new Date(year, 8, 11);
        
        let daysSinceNewYear;
        if (dt >= ethNewYear) {
            daysSinceNewYear = Math.floor((dt - ethNewYear) / (1000 * 60 * 60 * 24));
        } else {
            const prev = new Date(year - 1, 8, 11);
            daysSinceNewYear = Math.floor((dt - prev) / (1000 * 60 * 60 * 24));
        }
        
        let ethMonth, ethDay;
        if (daysSinceNewYear < 360) {
            ethMonth = Math.floor(daysSinceNewYear / 30) + 1;
            ethDay = (daysSinceNewYear % 30) + 1;
        } else {
            ethMonth = 13;
            ethDay = daysSinceNewYear - 360 + 1;
        }
        
        const monthIndex = Math.min(ethMonth - 1, 12);
        
        return {
            year: ethYear,
            month: ethMonth,
            day: ethDay,
            monthName: this.MONTHS[monthIndex],
            formattedShort: ethDay + '/' + ethMonth + '/' + ethYear
        };
    },

    // Get current Ethiopian date
    getCurrent() {
        return this.gregorianToEthiopian(new Date().toISOString().slice(0, 10));
    },

    // Update display element
    updateDisplay(fromDate, toDate) {
        const el = document.getElementById('ethiopianDateDisplay');
        if (!el) return;
        
        if (fromDate && toDate) {
            const fromEth = this.gregorianToEthiopian(fromDate);
            const toEth = this.gregorianToEthiopian(toDate);
            el.innerHTML = `📅 የኢትዮጵያ ቀን: ${fromEth.formattedShort} - ${toEth.formattedShort} (${fromEth.year} ዓ.ም)`;
        } else {
            const current = this.getCurrent();
            el.innerHTML = `📅 ዛሬ: ${current.formattedShort} (${current.year} ዓ.ም)`;
        }
    }
};

// ✅ Expose globally
window.EthiopianDate = EthiopianDate;

console.log('✅ EthiopianDate loaded successfully');