// ============================================
// MODULE LOADER - Ensures dependencies are ready
// ============================================

(function() {
    'use strict';
    
    console.log('🔧 Module loader initializing...');
    
    // Store modules waiting to load
    window.__pendingModules = [];
    window.__helpersReady = false;
    window.__storageReady = false;
    window.__stateReady = false;
    
    // ✅ Only create registerModule if it doesn't exist
    if (typeof window.registerModule === 'undefined') {
        window.registerModule = function(name, moduleFactory) {
            console.log('📦 Registering module:', name);
            
            // Check if all dependencies are ready
            function checkDependencies() {
                const deps = {
                    helpers: typeof Helpers !== 'undefined',
                    storage: typeof Storage !== 'undefined',
                    state: typeof State !== 'undefined'
                };
                
                const allReady = deps.helpers && deps.storage && deps.state;
                
                if (!allReady) {
                    console.log('⏳ Dependencies not ready for', name, ':', deps);
                    return false;
                }
                
                return true;
            }
            
            // Try to load now, or queue for later
            if (checkDependencies()) {
                try {
                    moduleFactory();
                    console.log('✅ Module loaded:', name);
                    return true;
                } catch (error) {
                    console.error('❌ Error loading module', name, ':', error);
                    return false;
                }
            } else {
                // Queue for later
                window.__pendingModules.push({
                    name: name,
                    factory: moduleFactory
                });
                console.log('📋 Module queued:', name);
                return false;
            }
        };
    } else {
        console.log('✅ registerModule already exists, keeping existing');
    }
    
    // Process queued modules when dependencies are ready
    window.processPendingModules = function() {
        if (!window.__pendingModules || window.__pendingModules.length === 0) {
            return;
        }
        
        console.log('🔄 Processing', window.__pendingModules.length, 'pending modules...');
        
        const stillPending = [];
        
        window.__pendingModules.forEach(function(item) {
            const deps = {
                helpers: typeof Helpers !== 'undefined',
                storage: typeof Storage !== 'undefined',
                state: typeof State !== 'undefined'
            };
            
            if (deps.helpers && deps.storage && deps.state) {
                try {
                    item.factory();
                    console.log('✅ Module loaded from queue:', item.name);
                } catch (error) {
                    console.error('❌ Error loading queued module', item.name, ':', error);
                    stillPending.push(item);
                }
            } else {
                stillPending.push(item);
            }
        });
        
        window.__pendingModules = stillPending;
        
        // If still pending, try again in 500ms
        if (window.__pendingModules.length > 0) {
            setTimeout(window.processPendingModules, 500);
        }
    };
    
    // Notify when Helpers is ready
    window.__notifyHelpersReady = function() {
        console.log('📢 Helpers is ready!');
        window.__helpersReady = true;
        window.processPendingModules();
    };
    
    // Notify when Storage is ready
    window.__notifyStorageReady = function() {
        console.log('📢 Storage is ready!');
        window.__storageReady = true;
        window.processPendingModules();
    };
    
    // Notify when State is ready
    window.__notifyStateReady = function() {
        console.log('📢 State is ready!');
        window.__stateReady = true;
        window.processPendingModules();
    };
    
    console.log('✅ Module loader initialized');
    
})();