// Android shell shim: WebView can't save blob downloads, so hand them to the native bridge.
(function(){
  if(!window.Android||!Android.saveFile)return;
  const blobs={},co=URL.createObjectURL.bind(URL);
  URL.createObjectURL=function(b){const u=co(b);blobs[u]=b;return u;};
  const orig=HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click=function(){
    const u=this.href,b=blobs[u];
    if(this.download&&b){
      const name=this.download,fr=new FileReader();
      fr.onload=function(){Android.saveFile(name,String(fr.result).split(',')[1]||'');};
      fr.readAsDataURL(b);delete blobs[u];return;
    }
    return orig.apply(this,arguments);
  };
})();
