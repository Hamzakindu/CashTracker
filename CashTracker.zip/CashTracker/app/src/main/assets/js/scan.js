// SCAN: camera barcode scanner (Android app) that fills a field or finds a product
(function(){'use strict';
window.Scan={
  start:function(cb){
    if(!window.Android||!Android.scan){Toast.warning('📷 The scanner works only in the Android app');return}
    window.__onScan=function(v){cb(String(v||''))};Android.scan();
  },
  into:function(id){
    Scan.start(function(v){const el=document.getElementById(id);if(!el)return;el.value=v;el.dispatchEvent(new Event('input',{bubbles:true}))});
  },
  find:function(){
    Scan.start(function(v){
      const p=(State.products||[]).find(function(x){return String(x.barcode||'').toLowerCase()===v.toLowerCase()});
      if(p){Tabs.switchTo('products');setTimeout(function(){Products.showDetail(p.id)},250)}else Toast.warning('No product with barcode '+v);
    });
  }
};
})();
