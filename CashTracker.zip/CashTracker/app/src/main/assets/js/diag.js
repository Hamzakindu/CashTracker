// Keeps the last errors so they can be shared for debugging (Bank SMS tab -> Share error log)
(function(){var K='SP_errlog';
function add(m){try{var l=JSON.parse(localStorage.getItem(K)||'[]');l.unshift(new Date().toISOString().slice(0,19)+' '+String(m).slice(0,300));localStorage.setItem(K,JSON.stringify(l.slice(0,40)));}catch(e){}}
window.addEventListener('error',function(e){add((e.message||'error')+' @'+String(e.filename||'').split('/').pop()+':'+e.lineno);});
window.addEventListener('unhandledrejection',function(e){add('promise: '+((e.reason&&e.reason.message)||e.reason));});})();
