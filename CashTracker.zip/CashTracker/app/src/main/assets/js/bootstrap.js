// ============================================
// BOOTSTRAP - Ensure everything loads correctly
// ============================================

(function() {
    console.log('🚀 Bootstrapping StockPro...');
    
    // Check if all required dependencies are loaded
    function checkDependencies() {
        const deps = {
            'Helpers': typeof Helpers !== 'undefined',
            'Storage': typeof Storage !== 'undefined',
            'EthiopianDate': typeof EthiopianDate !== 'undefined',
            'Theme': typeof Theme !== 'undefined',
            'State': typeof State !== 'undefined',
            'Tabs': typeof Tabs !== 'undefined',
            'Dashboard': typeof Dashboard !== 'undefined',
            'Products': typeof Products !== 'undefined',
            'Sales': typeof Sales !== 'undefined',
            'Purchases': typeof Purchases !== 'undefined',
            'Customers': typeof Customers !== 'undefined',
            'Suppliers': typeof Suppliers !== 'undefined',
            'Expenses': typeof Expenses !== 'undefined',
            'Returns': typeof Returns !== 'undefined',
            'Reports': typeof Reports !== 'undefined',
            'Payments': typeof Payments !== 'undefined',
            'TelegramModule': typeof TelegramModule !== 'undefined',
            'Profiles': typeof Profiles !== 'undefined',
            'Backup': typeof Backup !== 'undefined',
        };
        
        let allLoaded = true;
        let missing = [];
        
        for (const [name, loaded] of Object.entries(deps)) {
            if (!loaded) {
                missing.push(name);
                allLoaded = false;
            }
        }
        
        if (!allLoaded) {
            console.warn('⚠️ Missing dependencies:', missing.join(', '));
            // Don't fail - the app might still work with fallbacks
            return false;
        }
        
        console.log('✅ All dependencies loaded');
        return true;
    }
    
    // Wait for all scripts to load
    if (document.readyState === 'complete') {
        setTimeout(() => {
            checkDependencies();
        }, 300);
    } else {
        window.addEventListener('load', function() {
            setTimeout(() => {
                checkDependencies();
            }, 300);
        });
    }
    
    // Expose check function
    window.checkDependencies = checkDependencies;
})();