// ============================================
// MODAL MANAGEMENT
// ============================================
const Modals = {
    // Open modal
    open(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('show');
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
    },

    // Close modal
    close(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('show');
            modal.style.display = 'none';
            document.body.style.overflow = '';
        }
    },

    // Initialize modal close handlers
    init() {
        // Close on overlay click
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    overlay.classList.remove('show');
                    overlay.style.display = 'none';
                    document.body.style.overflow = '';
                }
            });
        });

        // Close on Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const openModals = document.querySelectorAll('.modal-overlay.show');
                if (openModals.length > 0) {
                    openModals[openModals.length - 1].classList.remove('show');
                    openModals[openModals.length - 1].style.display = 'none';
                    document.body.style.overflow = '';
                }
                
                // Also close hamburger menu
                const dropdown = document.getElementById('optionsDropdown');
                const btn = document.getElementById('hamburgerBtn');
                if (dropdown) dropdown.classList.remove('show');
                if (btn) btn.classList.remove('active');
            }
        });
    }
};