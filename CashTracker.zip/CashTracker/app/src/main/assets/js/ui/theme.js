// ============================================
// THEME & APPEARANCE MANAGEMENT — V5.7 polished
// ============================================
const Theme = {
    // Toggle dark/light theme
    toggleTheme() {
        const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
        const newTheme = isDark ? 'light' : 'dark';
        this.apply(newTheme);
        Storage.setSetting('stockTheme', newTheme);
        Toast.show(newTheme === 'dark' ? '🌙 Dark mode' : '☀️ Light mode', 'info', 1500);
        this.syncToggleButton();
    },

    apply(theme) {
        if (theme === 'dark') {
            document.documentElement.setAttribute('data-theme', 'dark');
        } else {
            document.documentElement.removeAttribute('data-theme');
        }
        this.updateMetaThemeColor(theme);
    },

    updateMetaThemeColor(theme) {
        const color = theme === 'dark' ? '#0a0f1a' : '#0d6efd';
        let meta = document.querySelector('meta[name="theme-color"]');
        if (!meta) {
            meta = document.createElement('meta');
            meta.name = 'theme-color';
            document.head.appendChild(meta);
        }
        meta.content = color;
        // Android status bar style hint
        let status = document.querySelector('meta[name="apple-mobile-web-app-status-bar-style"]');
        if (!status) {
            status = document.createElement('meta');
            status.name = 'apple-mobile-web-app-status-bar-style';
            document.head.appendChild(status);
        }
        status.content = theme === 'dark' ? 'black-translucent' : 'default';
    },

    // Change font size
    changeFontSize(size) {
        document.body.classList.remove('font-small', 'font-medium', 'font-large', 'font-xl');
        if (size !== 'medium') {
            document.body.classList.add('font-' + size);
        }
        Storage.setSetting('stockFontSize', size);
    },

    // Change font style
    changeFontStyle(style) {
        document.body.classList.remove('font-sans', 'font-serif', 'font-mono', 'font-rounded');
        if (style !== 'sans') {
            document.body.classList.add('font-' + style);
        }
        Storage.setSetting('stockFontStyle', style);
    },

    // Load saved font settings
    loadFontSettings() {
        const size = Storage.getSetting('stockFontSize', 'medium');
        const style = Storage.getSetting('stockFontStyle', 'sans');
        
        const sizeSelect = document.getElementById('fontSizeSelect');
        const styleSelect = document.getElementById('fontStyleSelect');
        
        if (sizeSelect) sizeSelect.value = size;
        if (styleSelect) styleSelect.value = style;
        
        this.changeFontSize(size);
        this.changeFontStyle(style);
    },

    // Load saved theme
    loadTheme() {
        const saved = Storage.getSetting('stockTheme', null);
        if (saved === 'dark' || saved === 'light') {
            this.apply(saved);
        } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            this.apply('dark');
        } else {
            this.apply('light');
        }
        this.syncToggleButton();
    },

    syncToggleButton() {
        const btn = document.querySelector('[onclick*="Theme.toggleTheme"]');
        if (!btn) return;
        const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
        btn.textContent = isDark ? '☀️ Light Mode' : '🌙 Dark Mode';
        btn.classList.toggle('is-dark', isDark);
    },

    // Initialize theme
    init() {
        this.loadTheme();
        this.loadFontSettings();

        // React to system preference changes when user hasn't forced a theme
        if (window.matchMedia) {
            const mq = window.matchMedia('(prefers-color-scheme: dark)');
            const handler = (e) => {
                if (!Storage.getSetting('stockTheme')) {
                    this.apply(e.matches ? 'dark' : 'light');
                    this.syncToggleButton();
                }
            };
            if (mq.addEventListener) mq.addEventListener('change', handler);
            else if (mq.addListener) mq.addListener(handler);
        }
    }
};

window.Theme = Theme;
