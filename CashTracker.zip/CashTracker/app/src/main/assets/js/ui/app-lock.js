// StockPro V5.9 — hardened App PIN lock
(function(){
'use strict';
const PIN_KEY='stockpro_app_pin_v2', LEGACY='stockpro_app_pin_hash', SALT_KEY='stockpro_app_pin_salt_v2', UNLOCK='stockpro_unlocked', FAIL_KEY='stockpro_pin_failures';
const AppLock={
 isEnabled(){return !!localStorage.getItem(PIN_KEY)||!!localStorage.getItem(LEGACY)},
 isUnlocked(){return sessionStorage.getItem(UNLOCK)==='1'},
 async setPin(pin){
   if(!/^\d{6}$/.test(pin)){Toast.warning('PIN must be exactly 6 digits for stronger security');return false;}
   if(!window.crypto?.subtle){Toast.error('Secure cryptography is unavailable in this browser');return false;}
   const salt=Security.newSalt(), hash=await Security.derivePin(pin,salt);
   localStorage.setItem(SALT_KEY,salt);localStorage.setItem(PIN_KEY,hash);localStorage.removeItem(LEGACY);sessionStorage.setItem(UNLOCK,'1');Security.touch();Security.audit('pin_enabled','security','',{algorithm:'PBKDF2-SHA256',iterations:120000});Toast.success('PIN lock enabled');return true;
 },
 async verify(pin){
   if(!this.isEnabled())return true;
   const until=Number(localStorage.getItem('stockpro_pin_lock_until')||0); if(until>Date.now()) return false;
   const salt=localStorage.getItem(SALT_KEY), stored=localStorage.getItem(PIN_KEY);
   if(salt&&stored){const hash=await Security.derivePin(pin,salt);return hash===stored;}
   // One-time legacy compatibility: successful legacy verification must immediately migrate.
   const legacy=localStorage.getItem(LEGACY); if(!legacy)return false;
   let h=0;for(let i=0;i<pin.length;i++){h=((h<<5)-h)+pin.charCodeAt(i);h|=0;}return 'h'+Math.abs(h).toString(36)===legacy;
 },
 async unlock(pin){
   const until=Number(localStorage.getItem('stockpro_pin_lock_until')||0);if(until>Date.now()){Toast.error('Too many attempts. Try again later.');return false;}
   if(await this.verify(pin)){
     sessionStorage.setItem(UNLOCK,'1');sessionStorage.setItem(FAIL_KEY,'0');localStorage.removeItem('stockpro_pin_lock_until');Security.touch();this.hideOverlay();Toast.success('Unlocked');return true;
   }
   let fails=Number(localStorage.getItem(FAIL_KEY)||0)+1;localStorage.setItem(FAIL_KEY,String(fails));
   if(fails>=5){localStorage.setItem('stockpro_pin_lock_until',String(Date.now()+30000));Toast.error('5 failed attempts. Locked for 30 seconds.');}else Toast.error(`Incorrect PIN (${5-fails} attempts remaining)`);return false;
 },
 async migrateLegacy(pin){if(localStorage.getItem(LEGACY)&&await this.verify(pin)){await this.setPin(pin);return true}return false},
 async removePin(currentPin){if(!(await this.verify(currentPin))){Toast.error('Wrong PIN');return false}localStorage.removeItem(PIN_KEY);localStorage.removeItem(SALT_KEY);localStorage.removeItem(LEGACY);sessionStorage.setItem(UNLOCK,'1');Security.audit('pin_disabled','security','',{});this.hideOverlay();Toast.success('PIN lock disabled');return true},
 showOverlay(){if(document.getElementById('appLockOverlay'))return;const o=document.createElement('div');o.id='appLockOverlay';o.style.cssText='position:fixed;inset:0;z-index:99999;background:var(--bg,#0d1117);display:flex;align-items:center;justify-content:center;flex-direction:column;padding:24px';o.innerHTML='<div style="max-width:320px;width:100%;text-align:center"><div style="font-size:2.5rem;margin-bottom:8px">🔒</div><h2>StockPro Locked</h2><p style="opacity:.7">Enter your 6-digit PIN</p><input id="appLockPinInput" type="password" inputmode="numeric" maxlength="6" pattern="[0-9]*" class="form-control" style="text-align:center;font-size:1.4rem;letter-spacing:6px;margin-bottom:12px" autocomplete="off"><button class="btn btn-primary btn-block" onclick="AppLock.tryUnlock()">Unlock</button></div>';document.body.appendChild(o);setTimeout(()=>{const i=document.getElementById('appLockPinInput');if(i){i.focus();i.addEventListener('keydown',e=>{if(e.key==='Enter')AppLock.tryUnlock()})}},100)},
 hideOverlay(){document.getElementById('appLockOverlay')?.remove()},
 tryUnlock(){const p=document.getElementById('appLockPinInput')?.value||'';this.unlock(p)},
 openSettings(){let m=document.getElementById('pinLockModal');if(!m){m=document.createElement('div');m.className='modal-overlay';m.id='pinLockModal';m.innerHTML='<div class="modal" style="max-width:400px"><button class="close-btn" onclick="Modals.close(\'pinLockModal\')">✕</button><h3>🔒 App PIN Lock</h3><p style="opacity:.75">Use a 6-digit PIN. Five failed attempts trigger a temporary lockout.</p><div id="pinLockStatus" style="margin:12px 0;font-weight:600"></div><div class="form-group"><label>Current PIN</label><input class="form-control" id="pinCurrent" type="password" inputmode="numeric" maxlength="6" autocomplete="off"></div><div class="form-group"><label>New 6-digit PIN</label><input class="form-control" id="pinNew" type="password" inputmode="numeric" maxlength="6" autocomplete="off"></div><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn-success" onclick="AppLock.saveFromModal()">Save PIN</button><button class="btn btn-danger" onclick="AppLock.removeFromModal()">Remove PIN</button></div></div>';document.body.appendChild(m)}document.getElementById('pinLockStatus').textContent=this.isEnabled()?'Status: 🔒 PIN enabled':'Status: 🔓 No PIN set';document.getElementById('pinCurrent').value='';document.getElementById('pinNew').value='';Modals.open('pinLockModal')},
 async saveFromModal(){const c=document.getElementById('pinCurrent')?.value||'',n=document.getElementById('pinNew')?.value||'';if(this.isEnabled()&&!await this.verify(c)){Toast.error('Current PIN is wrong');return}if(await this.setPin(n))Modals.close('pinLockModal')},
 async removeFromModal(){const c=document.getElementById('pinCurrent')?.value||'';if(!this.isEnabled())return Toast.info('No PIN is set');if(await this.removePin(c))Modals.close('pinLockModal')},
 async checkOnStartup(){if(this.isEnabled()&&!this.isUnlocked())this.showOverlay()}
};window.AppLock=AppLock;if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(()=>AppLock.checkOnStartup(),400));else setTimeout(()=>AppLock.checkOnStartup(),400);
})();
