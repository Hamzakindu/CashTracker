// StockPro multilingual operating/reporting UI
(function(){
'use strict';
const LANGS={en:'English',am:'አማርኛ',om:'Afaan Oromoo',ar:'العربية'};
const D={
'en':{},
'am':{
'Dashboard':'ዳሽቦርድ','Products':'ምርቶች','Purchases':'ግዢ','Sales':'ሽያጭ','Customers':'ደንበኞች','Suppliers':'አቅራቢዎች','Expenses':'ወጪዎች','Add':'ጨምር','Returns':'መመለሻ','Reports':'ሪፖርቶች','Accounting':'የሂሳብ አያያዝ','Calculator':'ካልኩሌተር','Offline':'ከመስመር ውጭ','Products':'ምርቶች','Total Stock':'አጠቃላይ ክምችት','Total Profit':'አጠቃላይ ትርፍ','Today Revenue':'የዛሬ ገቢ','Customer Debit':'የደንበኛ ዕዳ','Supplier Debit':'የአቅራቢ ዕዳ','Quick Actions':'ፈጣን እርምጃዎች','Recent Sales':'የቅርብ ሽያጮች','Low Stock':'ዝቅተኛ ክምችት','Purchase History':'የግዢ ታሪክ','Sales History':'የሽያጭ ታሪክ','New Sale':'አዲስ ሽያጭ','New Purchase':'አዲስ ግዢ','Date':'ቀን','Customer':'ደንበኛ','Supplier':'አቅራቢ','Payment Received':'የተቀበለ ክፍያ','Amount Paid':'የተከፈለ መጠን','Total':'ጠቅላላ','Paid':'ተከፍሏል','Debit':'ዕዳ','Profit':'ትርፍ','Generate Report':'ሪፖርት ፍጠር','From':'ከ','To':'እስከ','Generate':'ፍጠር','Walk-in Customer':'በቀጥታ የሚገዛ ደንበኛ','Search':'ፈልግ','Language':'ቋንቋ','Negative Stock':'አሉታዊ ክምችት','No sales recorded':'ምንም ሽያጭ አልተመዘገበም','No purchases recorded':'ምንም ግዢ አልተመዘገበም'},
'om':{
'Dashboard':'Daashboordii','Products':'Oomishaalee','Purchases':'Bittaa','Sales':'Gurgurtaa','Customers':'Maamiltoota','Suppliers':'Dhiyeessitoota','Expenses':'Baasiilee','Add':'Dabali','Returns':'Deebii','Reports':'Gabaasa','Accounting':'Herrega','Calculator':'Kaalukileetarii','Offline':'Sarara ala','Total Stock':'Kuusaa waliigalaa','Total Profit':'Bu’aa waliigalaa','Today Revenue':'Galii har’aa','Customer Debit':'Liqa maamilaa','Supplier Debit':'Liqa dhiyeessaa','Quick Actions':'Tarkaanfiiwwan saffisaa','Recent Sales':'Gurgurtaa dhiheenyaa','Low Stock':'Kuusaa xiqqaa','Purchase History':'Seenaa bittaa','Sales History':'Seenaa gurgurtaa','New Sale':'Gurgurtaa haaraa','New Purchase':'Bittaa haaraa','Date':'Guyyaa','Customer':'Maamilaa','Supplier':'Dhiyeessaa','Payment Received':'Kaffaltii fudhatame','Amount Paid':'Hanga kaffalame','Total':'Waliigala','Paid':'Kaffalame','Debit':'Liqa','Profit':'Bu’aa','Generate Report':'Gabaasa uumi','From':'Irraa','To':'Hanga','Generate':'Uumi','Walk-in Customer':'Maamilaa kallattiin','Search':'Barbaadi','Language':'Afaan','Negative Stock':'Kuusaa negaatiivii'},
'ar':{'Dashboard':'لوحة التحكم','Products':'المنتجات','Purchases':'المشتريات','Sales':'المبيعات','Customers':'العملاء','Suppliers':'الموردون','Expenses':'المصروفات','Add':'إضافة','Returns':'المرتجعات','Reports':'التقارير','Accounting':'المحاسبة','Calculator':'الحاسبة','Offline':'غير متصل','Total Stock':'إجمالي المخزون','Total Profit':'إجمالي الربح','Today Revenue':'إيراد اليوم','Customer Debit':'ديون العملاء','Supplier Debit':'ديون الموردين','Quick Actions':'إجراءات سريعة','Recent Sales':'المبيعات الأخيرة','Low Stock':'مخزون منخفض','Purchase History':'سجل المشتريات','Sales History':'سجل المبيعات','New Sale':'بيع جديد','New Purchase':'شراء جديد','Date':'التاريخ','Customer':'العميل','Supplier':'المورد','Payment Received':'المدفوع المستلم','Amount Paid':'المبلغ المدفوع','Total':'الإجمالي','Paid':'مدفوع','Debit':'الدين','Profit':'الربح','Generate Report':'إنشاء تقرير','From':'من','To':'إلى','Generate':'إنشاء','Walk-in Customer':'عميل نقدي','Search':'بحث','Language':'اللغة','Negative Stock':'مخزون سالب'}
};
function norm(s){return String(s||'').replace(/\s+/g,' ').trim();}
const I18n={
 languages:LANGS,
 current(){return localStorage.getItem('stockpro_language')||'en';},
 t(s){const k=norm(s); return (D[this.current()]&&D[this.current()][k])||k;},
 set(lang){if(!LANGS[lang])return;localStorage.setItem('stockpro_language',lang);document.documentElement.lang=lang;document.documentElement.dir=lang==='ar'?'rtl':'ltr';this.translatePage();if(window.App&&App.refreshAll)App.refreshAll();},
 translatePage(){const lang=this.current();document.querySelectorAll('[data-i18n]').forEach(el=>{const key=el.getAttribute('data-i18n');el.textContent=(D[lang]&&D[lang][key])||key;});
  const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);nodes.forEach(n=>{if(!n.parentElement||['SCRIPT','STYLE','OPTION'].includes(n.parentElement.tagName))return;const raw=norm(n.nodeValue);if(raw&&D[lang]&&D[lang][raw])n.nodeValue=n.nodeValue.replace(raw,D[lang][raw]);});
  document.querySelectorAll('[placeholder]').forEach(el=>{const p=norm(el.getAttribute('placeholder'));if(D[lang]&&D[lang][p])el.setAttribute('placeholder',D[lang][p]);});
 },
 init(){document.documentElement.lang=this.current();document.documentElement.dir=this.current()==='ar'?'rtl':'ltr';this.translatePage();}
};
window.I18n=I18n; window.t=(s)=>I18n.t(s);
})();
