package com.example.cashtracker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import org.json.JSONArray
import org.json.JSONObject

/** Tiny persistent queue shared by the receiver and the UI. */
object Queue {
    @Synchronized fun add(c: Context, item: JSONObject) {
        val p = c.getSharedPreferences("q", Context.MODE_PRIVATE)
        val a = JSONArray(p.getString("q", "[]")); a.put(item)
        p.edit().putString("q", a.toString()).apply()
    }
    @Synchronized fun drain(c: Context): String {
        val p = c.getSharedPreferences("q", Context.MODE_PRIVATE)
        val s = p.getString("q", "[]") ?: "[]"
        p.edit().putString("q", "[]").apply()
        return s
    }
}

class SmsReceiver : BroadcastReceiver() {
    // Only money-looking messages are kept; everything else is ignored.
    private val money = Regex("debited|credited|spent|paid|received|withdrawn|purchase|deposit|balance", RegexOption.IGNORE_CASE)

    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val m = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (m.isEmpty()) return
        val body = m.joinToString("") { it.messageBody ?: "" }
        if (!money.containsMatchIn(body)) return
        Queue.add(c, JSONObject().put("body", body).put("ts", m[0].timestampMillis).put("from", m[0].originatingAddress ?: ""))
    }
}
