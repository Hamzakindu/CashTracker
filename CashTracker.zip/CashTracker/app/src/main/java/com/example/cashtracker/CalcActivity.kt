package com.example.cashtracker

/** Standalone StockPro Calc: own launcher icon and task, same app data as StockPro. */
class CalcActivity : MainActivity() {
    override val startPage = "calculator-home.html"
    override val isMain = false
}
