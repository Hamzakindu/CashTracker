package com.example.cashtracker

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import java.io.File
import java.net.URLConnection

open class MainActivity : Activity() {
    protected open val startPage = "index.html"
    protected open val isMain = true
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private val host = "appassets.androidplatform.net"

    inner class Bridge {
        @JavascriptInterface fun drain(): String = if (isMain) Queue.drain(this@MainActivity) else "[]"

        @JavascriptInterface fun share(channel: String, text: String, phone: String, imgB64: String) {
            runOnUiThread {
                try { doShare(channel, text, phone, imgB64) }
                catch (e: Exception) { Toast.makeText(this@MainActivity, "Share failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }

        @JavascriptInterface fun openMain() {
            runOnUiThread {
                startActivity(Intent(this@MainActivity, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }

        @JavascriptInterface fun saveFile(name: String, b64: String) {
            val msg = try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                if (Build.VERSION.SDK_INT >= 29) {
                    val v = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, URLConnection.guessContentTypeFromName(name) ?: "application/octet-stream")
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
                    contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
                    "Saved to Downloads: $name"
                } else {
                    val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)!!
                    File(dir, name).writeBytes(bytes)
                    "Saved: ${dir.absolutePath}/$name"
                }
            } catch (e: Exception) { "Could not save file: ${e.message}" }
            runOnUiThread { Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show() }
        }
    }

    private val apps = mapOf(
        "whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "telegram" to listOf("org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram"),
        "imo" to listOf("com.imo.android.imoim", "com.imo.android.imoimbeta", "com.imo.android.imoimhd")
    )

    private fun doShare(channel: String, text: String, phone: String, img: String) {
        val digits = phone.filter { it.isDigit() }
        if (channel == "sms") {
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phone")).putExtra("sms_body", text)); return
        }
        val pkg = apps[channel]?.firstOrNull { packageManager.getLaunchIntentForPackage(it) != null }
        if (apps.containsKey(channel) && pkg == null) {
            Toast.makeText(this, "$channel isn't installed. Choose another app.", Toast.LENGTH_LONG).show()
        }
        if (channel == "whatsapp" && pkg != null && img.isEmpty() && digits.isNotEmpty()) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits?text=" + Uri.encode(text))).setPackage(pkg)); return
        }
        val send = Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_TEXT, text)
        if (img.isNotEmpty()) {
            val dir = File(cacheDir, "share").apply { mkdirs() }
            val f = File(dir, "share_${System.currentTimeMillis()}.jpg")
            f.writeBytes(Base64.decode(img, Base64.DEFAULT))
            send.type = "image/*"
            send.putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(this, "$packageName.files", f))
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } else send.type = "text/plain"
        if (pkg != null) {
            send.setPackage(pkg)
            if (channel == "whatsapp" && digits.isNotEmpty()) send.putExtra("jid", "$digits@s.whatsapp.net")
            startActivity(send)
        } else startActivity(Intent.createChooser(send, "Share"))
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (isMain) requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS), 1)
        val loader = WebViewAssetLoader.Builder()
            .setDomain(host)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(r.url)
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.host == host) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) { }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(v: WebView, url: String, m: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setOnCancelListener { r.confirm() }.show(); return true
            }
            override fun onJsConfirm(v: WebView, url: String, m: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m)
                    .setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }.show(); return true
            }
            override fun onJsPrompt(v: WebView, url: String, m: String, d: String?, r: JsPromptResult): Boolean {
                val input = EditText(this@MainActivity); input.setText(d ?: "")
                AlertDialog.Builder(this@MainActivity).setMessage(m).setView(input)
                    .setPositiveButton("OK") { _, _ -> r.confirm(input.text.toString()) }
                    .setNegativeButton("Cancel") { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }.show(); return true
            }
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                chooser?.onReceiveValue(null); chooser = cb
                return try { startActivityForResult(p.createIntent(), 42); true }
                catch (e: Exception) { chooser = null; false }
            }
        }
        setContentView(web)
        web.loadUrl("https://$host/assets/$startPage")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 42) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data)); chooser = null
        } else super.onActivityResult(req, res, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    override fun onResume() {
        super.onResume()
        if (isMain && ::web.isInitialized) web.evaluateJavascript("window.BankSMS&&BankSMS.pull&&BankSMS.pull()", null)
    }
}
